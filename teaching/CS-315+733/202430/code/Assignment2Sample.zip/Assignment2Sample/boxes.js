/*
 * boxes.cpp
 * An exercise in positioning simple boxes using projection/modelview
 * matrices and standard transforms.
 *
 * Adapted for WebGL by Alex Clarke, 2016.
 * Adapted for WebGL2 by Alex Clarke, 2020.
 * Shape class and various fixes by Alex Clarke, 2024
 * Adapted from an anonymous student's first effort and completed by Alex Clarke
 */

//----------------------------------------------------------------------------
// State Variable Setup 
//----------------------------------------------------------------------------

// This variable will store the WebGL rendering context
let gl;

// Variables for Transformation Matrices
let mv = new mat4();
let p = new mat4();
let mvLoc, projLoc;
const multiColour = true;

var numTimesToSubdivide = 3;


//----------------------------------------------------------------------------
// A Simple Drawable Shape Manager Class
// Provided by Alex Clarke for CS315 Lab
//----------------------------------------------------------------------------
class Shape {
   /**
    *  Construct a shape
    */
   constructor() {
      this.type = null;
      this.start = 0;
      this.length = 0;
      this.points = [];
      this.colours = [];
   }

   /** 
    * Adds shape to global points and colour arrays  
    * and calculates draw start index and length
    * 
    * @param type - primitive to draw data with. GL context must exist to refer to this.
    */
   load(type) {
      if (this.points.length != this.colours.length) {
         throw new Error("positions array and colours array are different lengths");
      }
      this.type = type;
      this.start = points.length;
      this.length = this.points.length;
      points = points.concat(this.points);
      colours = colours.concat(this.colours);
   }

   /**
    * Encapsulates code to draw the shape
    */
   draw() {
      gl.drawArrays(this.type, this.start, this.length);
   }
}

// Define a tidy collection of shapes to use
let shapes = {
   wireCube: new Shape(),
   solidCube: new Shape(),
   axes: new Shape(),
   tet: new Shape()
};


//----------------------------------------------------------------------------
// Define Shape Data 
//----------------------------------------------------------------------------

//Some colours to use
let red = vec4(1.0, 0.0, 0.0, 1.0);
let green = vec4(0.0, 1.0, 0.0, 1.0);
let blue = vec4(0.0, 0.0, 1.0, 1.0);
let lightRed = vec4(1.0, 0.5, 0.5, 1.0);
let lightGreen = vec4(0.5, 1.0, 0.5, 1.0);
let lightBlue = vec4(0.5, 0.5, 1.0, 1.0);
let white = vec4(1.0, 1.0, 1.0, 1.0);
let black = vec4(0,0,0,1);
let grey1 = vec4(.75,.75,.75,1);
let grey2 = vec4(.50,.50,.50,1);
let grey3 = vec4(.25,.25,.25,1);
let grey4 = vec4(.10,.10,.10,1);


//Generate Axis Data: use LINES to draw. Three axes in red, green and blue
shapes.axes.points =
   [
      vec4(2.0, 0.0, 0.0, 1.0), //x axis, will be green
      vec4(-2.0, 0.0, 0.0, 1.0),
      vec4(0.0, 2.0, 0.0, 1.0), //y axis, will be red
      vec4(0.0, -2.0, 0.0, 1.0),
      vec4(0.0, 0.0, 2.0, 1.0), //z axis, will be blue
      vec4(0.0, 0.0, -2.0, 1.0)
   ];

shapes.axes.colours =
   [
      green, green,
      red, red,
      lightBlue, lightBlue
   ];


//Define points for a unit cube
let cubeVerts = [
   vec4(0.5, 0.5, 0.5, 1), //0
   vec4(0.5, 0.5, -0.5, 1), //1
   vec4(0.5, -0.5, 0.5, 1), //2
   vec4(0.5, -0.5, -0.5, 1), //3
   vec4(-0.5, 0.5, 0.5, 1), //4
   vec4(-0.5, 0.5, -0.5, 1), //5
   vec4(-0.5, -0.5, 0.5, 1), //6
   vec4(-0.5, -0.5, -0.5, 1), //7
];

//Look up patterns from cubeVerts for different primitive types
//Wire Cube - draw with LINE_STRIP
let wireCubeLookups = [
   0, 4, 6, 2, 0, //front
   1, 0, 2, 3, 1, //right
   5, 1, 3, 7, 5, //back
   4, 5, 7, 6, 4, //right
   4, 0, 1, 5, 4, //top
   6, 7, 3, 2, 6, //bottom
];

//Solid Cube - draw with TRIANGLES, 2 triangles per face
let solidCubeLookups = [
   0, 4, 6, 0, 6, 2, //front
   1, 0, 2, 1, 2, 3, //right
   5, 1, 3, 5, 3, 7,//back
   4, 5, 7, 4, 7, 6,//left
   4, 0, 1, 4, 1, 5,//top
   6, 7, 3, 6, 3, 2,//bottom
];

//Expand Wire Cube data: this wire cube will be white...
for (let i = 0; i < wireCubeLookups.length; i++) {
   shapes.wireCube.points.push(cubeVerts[wireCubeLookups[i]]);
   shapes.wireCube.colours.push(white);
}

//Expand Solid Cube data: each face will be a different shade of grey so you can see
//    the 3D shape better without lighting.
let colourNum = 0;
let colourList = [grey3, grey2, grey1, grey2, white, grey4]; //modified from Lab 3 - it used the 6 red/green/blue type colours
for (let i = 0; i < solidCubeLookups.length; i++) {
   shapes.solidCube.points.push(cubeVerts[solidCubeLookups[i]]);
   shapes.solidCube.colours.push(colourList[colourNum]);
   if (i % 6 == 5) colourNum++; //Switch colour for every face. 6 vertices/face
}


//load data into points and colours arrays - runs once as page loads.
let points = [];
let colours = [];


//----------------------------------------------------------------------------
// Initialization Event Function
//----------------------------------------------------------------------------

window.onload = function init() {
   // Set up a WebGL Rendering Context in an HTML5 Canvas
   let canvas = document.getElementById("gl-canvas");
   gl = canvas.getContext("webgl2");
   if (!gl) {
      canvas.parentNode.innerHTML("Cannot get WebGL2 Rendering Context");
   }

   //
   //  Initialize our data for the Sierpinski Gasket
   //

   // First, initialize the vertices of our 3D gasket
   // Four vertices on unit circle
   // Intial tetrahedron with equal length sides

   var vertices = [
      vec4(0.0000, 0.0000, -1.0000, 1.0),
      vec4(0.0000, 0.9428, 0.3333, 1.0),
      vec4(-0.8165, -0.4714, 0.3333, 1.0),
      vec4(0.8165, -0.4714, 0.3333, 1.0)
   ];

   divideTetra(vertices[0], vertices[1], vertices[2], vertices[3],
      numTimesToSubdivide);

   //  Configure WebGL
   //  eg. - set a clear colour
   //      - turn on depth testing
   gl.viewport(0, 0, gl.drawingBufferWidth, gl.drawingBufferHeight);
   gl.enable(gl.DEPTH_TEST);
   gl.clearColor(0.0, 0.0, 0.0, 1.0);
   gl.enable(gl.CULL_FACE);

   //  Load shaders and initialize attribute buffers
   let program = initShaders(gl, "vertex-shader", "fragment-shader");
   gl.useProgram(program);

   // Load data to draw into combined local arrays
   shapes.axes.load(gl.LINES); // initialized globally - used to help visualize local frame while designing
   shapes.wireCube.load(gl.LINE_STRIP); // initialized globally
   shapes.solidCube.load(gl.TRIANGLES); // initialized globally
   shapes.tet.load(gl.TRIANGLES); //data initialized by divideTetra function above
   
   // Load the data into GPU data buffers and
   // Associate shader attributes with corresponding data buffers
   //***Vertices***
   let vertexBuffer = gl.createBuffer();
   gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
   gl.bufferData(gl.ARRAY_BUFFER, flatten(points), gl.STATIC_DRAW);
   program.aPosition = gl.getAttribLocation(program, "aPosition");
   gl.vertexAttribPointer(program.aPosition, 4, gl.FLOAT, false, 0, 0);
   gl.enableVertexAttribArray(program.aPosition);

   //***colours***
   let colourBuffer = gl.createBuffer();
   gl.bindBuffer(gl.ARRAY_BUFFER, colourBuffer);
   gl.bufferData(gl.ARRAY_BUFFER, flatten(colours), gl.STATIC_DRAW);
   program.aColour = gl.getAttribLocation(program, "aColour");
   gl.vertexAttribPointer(program.aColour, 4, gl.FLOAT, gl.FALSE, 0, 0);
   gl.enableVertexAttribArray(program.aColour);

   // Get addresses of shader uniforms
   projLoc = gl.getUniformLocation(program, "p");
   mvLoc = gl.getUniformLocation(program, "mv");

   //Set up viewport - see WebGL Anti-Patterns link
   //gl.viewport(0, 0, gl.drawingBufferWidth, gl.drawingBufferHeight);

   //Set up projection matrix
   var aspect = canvas.clientWidth / canvas.clientHeight;
   p = perspective(45.0, aspect, 1.0, 15.0); // (fovy, aspect[w/h], near, far)
   //p = ortho(-2.5, 2.5, -2.5, 2.5, 5.0, 15.0); //STEP 9
   // MVnew does the transpose to change to row major matrix
   gl.uniformMatrix4fv(projLoc, gl.FALSE, flatten(transpose(p)));


   mixColourLoc = gl.getUniformLocation(program, "mixColour");
   gl.uniform4fv(mixColourLoc, flatten(white));

   // Register even responders for control buttons
   let open = document.getElementById("open");
   open.addEventListener("click", openit);

   requestAnimationFrame(render);
};


// Global state and event responder function for Cube rendering type
// Selects between solid and wire cubes
// Updates UI to reflect changed state
let s = shapes.solidCube;

// Global state and event responder function to open and close cube
// Changes direction lid of cube tries to move
// Updates UI to reflect changed state
// Limits on cube direction are implemented in the render function
// which also serves as an animation update function rather than
// implementing a separate animation timer (which I know I should do and is demonstrated
// to students in the Robot Arm sample from lab 3)
let o = 0, dir = 1;
function openit(e) {
   dir = -dir;
   if (dir == 1) e.target.innerHTML = "Open Box";
   if (dir == -1) e.target.innerHTML = "Close Box";
}



///////////////////////
// BEGIN CODE BORROWED FROM gasket4.html/gasket4.js
///////////////////////
function triangle(a, b, c, colour) {

   // add colours and vertices for one triangle

   var baseColours = [
      vec4(1.0, 0.0, 0.0, 1.0),
      vec4(0.0, 1.0, 0.0, 1.0),
      vec4(0.0, 0.0, 1.0, 1.0),
      vec4(0.0, 1.0, 1.0, 1.0) // original was black.
   ];

   shapes.tet.colours.push(baseColours[colour]);
   shapes.tet.points.push(a);
   shapes.tet.colours.push(baseColours[colour]);
   shapes.tet.points.push(b);
   shapes.tet.colours.push(baseColours[colour]);
   shapes.tet.points.push(c);
}

function tetra(a, b, c, d) {
   // tetrahedron with each side using
   // a different colour

   triangle(a, c, b, 0);
   triangle(a, d, c, 1); // original green faces of tetraKoch were clockwise and didn't show with backface culling enabled
   triangle(a, b, d, 2);
   triangle(b, c, d, 3);
}

function divideTetra(a, b, c, d, count) {
   // check for end of recursion

   if (count === 0) {
      tetra(a, b, c, d);
   }

   // find midpoints of sides
   // divide four smaller tetrahedra

   else {
      var ab = mix(a, b, 0.5);
      var ac = mix(a, c, 0.5);
      var ad = mix(a, d, 0.5);
      var bc = mix(b, c, 0.5);
      var bd = mix(b, d, 0.5);
      var cd = mix(c, d, 0.5);

      --count;

      divideTetra(a, ab, ac, ad, count);
      divideTetra(ab, b, bc, bd, count);
      divideTetra(ac, bc, c, cd, count);
      divideTetra(ad, bd, cd, d, count);
   }
}
///////////////////////
// END CODE BORROWED FROM gasket4.html/gasket4.js
///////////////////////




//----------------------------------------------------------------------------
// Rendering Event Function
//----------------------------------------------------------------------------
let a = 0;
function render() {
   gl.clear(gl.DEPTH_BUFFER_BIT | gl.COLOR_BUFFER_BIT);

   //Set initial view
   let eye = vec3(1.0, 5.0, 4.0); // where is camera
   let at = vec3(0.0, 0.0, 0.0); // what does camera point at
   let up = vec3(0.0, 1.0, 0.0); // creates orthonormal 

   mv = lookAt(eye, at, up);

   gl.uniformMatrix4fv(mvLoc, false, flatten(transpose(mv)));
   //shapes.axes.draw();


   mv = mult(mv, rotateY(a));
   a+=.5;
   gl.uniformMatrix4fv(mvLoc, false, flatten(transpose(mv)));


   // Draw Tetrahedral Gasket
   gl.uniform4fv(mixColourLoc, flatten(white));
   //gl.drawArrays(gl.TRIANGLES, shapes.axes.length, points.length-shapes.axes.length);
   shapes.tet.draw();


   // Use Cubes to draw the "box" with optionally separately coloured pieces
   //left
   let cubeTF = mult(mv, translate(-.8665, .2357, -.3333));
   cubeTF = mult(cubeTF, scale(.1,1.5142,1.3333));
   gl.uniformMatrix4fv(mvLoc, gl.FALSE, flatten(transpose(cubeTF)));
   if (multiColour == true) {
      gl.uniform4fv(mixColourLoc, flatten(lightRed));
   }
   s.draw();

   //right
   cubeTF = mult(mv, translate(.8665, .2357, -.3333));
   cubeTF = mult(cubeTF, scale( .1, 1.5142, 1.3333));
   gl.uniformMatrix4fv(mvLoc, gl.FALSE, flatten(transpose(cubeTF)));
   if (multiColour == true) {
      gl.uniform4fv(mixColourLoc, flatten(red));
   }
   s.draw();
   
   //bottom
   cubeTF = mult(mv, translate(0, -.5714, -.3333));
   cubeTF = mult(cubeTF, scale(1.833, .1, 1.5333));
   gl.uniformMatrix4fv(mvLoc, gl.FALSE, flatten(transpose(cubeTF)));
   if (multiColour == true) {
      gl.uniform4fv(mixColourLoc, flatten(blue));
   }
   s.draw();

   //top - hinged
   cubeTF = mult(mv, translate(0, 1.0428, -.3333));// place hinge in world
   cubeTF = mult(cubeTF, translate(0, -0.05, -.76665)); //adjust for dimensions of box

   if (dir == 1 && o < 0) o += dir; // update hinge angle if necessary
   if (dir == -1 && o > -135) o += dir;
   cubeTF = mult(cubeTF, rotateX(o)); // the hinge itself

   cubeTF = mult(cubeTF, translate(0, 0.05, .76665)); // place hinge relative to box
   cubeTF = mult(cubeTF, scale(1.833, .1, 1.5333)); // size top of box
   gl.uniformMatrix4fv(mvLoc, gl.FALSE, flatten(transpose(cubeTF)));
   if (multiColour == true) {
      gl.uniform4fv(mixColourLoc, flatten(lightBlue));
   }
   s.draw();

   //back
   cubeTF = mult(mv, translate(0, .2357, -1.05));
   cubeTF = mult(cubeTF, scale(1.833, 1.5142, .1));
   gl.uniformMatrix4fv(mvLoc, gl.FALSE, flatten(transpose(cubeTF)));
   if (multiColour == true) {
      gl.uniform4fv(mixColourLoc, flatten(green));
   }
   s.draw();

   //front
   cubeTF = mult(mv, translate(0, .2357, .3833));
   cubeTF = mult(cubeTF, scale(1.833, 1.5142, .1));
   gl.uniformMatrix4fv(mvLoc, gl.FALSE, flatten(transpose(cubeTF)));
   if (multiColour == true) {
      gl.uniform4fv(mixColourLoc, flatten(lightGreen));
   }
   s.draw();

   requestAnimationFrame(render); //Animate!!!
}