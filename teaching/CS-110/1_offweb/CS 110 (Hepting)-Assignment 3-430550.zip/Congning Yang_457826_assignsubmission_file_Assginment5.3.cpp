//**************************************************************************
//
// Student name: Congning Yang
//
// Student number: 200350457
//
// Assignment number: Assignment #3 (listing 5.3)
//
// Program name: CS 110
//
// Date written: March 11th, 2015
//
// Problem statement:Modify Listing 5.3 so that the computer guesses a number that the user provides (switch the roles of user and computer from Listing 5.3). Write the guesses from the program and the user's answers to a file. Print a message if the computer detects that the user has not been trustworthy in her answers.
//
// Input: number,answer
//
// Output1: "Please input a number from 0-100."
// Output2: "This is a valid number."
// Output3: "The computer guessed:"
// Output4: "Please tell the computer if its guess is too high or too low." 
// Output5: "The guess was too high." || "The guess was too low." || "You guess is right." || "You are lying."
//
// Algorithm 1: Set up the limit of the number (0-100). Upperlimit is 100, lower limit is 0. IF the user inputs the number that is not in this limit, the program cannot run the next step. If the user inputs a valid number, the program can run the next step.
// Algorithm 2: After the user inputs a valid number, the program will enter a loop: The computer first guess 50 and then the user will tell if its guess is too high or too low.
// Algorithm 3: If the guess is lower than the number, the user should input "low"; if the guess is higher than the number, the user should input"high", if the guess is right, the user should input "right"
// Algorithm 4: In the case of "guess is lower than the number": if the user inputs higher, the computer will diplays" You are lying.". In the case of guess is higher than the number": if the user inputs lower, the computer will display "You are lying."
// Algorithm 5: The program ends until the computer's guess is right and the program will store the data that the computer's guess.
//
// Major variables: number, upperlimit, lowerlimit, answer, number
//
// Assumptions: The computer should guess a number from 0-100, any number is outside this limit will be seen as invalid and the program cannot run. The computer also should detect that if the user is lying or not.
//
// Program limitations: The number that the user input should between 0-100.
//
// Comment: The code I created can run succefully 
//**************************************************************************
#include <iostream>
#include <cstdlib>
#include <fstream>
#include <string>
#include <ctime> // Used for the time function
using namespace std;


int main()
{
	ofstream outData;
	outData.open("outputfile.txt");//output file is for storing the data
	int number;
	int upperlimit = 100;
	int lowerlimit = 0;
	string answer;
	cout << "Please input a number from 0-100\n";
	cin >> number;
	outData << number << endl;
	if (number >= 0 && number <= 100)
	{
		cout << "This is a valid number\n"; //The computer has to identify the number that the user enter is valid or invalid
		outData << "This is a valid number\n";
		int guess = (upperlimit + lowerlimit) / 2;
		outData << "The computer guessed: " << guess << endl;
		do
		{
			cout << "The computer guessed:" << guess << endl;
			cout << "Please tell the computer if its guess is too high or too low\n";
			cin >> answer;
			if (answer == "high")
			{
				if (guess > number)
				{
					upperlimit = guess;
					cout << "The guess was too high\n";
					outData << "too high\n";
					guess = (upperlimit + lowerlimit) / 2;
					outData << guess << endl; //The user's guess is stored
				}
				else if (guess < number)
				{
					cout << "You are lying!\n";
					outData << "You are lying!\n";
					return 0;
				}
				else if (guess == number)
				{
					cout << "Your guess is right!" << endl;
					outData << guess << endl;
					outData << "Your guess is right!" << endl;
				}
			}
			else if (answer == "low")
			{
				if (guess < number)
				{
					lowerlimit = guess;
					cout << "The guess was too low\n";
					outData << "too low\n";
					guess = (upperlimit + lowerlimit) / 2;
					outData << guess << endl;
				}
				else if (guess > number)
				{
					cout << "You are lying!\n";
					outData << "You are lying!\n";
					return 0;
				}
				else if (guess == number)
				{
					cout << "Your guess is right!" << endl;
					outData << guess << endl;
					outData << "Your guess is right!" << endl;
				}
			}
		} while (guess != number);
		if (guess == number)
		{
			cout << "The computer guessed: " << guess << endl;
			cout << "You guessed right!!\n";
			outData << "You guessed right!!\n";
		}
		return 0;
	}
}