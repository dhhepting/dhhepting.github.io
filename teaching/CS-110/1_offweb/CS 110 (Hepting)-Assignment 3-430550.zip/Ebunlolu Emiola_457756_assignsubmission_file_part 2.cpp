//**************************************************************************
// Student name: EMIOLA EBUNLOLU
//
// Student number: 200348870
//
// Assignment number: #3
//
// Program name: Random integers.
//
// Date written: 09-03-15
//
// Problem statement: Input addition, subtraction and multipulication
//
// Input: Random number for calculating the addition, subtraction and multipulication.
// Major variables: int answer1, int answer2 and int answer3.
//
// Assumptions:
//
// Program limitations: calcalating the integers.
//
// Output: addition, subtraction and multipulication of random integer.
//
// Algorithm: Ask the user to prompt addition, subtraction, multipulaction and the time spent taking the test to run the program.
//
//**************************************************************************


#include <iostream>
#include <ctime>                    // Needed for time functions
#include <cstdlib>                  // Needed for srand and rand functions
using namespace std;

int main()
{
	int correctcount = 0;                // Count the number of correct answers.
	int count = 0;                       // Count the number of questions.
	long startTime = time(0);
	const int NUMBER_OF_QUESTION = 5;
	int answer1;
	int answer2;
	int answer3;
	srand(time(0));                        // Set a random seed.

	while (count < NUMBER_OF_QUESTION)
	{
		
		// Generate random integer between 0 && 9
		int number1 = rand() % 10;
		int number2 = rand() % 10;

		// Generate a random operator (-, +, *)

		// Addition operator
		cout << "what is " << number1 << "+" << number2 << "?";
		int correctAnswer1 = number1 + number2;
		cin >> answer1;

		// Subtraction operator
		cout << "what is " << number1 << "-" << number2 << "?";
		int correctAnswer2 = number1 - number2;
		cin >> answer2;

		// Mulipulication operator
		cout << "what is " << number1 << "*" << number2 << "?";
		int correctAnswer3 = number1 * number2;
		cin >> answer3;

		// Display result
		if ((correctAnswer1 == answer1) && (correctAnswer2 == answer2) && (correctAnswer3 == answer3))
				{
					cout << "Your addition is correct!\n";
					correctcount++;
				}
				else if (number1 + number2 != answer1)
					cout << "Your addition is wrong!\n" << number1 << "+" << number2 << "should be " << (number1 + number2) << endl;
		if (correctAnswer2 == answer2)
		{
			cout << "Your subtraction is correct!\n";
			correctcount++;
		}
				else if (number1 - number2 != answer2)
				cout << "Your subtraction is wrong!\n" << number1 << "-" << number2 << "should be " << (number1 - number2) << endl;
		if (number1 * number2 == answer3)
				{
					cout << "Your multiplication is correct!\n";
					correctcount++;
				}
		else if (number1 * number2 != answer3)
			cout << "Your multiplication is wrong!\n" << number1 << "*" << number2 << "should be " << (number1 * number2) << endl;

		// increase the count
		count++;
	}

	long endTime = time(0);
	long testTime = endTime - startTime;

	cout << "Number of answers you got right is " << correctcount << "\nTest time is " << testTime << "seconds\n";

	return 0;
}