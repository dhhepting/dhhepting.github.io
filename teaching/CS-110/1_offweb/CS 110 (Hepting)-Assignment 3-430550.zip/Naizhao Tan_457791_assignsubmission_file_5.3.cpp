/*
Name: Naizhao Tan
Student Number: 200353140
Assignment Number: 3
Program name: Assignment 3
Data: Mar 08 2015
Problem Statement:
Modify Listing 5.3 so that the computer guesses a number that the user provides (switch the roles of user and computer from Listing 5.3). 
Write the guesses from the program and the user's answers to a file. 
Print a message if the computer detects that the user has not been trustworthy in her answers. 
Use the technique that we discussed in class today.

Input: A number
Output: Computer's guess number
Algorithm:
Step 1: Input a number. 
Step 2: Computer will make a guess about the number
Step 3: User will make the range smaller
Step 4: Computer will find the number

Major variables:
givenNumber: The number user give
judge: Used to locate the range of the number
max: The biggest number it could be
min: The smallest number it could be
guess: Computer's guess number
*/


#include <iostream>
#include <cstdlib>
#include <ctime> // Needed for the time function
using namespace std;

int main()
{
	// Generate a random number to be guessed
	srand(time(0));
	int givenNumber;
	int judge, max = 101, min = -1;
	do{
		cout << "Give a magic number between 0 and 100" << endl;
		cin >> givenNumber;
		if (givenNumber <= 100 && givenNumber >= 0){
			break;
		}
		else{
			cout << "Please give a right number" << endl;
			continue;
		}
	}while (givenNumber > 100 || givenNumber < 0);


	int guess = rand() % 101;
	do{
		if (guess == givenNumber){
			break;
		}
		cout << "Computer's guess is " << guess << endl;
		cout << "Enter 1: too high, enter 2: too low" << endl;
		cin >> judge;
		if (judge == 1 && guess > givenNumber){
			max = guess;

		}
		else if (judge == 2 && guess < givenNumber){
			min = guess;
		}
		else{
			cout << "Please choose a right option" << endl;
		}
		guess = min + 1 + rand() % (max - min - 1);
	} while (guess != givenNumber);
	cout << "The number is " << guess << endl;
	return 0;
}