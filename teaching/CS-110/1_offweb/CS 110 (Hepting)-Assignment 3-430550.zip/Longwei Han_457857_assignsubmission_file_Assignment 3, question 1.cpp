//**************************************************************************
//
// Student name: Longwei Han
//
// Student number: 200313136
//
// Assignment number: num3
//
// Program name: guess number
//
// Date written: 10 Mar 2015
//
// Problem statement: Write the guesses from the program and the user's answers to a file. Print a message if the computer detects that the user has not been trustworthy in her answers.
//
// Input: the number between 0 and 100.
//
// Output: the guess is trustworthy or not.
//
// Algorithm: First we need to enter a number between 0 and 100.
//			  The program will ask is this number high or low.
//			  If the guess will be three type of output, the guess is too high, the guess is too low and  you haven't been trustworthy.
//			  The program will continue to process numbers until the user enters the letter q.
//
// Major variables: number, low, high.
//
// Assumptions: we assume user input a number between 0 and 100.
//
// Program limitations:  it works only with 0 to 100, and the output is limit with two main option.
//                       if the input is not belong to 0 to 100, the program will report it.
//**************************************************************************
#include <iostream>
#include <cstdlib>
#include <fstream>
#include <string>
#include <ctime> 
using namespace std;

int main()
{
	ofstream outData;
	outData.open("outputfile.txt");
	srand(time(0));
	int number;
	string response;
	cout << "Please input a number from 0-100\n";
	cin >> number;
	outData << number << endl;
	if (number >= 0 && number <= 100)
	{
		cout << "This is a valid number\n";
		outData << "This is a valid number\n";
		int guess = rand() % 101;
		cout << "The computer guessed: " << guess << endl;
		outData << "The computer guessed: " << guess << endl;
		while (guess != number)
		{
			cout << "The computer guessed is : " << guess << endl;
			cout << "Please tell the computer if its guess is high or low\n";
			cin >> response;
			if (response == "high")
			{
				if (guess > number)
				{
					cout << "The guess was too high\n";
					outData << "TOO HIGH\n";
					guess = rand() % (guess + 1);
					outData << guess << endl;
				}
				else if (guess < number)
				{
					cout << "You haven't been trustworthy!!!\n";
					outData << "You haven't been trustworthy!!!\n";
					return 0;
				}
				else if (guess == number)
				{
					cout << "Good work you guessed right!" << endl;
					outData << guess << endl;
					outData << "Good work you guessed right!" << endl;
				}
			}
			else if (response == "low")
			{
				if (guess < number)
				{
					cout << "The guess was too low\n";
					outData << "too low\n";
					guess = (100 + guess) / 2;
					cout << "The computer guessed: " << guess << endl;
					outData << guess << endl;
				}
				else if (guess > number)
				{
					cout << "You haven't been trustworthy!!!\n";
					outData << "You haven't been trustworthy!!!\n";
					return 0;
				}
				else if (guess == number)
				{
					cout << "Good work you guessed right!" << endl;
					outData << guess << endl;
					outData << "Good work you guessed right!" << endl;
				}
			}

		}
	}
	return 0;
}