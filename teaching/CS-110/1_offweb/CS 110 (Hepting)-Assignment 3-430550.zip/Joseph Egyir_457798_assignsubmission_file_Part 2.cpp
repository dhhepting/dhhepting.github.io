// Joseph Egyir
// 200357099
// March 11, 2015
#include <iostream>
#include <ctime> // Needed for time function
#include <cstdlib> // Needed for the srand and rand functions
using namespace std;

int mama()
{
	int correctCount = 0; // Count the number of correct answers
	int count = 0; // Count the number of questions
	long startTime = time(0);
	const int NUMBER_OF_QUESTIONS = 5;
	int i;
	int j;
	int k;
	long questiontime;
	long questiontime2;
	long questiontime3;

	srand(time(0)); // Set a random seed
	
	
	while (count < NUMBER_OF_QUESTIONS)
	{
		// 1. Generate two random single-digit integers
		int number1 = rand() % 10;
		int number2 = rand() % 10;
		int num1 = rand() % 100;
		// 2. If number1 < number2, swap number1 with number2
		if (number1 < number2)
		{
			int temp = number1;
			number1 = number2;
			number2 = temp;
		}
		{
			if (num1 < 33)
			{
				long startTime = time(0);
				cout << "What is " << number1 << " - " << number2 << "? ";
				int answer;
				cin >> answer;

				// 4. Grade the answer and display the result
				if (number1 - number2 == answer)
				{

					cout << "You are correct!\n";
					correctCount++;
				}
				else
				{
					for (i = 1; number1 - number2 != answer; i++)
					{
						cout << "Answer is incorrect. What is " << number1 << " - " << number2 << "? ";
						cin >> answer;
						cout << endl;
					}
					cout << "Your number of attempts was: " << i << " attempts" << endl; 
				}
					long endTime = time(0);
					questiontime = endTime - startTime;
				cout << "question time is "
					<< questiontime << " seconds\n";
			}

			else if (num1 >= 33 && num1 <= 66)
			{
				long startTime = time(0);
				cout << "What is " << number1 << " + " << number2 << "? ";
				int answer2;
				cin >> answer2;

				// 4. Grade the answer and display the result
				if (number1 + number2 == answer2)
				{
					cout << "You are correct!\n";
					correctCount++;
				}
				else
				{
					for (j = 1; number1 + number2 != answer2; j++)
					{
						cout << "Answer is incorrect. What is " << number1 << " + " << number2 << "? ";
						cin >> answer2;
						cout << endl;
					}
					cout << "Your number of attempts was: " << j << " attempts" << endl;
				}
				long endTime = time(0);
					questiontime2 = endTime - startTime;
				cout << "question time is "
					<< questiontime2 << " seconds\n";

				
		}

		else if (num1 > 66)
		{
			long startTime = time(0);
			cout << "What is " << number1 << " x " << number2 << "? ";
			int answer3;
			cin >> answer3;

			// 4. Grade the answer and display the result
			if (number1 * number2 == answer3)
			{
				cout << "You are correct!\n";
				correctCount++;
			}
			else
			{
				for (k = 1; number1 * number2 != answer3; k++)
				{
					cout << "Answer is incorrect. What is " << number1 << " x " << number2 << "? ";
					cin >> answer3;
					cout << endl;
				}
				cout << "Your number of attempts was: " << k << " attempts" << endl;
			}
			long endTime = time(0);
			questiontime3 = endTime - startTime;
			cout << "question time is "
				<< questiontime3 << " seconds\n";
		}
	}
				count++;
				cout << count << endl; 
		}
	

	long endTime = time(0);
	long testTime = endTime - startTime;

	cout << "Questions answered correctly in first attempt: " << correctCount << "\nTest time is "
		<< testTime << " seconds\n";
	cout << "number of total attempts made: " << i + j + k << endl;
	cout << endl;
	cout << "the average number of attempts made per question are: " << (i + j + k) / 5 << endl;
	cout << endl; 
	cout << "The average time to attempt each question is: " << testTime / 5 << " seconds" << endl;
	return 0;
}