//**************************************************************************
//
// Student name: Longwei Han
//
// Student number: 200313136
//
// Assignment number: num3
//
// Program name: calculation
//
// Date written: 10 Mar 2015
//
// Problem statement: Write the program that user answer the question correctly before proceeding and offer addition and multiplication questions (at random).
//                 print out the number of attempts on the question and the time taken. At the end of the quiz, print the average number of attempts and the average time taken.
// 
// Input: answer the question.
//
// Output: the answer correct or wrong,
//         Total number of attempts, Average number of attempts, Total amount of time taken, Average time taken
//
// Algorithm: The user will answer the question five times, if it is wrong, it will answer again.		
//			  
// Major variables: correct_answer1, correct_answer2, correct_answer3
//
// Assumptions: we assume user answer the question.
//
// Program limitations:  it works only five times
//                       if the user keep answer wrong, the program will keep ask the question until user answer right with five times.
//**************************************************************************

#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;

int main()
{
	int correctCount = 0;
	int count1 = 0;
	int count2 = 0;
	int count3 = 0;
	int totalattempts = 0;
	long average = 0;
	long timetaken1 = 0;
	long timetaken2 = 0;
	long timetaken3 = 0;
	long starttime1 = time(0);
	long starttime2 = time(0);
	long starttime3 = time(0);
	long averagetime = 0;
	long totaltime = 0;

	srand(time(0));

	for (int i = 0; i < 5; i++)
	{
		int type = rand() % 3;
		if (type == 0)
		{
			long starttime1 = time(0);
			int number1 = rand() % 10;
			int number2 = rand() % 10;
			if (number1 < number2)
			{
				int temp = number1;
				number1 = number2;
				number2 = temp;
			}
			cout << "What is " << number1 << " - " << number2 << "?\n ";
			int correct_answer1 = -1;

			while (number1 - number2 != correct_answer1)
			{
				cin >> correct_answer1;
				count1++;

				if (number1 - number2 != correct_answer1)
				{
					cout << "Sorry, you are wrong, please try again\n";
				}
				else
				{
					cout << "You are correct\n";
				}
			}

			long endtime1 = time(0);
			cout << "Number of attempts: " << count1 << "\n";
			timetaken1 += endtime1 - starttime1;
			cout << "Time taken: " << timetaken1 << "\n";
		}

		else if (type == 1)
		{
			long starttime2 = time(0);
			int number11 = rand() % 10;
			int number22 = rand() % 10;
			cout << "What is " << number11 << " + " << number22 << "?\n ";
			int correct_answer2 = -1;

			while (number11 + number22 != correct_answer2)
			{
				cin >> correct_answer2;
				count2++;

				if (number11 + number22 != correct_answer2)
				{
					cout << "Sorry, you are wrong, please try again\n";
				}
				else
				{
					cout << "You are correct\n";
				}
			}

			long endtime2 = time(0);
			cout << "Number of attempts; " << count2 << "\n";
			timetaken2 += endtime2 - starttime2;
			cout << "Time taken: " << timetaken2 << "\n";
		}
		else if (type == 2)
		{

			long starttime3 = time(0);
			int number111 = rand() % 10;
			int number222 = rand() % 10;
			cout << "What is " << number111 << " * " << number222 << "?\n ";
			int correct_answer3 = -1;


			while (number111 * number222 != correct_answer3)
			{
				cin >> correct_answer3;
				count3++;
				if (number111 * number222 != correct_answer3)
				{
					cout << "Sorry, you are wrong, please try again\n";
				}
				else
				{
					cout << "Your are correct\n";
				}
			}

			long endtime3 = time(0);
			cout << "Number of attempts: " << count3 << "\n";
			timetaken3 += endtime3 - starttime3;
			cout << "Time taken: " << timetaken3 << "\n";
		}
		cout << endl;
	}

	totalattempts = totalattempts + count1 + count2 + count3;
	cout << "Total number of attempts: " << totalattempts << endl;
	average = totalattempts / 5;
	cout << "Average number of attempts: " << average << endl;
	totaltime = totaltime + timetaken1 + timetaken2 + timetaken3;
	cout << "Total amount of time taken: " << totaltime << endl;
	averagetime = totaltime / 5.0;
	cout << "Average time taken: " << averagetime << endl;
	return 0;
}