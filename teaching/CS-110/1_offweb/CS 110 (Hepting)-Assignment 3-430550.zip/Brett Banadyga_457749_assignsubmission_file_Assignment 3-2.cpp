#include <iostream>
#include <ctime>
#include <cstdlib> 
using namespace std;

int main()
{
	int correctCount = 0;
	int count = 0;
	long startTime = time(0);
	const int NUMBER_OF_QUESTIONS = 5;
	int answer = -1;

	srand(time(0));

	while (count < NUMBER_OF_QUESTIONS)
	{
		int number1 = rand() % 10;
		int number2 = rand() % 10;
		int operationselector = rand() % 3;

		if (number1 < number2)
		{

			int temp = number1;
			number1 = number2;
			number2 = temp;

		}

		if (operationselector == 0)
		{

			int count1 = 0;
			long startTime1 = time(0);
			while (answer != number1 - number2)
			{

				cout << "What is " << number1 << " - " << number2 << "? " << endl;
				cin >> answer;
				count1++;
			}

			if (number1 - number2 == answer)
			{

				cout << "You are correct!\n";
				cout << "Number of attempts for that question was: " << count1 << endl;
				correctCount++;

			}

			long endTime1 = time(0);
			long questionTime1 = endTime1 - startTime1;
			cout << "The time taken for that question was: " << questionTime1 << " seconds" << endl;

		}

		if (operationselector == 1)

		{
			int count2 = 0;
			long startTime2 = time(0);

			while (answer != number1 + number2)

			{

				cout << "What is " << number1 << " + " << number2 << "? ";
				cin >> answer;
				count2++;

			}

			if (number1 + number2 == answer)
			{

				cout << "You are correct!\n";
				cout << "Number of attempts for that question was: " << count2 << endl;
				correctCount++;

			}

			long endTime2 = time(0);
			long questionTime2 = endTime2 - startTime2;
			cout << "The time taken for that question was: " << questionTime2 << " seconds" << endl;

		}

		if (operationselector == 2) // operationselector 2 is equivalent to multiplication

		{

			int count3 = 0;
			long startTime3 = time(0);

			while (answer != number1 * number2)
			{

				cout << "What is " << number1 << " * " << number2 << "? ";
				cin >> answer;
				count3++;
			}

			if (number1 * number2 == answer)
			{
				cout << "You are correct!\n";
				cout << "Number of attempts for that question was: " << count3 << endl;
				correctCount++;

			}

			long endTime3 = time(0);
			long questionTime3 = endTime3 - startTime3;
			cout << "The time taken for that question was: " << questionTime3 << " seconds" << endl;

		}

		// Increase the count
		count++;
	}

	long endTime = time(0);
	long testTime = endTime - startTime;

	cout << "Correct count is " << correctCount << "\nTest time is "
		<< testTime << " seconds\n";

	return 0;
}