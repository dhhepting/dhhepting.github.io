#include <iostream>
#include <cmath>
#include <string>
#include <fstream>
using namespace std;

int main ()
{
	int nLowerBound = -1;			//Declaring the necessary variables. The two bounds are used to keep track of which 
	int nUpperBound = 101;			//numbers have been ruled out. nGuess will be the computers current guess. sResponse 
	int nGuess = 50;				//is used to store the user's response. nBreakLoop is used to terminate the guessing 
	string sResponse = " ";			//loop once the answer is found or the user has been found to be lying. An integer is
	int nBreakLoop = -1;			//used instead of a boolean so the loop can end with different conditions.

	ofstream outData;							//Declaring and binding the output stream for the text file.

	outData.open("User_Guesses.txt");

	cout << "Please choose a number between 0 and 100." << endl;

	while (nBreakLoop < 0)
	{
		nGuess = ceil((nLowerBound + nUpperBound)/2.0);			//nGuess is set to the average of the upper and lower 
																//bounds. The program was wirtten on an older compiler, 
																//so ceil() is used to substitute round().
		
		cout << "Is your number bigger, smaller, or equal to " << nGuess << "?\n<Bigger, Smaller, Equal>" << endl;
		cin >> sResponse;

		if (sResponse == "Bigger" || sResponse == "bigger")				//If the response given is "bigger" or "smaller",
			nLowerBound = nGuess;										//then the upper or lower bound is changed to 
																		//reflect the new range. If the response is 
		else if (sResponse == "Smaller" || sResponse == "smaller")		//"equal", the loop terminates with a 0. If the 
			nUpperBound = nGuess;										//response is anything else, nothing happens.

		else if (sResponse == "Equal" || sResponse == "equal")
			nBreakLoop = 0;

		else
			cout << "Invalid answer. Please try again." << endl;

		outData << nGuess << "  " << sResponse << endl;				//Save the guess and response to output file.

		if ((nLowerBound + 2) > nUpperBound)			//If there is no number between the upper and lower bounds (ie. 
			nBreakLoop = 1;								//the difference between them is 1 or less), then at least one 
														//input must be incorrect , so the loop terminates with a 1.
		cout << endl;
	}
	
	switch (nBreakLoop)													//If nBreakLoop is 0, the correct guess was 
	{																	//found. Output this to both the console and
	case 0: cout << "Your number was " << nGuess << "!" << endl;		//the output file. If nBreakLoop is 1, a question
		outData << "User's number was " << nGuess << endl;				//was answered wrong. Output this to both the
		break;															//console and the output file.
	case 1: cout << "An incorrect answer has been given." << endl;
		outData << "An incorrect answer was given." << endl;
		break;
	}
	
	return 0;
}