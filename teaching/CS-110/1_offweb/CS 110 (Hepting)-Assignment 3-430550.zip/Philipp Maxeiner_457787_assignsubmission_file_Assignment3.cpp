//**************************************************************************
//
// Student name: Philipp Maxeiner
//
// Student number: 200343181
//
// Assignment number: 3
//
// Program name: Modified Listing 5.3
//
// Date written: March 11 / 2015
//
// Problem statement: Write a program where the computer guesses a random number
//
// Input: Random number generated at the beginning of the program
//
// Output: The computer will guess until it is correct
//
// Algorithm: Write a program that allows the computer to guess what number has been randomly generated
// between 0 and 100 (inclusive). The results should be sent to an output file and hints can be given if
// the computer is guessing too high or too low
//
// Major variables: compGuess, number, upperLimit, lowerLimit
//
// Assumptions: The computer will analyze it's data to narrow down the range of numbers until the correct
// number is guessed
//
// Program limitations: 
//**************************************************************************





#include <iostream>
#include <cstdlib>
#include <ctime> // Needed for the time function
#include <fstream>
using namespace std;

int main()
{
  // Generate a random number to be guessed
  srand(time(0));
  int number = rand() % 101;

  cout << "A random number between 0 and 100 has been selected. Can the computer guess it?" << endl;

  // A file is created for the storage of the computer's guesses
  ofstream outData;
  outData.open ("output.txt");
  
  // Variable declaration for the computers' guess
  // This ensures that the loop will run at least once because -1 is not within 0 - 100
  int compGuess = -1;
  
  // Upper and Lower limits will help to narrow down the guesses
  int lowerLimit = 0;
  int upperLimit = 100;
 
  // A loop is used until the computer guesses correctly
  while (compGuess != number)
  {
    int range = upperLimit - lowerLimit;
    compGuess = rand() % range;       // The computer randomly generates a number
    
    
    outData << "The computer guessed: " << compGuess << endl;           // The guess is recorded to the outData stream
    cout << "The computer guessed: " << compGuess << endl;
    if (compGuess == number)
      {
          outData << "Yes, the number is " << number << endl;
          cout << "Yes, the number is " << number << endl;
      }
    else if (compGuess > number)
      {
          outData << "Your guess is too high" << endl;
          cout << "Your guess is too high" << endl;
          range = compGuess - lowerLimit;
      }
    else
      {
          outData << "Your guess is too low" << endl;
          cout << "Your guess is too low" << endl;
          range = upperLimit - compGuess;
      }
  } // End of loop

  return 0;
}