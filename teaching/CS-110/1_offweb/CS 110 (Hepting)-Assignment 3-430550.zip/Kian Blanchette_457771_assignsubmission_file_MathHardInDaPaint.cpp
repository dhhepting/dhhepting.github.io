// Kian Blanchette
// 200354600
// Assignment #3
// MathHardInDaPaint.cpp
// 10 March 2015
// Problem Statement: Write a program that asks the user five random math questions, either addition, subtraction, or multiplication. Keep track of how many
//					  attempts and how much time the user takes. Print the number of attempts and time taken on each question. At the end display the average
//					  time taken as well as the average number of attempts on each question.
// Input: The program takes input from the user during the quiz in the form of answers to simple math problems. It also takes input of times and attempts from a
//		  file to compute the averages at the end.
// Output: The program outputs questions to the user as well as information on how the user did on each question. It also stores that info on a file so it can be 
//		   accessed later to compute the averages.
// Algorithm: Initialize the count at 0 and set the number of questions to 5. Loop random math questions until the count reaches 5, but don't increase the count 
//			  until the user gets the question correct. For each question display the number of attempts and time taken to the user and write that data to a file 
//			  called "data.txt." When the count reaches 5, exit the loop and read the data from the file "data.txt." Use this data to compute the averages and 
//			  display this information to the user.
// Major Variables: count - The number of questions answered successfully.
//					NUMBER_OF_QUESTIONS - The number of questions. This is set at 5.
//					number1, number2 - The two randomly generated numbers to be used in the math questions.
//					question - A randomly generated number that determines what type of question will be asked.
//					startTimei, endTimei - The start times and total times for each question type where i = 0, 1, 2.
//					attempti - The number of attempts for a given question type where i = 0, 1, 2.
//					ni - The numbers read from data.txt where i = 0, 1, 2, ... , 9.
//					aveAttempts, aveTime - The average number of attempts per question and the average amount of time per question, respectively.
// Assumptions: The program assumes the user will eventually get all the questions correct; otherwise, it loops forever.
// Program Limitations: If the user enters something that isn't an integer it goes into an infinite loop for some reason.
#include <iostream>
#include <ctime> 
#include <cstdlib> 
#include <fstream>
using namespace std;

int main()
{
	int count = 0;
	const int NUMBER_OF_QUESTIONS = 5;

	ofstream outData;
	outData.open("data.txt");

	srand(time(0));

	while (count < NUMBER_OF_QUESTIONS)
	{

		int number1 = rand() % 10;
		int number2 = rand() % 10;
		int question = rand() % 3;

		if (number1 < number2)
		{
			int temp = number1;
			number1 = number2;
			number2 = temp;
		}

		if (question == 0)
		{
			long startTime0 = time(0);
			long endTime0;

			cout << "What is " << number1 << " - " << number2 << "? ";
			int answer;
			cin >> answer;

			int attempt0 = 1;

			if (number1 - number2 == answer)
			{
				cout << "You are correct!\n";
				cout << "Number of attempts: " << attempt0 << endl;
				outData << attempt0 << endl;

				endTime0 = time(0) - startTime0;
				cout << "Time taken: " << endTime0 << " seconds." << endl << endl;
				outData << endTime0 << endl;
			}
			while (number1 - number2 != answer)
			{
				cout << "Wrong, old sport! Try it again!" << endl;
				cout << "What is " << number1 << " - " << number2 << "? ";
				cin >> answer;
				attempt0++;

				if (number1 - number2 == answer)
				{
					cout << "You are correct!\n";
					cout << "Number of attempts: " << attempt0 << endl;
					outData << attempt0 << endl;

					endTime0 = time(0) - startTime0;
					cout << "Time taken: " << endTime0 << " seconds." << endl << endl;
					outData << endTime0 << endl;
				}
			}
			count++;
		}
		else if (question == 1)
		{
			long startTime1 = time(0);
			long endTime1;

			cout << "What is " << number1 << " + " << number2 << "? ";
			int answer;
			cin >> answer;

			int attempt1 = 1;

			if (number1 + number2 == answer)
			{
				cout << "You are correct!\n";
				cout << "Number of attempts: " << attempt1 << endl;
				outData << attempt1 << endl;

				endTime1 = time(0) - startTime1;
				cout << "Time taken: " << endTime1 << " seconds." << endl << endl;
				outData << endTime1 << endl;
			}
			while (number1 + number2 != answer)
			{
				cout << "Wrong, old sport! Try it again!" << endl;
				cout << "What is " << number1 << " + " << number2 << "? ";
				cin >> answer;
				attempt1++;

				if (number1 + number2 == answer)
				{
					cout << "You are correct!\n";
					cout << "Number of attempts: " << attempt1 << endl;
					outData << attempt1 << endl;

					endTime1 = time(0) - startTime1;
					cout << "Time taken: " << endTime1 << " seconds." << endl << endl;
					outData << endTime1 << endl;
				}
			}
			count++;
		}
		else
		{
			long startTime2 = time(0);
			long endTime2;

			cout << "What is " << number1 << " * " << number2 << "? ";
			int answer;
			cin >> answer;

			int attempt2 = 1;

			if (number1 * number2 == answer)
			{
				cout << "You are correct!\n";
				cout << "Number of attempts: " << attempt2 << endl;
				outData << attempt2 << endl;

				endTime2 = time(0) - startTime2;
				cout << "Time taken: " << endTime2 << " seconds." << endl << endl;
				outData << endTime2 << endl;
			}
			while (number1 * number2 != answer)
			{
				cout << "Wrong, old sport! Try it again!" << endl;
				cout << "What is " << number1 << " * " << number2 << "? ";
				cin >> answer;
				attempt2++;

				if (number1 * number2 == answer)
				{
					cout << "You are correct!\n";
					cout << "Number of attempts: " << attempt2 << endl;
					outData << attempt2 << endl;

					endTime2 = time(0) - startTime2;
					cout << "Time taken: " << endTime2 << " seconds." << endl << endl;
					outData << endTime2 << endl;
				}
			}
			count++;
		}
	}
	int n1, n2, n3, n4, n5, n6, n7, n8, n9, n0;
	ifstream inData;
	inData.open("data.txt");
	inData >> n1 >> n2 >> n3 >> n4 >> n5 >> n6 >> n7 >> n8 >> n9 >> n0;

	double aveAttempts = (n1 + n3 + n5 + n7 + n9) / 5.0;
	double aveTime = (n2 + n4 + n6 + n8 + n0) / 5.0;
	cout << "Average number of attempts: " << aveAttempts << endl;
	cout << "Average time per question: " << aveTime << endl;

	return 0;
}