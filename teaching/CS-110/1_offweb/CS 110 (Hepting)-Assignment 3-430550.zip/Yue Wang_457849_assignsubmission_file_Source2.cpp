// *********************************************************
//
// Student name: Yue Wang
// Studnet number: 200350793
// Assignment number: 3 part 2 
// Program name: source2.cpp
// Date written: March 11th, 2015
// Problem statement: user must answer the question correctly before proceeding. Also, your program should offer addition and multiplication questions (at random). 
//                    For each question, print out the number of attempts on the question and the time taken. At the end of the quiz, print the average number of attempts and the average time taken. 
// Input: answer.
// Output: correct attempts and tital time
// Algorithm: If-else and srang rand
// Major variables: wrongmul, wrongadd, wrongsub, attempt, starttime, endtime, addtime, 
// Assumptions: None
// Program limitations: None
//
//****************************************************************

#include <iostream>
#include <ctime> // Needed for time function
#include <cstdlib> // Needed for the srand and rand functions

using namespace std;
int main()
{
	int wrongmul = 0;//count the wrng question while using "*"multiplication
	int wrongadd = 0;//count the wrng question while using "+"addition
	int wrongsub = 0;//count the wrng question while using "-"subtraction
	int attempts = 0;//count the total attempt 
	long avgattempts = 0;
	long subtime = 0;
	long addtime = 0;
	long multime = 0;
	long totaltime = 0;
	long avgtime = 0;

	srand(time(0)); //Set a random seed

	for (int i = 0; i < 5; i++)
	{
		int type = rand() % 3;
		if (type == 0)
		{
			// Generate two random single-digit integers
		
			int number = rand() % 10;//1. Generate two random single-digit integers
			int number1 = rand() % 10;
			long starttimesub = time(0);
			
			if (number < number1)
				// 2. If number < number1, swap number with number1
			{
				int temp = number;
				number = number;
				number1 = temp;
			}
			// Select ONE OF subtraction, addition, or multiplication - AT RANDOM
				// Prompt the user for an answer, based on the question type selected
			cout << "What is " << number << "-" << number1 << "?\n";// Prompt the student to answer �what is number � number1? �
			int answersub = -1;
			while (number1 - number1 != answersub)
			{

				cin >> answersub;
				wrongsub++;
				if (number1 - number1 != answersub)
				{
					cout << "Sorry Please Try Again\n";
				}
				else
				{
					cout << "You got it!\n";
				}
			}
			long endtimesub = time(0);
			cout << "Number of attempts: " <<wrongsub << "\n";
			subtime = endtimesub - starttimesub;
			cout << "Time taken: " << subtime << "\n";
		}
		else if (type == 1)
		{
			long starttimeadd = time(0);
			int number2 = rand() % 10;
			int number3 = rand() % 10;
			cout << "What is " << number2 << "+" << number3 << "?\n"; //Prompt the student to answer �what is number2 +number3 ? �
			int answeradd = -1;
			while (number2 + number3 != answeradd)
			{
				cin >> answeradd;
				wrongadd++;
				if (number2 + number3 != answeradd)
				{
					cout << "Sorry Please Try Again\n";
				}
				else
				{
					cout << "You got it!\n";
				}
			}
			long endtimeadd = time(0);
			cout << "Number of attempts: " << wrongadd << "\n";
			addtime = endtimeadd - starttimeadd;
			cout << "Time taken: " << addtime << "\n";
		}
		else if (type == 2)
		{
			long starttimemul = time(0);
			int number4 = rand() % 10;
			int number5 = rand() % 10;
			cout << "What is " << number4 << "*" << number5 << "?\n";// Prompt the student to answer �what is number4*number5?�
			int answermul = -1;
			while (number4*number5 != answermul)
			{
				cin >> answermul;
				wrongmul++;
				if (number4 * number5 != answermul)
				{
					cout << "Sorry Please Try Again\n";
				}
				else
				{
					cout << "You got it!\n";
				}
			}
			long endtimemul = time(0);
			cout << "Number of attempts: " <<wrongmul << "\n";
			addtime = endtimemul - starttimemul;
			cout << "Time taken: " << multime << "\n";
		}
		cout << endl;
	}
	// what will get printed here?-The total time taken and attempts taken
	attempts = attempts + wrongsub + wrongadd + wrongmul;
	cout << "The total number of attempts: " << attempts << endl;
	avgattempts = attempts / 5;
	cout << "The average number of attempts :" << avgattempts << endl;
	totaltime = totaltime + subtime + addtime + multime;
	cout << "The total amount of time taken :" << totaltime << endl;
	avgtime = totaltime / 5;
	cout << "The average time taken: " << avgtime <<"secons"<< endl;

	return 0;
}