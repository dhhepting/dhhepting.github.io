/*
Student name: Brooke Ham
Student number: 200353759
Assignment number: 3
Program name: Listing 5.4
Date: written for Mar. 9, 2015
Problem Statement: Modify Listing 5.4 so that the user must answer the question correctly before proceeding. Also, your program should offer addition
	and multiplication questions (at random). For each question, print out the number of attempts on the question and the time taken. At the end of
	the quiz, print the average number of attempts and the average time taken.
Input: Answers to five test questions
Output: Correctness of each answer, number of attempts per question, test time, average amount of time spent on each question, average amount of attempts 
	per question
Algorithm: Numbers will be generated using the rand function, and reduced to single digit numbers using modulus 10. These numbers will be used in subtraction, 
	addition, or multiplication equations, depending on the value of the operation variable (found using modulus 3). While loops are used to make sure that
	the user inputs the correct answer before continuing to the next question. The total time is found using the values for the start and end time, and the 
	average number of attempts per question the and average time taken per question are found by dividing the totals by 5.
Major variables: startTime, totAttempt, singOrPlur, num1, num2, operation, qTime, attempt, temp, answer, endTime, testTime 
Assumptions: The program will compile and run correctly, no syntax or logic or runtime errors are present in the code.
Program Limitations: The user must answer all the questions correctly eventually.
*/

#include <iostream>
#include <ctime>																					// Needed for time function
#include <cstdlib>																					// Needed for the srand and rand functions
#include <string>																					// Needed for strings and characters
using namespace std;																				// Standard namspace is used for the code

int main()																							// The main funciton intitates the program by creating an integer and an argument (which is the code below).
{
	long startTime = time(0);																		// The variable startTime, which will be assigned the time that the test was started, is declared.
	int totAttempt = 0;																				// The variable totAttempt is used for the total number of attempts for all the questions the user will take in completing the test.
	string singOrPlur;																				// This variable will determine if the string "attempts" or  "attempt" will be used based on the number of attempts the user takes per question. 
	srand(time(0));																					// A random seed is set.

	for (int count = 0; count < 5; count++)															// The code will run until the variable count is equal to five. The first time the code is run, count = 0. After each run is completed, the variable is incremented.
	{

		int num1 = rand() % 10;																		// Two numbers (declared as num1 and num2) are generated and reduced to numbers between 0 and 9 (inclusive) using the modulus opertor.
		int num2 = rand() % 10;
		int operation = rand() % 3;																	// Three numbers are generated to determine which of the three operation choices are to be used. Each number will be assigned an operation.
		long qTime = time(0);																		// The variable qTime is for the time that it takes the user to complete each question.
		int attempt = 1;																			// The varaible attempt is for the number of attempts it takes the user to complete each question.

		if (operation == 0)																			// The value 0 is assigned to subtraction.
		{
			if (num1 < num2)																		// The order of the numbers is switched (if necessary) to make num1 > num2.
			{
				int temp = num1;
				num1 = num2;
				num2 = temp;
			}

			cout << "What is " << num1 << "-" << num2 << "?" << endl;								// This is outputted to the user.
			cout << "Answer: ";																		// A spot for the answer is generated on the screen.
			int answer;																				// A variable for the answer the user will input is generated.
			cin >> answer;																			// The computer recognizes the input as the answer.

			while (num1 - num2 != answer)															// This code runs if the input is not equal to the answer to the question.
			{
				cout << "Your answer is wrong. Try again." << endl;									// The user is informed that the question was answered incorrectly and has another oppertunity to answer the same question. 
				cout << "Answer: ";
				cin >> answer;

				attempt++;																			// Incorrect answers still contribute to the total attempts at the question.
			}

			if (attempt == 1)																		// If the question was answered correctly the first time, then they took one attempt (which is singlular).
				singOrPlur = "attempt";
			else
				singOrPlur = "attempts";															// If the question was answered correctly after the first time, then the user took more than one attempt (which is plural).

			cout << "You got it right!" << endl;													// When the answer matches the input, this message is displayed.
			cout << "It took you " << attempt << " " << singOrPlur << "." << endl;					// The number of attempts (with the plural suffix if necessary) is dispayed
			cout << " " << endl;																	// This is used to separate the questions when they are displayed.

			long qTime = time(0);																	// The time after the correct answer is inputted is displayed.
		}

		else if (operation == 1)																	// 1 is assigned to multiplication. 
		{																							// The same process is used for multiplication as subtraction.
			cout << "What is " << num1 << "*" << num2 << "?" << endl;
			cout << "Answer: ";
			int answer;
			cin >> answer;

			while (num1 * num2 != answer)
			{
				cout << "Your answer is wrong. Try again." << endl;
				cout << "Answer: ";
				cin >> answer;

				attempt++;
			}

			if (attempt == 1)
				singOrPlur = "attempt";
			else
				singOrPlur = "attempts";

			cout << "You got it right!" << endl;
			cout << "It took you " << attempt << " " << singOrPlur << "." << endl;
			cout << " " << endl;

			long qTime = time(0);
		}

		else if (operation == 2)																	// 2 is assigned to addition.
		{																							// The process for addition is the same as both the process for subtraction and multiplication.
			cout << "What is " << num1 << "+" << num2 << "?" << endl;
			cout << "Answer: ";
			int answer;
			cin >> answer;

			while (num1 + num2 != answer)
			{
				cout << "Your answer is wrong. Try again." << endl;
				cout << "Answer: ";
				cin >> answer;

				attempt++;
			}

			if (attempt == 1)
				singOrPlur = "attempt";
			else
				singOrPlur = "attempts";

			cout << "You got it right!" << endl;
			cout << "It took you " << attempt << " " << singOrPlur << "." << endl;
			cout << " " << endl;

			long qTime = time(0);
		}
		totAttempt += attempt;																		// The variable totAttempt is the sum of all the attempts the user took for all of the questions.
	}

	long endTime = time(0);																			// The time that the user finished the quiz is stored in endTime.
	long testTime = endTime - startTime;															//The total test time is the end time minus the start time.

	cout << "Your test time is " << testTime << " seconds." << endl;								// The total test time is relayed to the user.
	cout << "Your average time per question is " << testTime / 5.00 << " seconds." << endl;			// Since there are five questions, the average is the total time /5.0 (a float is used to keep decimal digits).
	cout << "Your average number of attempts per question is " << totAttempt / 5.0 << endl;			// Since there are five questions, the average is the total attempts /5.0 (a float is used to keep decimal digits).
	
	return 0;																						// The main function returns the value 0 and the code finishes.
}