// 
//**************************************************************************
//
// Student name: Sheena-Lee Gaetz
//
// Student number: 200317727
//
// Assignment number: 3
//
// Program name: 5.4
//
// Date written: March 9, 2015
//
// Problem statement: Make the user answer the question in the quiz correclty before proceeding. The questions
//					will include addition, subtraction, multiplication. Print out the number of attempts and time taken for
//					each question and at the end of the quiz, print the average number of attempts and the average time taken.
//
// Input: The user will input answers to the random math questions asked
//
// Output: If the answer is correct or not, the time taken, the amount of tries, the average time, the average amount of tries
//
// Algorithm: Generate 2 random numbers using the modulus so they are 0-9. Create another random number from 0-2 to determine which
//			operator will be used to create a math question. If statments split up the 3 different types of questions. A while loop
//			will contine to ask the user for an answer if they get it wrong and an increment will increase the number of tries
//			taken for wach question. The time is determined for each question completed. At any time the user can input 99 to exit the program.
//			At the end of the quiz, the average time and tries is calculated and ouputed.
//
// Major variables: count, answer, starttime, endtime
//
// Assumptions: none
//
// Program limitations: None
//
//**************************************************************************

#include <iostream>
#include <ctime> // Needed for time function
#include <cstdlib>// Needed for the srand and rand functions
using namespace std;

int main()
{
	
	int count = 0; // Count the number of time they were asked the question
	int tries0 = 1;
	int tries1 = 1;
	int tries2 = 1;
	srand(time(0));
	int answer = 0;
	float averagetries = 0;


	cout << "To end the program enter '99'" << endl;

	do
	{
	
		int number1 = rand() % 10; //generate random number 1
		int number2 = rand() % 10;//generate radom number 2

		if (number1 < number2) //used to make number never negative
		{
			int temp = number1;
			number1 = number2;
			number2 = temp;
		}

		int operation = rand() % 3; //Determine which math operator will be used

		if (operation == 0) //will make a subtraction question
			{
				long startTime = time(0); //begin time
				cout << "What is " << number1 << " - " << number2 << "? ";
				int answer;
				cin >> answer;

				if (answer == 99)
					{
						return 0;
					}

				while (number1 - number2 != answer) //prompt user to keep trying if they get answer wrong
				{
					cout << "Try again!" << endl;
					cout << "What is " << number1 << " - " << number2 << "? ";
					cin >> answer;
					tries0++; //increment tries

						if (answer == 99)
						{
							return 0;
						}
				}
				cout << "\ncorrect!" << endl;
				long endTime = time(0); //end the time
				long questionTime = endTime - startTime; //calculate the time it took for one question to be completed
				cout << "The number of attempts on this question was: " << tries0 <<endl;
				cout << "The time it took to complete this question was " << questionTime << " seconds\n" << endl;
				
			}
	
		
		if (operation == 1) //will make an addition question
		{
			long startTime = time(0); //begin time
			cout << "What is " << number1 << " + " << number2 << "? ";
			int answer;
			cin >> answer;

				if (answer == 99)
				{
					return 0;
				}

			while (number1 + number2 != answer) //make user continue to enter answers until they are correct
			{
				cout << "Try again!" << endl;
				cout << "What is " << number1 << " + " << number2 << "? ";
				cin >> answer;
				tries1++; //increment tries 

					if (answer == 99)
					{
						return 0;
					}
			}
			cout << "\ncorrect!" << endl;
			long endTime = time(0); //end time
			long questionTime = endTime - startTime; //calculate time it took for question
			cout << "The number of attempts on this qestion was: " << tries1 << endl;
			cout << "The time it took to complete this question was " << questionTime << " seconds\n" << endl;
		}

		if (operation == 2) //determined a multiplication question
		{
			long startTime = time(0);
			cout << "What is " << number1 << " * " << number2 << "? ";
			int answer;
			cin >> answer;

				if (answer == 99)
				{
					return 0;
				}


			while (number1 * number2 != answer)
			{
				cout << "Try again!" << endl;
				cout << "What is " << number1 << " * " << number2 << "? ";
				cin >> answer;
				tries2++;

					if (answer == 99)
					{
						return 0;
					}

					
			}
			cout << "\ncorrect!" << endl;
			long endTime = time(0);
			long questionTime = endTime - startTime;
			cout << "The number of attempts on this qestion was: " << tries2 << endl;
			cout << "The time it took to complete this question was " << questionTime << " seconds\n" << endl;

		}

		count++; //increment count
	} while (count != 5); //while loop ends when 5 questions are complete

	averagetries = (tries0 + tries1 + tries2) / 3; //calculate the average tries (do not know how to get another 2 count values
												   //from those 3 while loops because it is random
	cout << "The average attempts for each question is:" << averagetries << endl;

	cout << "The average time taken for each quesiton is:" << endl; //No idea how to calculate this

		return 0;
	}