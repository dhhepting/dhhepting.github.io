//**************************************************************************
//
// Student name: Caleb Foster
//
// Student number: 200354226
//
// Assignment number: 3
//
// Program name: Listing 5.4 Modification
//
// Date written: March 11, 2015
//
// Problem statement: The computer will ask the user a random math equation to
//  answer. The user enters a value to answer the math equations. The program
//  tells the user how many guesses it took and how long it took to get the
//  correct answer.
//
// Input: answer to the equation
//
// Output: whether the answer to the math equation is correct or not, how many
//  guess it takes to get the right answer, how long it takes to get the
//  right answer
//
// Algorithm: The program starts the count of how many tries it takes to get
//  the correct answer and the start time at 0. Then the program generates two
//  two random numbers and a random mathematical operator. The user is asked to
//  answer the question. If he gets it correct, the computer will ask another
//  mathematical question until it asks a total of 5 different mathematical
//  equations. If the user enters an incorrect answer, the program loops and
//  it will ask the same question again. After the user has given 5 correct
//  answers, the program gives how many guesses it took to answer 5 correctly
//  and the total time taken to answer 5 correctly.
//
// Major variables: answer
//
// Assumptions: The user knows how to add, subtract, and multiply
//
// Program limitations: The program doesn't divide
//
//**************************************************************************

#include <iostream>
#include <ctime> // Needed for time function
#include <cstdlib> // Needed for the srand and rand functions
using namespace std;

int main()
{
	int trial = 0; // Count the number of correct answers
	int count = 0; // Count the number of questions
	long startTime = time(0);
	const int NUMBER_OF_QUESTIONS = 5;
	int answer;

	srand(time(0)); // Set a random seed

	while (count < NUMBER_OF_QUESTIONS)
	{
		// 1. Generate two random single-digit integers
		int number1 = rand() % 10;
		int number2 = rand() % 10;
		count++;
		startTime;

		// 2. If number1 < number2, swap number1 with number2
		if (number1 < number2)
		{
			int temp = number1;
			number1 = number2;
			number2 = temp;
		}

		int chooser = rand() % 3;
		if (chooser == 0)
		{
			do
			{
				// 3. Prompt the student to answer �what is number1 � number2?�
				cout << "What is " << number1 << " - " << number2 << "? ";
				cin >> answer;
				trial++;
				if (number1 - number2 != answer)
					cout << "Wrong, try again" << endl;
			} while (number1 - number2 != answer);
			{
				cout << "Correct!" << endl;
			}
		}
		if (chooser == 1)
		{
			do
			{
				// 3. Prompt the student to answer �what is number1 + number2?�
				cout << "What is " << number1 << " + " << number2 << "? ";
				cin >> answer;
				trial++;
				if (number1 + number2 != answer)
					cout << "Wrong, try again" << endl;
			} while (number1 + number2 != answer);
			{
				cout << "Correct!" << endl;
			}
		}
		if (chooser == 2)
		{
			do
			{
				// 3. Prompt the student to answer �what is number1 * number2?�
				cout << "What is " << number1 << " * " << number2 << "? ";
				cin >> answer;
				trial++;
				if (number1 + number2 != answer)
					cout << "Wrong, try again" << endl;
			} while (number1 + number2 != answer);
			{
				cout << "Correct!" << endl;
			}
		}

	}

	long endTime = time(0);
	long testTime = endTime - startTime;

	cout << "Number of trials is " << trial << "\nTest time is "
		<< testTime << " seconds\n";

	return 0;
}