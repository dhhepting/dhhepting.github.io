
//******************************************************************
//
//Student name: Ronglian Wang
//
//Student number: 200269662
//
//Assignment number: 3
//
//Program name: modifying 5.4, fun math  
//
//Date written: 2015-03-11
//
//Problem statement:  quiz loop
//
//Input: numbers
//
//Output: guessing numbers,time using, attempting times
//
//Algorithm:  boolean, while loop, if statement
//
//Major variables: int
//
//Assumptions: 
//
//Program limitations: run five times
//
//*********************************************************************




#include <iostream>
#include <ctime> // Needed for time function
#include <cstdlib> // Needed for the srand and rand functions
using namespace std;

int main()
{
	long totalAttempt=0.0 ;
	long averageAttempt=0.0 ; 
	long averageTime=0.0;
	int count = 0; // Count the number of questions
	long startTime0 = time(0);
	const int NUMBER_OF_QUESTIONS = 5;
	
	
	int count1 = 0;
	int count2 = 1;
	int count3 = 0;
	int count4 = 1;
	int count5 = 0;
	int count6 = 1;
	srand(time(0)); // Set a random seed

	while (count < NUMBER_OF_QUESTIONS)
	{
		
		long startTime = time(0);
		// 1. Generate two random single-digit integers
		int number1 = rand() % 10;
		int number2 = rand() % 10;
		int number = rand() % 3;

		switch (number)

		{
		case 0:
			if (number1 < number2)
			{
				int temp = number1;
				number1 = number2;
				number2 = temp;
			}


			// 3. Prompt the student to answer �what is number1 � number2?�
			cout << "What is " << number1 << " - " << number2 << "? ";
			int answer;
			cin >> answer;

			// 4. Grade the answer and display the result
			if (number1 - number2 == answer)
			{

				cout << "You are correct!\n";

				long endTime = time(0);
			long testTime1 = endTime - startTime;
				 count1++;
				cout << "Attempt times is " << count1 << "\nTest time is "
					<< testTime1 << " seconds\n";

				break;
			}
			else
				do
				{
					

					cout << "Your answer is wrong.\n" << number1 << " - " <<
						number2 << " should be :" << endl;
					cin >> answer;
					long endTime = time(0);
					long testTime2 = endTime - startTime;
					count2++;
					cout << "Attempt times is " << count2 << "\nTest time is "
						<< testTime2 << " seconds\n";
				} while (answer != number1 - number2);
				// Increase the count
				count++;
				break;

		case 1:
			cout << "What is " << number1 << " + " << number2 << "? ";

			cin >> answer;

			// 4. Grade the answer and display the result
			if (number1 + number2 == answer)
			{
				count3++;
				cout << "You are correct!\n";
				long endTime = time(0);
				long testTime3 = endTime - startTime;
				cout << "Attempt times is " << count3 << "\nTest time is "
					<< testTime3 << " seconds\n";
			}
			else
				do
				{


					cout << "Your answer is wrong.\n" << number1 << " + " <<
						number2 << " should be :" << endl;
					cin >> answer;
					long endTime = time(0);
					long testTime4 = endTime - startTime;
					count4++;
					cout << "Attempt times is " << count4 << "\nTest time is "
						<< testTime4 << " seconds\n";
				} while (answer != number1 + number2);
				// Increase the count
				count++;

				break;


		case 2:
			cout << "What is " << number1 << " * " << number2 << "? ";

			cin >> answer;

			// 4. Grade the answer and display the result
			if (number1 * number2 == answer)
			{
				cout << "You are correct!\n";
				 count5++;
				long endTime = time(0);
				long testTime5 = endTime - startTime;				cout << "Attempt times is " << count5 << "\nTest time is "

					<< testTime5 << " seconds\n";
			}
			else
				do
				{
				

					cout << "Your answer is wrong.\n" << number1 << " * " <<
						number2 << " should be :" << endl;
					cin >> answer;
					long endTime = time(0);
					long testTime6 = endTime - startTime;
					count6++;
					cout << "Attempt times is " << count6 << "\nTest time is "
						<< testTime6 << " seconds\n";
					totalAttempt = (count1 + count2 + count3 + count4 + count5 + count6);
					
				} while (answer != number1 * number2);
				// Increase the count
				count++;
				
				
				

				
		}
		count++;
	}
	long endTime = time(0);
	long testTime = endTime - startTime0;
	averageAttempt = (count1 + count2 + count3 + count4 + count5 + count6) / 4;
	totalAttempt = (count1 + count2 + count3 + count4 + count5 + count6);
	cout << "Total test time is " << testTime<<" seconds" << endl;
	cout << "Average times taken is " << testTime /4 << " seconds" << endl;
	
	cout << "Total attempt times is " << totalAttempt <<" times"<< endl;
	
	return 0;
}

