//Ashlyn Heintz
// 200287036
//Assignment 3: 5.3

#include <iostream>
#include <cstdlib>
#include <ctime> // Needed for the time function
using namespace std;

int main()
{
	// Generate a random number to be guessed
	srand(time(0));
	int guess = rand() % 101;
	int number;

	cout << "Enter a number between 0 and 100: ";
	cin >> number;
	while (number > 100 || number < 0)
	{
		if (number > 100 || number < 0)
			cout << "The user has entered an incorrect value, Please Enter a number between 0 and 100: ";
		cin >> number;
	}

	while (guess != number)
	{
		guess = rand() % 101;
		// Prompt the user to guess the number
		cout << "\nComputer's Guess: ";
		cout << guess << endl;

		if (guess == number)
			cout << "Yes, the number is " << number << endl;
		else if (guess > number)
			cout << "Your guess is too high" << endl;
		else if (guess < number)
			cout << "Your guess is too low" << endl;

	} // End of loop

	return 0;
}
