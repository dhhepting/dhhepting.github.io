// Nandha Kishore Bijumon
// 200 355 253
// March 11, 2015
#include <iostream>
#include <ctime>
#include <cstdlib>
#include <fstream>
using namespace std;

int main()
{
	srand(time(NULL));
	int num;
	int comp;
	int maxlim = 100;
	int lowlim = 1;
	ifstream inData;
	ofstream outData;

	inData.open("intxt.txt");
	outData.open("outtxt.txt");
	outData << "Input a number for the computer to guess" << endl;
	outData << "num";

	do
	{
		comp = rand() % 101;

		outData << comp;

		if (num > comp)

		{
			outData << "too low";
			lowlim = comp + 1;
		}
		else if (comp < num)
		{
			outData << "too high";
			maxlim = comp - 1;
		}
		else if (comp == num)
		{
			outData << "the computer guessed your number";

		}


	} while (num != comp);
	return 0;


}