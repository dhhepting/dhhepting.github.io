// Student name: Callum Jacobson
//
// Student number: 200234874
//
// Assignment number: 3 Part 1
//
// Program name: Number Guesser
//
// Date written: 11 March 2015
//
// Problem statement: 
//		The problems that need to be solved by this program are:
//		1) Correctly guess a user-entered integer.
//		2) Recognize if the user is being truthful when the user indicates if the guess is too high, too low or correct.
//
// Input:
//		The user inputs an integer between 0 and 100.
//		After each computer guess the user inputs whether the guess was too high, too low or correct.
//
// Output:
//		The program will output the following:
//		1) A integer between 0 and 100
//		2) Integers that are higher than the previous too low guess and integers that are lower than the previous too high guess.
//		3) A record of all program guesses and the user's response to a .txt file.
//
// Algorithm: 
//		1) User inputs integer between 0 and 100.
//		2) Program outputs an integer that is the average of 0 and 100 (50).
//		3) User inputs whether the guess was too high, too low or correct.
//		4) Program outputs an integer that is higher than the previous guess (if user indicated too low) 
//		or an integer that is lower than the previous guess (if user indicated too high).
//		5) Steps 3 and 4 repeat until user indicates the program has guessed correctly
//
// Major variables: 
//		1) The integer entered by the user.
//		2) The user's response of too high, too low or correct.
//
// Assumptions:
//		1) Assumes that user will enter an integer that is between 0 and 100.
//
// Program limitations:
//		1) Limited to guessing an integer between 0 and 100.
//
//**************************************************************************

#include <iostream>
#include <cstdlib>
#include <ctime>
#include <fstream>
using namespace std;

int main()
{
	srand(time(0));

	int number;
	int UpperLim = 100;
	int LowerLim = 1;
	int guess = -1;

	ofstream outData;

	cout << "Enter a number between 0 and 100: ";
	cin >> number;

	outData.open("guesses.txt");

	do
	{
		char user_response;
		int guess = (UpperLim + LowerLim) / 2;

		cout << "The computer's guess is " << guess << "." << endl;
		cout << "Enter 'y' if this the correct number." << endl;
		cout << "Enter 'h' if it is too high." << endl;
		cout << "Enter 'l' if it is too low." << endl;

		outData << guess << endl;
		cin >> user_response;
		outData << user_response << endl;

		if (user_response == 'l')
		{
			LowerLim = guess + 1;
			guess = (UpperLim + LowerLim) / 2;

			cout << "The computer's guess is " << guess << "." << endl;
			cout << "Enter 'y' if this the correct number." << endl;
			cout << "Enter 'h' if it is too high." << endl;
			cout << "Enter 'l' if it is too low." << endl;

			outData << guess << endl;
			cin >> user_response;
			outData << user_response << endl;

			if (guess > number || guess == number)
			{
				cout << "Liar!" << endl;
			}
		}
		else if (user_response == 'h')
		{
			UpperLim = guess - 1;
			guess = (UpperLim + LowerLim) / 2;

			cout << "The computer's guess is " << guess << "." << endl;
			cout << "Enter 'y' if this the correct number." << endl;
			cout << "Enter 'h' if it is too high." << endl;
			cout << "Enter 'l' if it is too low." << endl;

			outData << guess << endl;
			cin >> user_response;
			outData << user_response << endl;

			if (guess < number || guess == number)
			{
				cout << "Liar!" << endl;
			}
		}
		else if (user_response == 'y')
		{
			cout << "The number is " << guess << endl;

			if (guess != number)
			{
				cout << "Liar!" << endl;
			}
			return 1;
		}
	}
	while (number != guess);

	return 0;
}
