//**************************************************************************
//
// Student name:Regan Tessier
//
// Student number: 200300419	
//
// Assignment number: 3
//
// Program name: Computer guessing user picked number
//
// Date written: March 11th 2015
//
// Problem statement: Guess a users number, input guess and answer into file
//
// Input:y,g,l
//
// Output:Guess
//
// Algorithm: 
//
// Major variables: guess, lowerguess, upperguess
//
// Assumptions:That the fact that I couldn't write this into a file wont be minded
//
// Program limitations:
//
//**************************************************************************
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <iomanip>
#include <ctime> // Needed for the time function
using namespace std;

int main()
{
	
				// declares output stream

	// Generate a random number to be guessed
	srand(time(0));
	int temp;
	int lowerguess = 0;
	int upperguess = 100;
	int guess = 50;
	
	while (guess != lowerguess&&upperguess != guess)
	{
		ifstream inData;
		ofstream outData;
		outData.open("output.txt");
		char car;
		cout << "Pick a number, If your number is guessed enter(y) for yes, if your number is greater than the one guessed enter(g), if it is less than the one that is guessed enter(l)" << endl;
		cout << "Is this your number " << guess << endl;
		outData << "Is this your number " << guess << endl;
		cin>>car;
		if (car == 'y')
		{
			outData << "Is this your number? " << guess << endl;
			return 0;
		}
		else if (car == 'g')
		{
			lowerguess = guess;
			guess = (guess + upperguess) / 2;
		}
		else if (car == 'l')
		{
			upperguess = guess;
			guess = (guess + lowerguess) / 2;
		}
		else
		{
			cout << "Incorrect character" << endl;
		}
		
		outData.close();
	} // End of loop
	cout << "you lie" << endl;
	
	return 0;
}