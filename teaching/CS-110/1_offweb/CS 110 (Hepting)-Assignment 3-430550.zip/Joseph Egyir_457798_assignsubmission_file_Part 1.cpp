// Joseph Egyir
// 200357099
// March 11, 2015
#include <iostream>
#include <ctime>
#include <cstdlib>
#include <fstream>
using namespace std;

int main()
{
	srand(time(NULL));

	int tries = 0;
	int num1;
	int UpperLim = 100;
	int LowerLim = 1;
	int iCompNum;

	
	cout << "The computer will guess number\n\n\n";

	cout << "Enter a number: ";
	cin >> num1;

	ofstream outData;
	outData.open("guess outputs.txt");

	do
	{
		iCompNum = rand() % (UpperLim - LowerLim) + LowerLim;

		outData << "\nComputer's guess: ";
		outData << iCompNum;
		++tries;

		if (num1 > iCompNum)
		{
			outData << "\nYou're too low..!\n\n";
			LowerLim = iCompNum + 1;
		}
		else if (num1 < iCompNum)
		{
			outData << "\nToo high..!\n\n";
			UpperLim = iCompNum - 1;
		}
		else if (num1 == iCompNum)
		{
			outData << "\nYou guessed the number in " << tries << " tries!\n\n";
		}

	} while (num1 != iCompNum);

	return 0;
}