#include <iostream>
#include <cstdlib>
#include <fstream>
#include <string>
#include <ctime> 
using namespace std;

int main()
{
	ofstream outData;
	outData.open("outputfile.txt");
	srand(time(0));
	int number;
	string response;
	cout << "Please input a number from 0-100\n";
	cin >> number;
	outData << number << endl;
	if (number >= 0 && number <= 100)
	{
		cout << "This is a valid number\n";
		outData << "This is a valid number\n";
		int guess = rand() % 101;
		cout << "The computer guessed: " << guess << endl;
		outData << "The computer guessed: " << guess << endl;
		while (guess != number)
		{
			cout << "The computer guessed:" << guess << endl;
			cout << "Please tell the computer if its guess is high or low\n";
			cin >> response;
			if (response == "high")
			{
				if (guess > number)
				{
					cout << "The guess was too high\n";
					outData << "TOO HIGH\n";
					guess = rand() % (guess + 1);
					outData << guess << endl;
				}
				else if (guess < number)
				{
					cout << "You haven't been honest!!!\n";
					outData << "You haven't been honest!!!\n";
					return 0;
				}
				else if (guess == number)
				{
					cout << "Great job! You guessed right!" << endl;
					outData << guess << endl;
					outData << "Great job! You guessed right!" << endl;
				}
			}
			else if (response == "low")
			{
				if (guess < number)
				{
					cout << "The guess was too low\n";
					outData << "too low\n";
					guess = (100 + guess) / 2;
					cout << "The computer guessed: " << guess << endl;
					outData << guess << endl;
				}
				else if (guess > number)
				{
					cout << "You haven't been honest!!!\n";
					outData << "You haven't been honest!!!\n";
					return 0;
				}
				else if (guess == number)
				{
					cout << "Great job! You guessed right!" << endl;
					outData << guess << endl;
					outData << "Great job! You guessed right!" << endl;
				}
			}

		}
	}
	return 0;
}