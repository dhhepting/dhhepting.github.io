// STUDENT NAME: Emily Chea

// STUDENT NUMBER: 200352055

// ASSIGNMENT NUMBER: 3

// PROGRAM NAME: C++ Visual Studio 2013

// DATE WRITTEN: March 7, 2015

// PROBLEM STATEMENT: make the computer guess a number that the user has chosen

// INPUT: mystery number; "y", "h", "l" to show if the guesses are correct, or need to be higher or lower

// OUTPUT: Guesses made by the computer

// ALGORITHM: have the user enter their mystery number to be stored in the text file; check to see if the number is within the set limits, guess the number based on what the user inputs ("y", "h", "l")

// MAJOR VARIABLES: int number, int mysterynumber, char right;

// ASSUMPTIONS: user will be honest when enteringnif guesses need to be higher or lower

// PROGRAM LIMITATIONS: 

//**************************************************************************************************************************************************************

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime> // Needed for the time function
using namespace std;

int main()
{
	srand(time(0));
	ofstream outData;
	int number = rand() % 101; // generate a random number between 0 and 100
	int mysterynumber;
	char right;
	//Create the text file "assignment3.1" and open the file. This is where the mysterious number and all the guesses will be recorded.
	outData.open("assignment3.1.txt");
	//Ask the user to enter a mysterious number between 0 annd 100
	cout << "Please enter a mystery number between 0 and 100." << endl;
	cin >> mysterynumber;
	outData << "Mystery number: " << mysterynumber << endl;
	cout << "The computer will now attempt to guess your number. After each guess, either: " << endl;
		cout << "1) Enter y if the computer has guessed correctly." << endl;
		cout << "2) Enter l if your number is lower that the computer's guess." << endl;
		cout << "3) Enter h if your number is higher that the computer's guess." << endl;
	if (mysterynumber <= 100 && mysterynumber >= 0)
	{
		mysterynumber = -1;
		while (number != mysterynumber)
		{
			// Computer will guess the number
			cout << "Is the number " << number << "?" << endl;
			outData << "Guess: " << number << endl;
			cin >> right;
			outData << right << endl;

			if (right == 'y')
			{
				cout << "Yes, I win. " << number << endl;
				outData << "Yes, I win. " << number << endl;
				break;
			}
			else if (right == 'l')
			{
				cout << "Your guess is too high" << endl;
				outData << "Your guess is too high" << endl;
				number = number--;
			}
			else
			{
				cout << "Your guess is too low" << endl;
				outData << "Your guess is too low" << endl;
				number = number++;
			}
		} // End of loop*/
	}
	else 
	{
		cout << "Your number is not within the limits." << endl;
		outData << "Your number is not within the limits." << endl;
	}
	return 0;
}

