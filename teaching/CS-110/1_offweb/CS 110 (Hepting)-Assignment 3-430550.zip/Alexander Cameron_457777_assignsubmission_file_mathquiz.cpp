/*********************************************************************************************************
 
 Student Name: Alexander Cameron
 
 Student Number: 200 246 288
 
 Assignment Number: 3 Part 2
 
 Program Name: Math Quiz
 
 Date Written: 03 March, 2015
 
 Problem Statement: This program is created to randomly generate one digit math questions in multiplication, addition, and subtraction.
 
 Input: Answer to the given question.
 
 Output: Mathematic question(addition, multiplication, or subtraction), whether the answer is correct or not, the time each question took, and the average time, the amount of tries each questions took and the average number of tries.
 
 Algorithm: The user will be prompted to answer math questions. If incorrect the program will re-ask the question, if correct the program will create a new question until five questions are answered.
 
 Major Variables: int and long
 
 Assumptions: This program assumes that the person is putting in integers.
 
 Program Limitations: This program is limited to addition, subtraction and multiplication of one digit whole numbers.
 
 
 ********************************************************************************************************/
#include <iostream>   //needed for standard functions (ie cout)
#include <ctime>      //for time function
#include <cstdlib> //for srand function

using namespace std;

int main ()
{
    float NumberOfQuestions;
    cout <<"Its Math Quiz Time!!!"<<endl<<"How many math questions would you like to do?";
    cin>>NumberOfQuestions; //gets user to input the number of test questions.
    int totalcount=0;       //sets the total count(how many questions the user has finished
    int attemptcounter=0;  //sets the number of attempts the user has taken for all questions, later this will be divided to find average
    long start=time(0);    //starts timing the entire test.
    while (totalcount< NumberOfQuestions)//keeps repeating until total time =number of questions, then outputs results
    {
        int attemptcount=0; //sets up initial attempt count for each question
        int timecount=0;
        srand(time(0));   //sets up random numbergenerator
        int num1=rand()%10; //sets first number of question
        int num2=rand()%10;
        int method=rand()%3; //choses between methods at random (three choices, so modulus three
        int subtractionCounter=0;  //initial counts for each method
        int multiplicationCounter=0;
        int additionCounter=0;
        
        
        if (method==0)  //when generator comes up with 0 for the method count initiates this set of code
        {
            if (num1<num2)    //ensures always a positve answer for the subtraction
            {
                int temp =num1; //ensures that num1 isnt overwritten, stores temperarily
                num1=num2;
                num2=temp;
            }
            
            cout<< "What is "<<num1<< "-" <<num2<< "? "; //the question output
            long startTime=time(0);                        //starts timer for this question
            int answer;                           //declares variable answer so the user can input
            cin>>answer;
            
            
            while (num1-num2!= answer)   //if not right answer, question repeats until answer is given
            {
                cout << "you are incorrect, please input a new answer!"<<endl;
                cin >> answer;
                subtractionCounter++; //the attempt is recorded for this question, and also for the average calculated later
                attemptcount++;
            }
            if (num1-num2==answer)  //if answer given the total time it took to come to the answer is output
            {
                attemptcount++;   //the attempt is recoreded
                subtractionCounter++;
                long endTime = time(0); //ends the timer for this question
                long testTime = endTime - startTime; //calculates total time
                cout << "You are correct! It took you "<<subtractionCounter<< " attempt(s).";
                cout << "The question took "<<testTime<<" seconds."<<endl;
                
                
                
                
            }
        }
        
        else if (method==1) //if method randomly generates one, ths code will be initiated
        {
            cout<< "What is "<<num1<< "+" <<num2<< "? "; //initial question prompts user for answer
            long startTime=time(0); //starts the timer for this question
            int answer;
            cin>>answer;
            
            while (num1+num2!= answer) //if not right, repeats question
            {
                cout << "you are incorrect, please input a new answer!"<<endl;
                cin >> answer;
                additionCounter++;  //records number of attmepts
                attemptcount++;
            }
            if (num1+num2==answer) //answer right, outputs info of time, and attempts.
            {
                attemptcount++;
                additionCounter++;
                long endTime = time(0);
                long testTime = endTime - startTime;
                cout << "You are correct! It took you "<<additionCounter<< " attempt(s).";
                cout<< "The question took "<<testTime<<" seconds."<<endl;
    
            }
            
        }
        
        else if (method==2) //if generator for method gets 2 then multiplication code is initiated
        {
            cout<< "What is "<<num1<< "x" <<num2<< "? "; //initial question
            long startTime=time(0);                      //timer started for this question
            int answer;
            cin>>answer;
            
            while (num1*num2!= answer) //incorrect answer
            {
                cout << "you are incorrect, please input a new answer!"<<endl;//prompt for new answer
                cin >> answer;
                multiplicationCounter++;//attempts for this question recorded
                attemptcount++;
            }
            if (num1*num2==answer)//right answer, stops timer
            {
                attemptcount++;
                multiplicationCounter++;
                long endTime = time(0);  //records end time
                long testTime = endTime - startTime; //calculation for time for this question
                cout << "You are correct! It took you "<<multiplicationCounter<< " attempt(s).";
                cout << "The question took "<<testTime<<" seconds."<<endl;
                
            }
            
        }
        totalcount++;// puts the total count up one, to keep track of number of questions
        attemptcounter=attemptcounter+attemptcount; //adds the attempts of any question to variable for storage until end of test
        long timecounter=0;
        timecounter=timecounter+timecount;
        
    }
    long end=time(0); //records end point of total test
    float totalTest=(end-start)/NumberOfQuestions;//calculates averages for tine spent on a question.
    
    
    
    
    cout<<"You got "<<totalcount<<"/"<<NumberOfQuestions<<" questions right. The average time per question was "<<totalTest<<" seconds.The average number of attempts was "
    <<attemptcounter/NumberOfQuestions<<endl; // outouts all score, time and attempt data
    
    
    return 0;
    
}

