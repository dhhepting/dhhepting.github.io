/*

Name: Kyle HUngle
Student #: 200354270
Assignment #3
Program Name: Assignment#3-1
March 11/15
Problem Question
Modify Listing 5.3 so that the computer guesses a number that the user provides 
(switch the roles of user and computer from Listing 5.3). Write the guesses from the program and the user's answers 
to a file. Print a message if the computer detects that the user has not been trustworthy in her answers. Use the technique that we discussed in class today.


*/
#include <iostream>
#include <string>
using namespace std;
int main()
{
	int upperlimit=100; //declares upper limit and sets it equal to 100
	int lowerlimit=0; //declares lower limit and sets it equal to 0
	int guess = (upperlimit + lowerlimit)/2; //guess varaible first assigned to be the average of upper and lower
	int count=0; // count variable 
	string input = "A";  // string for the users input

	cout<< "This  program will guess a number that you pick between 0 and 100, if the guess it to high input 'high' if the guess is to low input 'low', if the computer guesses the correct number input 'correct'" << endl;
	while (input != "yes" && input != "no")  // asks the user if they are ready to begin, will only pass by if yes or no is inserted
	{
		cout << "Are you ready to play? Enter 'yes' to begin or 'no' to end the program: " << endl;
		cin >> input;
	}

		if (input == "yes" )
		{
			cout << "Computer's first guess is: " << guess << endl;  //displays the first guess

		while (input != "correct")   //loop that initiates until the user tells the computer its guess is correct
		{
			cout << "Is guess to high, low, or is it correct?" << endl;  // asks the user if the guess is too high or too low
			cin >> input;

			if (input == "high")  // if the input is high, adjust the upper limit accordingly as well as figures out the next guess and displays it
			{
				upperlimit = guess-1;
				guess = (upperlimit + lowerlimit)/2;
				cout << "The computers guess is: " << guess << endl;
			}
			if (input == "low") // if the input is low, adjust the upper limit accordingly as well as figures out the next guess and displays it
			{
				lowerlimit = guess +1;
				guess = (upperlimit + lowerlimit)/2;
				cout << "The computers guess is: " << guess << endl;
			}
			if (input == "correct") //if inout is correct the computer tells the user it wins
			{
				cout << "I knew i would figure it out, thanks for playing!" << endl;
			}
			if (upperlimit == lowerlimit && input != "correct") // if the upper equals the lower it adds one to the counter as it needs to make sure that the upper = to lower is not the right number
			{
				count +=1;
			}
			if (count == 2  || lowerlimit > upperlimit || upperlimit < lowerlimit) //when the count is equal to 2 or lower is greater than upper or upper is less than lower, the computer knows the user is lying
			{
				cout << "I think you are lying to me please play fairly next time" << endl;
				input = "correct";
			}
		}
	
		cout << "Thanks for coming out" << endl;  //thanks the user for playing
	
	}
	return 0;
	

}