#include <iostream>
#include <cstdlib>
#include <ctime>
#include <fstream>


using namespace std;

int main() 
{
    ofstream fout;
	int guess;
	int number = -1;
	int try=0;
 	
 	fout.open("outdata.txt");
 	if (!fout)
 	{
 		cout << "File can not created"<< endl;
 		return -1;
 	}
 	else 
	{
		cout << "\nEnter your guess: ";
    	cin >> guess;
    	fout<< guess;
    	
		
		while (number != guess)
 	{
 		srand(time(0));
 		number = rand() % 101;
    	fout <<  number;
    	if (number == guess)
      	cout << "Yes, the number is " << number << endl;
   		else if (number!= guess)
   		{
   			cout << "Try again" << endl;
   			try ++;
   		}
      	
      	else if (try>100)
      	cout << "You are not trustworthy";
 	}
 	} 	
  
	return 0;
}
