//**************************************************************************
//
// Student name: Kennedy Dollard
//
// Student number: 200236150
//
// Assignment number: three
//
// Program name: Random Guess
//
// Date written: March 11th, 2014
//
// Problem statement: Guess and Identify a Users Random Number
//
// Input: higher, lower, equal to computer guess
//
// Output: computers guesses
//
// Algorithm: 
//
// Major variables: if user changes number mid guesses
//
// Assumptions: user will not lie/cheat
//
// Program limitations: only numbers 1-100
//
//**************************************************************************



#include <iostream>
#include <cstdlib>
#include <fstream>
#include <string>
#include <ctime> // Needed for the time function
using namespace std;

int main()
{
	// Generate a random number to be guessed
	srand(time(0));
	int guess;				//computers guess
	int upperlimit = 100;
	int lowerlimit = 0;
	string input = " ";

	cout << "Think of a number between 0 and 100 and the computer will guess it." << endl;

	guess = (upperlimit + lowerlimit) / 2;
	{
		cout << "Computer guesses " << guess << ". Is this number high, low or equal to your number?" << endl;
		cin >> input;

		while (input != "equal")
		{
			if (input == "high")
			{
				guess = (upperlimit + lowerlimit) / 2; // re-calculates variable 
				upperlimit = guess; // re-assigns variable 
			}

			else if (input == "low")
			{
				guess = (upperlimit + lowerlimit) / 2; // re-calculates variable 
				lowerlimit = guess; // re-assigns variable 
			}

			else
			{
				cout << "Invalid response: use high, low or equal" << endl;
			}
		}
		while (input == "equal")
		{
			cout << "Your number is " << guess << endl;
			return 0;
		}

	}
	return 0;
}