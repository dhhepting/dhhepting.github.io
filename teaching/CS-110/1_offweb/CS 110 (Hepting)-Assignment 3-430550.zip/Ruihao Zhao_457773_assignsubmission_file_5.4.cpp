//**************************************************************************
//
// Student name:Ruihao Zhao    
//
// Student number: 200338484    
//
// Assignment number: #3
//
// Program name: 5.4.cpp
//
// Date written: 3/06/2015
//
// Problem statement: giving 5 questions (of types:*,+,-), the person must answer correctly to proceed to the next question. the total number of attempts, total time spent, average time spent and average number of attempts.
//
// Input: int answersub, int answeradd, int answerprod.
//
// Output: each question, answer, number of attempts, amount of time spent, total time spent, total attempts, average time spent, average attempts 
//
// Algorithm1:5repetitions(questions)
//
// Algorithm2:randomizequestiontype
//
// Algorithm3:randomizetwonumbers
//
// Algorithm4:swap: if the 2nd value is larger than the first they are swapped
//
// Algorithm5:total attempts,total time, average attempts, and average time
//
// Major variables: int countwrongprod,int countwrongadd,int countwrongsub,int totalattempts, long avgattempts, long timetakensub, long timetakenadd, long timtakenprod, long totaltimetaken
// long avgtimetaken, long totalsubtime, long totaladdtime, long totalprodtime,int number1sub, int number2sub, long starttimeadd,long starttimesub, long starttimeprod, int answersub, int answeradd, int answersub
// long endtime
//
// Assumptions:that the person knows its timed. No decimal values for any numbers.	
//
// Program limitations:non precise time keeping and averaging, only 2 numbers, only 5 questions, and only 3 types of questions. 
//
//**************************************************************************
#include <iostream>
#include <ctime> 
#include <cstdlib> 
using namespace std;

int main()
{
	int countwrongprod = 0;
	int countwrongadd = 0;
	int countwrongsub = 0;
	int totalattempts = 0;
	long avgattempts = 0;
	long timetakensub = 0;
	long timetakenadd = 0;
	long timetakenprod = 0;
	long totaltimetaken = 0;
	long avgtimetaken = 0;
	long totalsubtime = 0;
	long totaladdtime = 0;
	long totalprodtime = 0;
	srand(time(0));
	for (int i = 0; i < 5; i++)															//Algorithm1:start
	{
		
		int type = rand() % 3;															//Algorithm2:start
		
		if (type == 0)
		{
			long starttimesub= time(0);
			int number1sub = rand() % 10;												//Algorithm3:start
			int number2sub = rand() % 10;
			if (number1sub < number2sub)												//Algorithm4:start
			{	
				int temp = number1sub;
				number1sub = number2sub;
				number2sub = temp;
			}																			//Algorithm4:end
			cout << "What is " << number1sub << "-" << number2sub << "?\n";
			int answersub = -1;
			while (number1sub - number2sub != answersub)
			{
				cin >> answersub;
				
					countwrongsub++;
				if (number1sub - number2sub != answersub)
					cout << "Sorry Please Try Again\n";
				else
				{
					cout << "Good Work\n";	
				}
			}
			long endtimesub = time(0);
			cout << "Number of attempts: "<<countwrongsub<<"\n";
			timetakensub = endtimesub - starttimesub;
			cout << "Time taken: " << timetakensub << "\n";
			totalsubtime += endtimesub - starttimesub;
		}
		else if (type == 1)
		{
			long starttimeadd = time(0);
			int number1add = rand() % 10;
			int number2add = rand() % 10;
			cout << "What is " << number1add << "+" << number2add << "?\n";
			int answeradd = -1;
			while (number1add + number2add != answeradd)
			{
				cin >> answeradd;
				countwrongadd++;
				if (number1add + number2add != answeradd)
					cout << "Sorry Please Try Again\n";
				else
				{
					cout << "Good Work\n";
				}
			}
			long endtimeadd = time(0);
			cout << "Number of attempts: " << countwrongadd << "\n";
			timetakenadd = endtimeadd - starttimeadd;
			cout << "Time taken: " << timetakenadd << "\n";
			totaladdtime += endtimeadd - starttimeadd;
		}
		else if (type == 2)																//Algorithm2:end
		{
			long starttimeprod = time(0);
			int number1prod = rand() % 10;
			int number2prod = rand() % 10;												//Algorithm3:end
			cout << "What is " << number1prod << "*" << number2prod << "?\n";
			int answerprod = -1;
			while (number1prod*number2prod != answerprod)
			{
				cin >> answerprod;
				countwrongprod++;
				if (number1prod * number2prod != answerprod)
					cout << "Sorry Please Try Again\n";
				else
					cout << "Good Work\n";
				
			}
				long endtimeprod = time(0);
				cout << "Number of attempts: " << countwrongprod << "\n";
				timetakenprod = endtimeprod - starttimeprod;
				cout << "Time taken: " << timetakenprod << "\n";
				totalprodtime += endtimeprod - starttimeprod;
		}
		cout << endl;
	}																						//Algorithm1:end
	
	totalattempts = totalattempts + countwrongsub + countwrongadd + countwrongprod;			//Algorithm5:start
	cout << "total number of attempts: " << totalattempts << endl;
	avgattempts = totalattempts / 5;
	cout << "average number of attempts :" << avgattempts << endl;
	totaltimetaken = totalsubtime + totaladdtime + totalprodtime;
	cout << "total amount of time taken :" << totaltimetaken << endl;
	avgtimetaken = totaltimetaken / 5.0;
	cout << "average time taken: " << avgtimetaken << endl;									//Algorithm5:end
}
