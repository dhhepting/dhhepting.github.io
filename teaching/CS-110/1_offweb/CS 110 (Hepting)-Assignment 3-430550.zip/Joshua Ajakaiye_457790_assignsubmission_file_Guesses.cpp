//*******************************************************************************************
// Student Name: Joshua Ajakaiye
// Student Number: 200348270
// Program Name: Guesses
// Assignment Number: 3
// date written: 3/10/2015
//
// problem Statement: to input a number and let the computer guess the number whilst you
//                   direct the computer by mention if the number guessed is higher or 
//                   lower than the number you guessed
// input: a number between 0 and 100 thought of by the user and "high" or "low"
// output: the number guessed by the computer, a statement stating that its to high and a 
//        statement stating that it is too low, also a statement stating that the user is
//        not trust worthy
// Main algorithm: open an output file "guess.txt"
//                 error check the openning
//                 prompt the user a magic number
//                 check if the number inputed is within the range of 0 and 100
//                 using a while statement check if the guess is higher than the number
//                 inputted as prompted by the user and also detect if the user to lying 
//                 about the number being too high
//                 also to check if the guess is higher than the number inputted and also 
//                 detect if the user is lying about that as well.
//                 and also end the program when the guess correlates with the number
// Major variables: outFile, number, guess, judgement.
// Assumptions: by typing high and low depending on the guess the computer will eventually
//              get the number
// limitations: the computer can only guess between 0 and 100, also the user can only say 
//              high or low not hinting on how much higher or or how much lower the computer
//              is
//*******************************************************************************************
#include <iostream>
#include <cstdlib>
#include <ctime> // Needed for the time function
#include<fstream>
#include<string>
using namespace std;

int main()
{
	// Declaration of output file
	ofstream outFile;
	outFile.open("guess.txt");

	// error message for opening the output file
	if (!outFile)
	{
		cout << "Error openning output file outFile. Exiting... " << endl;
		return 1;
	}

	// Generate a random number to be guessed
	srand(time(0));

	int number;
	// prompt the user for a magic number
	cout << "Please enter a magic number here: ";
	cin >> number;
	outFile << number << endl;

	if (number >= 0 && number <= 100)
	{
		cout << "number is within the guess range.\n";
		int guess = rand() % 101;

		// number produced by user guessed by the computer
		cout << "The number you guessed is: " << guess << endl;
		outFile << "The number you guessed is: " << guess << endl;
		cout << endl;

		// while loop for checking if the guess correlates to the number the user inputs
		while (guess != number)
		{
			cout << "The number guessed is: " << guess << endl;
			cout << "Is my Guess too High or too Low?\n";

			string judgement;
			cin >> judgement;

			// check and error message for an input that is higher than the number inputted
			if (judgement == "high")
			{
				if (guess > number)
				{
					cout << "The guess is too high, guess again." << endl;
					outFile << "The guess is too high, guess again\n";
					guess = rand() % (guess + 1);
					cout << guess << endl;
					outFile << guess << endl;
					cout << endl;
				}
				else if (guess < number)
				{
					cout << "You are not trust-worthy\n";
					outFile << "You are not trust-worthy\n";
					return 1;
				}
				else if (guess == number)
				{
					cout << "You guessed my number right." << endl;
					cout << guess << endl;
					outFile << "You guessed my number right." << endl;
					outFile << guess << endl;
					cout << endl;
				}

			}

			// check for if the guess is too low in comparison to the entered number by the user
			else if (judgement == "low")
			{
				if (guess < number)
				{
					cout << "The guess is too low, guess again." << endl;
					outFile << "The guess is too low, guess again." << endl;
					guess = (guess + 100) / 2;
					cout << guess << endl;
					outFile << guess << endl;
					cout << endl;
				}
				else if (guess > number)
				{
					cout << "You are not trust-worthy\n";
					outFile << "You are not trust-worthy\n";
					return 1;
				}
				else if (guess == number)
				{
					cout << "You guessed my number right." << endl;
					cout << guess << endl;
					outFile << "You guessed my number right." << endl;
					outFile << guess << endl;
					cout << endl;
				}
			}
		}
	}

	return 0;
}
			

