//**************************************************************************
//
// Student name: Julie Ziemer
//
// Student number: 200342432
//
// Assignment number: Assignment 3
//
// Program name: Assignment 3 math quiz.cpp
//
// Date written: March 11, 2015
//
// Problem statement: Develop a program that offers addition and multiplication questions (at random). For each question, print out the number of attempts on 
//					  the question and the time taken. The user may not continue until the question is answered correctly.  At the end of the quiz, print the 
//					  average number of attempts and the average time taken.
//
// Input:			  User enters their answer to the math equation.
//
// Output:	"What is " << number1 << " - " << number2 << "? "; "What is " << number1 << " + " << number2 << "? "; "What is " << number1 << " * " << number2 << "? ";
//			"Incorrect. Please try answering again."; "Correct!  Good answer."; "You answered in " << attempts << "attemps." << "Your time was " << questionTime << " seconds.";
//			 "Your average attempts per question: " << (question1 + question2 + question3 + question4 + question5) / 5.0; "Your average time per question: " << (qt1 + qt2 + qt3 + qt4 + qt5) / 5.0 << " seconds"
//
// Algorithm: Using rand, time is generated to begin timing the user.  A while loop is used to make sure that no more than 5 questions are asked.  The type of operators
//			  and random numbers used in the questions are also generated using the rand function.  The numbers range between 0 and 9, while the operators are set to 3 options
//			 including addition, subtraction, and multiplication.  When the user inputs their anwer, the number of attempts is increamented and it is tested using the correct_answer variable.  If the answer is 
//			  incorrect, a while loop continues to ask the question while incrementing the number of attempts.  When the user inputs the correct answer, the time and 
//			 their attempts for the question are displayed.  At the end of 5 questions, the user's average time and attempts per question are displayed.  These values are 
//			 stored in variables that correspond with the number of counts incremented after each question.
//
// Major variables: int count, number1, number2, temp, answer, correct_answer, attempts, question_type; float question1, question2, question3, question4, question5;
//					float qt1, qt2, qt3, qt4, qt5; long endTime, questionTime, startTime;
//
// Assumptions:  The user will be able to answer all 5 questions.  The rand function will work for time and generating the numbers and operators.
//
// Program limitations: The time function may not be entirely accurate especally using long.  The program will not build.  
//
//**************************************************************************
#include <iostream>
#include <ctime> // Needed for time function
#include <cstdlib> // Needed for the srand and rand functions
using namespace std;

int main()
{
	int count = 0; // Count the number of questions
	long startTime = time(0);
	const int NUMBER_OF_QUESTIONS = 5;

	srand(time(0)); // Set a random seed

	while (count < NUMBER_OF_QUESTIONS)
	{
		// 1. Generate two random single-digit integers
		int number1 = rand() % 10;
		int number2 = rand() % 10;

		// 2. If number1 < number2, swap number1 with number2
		if (number1 < number2)
		{
			int temp = number1;
			number1 = number2;
			number2 = temp;
		}

		int answer;  // user input
		int correct_answer; // the actual answer to the question
		int attempts = 0;
		// Select ONE OF subtraction, addition, or multiplication - AT RANDOM
		// Prompt the user for an answer, based on the question type selected
		int question_type = rand() % 3;
		if (question_type == 0)
		// subtraction selected
		cout << "What is " << number1 << " - " << number2 << "? ";
		correct_answer = number1 - number2;
		cin >> answer;
		
		attempts ++;
		
		if (question_type == 1)
		// addition selected
		cout << "What is " << number1 << " + " << number2 << "? ";
		correct_answer = number1 + number2;
		cin >> answer;
		attempts ++;
	
		if (question_type == 2)
		// multiplication selected
		cout << "What is " << number1 << " * " << number2 << "? ";
		correct_answer = number1 * number2;
		cin >> answer;
		attempts ++;

		while (answer != correct_answer)
		  {
		 cout << "Incorrect. Please try answering again."  << endl;
		 cin >> answer;
		
		 attempts ++;
		  }
		
		cout << "Correct!  Good answer." << endl;
		 
		count++; 
		
		long endTime = time(0);
		long questionTime = endTime - startTime;

		cout << "You answered in " << attempts << "attemps." << "Your time was " << questionTime << " seconds." << endl;
		
		int question1, question2, question3, question4, question5;  // store the number of attempts for each question
		long qt1, qt2, qt3, qt4, qt5; // store the time for each question
		
		if (count == 1)
		 {
	      question1 = attempts;
		  qt1 = questionTime;
		 }
		 if (count == 2)
		 {
		 question2 = attempts;
		 qt2 = questionTime;
		 }
		 if (count == 3)
		 {
		 question3 = attempts;
		 qt3 = questionTime;
		 }
		 if (count == 4)
		 {
		 question4 = attempts;
		 qt4 = questionTime;
		 }
		 if (count == 5)
		 {
		 question5 = attempts;
		 qt5 = questionTime;
		 }
		
		 }
		
		cout << "Your average attempts per question: " << (question1 + question2 + question3 + question4 + question5) / 5.0 << endl;  // add up attempts and divide by total questions
		cout << "Your average time per question: " << (qt1 + qt2 + qt3 + qt4 + qt5) / 5.0 << " seconds" << endl; // add up the time and divide them by the total questions
		
		return 0; // end program
	  }