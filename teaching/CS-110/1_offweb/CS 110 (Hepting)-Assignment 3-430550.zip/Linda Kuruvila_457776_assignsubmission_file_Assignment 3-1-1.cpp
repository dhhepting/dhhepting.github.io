#include <iostream>
#include <ctime> 
#include <cstdlib> 
using namespace std;

int main()

{
	int countwrongprod = 0;
	int countwrongadd = 0;
	int countwrongsub = 0;
	int totalattempts = 0;
	long avgattempts = 0;
	long timetakensub = 0;
	long timetakenadd = 0;
	long timetakenprod = 0;
	long totaltimetaken = 0;
	long avgtimetaken = 0;

	srand(time(0));
	for (int i = 0; i < 5; i++)
	{
		int type = rand() % 3;
		if (type == 0)
		{
			long starttimesub = time(0);
			int num1sub = rand() % 10;
			int num2sub = rand() % 10;
			if (num1sub < num2sub)
			{
				int temp = num1sub;
				num1sub = num2sub;
				num2sub = temp;
			}
			cout << "What is " << num1sub << "-" << num2sub << "?\n" << endl;
			int answersub = -1;
			while (num1sub - num2sub != answersub)
			{
				cin >> answersub;
				countwrongsub++;
				if (num1sub - num2sub != answersub)
				{
					cout << "Oh Oh Sorry! Please try again\n" << endl;
				}
				else
				{
					cout << "Good Job! You did it.\n" << endl;
				}
			}
			long endtimesub = time(0);
			cout << "Number of attempts: " << countwrongsub << "\n" << endl;
			timetakensub = endtimesub - starttimesub;
			cout << "Time taken: " << timetakensub << "\n seconds." << endl;
		}
		else if (type == 1)
		{
			long starttimeadd = time(0);
			int num1add = rand() % 10;
			int num2add = rand() % 10;
			cout << "What is " << num1add << "+" << num2add << "?\n" << endl;
			int answeradd = -1;
			while (num1add + num2add != answeradd)
			{
				cin >> answeradd;
				countwrongadd++;
				if (num1add + num2add != answeradd)
				{
					cout << "Oh Oh Sorry! Please try again\n" << endl;
				}
				else
				{
					cout << "Good Job! You did it.\n" << endl;
				}
			}
			long endtimeadd = time(0);
			cout << "Number of attempts: " << countwrongadd << "\n" << endl;
			timetakenadd = endtimeadd - starttimeadd;
			cout << "Time taken: " << timetakenadd << "\n seconds." << endl;
		}
		else if (type == 2)
		{
			long starttimeprod = time(0);
			int num1prod = rand() % 10;
			int num2prod = rand() % 10;
			cout << "What is " << num1prod << "*" << num2prod << "?\n" << endl;
			int answerprod = -1;
			while (num1prod*num2prod != answerprod)
			{
				cin >> answerprod;
				countwrongprod++;
				if (num1prod * num2prod != answerprod)
				{
					cout << "Oh Oh Sorry! Please try again\n" << endl;
				}
				else
				{
					cout << "Good Job! You did it.\n" << endl;
				}
			}
			long endtimeprod = time(0);
			cout << "Number of attempts: " << countwrongprod << "\n" << endl;
			timetakenprod = endtimeprod - starttimeprod;
			cout << "Time taken: " << timetakenprod << "\n seconds." << endl;
		}
		cout << endl;
	}
	totalattempts = totalattempts + countwrongsub + countwrongadd + countwrongprod;
	cout << "total number of attempts: " << totalattempts << endl;

	avgattempts = totalattempts / 5;
	cout << "average number of attempts :" << avgattempts << endl;

	totaltimetaken = totaltimetaken + timetakensub + timetakenadd + timetakenprod;
	cout << "total amount of time taken :" << totaltimetaken << endl;

	avgtimetaken = totaltimetaken / 5.0;
	cout << "average time taken: " << avgtimetaken << " seconds" << endl;

	cout << " Fantastic Work! Keep it up." << endl;

	return 0;
}