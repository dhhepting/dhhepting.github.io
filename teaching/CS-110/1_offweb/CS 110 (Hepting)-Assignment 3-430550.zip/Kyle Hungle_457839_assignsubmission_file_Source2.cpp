/*Name: Kyle HUngle
Student #: 200354270
Assignment #3
Program Name: Assignment#3-2
March 11/15
Problem Question
2.Modify Listing 5.4 so that the user must answer the question
correctly before proceeding. Also, your program should offer addition
and multiplication questions (at random). For each question, print out
the number of attempts on the question and the time taken. At the end of
the quiz, print the average number of attempts and the average time taken.
*/


#include <iostream>
#include <ctime> // Needed for time function
#include <cstdlib> // Needed for the srand and rand functions
using namespace std;

int main()
{
  int correctCount = 0; // Count the number of correct answers
  int count = 0; // Count the number of questions
  int answer; // anser variable
  long startTime = time(0);  // starts the time at zero for the whole question
  int NUMBER_OF_QUESTIONS; // variable for number of questions

  cout << "How many math questions would you like to do? " ; //prompts the user for how many questions they want
  cin >> NUMBER_OF_QUESTIONS;

  srand(time(0)); // Set a random seed 

  while (count < NUMBER_OF_QUESTIONS) //initiates while the counter is less than the desired number of questions
  {
    // 1. Generate two random single-digit integers
    int number1 = rand() % 10;
    int number2 = rand() % 10;
	int operationselector = rand() % 3;

    // 2. If number1 < number2, swap number1 with number2
    if (number1 < number2)
    {
      int temp = number1;
      number1 = number2;
      number2 = temp;
    }

	if (operationselector == 0 ) //if the selector is 0 then subtracction is the operation
	{
		int count1 =0; //count1 variable to count question attempts
		long startTime1 = time(0); //starts time for the question
	do
	{
    cout << "What is " << number1 << " - " << number2 << "? ";  // outputs the question
    cin >> answer;
	count1 ++; //adds 1 to the counter
	} while (number1-number2 != answer);  // will keep doing above until the answer is equal to the answer

    
    if (number1 - number2 == answer)   // displays correct and the attempts that the question took as well as the time the question took to do
    {
      cout << "You are correct!\n";
	  cout << "Number of attempts for that question was: " << count1 << endl;
      correctCount++; //adds one to the total questions correct counter
	  long endTime1 = time(0);
	  long questionTime1 = endTime1 - startTime1; //figures out the time for the individual question
	  cout << "Question time was: " << questionTime1 << " seconds" << endl; //displays the time for that question
	}
    // Increase the count
    count++;

	}
	if (operationselector == 1 ) //if the selector is 1 then addition is the operation
	{
		int count2 =0; //count2 variable to count question attempts
		long startTime2 = time(0);  //starts time for the question
	do
	{
    cout << "What is " << number1 << " + " << number2 << "? "; // outputs the question
    cin >> answer;
	count2 ++; //adds 1 to the counter
	} while (number1+number2 != answer); // will keep doing above until the answer is equal to the answer


    if (number1 + number2 == answer) 
    {
      cout << "You are correct!\n";
	  cout << "Number of attempts for that question was: " << count2 << endl;
      correctCount++; 
	  long endTime2 = time(0); 
	  long questionTime2 = endTime2 - startTime2;
	  cout << "Question time was: " << questionTime2 << " seconds" << endl;
	}
    // Increase the count
    count++;

	}
	if (operationselector == 2 ) //if the selector is 2 then multiplication is the operation
	{
		int count3 = 0; //count3 variable to count question attempts
		long startTime3 = time(0);  //starts time for the question
	do
	{
    cout << "What is " << number1 << " * " << number2 << "? "; // outputs the question
    cin >> answer;
	count3 ++; //adds 1 to the counter
	} while (number1*number2 != answer); // will keep doing above until the answer is equal to the answer

    
    if (number1 * number2 == answer) // displays correct and the attempts that the question took as well as the time the question took to do
    {
      cout << "You are correct!\n";
	  cout << "Number of attempts for that question was: " << count3 << endl;
      correctCount++;
	  long endTime3 = time(0);
	  long questionTime3 = endTime3 - startTime3;
	  cout << "Question time was: " << questionTime3 << " seconds" << endl;
	}
    // Increase the count
    count++;

	}

  }

  long endTime = time(0); //starts end time
  long testTime = endTime - startTime; //testime is endtime - starttime

  cout << "Number of questions completed " << correctCount << "\nTest time is "
       << testTime << " seconds\n"; // displays the time taken to do the test

  return 0;
}
