// Student name: Callum Jacobson
//
// Student number: 200234874
//
// Assignment number: 3 Part 2
//
// Program name: Math Quiz
//
// Date written: 11 March 2015
//
// Problem statement: 
//		The problems that need to be solved by this program are:
//		1) Randomly generate 5 subtraction, addition and multiplication problems.
//		2) Measure the amount of time user takes to complete each problem, 
//		total amount of time taken, number of attempts per question, and average number of attempts
//
// Input:
//		The user inputs integer answers to each problem
//
// Output:
//		The program will output the following:
//		1) 5 randomly generated subtraction, addition or multiplication problems.
//		2) The amount of time taken per question.
//		3) The number of attempts per question.
//		4) The total amount of time taken.
//		5) The average number of attempts per question
//
// Algorithm: 
//		1) Program outputs a randomly generated subtraction, addition or multiplication problem (x5).
//		2) User answers the problem (x5).
//		3) Program outputs the amount of time taken and the number of attempts after each question (x5).
//		4) After 5 questions are completed the program outputs the total time taken and the average number of attempts per question.
//
// Major variables: 
//		1) The randomly generated numbers that comprise the questions.
//		2) The user's answers.
//		3) The user's number of attempts
//		4) The time taken (per question and total).
//
// Assumptions:
//		1) Assumes that user will give answer in integers.
//
// Program limitations:
//		1) Can only generate multiplication, addition and subtraction questions.
//
//**************************************************************************
#include <iostream>
#include <ctime> // Needed for time function
#include <cstdlib> // Needed for the srand and rand functions
using namespace std;

int main()
{
	int subattempts = 0;
	int addattempts = 0;
	int multattempts = 0;
	int correctCount = 0; // Count the number of correct answers
	int count = 0; // Count the number of questions
	long startTime = time(0);
	long totaltime = 0;
	const int NUMBER_OF_QUESTIONS = 5;

	srand(time(0)); // Set a random seed

	while (count < NUMBER_OF_QUESTIONS)
	{
		int qtype = rand() % 3;

		if (qtype == 0)
		{
			long substarttime = time(0);
			int number1 = rand() % 10;
			int number2 = rand() % 10;
			int subanswer;
			int substudentanswer;


			cout << "What is " << number1 << " - " << number2 << "? ";
			subanswer = number1 - number2;
			cin >> substudentanswer;
			while (number1 - number2 != substudentanswer)
			{
				cout << "Incorrect, try again. What is " << number1 << " - " << number2 << "? ";
				cin >> substudentanswer;
				subattempts++;
			}
			cout << "Correct" << endl;
			long subendtime = time(0);
			subattempts++;
			cout << "Attempts: " << subattempts << endl;
			long subtimetaken = subendtime - substarttime;
			cout << "Time taken: " << subtimetaken << endl;
			totaltime += subtimetaken;

			count++;
		}
		else if (qtype == 1)
		{
			long addstarttime = time(0);
			int addanswer;
			int addstudentanswer;
			int number1 = rand() % 10;
			int number2 = rand() % 10;

			cout << "What is " << number1 << " + " << number2 << "? ";
			addanswer = number1 + number2;
			cin >> addstudentanswer;
			while (number1 + number2 != addstudentanswer)
			{
				cout << "Incorrect, try again. What is " << number1 << " + " << number2 << "? ";
				cin >> addstudentanswer;
				addattempts++;
			}
			cout << "Correct" << endl;
			long addendtime = time(0);
			addattempts++;
			cout << "Attempts: " << addattempts << endl;
			long addtimetaken = addendtime - addstarttime;
			cout << "Time taken: " << addtimetaken << endl;
			totaltime += addtimetaken;

			count++;
		}
		
		else if (qtype == 2)
		{
			long multstarttime = time(0);
			int multanswer;
			int multstudentanswer;
			int number1 = rand() % 10;
			int number2 = rand() % 10;

			cout << "What is " << number1 << " * " << number2 << "? ";
			multanswer = number1 * number2;
			cin >> multstudentanswer;
			while (number1 * number2 != multstudentanswer)
			{
				cout << "Incorrect, try again. What is " << number1 << " * " << number2 << "? ";
				cin >> multstudentanswer;
				multattempts++;
			}
			cout << "Correct" << endl;
			long multendtime = time(0);
			multattempts++;
			cout << "Attempts: " << multattempts << endl;
			long multtimetaken = multendtime - multstarttime;
			cout << "Time taken: " << multtimetaken << endl;
			totaltime += multtimetaken;

			count++;
		}

	}
	int totalattempts = (subattempts + addattempts + multattempts);
	float averageattempts = totalattempts / 5;
	cout << "Average number of attempts per question: " << averageattempts << endl;
	cout << "Total time taken: " << totaltime << endl;


	// while...
	// what condition needs to be true?
		//{
			// what needs to happen in this loop?  
			// Does it need to executed at least once?
		//}
	//correctCount++;

	//long endTime = time(0);
	//long testTime = endTime - startTime;
	// what will get printed here?
	//cout << "Correct count is " << correctCount << "\nTest time is ";
	//cout << testTime << " seconds\n";

	return 0;
}