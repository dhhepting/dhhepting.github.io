//Ian Cowan
//ID 200229343
//CS 110 Assignment 3 Part 1 (Modified Listing 5.3)
//Dr. Daryl Hepting
//due March 11th, 2015
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <fstream> 	//needed for file stream
using namespace std;

int main()
{
//Declare variables, and define output file
ofstream outData;
outData.open("Asst3P1.txt");
int num;
int upperlimit = 100;
int lowerlimit = 0;
	
  // Get user to pick a number
cout << "Please pick an integer greater than or equal to zero, and less than or equal to 100: ";
cin >> num;
outData << num << endl;
bool guess_correctness = false;		// allows easy identification later of paths to take for 
					//right and wrong guesses by the computer

//When input follows given guidelines, enter the bisectoring guess loop
 if (num >= 0 && num <= 100)
{
	do
	{
		int guess = (upperlimit + lowerlimit) / 2;	//Max. efficiency by eliminating half the 
							//possible numbers with each guess
		cout << "The computer's guess is " << guess << "." << endl;
		outData << "The computer's guess is " << guess << "." << endl;
		cout << "Is the guess too high (h), too low (l), or correct (c)?" << endl;
		char response;
		cin >> response;
		outData << "User responded the above guess was: " << response << "." << endl; 
		
		if (response == 'h')
		{
			upperlimit = guess - 1;	//Changes guess parameters to reflect response
		}
		else
		{
			if (response == 'l')
			{
				lowerlimit = guess + 1;	//Changes guess par. to reflect response
			}
			else
			{
				if (response == 'c')
				{
					guess_correctness = true;      //Do-while exit condition
				}
			}
		}
	}
	while (guess_correctness = false && (upperlimit >= lowerlimit))
	
	//Determine whether the user is being honest (the following condition should always fail 
	//since it's placed outside the above do-while loop. If not, the user lied.)
	if (guess_correctness = false) 			
	{
		cout << "You're not being honest!" << endl;
	}
}

  return 0;
}