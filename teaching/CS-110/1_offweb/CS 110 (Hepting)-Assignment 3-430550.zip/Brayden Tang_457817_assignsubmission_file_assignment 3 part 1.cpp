//**************************************************************************
//Note: I talked to Dr. Hepting and it appears that I did the assignment, but misinterpreted the question making it more difficult than it should have been. Technically, the requirments going by the description are met but it is not exactly how Dr. Hepting wanted it.
// Student name: Brayden Tang
//
// Student number: 200350623
//
// Assignment number: 3, Part 1 
//
// Program name: Picking an Integer Between 0-100 and Having a Computer Randomly Guess The Integer
//
// Date written: March 8, 2015
//
// Problem statement: Modify Listing 5.3 so that the computer guesses a number that the user provides (switch the roles of user and computer from Listing 5.3). Write the guesses from the program and the user's answers to a file. Print a message if the computer detects that the user has not been trustworthy in her answers. Use the technique that we discussed in class today.
//
// Input: A number from 0-100, inclusive for the computer to guess.
//
// Output: Validity of input, a guess by the computer, if the guess is higher or lower than the inputted value by the user, if the user is being honest in telling the computer if it's higher or lower, and then confirmation by the computer that the guessed value matches the inputted value.
//
// Algorithm: The main algorithm relies on the fact that if the computer initially guesses 50, half of the values will be automatically removed in the range 0-100 when the user inputs higher or lower. Then, as the user keeps entering higher or lower, the lowest possible value will gradually become higher (or the highest possible value will gradually become lower) until there is only one option remaining (assuming the computer doesn't get lucky and guesses correctly before narrowing it down to a single value).
//
// Major variables: uservalue, highORlow, computer_guess, lowest_possible, highest_possible, number
//
// Assumptions: The user must input a value from 0-100 in the first step or they will receive an error. The program also assumes the user will enter some sort of interger in the first step, if they don't, the program enters an infinite loop.
//
// Program limitations: Inputted values that aren't an interger will cause the program to enter an infinite loop. Also, values from 0-100 can only be read, though this could be changed (it wasn't said in the assignment to specify ranges and listing 5.3 guesses integers from 0-100).
//
//**************************************************************************


#include <iostream>
#include <cstdlib>     //for srand function
#include <fstream>     //to output to a textfile
#include <ctime>       //to obtain time
using namespace std;
int main()

{
	int uservalue;
	char highORlow;
	int computer_guess;
	int lowest_possible = 0;      //initalize variables lowest_possible and highest_possible to be 0 and 100, respectively. This is due to the specified domain of 0-100.
	int highest_possible = 100;
	srand(time(0));
	int number = 50; //the computer will initally guess at 50 every time to easily narrow the search the fastest
	computer_guess = number;

	ofstream output("answersandguesses.txt");   //output to a textfile called answersandguesses
	cout << "Input an interger for the computer to guess between 0 and 100 inclusive." << endl;  //prompt user for an interger between 0 and 100. If they put in any other value outside this domain they will get an error.
	cin >> uservalue;
	output << "The user inputted " << uservalue << " for the computer to guess." << endl;  //output the inputted value to the textfile

	while (uservalue > 100 || uservalue < 0)   //error message for people who don't listen to the instructions
	{
		cout << "Invalid input. Try again. Please input a value between 0 and 100 inclusive." << endl;
		cin >> uservalue;
	}


	while (uservalue != computer_guess)
	{

		cout << "The computer guessed " << computer_guess << "." << endl;
		output << "Computer guess was: " << computer_guess << endl;
		cout << "The computer was wrong." << endl;
		cout << "Was the value too high or too low? Enter H/h for too high and L/l for too low. Don't lie!" << endl;
		cin >> highORlow;
		output << "Was the value too high or too low? Note that H/h is too high and L/l means too low: " << highORlow << endl;
		while (((uservalue > computer_guess) && (highORlow == 'H' || highORlow == 'h')) || (((uservalue < computer_guess) && (highORlow == 'l' || highORlow == 'L'))))   //in this line, we know the user is lying or made a mistake if the interger entered is lower than the computer's guess but the user says it's higher, and vice versa.
		{
			cout << "Are you sure? Don't be a liar. Recheck the values and try again." << endl;
			output << "Answer was not trustworthy." << endl;  //output to the textfile the untrustworthy answer
			cin >> highORlow;
		}

		if (highORlow == 'H' || highORlow == 'h')
		{
			highest_possible = computer_guess - 1;   //the highest possible value will always be one less than what was last guessed 
			if ((highest_possible == lowest_possible) && (uservalue == 0))  //in the special case for the value 0 in which all other values are exhausted, an error occurs if this isn't added (division by zero).
			{
				computer_guess = 0;
				break;
			}
			else if (highest_possible == lowest_possible)  //if the highest possible digit equals the lowest possible digit, the numbers are all exhausted and there is only one option. The +1 is to adjust for the offset. This is also here to avoid the runtime error of again division by zero.
			{
				computer_guess = 1 + number;
				break;
			}
			number = ((rand() % (highest_possible - lowest_possible)) + lowest_possible); //the main algorithm as alluded to earlier in the headerfile
			computer_guess = number;

		}
		else if (highORlow == 'L' || highORlow == 'l')  //code is essentially the same thing as above, except the lowest possible is being adjusted
		{
			lowest_possible = computer_guess + 1; //the lowest possible digit equals the last guess + 1
			if ((highest_possible == lowest_possible) && (uservalue == 0))
			{
				computer_guess = 0;
				break;
			}
			else if (highest_possible == lowest_possible)
			{
				computer_guess = 1 + number;
				break;
			}
			number = ((rand() % (highest_possible - lowest_possible)) + lowest_possible);
			computer_guess = number;


		}
		else if (highORlow != 'H' || highORlow != 'h' || highORlow != 'l' || highORlow != 'L')  //if user doesn't enter a valid character to represent higher or lower, this message is displayed
		{
			cout << "Invalid input. Try again." << endl;
		}
	}

	cout << "The computer has guessed " << computer_guess << "." << endl;
	cout << "The computer has guessed correctly." << endl;
	output << "The computer guessed " << computer_guess << " and thus has guessed correctly." << endl;  //output to textfile the correct guess
	output.close();  //file is closed

	return 0;
}

//end of program