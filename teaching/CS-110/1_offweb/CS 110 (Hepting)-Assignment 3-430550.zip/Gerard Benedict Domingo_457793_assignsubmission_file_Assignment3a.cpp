/**********************************************************************************
Name: Gerard Domingo

SID: 200356051

Assignment number: 3

Program name: Computer Guess

Date Written: March 12, 2015

Problem statement: The computer will try to guess the number that the user have in mind. It will keep showing random numbers until the number wanted is shown to the user.

Input: Yes or No inputs from user. Also it will show the number of times it got the wrong number.

output: A message showing the right number and the number of attempts it took to get said number. 

Major Variable: The rand and while statments. The rand fuction will generate a random number from a seed and depending on the time of current time. Also with the incrementation 
of the number of attempts in tell the chances of the computer getting the right number.

***********************************************************************************/

#include <iostream>
#include <cstdlib>
#include <ctime> 
using namespace std;

int main()
{
	srand(time(0));
	char user;
	int guess = rand() % 101;
	int attempts = 0;
	
	cout << "This program will guess the number you have in your head" << endl;
	
	do 
	{
	
	cout << "Is the number you have is " << guess <<  " y or n" << endl;
	cin >> user;
	attempts++;	
	
		guess = rand() % 101;
		
		if (user == 'y')
		{
		cout << "The computer guessed the number  " << attempts << " times." << "The right number is: " << guess << endl;
	    }
	    
	} while (user == 'n');
	
	return 0;
		
}
