//********************************************************************
//Name: Shu Wang
//Student number: 200335170
//Assignment number: 3
//Program name: Modify Listing 5.3
//Date written: Mar11, 2015
//Problem statement: Modify Listing 5.3 so that the computer guesses a number that the user provides (switch the roles of user and computer from Listing 5.3). Write the guesses from the program and the user's answers to a file. Print a message if the computer detects that the user has not been trustworthy in her answers. Use the technique that we discussed in class today.
//Input: the number that you want computer to guess
//Output: computer guess number
//Algorithm:
//(1) while
//(2)  while (count < NUMBER_OF_QUESTIONS), program runs

//Major variables: number,guess,upper,lower,count
//Assumptions:  user will judge the value that is guessed by computer
//Program limitations: After 8 times guessing, the program will know if the user is truthworthy.
//**********************************************************************

#include <iostream>
#include <cstdlib>
#include <ctime> // Needed for the time function
#include <fstream>
using namespace std;

int main()

{
    int number,guess,upper,lower,count;
    string user_input;
    ofstream outData;
    outData.open("guesses.txt");// output file opened for storage
    
    // get a  number from user
    cout << "The computer will guess the number that you enter. Please provide a number (Between 0 and 100): "<< endl;
    cin >> number;
    cout << "Your input number is stored in 'guesses'file"<<endl;
    outData << number << endl; // users guess is stored
    
    upper=100;
    lower=0;
    guess=50;
    
    count=0;

    while (count < 8)// if the program calculate more 7 times, it means the user lies
    {
        
        if (number!=guess)
    {
       guess=(upper+lower)/2;
        // The guess will be printed both in file and program
        outData << "The computer guess number is:" << guess << endl;
        cout <<"The computer guess number is:" <<guess<<endl;
        cout << endl; // just want to get a empty line between each guess
        cout << "Compare the value of guess. Choose from option: Guess is LOWER than user's number: L. Guess is HIGHER than user's number: H. The Computer get the right guess: Y." << endl;
        cin >> user_input;
        
        
        
            //ask user to compare the relationship between input number and guess
            if (user_input == "L")
            {
                lower=guess;
                cout<< "The guess number too large. "<< guess << endl;
            }
            else if (user_input == "H")
            {
                upper=guess;
                cout << "The guess number is too small. "<< guess << endl;
            }
            else if (user_input == "Y")
            {
                cout<< "The computer guess the right number\n" << endl;
                return 0;
            }
            
    }
        else // if 50 is the input number, program jumps to here withou chooseing L,H,Y
        {
            outData << "The computer guess number is:" << guess << endl;
            cout <<"The computer guess number is:" <<guess<<"\nThe computer guess the right number at the first time"<<endl;
            return 0;
        }
        
       count++;
    }
        //after 8 times of calculation,"User is lying " will be displayed
        cout << "User is lying. Because 8 times of guess should cover all numbers"<< endl;
        outData << "User is lying. Because 8 times of guess should cover all numbers"<< endl;
    
    
    return 0;
}