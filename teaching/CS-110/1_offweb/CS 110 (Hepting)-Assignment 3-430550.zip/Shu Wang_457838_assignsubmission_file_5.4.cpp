//********************************************************************
//Name: Shu Wang
//Student number: 200335170
//Assignment number: 3
//Program name: Modify Listing 5.4
//Date written: Mar11, 2015
//Problem statement: Modify Listing 5.4 so that the user must answer the question correctly before proceeding. Also, your program should offer addition and multiplication questions (at random). For each question, print out the number of attempts on the question and the time taken. At the end of the quiz, print the average number of attempts and the average time taken.
//Input: Answer for each question
//Output: number of attempts for each question; time taken for calculating one question; average number of attempts;average time taken for calculations
//Algorithm:
//(1) srand(time(0)) get random number
//(2)  while (count < NUMBER_OF_QUESTIONS), program runs
//(3) if (number1 < number2), change the order of two numbers
//(4) if, if else, to choose the type of calculation
//(5) while (answer != correct_answer), ask user to keep doing calculation until getting right answer
//(6) time(0), get the start time and end time.
//Major variables: answer, attemp, testTime
//Assumptions:  It only for three types of calculation: addition, deduction, multiplication
//Program limitations: It can only do three types of calculation
//**********************************************************************


#include <iostream>
#include <ctime> // Needed for time function
#include <cstdlib> // Needed for the srand and rand functions
using namespace std;

int main()
{
   // int correctCount = 0; // Count the number of correct answers
    int count = 0; // Count the number of questions
    int attemp = 0; // Count the number of attemp
    int correct_answer=0;
    int sum_attemp=0;
    long startTime = time(0);

    const int NUMBER_OF_QUESTIONS = 5;
    
    srand(time(0)); // Set a random seed
    
    
    
    while (count < NUMBER_OF_QUESTIONS)
    {
        // Generate two random single-digit integers
        int number1 = rand() % 10;
        int number2 = rand() % 10;
        
        if (number1 < number2) //compare two numbers, if number1<number2, we change the order
        {
            int temp = number1;
            number1 = number2;
            number2 = temp;
        }
        
        // Select ONE OF subtraction, addition, or multiplication - AT RANDOM
        // Prompt the user for an answer, based on the question type selected
        int choice = rand()% 3;
        
        // subtraction selected
        if (choice==0)
        {
            cout << "What is " << number1 << " - " << number2 << "? ";
            
            correct_answer = number1 - number2;
        }
        
        // addition selected
        else if (choice==1)
        {
            cout << "What is " << number1 << " + " << number2 << "? ";
            correct_answer = number1 + number2;
        }
        
        // multiplication selected
        else if (choice==2)
        {
            cout << "What is " << number1 << " * " << number2 << "? ";
            correct_answer = number1 * number2;
        }
        
        int answer;
        cin >> answer;
        
        while (answer != correct_answer)
        {
            
            cout << "You didn't get the right answer. Please try again\n";
            cin >> answer;
            // what needs to happen in this loop?
            // Does it need to executed at least once?
            attemp++;
            
        }
       sum_attemp=++attemp;
       
        //get the time for testtime
        long endTime = time(0);
        long testTime = endTime - startTime;
        
        cout << "The number of attempts on the question is：" << attemp<< endl;
        cout << "The time taken for calculating one question is：" << testTime<< endl;
              
        // Increase the count
        count++;
    }
    //get the time for average test time
    long endTime = time(0);
    int averageTime= (endTime - startTime)/5.0;
    cout << "The average number of attempts is: " << sum_attemp/5.0 << endl;
    cout << "The average time taken for calculations is:" <<averageTime<< " seconds\n";
    
    return 0;
}