//**************************************************************************
//
// Student name: Riley Peters
//
// Student number: 200 354 249
//
// Assignment number: #3 - Part 1
//
// Program name: Number Guessing
//
// Date written: March 7th, 2015
//
// Problem statement: Have a computer guess the number that a user is thinking of by asking questions.
//                      User answers questions by saying high, low, or correct.
//
// Input: Answers to the programs questions
//
// Output: The programs guesses and the persons number, as well as a text file of a review of all the
//          questions
//
// Algorithm:   -> the computer guesses the number between the two limits
//              -> if high, guess becomes upper limit, if low guess becomes lowerlimit
//              -> the question number, guess, and answer are all output to a txt file
//              -> this continues in a loop till the guess is correct
//              -> Once guess is correct it escapes loop
//              -> exit program
//
// Major variables: lower limit, upper limit, guess.
//
// Assumptions: people are only considering integer values, the user stays within limits of 0-100, people
//                  are honest
//
// Program limitations: -> Does not work with negative numbers
//                      -> Only integer values
//
//**************************************************************************

#include <iostream>
#include <fstream>      // for outData functions
using namespace std;
int main()

{
    // Defining variables
    int upperLimit = 100;
    int lowerLimit = 0;
    int number;
    int guess;
    int count = 1;
    string answer;
    
    ofstream outData;   /* setting outData function */
    
    // Prompt for input
    cout << "Enter a  number between 0-100 to be guessed to be written on the output file" << endl;
    cin >> number;
    
    cout << "This program will ask you questions to guess your number" << endl;
    
    outData.open("guessreview.txt");    /* Opening outData file */
    outData << "Number: " << number << endl;
    
    // Loop to continue till the user inputs correct
    while (answer != "correct")
    {
        guess = (upperLimit + lowerLimit) / 2;
        cout << "Is your number " << guess << endl;
        outData << "Guess " << count << ":" << endl;    /* Outputting to txt file */
        outData << guess << " -> ";
        
        // Prompt for answer input
        cout << "Enter high, low, or correct" << endl;
        cin >> answer;
        
        outData << answer << endl;                      /* Output answer to file */
    
        // Loop to ensure proper answer is given
        while (answer != "high" && answer != "low" && answer != "correct")
        {
            cout << "Enter if the guess is high, low, or correct" << endl;
            cin >> answer;
        }
        
        // If guess is too high, sets it as upper limit
        if (answer == "high")
            upperLimit = guess;
        
        // If guess is too low, sets it as lower limit
        if (answer == "low")
            lowerLimit = guess;
        
        // If computer has narrowed onto an answer and the user doesn't say they are correct
        if (lowerLimit == upperLimit && answer != "correct")
            cout << "Please be honest with your answers." << endl;
        
        count++;
    }
    
    cout << "Your number is: " << guess << endl;
    
    cout << "A review can be found in the file 'guessreview.txt'" << endl;
    
    return 0;
}

