//**************************************************************************
//
// Student name:Juan Echavarria	
//
// Student number: 200360759
//
// Assignment number: 3
//
// Program name: 5.3
//
// Date written: 11-03-2015
//
// Problem statement: Modify Listing 5.3 so that the computer guesses a number that the user provides (switch the roles of user and computer from Listing 5.3). Write the guesses from the program and the user's answers to a file. Print a message if the computer detects that the user has not been trustworthy in her answers. Use the technique that we discussed in class today.
//
// Input: number
//
// Output: Is the number
//
// Algorithm: Binary search
//
// Major variables: number, guess, vf, in, lt = 100, md;
//
// Assumptions:
//
// Program limitations:
//
//**************************************************************************
#include "iostream"
#include "cstdlib"
#include "fstream"
#include "string"
#include "ctime"
int i, k, d, w, number, guess, vf, in, lt = 100, md;
using namespace std;
int main(){
	ofstream outData;
	outData.open("outputfile.txt");

	srand(time(0));
	cout << "Enter a number to be guess (0-100)" << "\n";
	outData << "Enter a number to be guess (0-100)" << "\n";
	cin >> number;
	guess = rand() % 101;
	if (number == guess)
		cout << "The number is " << guess;
	else
	{
		if (guess < number)
			in = guess;
		else
			lt = guess;
		while (md != number)
		{
			md = (in + lt) / 2;
			if (md == number){
				cout << "Is The number " << md << "\n";
				outData << "Is The number " << md << "\n";
				cout << "Press 1 if yes, 2 if not\n";
				outData << "Press 1 if yes, 2 if not\n";
				cin >> vf;
				if (vf == 1){
					cout << "User Is TrustWorthy\n";
					outData << "User Is TrustWorthy\n";
				}
				else
				{
					cout << "User Is not TrustWorthy\n";
					outData << "User Is not TrustWorthy\n";
				}
			}
			else
				if (md < number)
				{
				in = md;
				cout << "Is The number  " << md << " Lesser\n";
				outData << "Is The number " << md << "Lesser\n";
				cout << "Press 1 if yes, 2 if not\n";
				outData << "Press 1 if yes, 2 if not\n";
				cin >> vf;
				if (vf == 1){
					cout << "User Is TrustWorthy\n";
					outData << "User Is TrustWorthy\n";
				}
				else
				{
					cout << "User Is not TrustWorthy\n";
					outData << "User Is not TrustWorthy\n";
				}
				}
				else
				{
					cout << "Is The number " << md << " Greater\n";
					outData << "Is The number " << md << " Greater\n";
					cout << "Press 1 if yes, 2 if not\n";
					outData << "Press 1 if yes, 2 if not\n";
					cin >> vf;
					if (vf == 1){
						cout << "User Is TrustWorthy\n";
						outData << "User Is TrustWorthy\n";
					}
					else
					{
						cout << "User Is not TrustWorthy\n";
						outData << "User Is not TrustWorthy\n";
					}
					lt = md;
			}
		}
	}
}