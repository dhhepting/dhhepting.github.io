#include <iostream>
#include <string>
using namespace std;

int main()
{
	// Variables for the program to opperate.
	string answer;
	int low = 0;
	int high = 100;
	int guess = 50;
	int count = 0;

	// Give user instructions as well as prompt user to answer the guess.
	cout << "Pick a number in your head between 0 and 100. The program will guess the number." << endl;
	cout << "Use the word 'yes' if the number is correct." << endl;
	cout << "Use the word 'lower' if your number is lower than the guess." << endl;
	cout << "Use the word 'higher' if your number is higher than the guess." << endl;

	do
	{
		cout << "Is your number "  << guess << " ?" << endl;
		cin >> answer;
		count++;

		if (count > 6)		// Stop user from cheating.
		{
		cout << "Sorry, you were not being truthful." << endl;
		answer = "yes";
		}
		else if (answer == "higher")		// Generates a number higher than previous guess.
		{
		low = guess;
		guess = (((guess + high) / 2) + 0.5);
		}
		else if (answer == "lower")		// Generates a number lower than previous guess.
		{
		high = guess;
		guess = ((guess + low) / 2);
		}
	
		
	} while (answer != "yes"); // End of loop
	cout << "Thank you for trying" << endl;

  return 0;
}
