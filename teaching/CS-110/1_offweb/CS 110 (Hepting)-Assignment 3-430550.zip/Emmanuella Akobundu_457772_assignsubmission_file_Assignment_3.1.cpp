//**************************************************************
//
// Student name: Emmanuella Akobundu
// Studnet number: 200359057
// Assignment number: 3.1
// Program name: Assignment3-listing5.3.cpp
// Date written: March 11, 2015
// Problem statement: This program will ask the computer to guess the number that the user inputs, 
//                    then stores the computers guesses and the users number in a file.
//					  Finally, it shows when the computer guesses right and when it doesn't.
// Input: User's number.
// Output: Computer's guesses, and the correct number.
// Algorithm: The code consists of if and else statements as well as loops.
// Major variables: upperLimit, lowerLimit, myGuess, compGuess
// Assumptions: None
// Program limitations: None
//
//**************************************************************


#include <iostream>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <string>
using namespace std;

int main()
{
	int upperLimit;
	int lowerLimit;
	int myGuess;
	int compGuess = 0;
	ofstream outData;
	string answer;


	cout << "Welcome to the guess game. The computer will be guess your number between 0 and 100." << endl;

	cout << "Please enter a magic number between 0 and 100: ";
	cin >> myGuess;
	cout << "Please enter the highest limit that the computer can guess: ";
	cin >> upperLimit;
	cout << "Please enter the lowest limit that the computer can guess: ";
	cin >> lowerLimit;


	if (myGuess >= 0 && myGuess <= 100)
	{
		//Write user's number to a file
		outData.open("guess.txt");
		outData << myGuess << endl;


		do
		{
			//Computer will now guess the user's number
			srand(time(0));
			compGuess = lowerLimit + rand() % (upperLimit - lowerLimit + 1);


			cout << "The computer guesses: " << compGuess << endl;

			outData << compGuess << endl;


			if (compGuess > myGuess)
			{
				cout << "The guess is: ";
				getline(cin, answer);
				upperLimit = compGuess - 1;
			}
			else if (compGuess < myGuess)
			{
				cout << "The guess is : ";
				getline(cin, answer);
				lowerLimit = compGuess + 1;
			}

		} while (myGuess != compGuess);

		cout << "The guess is: ";
		getline(cin, answer);
		// End of loop

	}

	else
		cout << "You are not being trustworthy!\n";

	return 0;
}

