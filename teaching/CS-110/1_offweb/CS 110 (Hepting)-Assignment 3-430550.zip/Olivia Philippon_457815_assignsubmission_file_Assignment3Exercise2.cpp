//**************************************************************************
//
// Student name: Olivia Philippon
//
// Student number: 200294151	
//
// Assignment number: 3
//
// Program name: Assignment3Exercise2
//
// Date written: Mar. 3, 2015
//
// Problem statement: The problem I was trying to solve with my code is to allow the user to be provided with either a multiplication, 
//	subtraction, or addition question randomly. The user must answer the question correctly before proceeding. The computer will average the 
//	number of attempts for each question individually and the overall number of attempts. It will also provide the time taken to do each question and 
//  provide the average of the time for each of the 5 questions provided. 
//
// Input: I expect the user to input the answer to the random question provided. If the answer is not correct, I expect the 
//   user to input their next best answer until they reach the correct answer. 
//
// Output: I expect the output of the program to provide two random numbers and a random question involving either multiplication, 
//   addition, or subtraction. The output will also notify the user when they get a question correct. If they do not have the correct answer
//   for the question, the program will output the same question again in order for the use to have a second chance at answering. These 
//   opportunities to guess again continue until the output indicates that the user's input is correct. I also expect the computer to output the time taken
//   and the number of attempts for each individual question. In the end, the computer will output the total average number of attempts and 
//   time taken for the five questions provided. 
//      
// Algorithm: In order to solve the problem, I will instruct the computer to generate two random numbers. If the first number is less than the 
//     the second number, the computer will change these numbers and temporarily store the first number to prevent losing it forever. This is necessary 
//     to avoid providing the user with a subtraction question that would lend itself to a negative answer. From here, the computer randomly generates a number 
//     between 0 and 2 by using the modulus operator to keep the number within this range. The number generated selects which quesiton is provided to the user. 
//     Depending on the coordination of the number and the if statement, a multiplication, subtraction, or addition question will be provided. The computer will 
//     display the question and allow the user to enter their answer. If the user is correct, the computer will display a message indicating that they are correct. If they 
//     are not correct, the user will be presented with the same question and must answer until they achieve the correct answer. Their total number of attempts for 
//	   each question and time taken will be displayed. By incrementing "count" for each attempt, the comptuer is able to present the number of attempts and ultimately 
//     average the number of attempts after all five questions have been asnwered. The computer is also able to present the time taken for each question
//     by first setting a seed for the initial time within each question and keeping track of the total time within each question. In the end, the program will average 
//     time taken for all questions. 
//
// Major variables: One major variable in this program is the count vairable that keeps track of the number of attempts by incrementing. The time variables are important
//             to keep track of the time for each attempt. The variable of the user's answer is also important in order to progress in the program depending on whether or not they 
//             get the question right. The random number generator variables are also important in order to generate the random number that will be provided the numbers in the questions and  
//             to get a random question. 
//
// Assumptions: The assumptions of this program are that the user does not want to work with subtraction that will lead to providing a negative answer. 
//
// Program limitations: One limitiation is that only the average time, out of the times produced, that indicate a precise decimal value. 
//
//**************************************************************************
#include <iostream>
#include <ctime> // Needed for time function
#include <cstdlib> // Needed for the srand and rand functions
#include <iomanip>  //Needed for the set precision function
using namespace std;

int main()

{
	int count = 0; // Counts the number of questions
	double endTime = time(0);
	double startTime = time(0);
	double testTime = endTime - startTime;
	const int NUMBER_OF_QUESTIONS = 5;
	srand(time(0)); // Set a random seed
	int answer = 0;
	int correctAnswer = 0;
	int numberOfAttempts2 = 0;
	int numberOfAttempts1 = 0;
	int numberOfAttempts3 = 0;
	long totalTime=0;

	while (count < NUMBER_OF_QUESTIONS)
	{
		//Generates random numbers to be included in the question provided.
		int number1 = rand() % 10;
		int number2 = rand() % 10;

		//This is where the value of number 1 is temporarily stored if it is less than number 2. 
		if (number1 < number2)
		{
			int temp = number1;
			number1 = number2;
			number2 = temp;
		}

		//This part of the program generates a random number between 0-2. Depending on the number generated, the computer
		//is directed to a question in the subsequent if statements.
		int question = rand() % 3;
		
		//The computer will provide a subtraction question if the randomly generated question value is 2. 
		if (question == 2)
		{
			double startTime1 = time(0);
			cout << "What is " << number1 << " - " << number2 << "?\n";
			int answer;
			cin >> answer;

			//The computer checks to see if the user's answer matches the correct answer. If it does, the number of correct 
			// answers is increased. 
			if (number1 - number2 == answer)
			{
				cout << "You are correct!\n";
				numberOfAttempts2++;
				correctAnswer++;
			}
			//This loop repeats until the user gets the question correct. 
			while (number1 - number2 != answer)
			{
				cout << "Your answer is wrong.\n" << endl;
				cout << "What is " << number1 << " - " << number2 << "?\n";
				cin >> answer;
				numberOfAttempts2++;

				if (number1 - number2 == answer)
				{
					cout << "You are correct!" << endl;		
				}				
			}
			cout << "Your number of attempts for this question was " << numberOfAttempts2 << endl;
			double endTime1 = time(0);
			double testTime = endTime1 - startTime1;
			//This adds the time to the total time. This is important when calcuating the average time for all 5 questions. 
			totalTime += testTime;
			cout << "Test time was " << testTime << " seconds" << endl;
		}

		//The computer will provide a multiplication question if the randomly generated question value is 1.
		if (question == 1)
		{
			double startTime2 = time(0);
			cout << "What is " << number1 << " x " << number2 << "?\n";
			cin >> answer;

			if (number1 * number2 == answer)
			{
				cout << "You are correct!\n";
				numberOfAttempts1++;
				correctAnswer++;
			}
			while (number1 * number2 != answer)
			{
				cout << "Your answer is wrong.\n" << endl;
				cout << "What is " << number1 << " x " << number2 << "?\n";
				cin >> answer;
				numberOfAttempts1++;

				if (number1 * number2 == answer)
				{
					cout << "You are correct!" << endl;	

				}
				
			}
			cout << "Your number of attempts for this question was " << numberOfAttempts1 << endl;
			double endTime2 = time(0);
			double testTime = endTime2 - startTime2;
			totalTime += testTime;
			cout << "Test time was " << testTime << " seconds" << endl;
		}

		//The computer will provide a addition question if the randomly generated question value is 0.
		if (question == 0)
		{
			double startTime3 = time(0);
			cout << "What is " << number1 << " + " << number2 << "?\n";
			cin >> answer;
			numberOfAttempts3++;

			if (number1+number2 == answer)
			{
				cout << "You are correct!\n";
				correctAnswer++;
			}
			while (number1+number2 != answer)
			{
				cout << "Your answer is wrong.\n" << endl;
				cout << "What is " << number1 << " + " << number2 << "?\n";
				cin >> answer;
				numberOfAttempts3++;

				if (number1+number2 == answer)
				{
					cout << "You are correct!" << endl;	
				}
			}
			cout << "Your number of attempts for this question was " << numberOfAttempts3 << endl;
			double endTime3 = time(0);
			double testTime = endTime3 - startTime3;
			totalTime += testTime;

			cout << "Test time was " << testTime << " seconds" << endl;
		}

		count++;	
		
	}
		double totalAttempts = (numberOfAttempts1 + numberOfAttempts2 + numberOfAttempts3);
		double averageTestTime = totalTime / 5.0;
		double averageAttempts = (numberOfAttempts1 + numberOfAttempts2 + numberOfAttempts3) / totalAttempts;
		cout << "Your average number of attempts is " << averageAttempts << "\n";
		cout << "\nYour average test time is " << averageTestTime << setprecision(2) << fixed << " seconds\n";
		//This displays how many questions were correct on the first attempt. 
		cout << "Also, you got " << correctAnswer << " questions correct on your first try!" << endl; 

	return 0; 

}




