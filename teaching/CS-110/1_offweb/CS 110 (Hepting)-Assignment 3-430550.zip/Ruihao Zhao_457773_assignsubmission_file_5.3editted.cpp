//**************************************************************************
//
// Student name:Ruihao Zhao    
//
// Student number: 200338484    
//
// Assignment number: #3
//
// Program name: 5.3editted.cpp
//
// Date written: 3/10/2015
//
// Problem statement: User inputs a number (between 0 and 100) for the computer to guess. The user responds to every guess the computer makes by inputting high or low
// to affect the computer's guess(make the guess closer and closer to the actual number) It also checks if the user was truthful with all inputs
//
// Input: string response, int number.
//
// Output: continued attempts until the inputed number is reached and the result and process is to be inputed into a external file
// 
// Algorithm1:input: the number to be guessed
//
// Algorithm2:computer guess: upper and lower limits
//
// Algorithm3:response high:once response high is given then the upper limit becomes the last guess
//
// Algorithm4:response low:one response low is given then the lower limit becomes the last guess
//
// Algorithm5:correct guess output:once the guess equals the number the output ends
//
// Major variables: ofstream outData, int number, int upper, int lower, string response, int guess, 
//
// Assumptions:input is from 0-100, the user can input correctly if the value is higher or lower than the number. 
//
// Program limitations:many repetitions, no decimals, if the user inputs high or low incorrectly the output ends.
//
//**************************************************************************
#include <iostream>
#include <cstdlib>
#include <fstream>
#include <string>
#include <ctime> 
using namespace std;


int main()
{
	ofstream outData;
	outData.open("outputfile.txt");
	int number;
	int upper = 100;
	int lower = 0;			
	string response;
	cout << "Please input a number from 0-100\n";									//Algorithm1:start
	cin >> number;
	outData << number << endl;
	if (number >= 0 && number <= 100)												
	{
		cout << "This is a valid number\n";
		outData << "This is a valid number\n";										//Algorithm1:end
		int guess = (upper + lower) / 2;											//Algorithm2:start
		outData << "The computer guessed: "<<guess << endl;
		do 
		{
			cout << "The computer guessed:" <<guess << endl;						//Algorithm2:end
			cout << "Please tell the computer if its guess is high or low\n";		
			cin >> response;																
			if (response == "high")													//Algorithm3:start
			{
				if (guess > number)
				{
					upper = guess;
					cout << "The guess was too high\n";
					outData << "too high\n";
					guess = (upper+lower)/2;
					outData << guess << endl;
				}
				else if (guess < number)
				{
					cout << "You haven't been trustworthy!!!\n";
					outData << "You haven't been trustworthy!!!\n";
					return 0;
				}
				else if (guess == number)
				{
					cout << "Good work you guessed right!" << endl;
					outData << guess << endl;
					outData << "Good work you guessed right!" << endl;
				}
			}																		//Algorithm3:end
			else if (response == "low")												//Algorithm4:start
			{
				if (guess < number)
				{
					lower = guess;
					cout << "The guess was too low\n";
					outData << "too low\n";
					guess = (upper+lower) / 2;
					outData << guess << endl;
				}
				else if (guess > number)
				{
					cout << "You haven't been trustworthy!!!\n";
					outData << "You haven't been trustworthy!!!\n";
					return 0;
				}
				else if (guess == number)
				{
					cout << "Good work you guessed right!" << endl;
					outData << guess << endl;
					outData << "Good work you guessed right!" << endl;
				}
			}																		//Algorithm4:end
		} while (guess != number);													//Algorithm5:start
			if (guess == number)
			{
				cout << "The computer guessed: " << guess << endl;
				cout << "You guessed right!!\n";
				outData << "You guessed right!!\n";
			}
			return 0;																//Algorithm5:end
	}
}