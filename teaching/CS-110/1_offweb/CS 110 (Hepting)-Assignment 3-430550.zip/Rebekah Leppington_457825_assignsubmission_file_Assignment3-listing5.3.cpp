// *********************************************************
//
// Student name: Rebekah Leppington
// Studnet number: 200 343 095
// Assignment number: 3.1
// Program name: Assignment3-listing5.3.cpp
// Date written: March 11, 2015
// Problem statement: This program will ask the computer to guess the number that the user inputs, 
//                    then stores the computers guesses and the users number in a file.
// Input: Users number.
// Output: Computer's guesses, and the correct number.
// Algorithm: The computer will use if and else statements as well as loops to gather the required results.
// Major variables: upperLimit, lowerLimit, yourGuess, compGuess, input.
// Assumptions: That the user understands the questions being asked.
// Program limitations: ignores first letter of user's input answer, requires that the user's responses contain more than one word.
//
//****************************************************************

#include <iostream>
#include <cstdlib>
#include <fstream>
#include <string>
using namespace std;

int main()
{
	int upperLimit;                                                  // variable to store the upper limit
	int lowerLimit;                                                  // variable to store the lower limit
	int yourGuess;                                                   // variable to store the user's magic number
	int compGuess;                                                   // variable to store the computer's guess
	ofstream outData;                                                // variable to open the text file
	string input;                                                    // variable to store a sentence answer

	outData.open("guesses.txt");                                    // opens text file to deposit info into
	
	cout << "The computer will guess your number. " << endl;        // output statement
	cout << "Please enter an upper limit. " << endl;                // upper limit stated
	cin >> upperLimit;                                              // variable initiated
	cout << "Please enter a lower limit. " << endl;                 // lower limit stated
	cin >> lowerLimit;                                              // variable initiated

	outData << "The upper limit is " << upperLimit << endl;
	outData << "The lower limit is " << lowerLimit << endl;
	
	if (upperLimit < lowerLimit)                                    // if statement reorders the upper and lower limits to have a positive difference
	{
		int temp = upperLimit;                                      // temp variable used to reorder variable limits
		upperLimit = lowerLimit;
		lowerLimit = temp;
	}

	cout << "Please enter your number to be saved in a text file. " << endl;    // guess stated
	cin >> yourGuess;                                               // variable initiated
	outData << yourGuess << endl;                                   // variable deposited into text file

	if (lowerLimit <= yourGuess && upperLimit >= yourGuess)         // tests that variable yourGuess is valid
	{
		cout << "This is a valid number" << endl;
		outData << "This is a valid number" << endl;
		
	}
	else
	{
		cout << "This is not a valid number. " << endl;             // happens when variable yourGuess is outside user's limits
		outData << "This is not a valid number" << endl;
		return 0;
	}

	do                                                              // main loop
	{
		compGuess = (upperLimit + lowerLimit) / 2;                  // computer's guess is in between the limits/ re-calculates
		cout << "Computer guesses " << compGuess << endl;           // computer's guess
		outData << compGuess << endl;                               // stores computer's guess
		cout << "Is this number too high, too low or equal? " << endl;
		cin.ignore();
		getline(cin, input);                                        // user states if the computer's number is too high. low or equal

		outData << input << endl;                                   // stores user's response

		if (input.find("high") != std::string::npos)                // seraches user's response for word
		{
			upperLimit = compGuess;                                 // re-assigns variable
		}
		else if (input.find("low") != std::string::npos)            // seraches user's response for word
		{
			lowerLimit = compGuess;                                 // re-assigns variable
		}
		else if (input.find("equal") != std::string::npos)          // seraches user's response for word
		{
			cout << "YAY!!! I found that your number is " << compGuess << endl;
			return 0;
		}
		else
		{
			cout << "Your response is giving me a headache... What was that? " << endl;
		}

	} while (upperLimit - lowerLimit > 0);                         // loop-continuation condition determines end point
	{
		cout << "You lie!" << endl;
	}

	return 0;
}