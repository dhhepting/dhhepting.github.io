//**************************************************************************
//
// Student name: Jinze Xue
//
// Student number: 200353480
//
// Assignment number: #3
//
// Program name:guess number
//
// Date written: March 9/2015
//
// Problem statement:input number and the computer guessthe number, and ask higher or lower.
//
// Input: number,higher or lower
// 
// Output: number and question
//
// Algorithm: number->guess->higher/lower->guess
// Major variables: number
//
// Assumptions:the process can continue
//
// Program limitations:integer form 0 to 100
//
//**************************************************************************


#include <iostream>
#include <cstdlib>
#include <string>

using namespace std;

int main()
{
	// Generate a random number to be guessed
	
	string a;
	
	int guess;
	cout << "Guess a magic number between 0 and 100"<<endl;
	cin >> guess;
	int number = rand() % 101;

	cout << number << endl ;
	int b = number;
	while (number !=guess)
	{
		cout<< "Is the number higher or lower?";
		cin >> a;
		
		if (a == "lower")
		{
		
			int number = rand() % 101  ;
			
			cout << "\nThe number: " << number<< endl;

		}
		if (a == "higher")
		{
			int number = rand() % 101 ;
		
			cout << "\nThe number: " << number<< endl;
		}
		if (number == guess)
		{

			cout << "Yes, the guess is " << number << endl;
			break;
		}
	} // End of loop
	


	return 0;
}