// Ashlyn Heintz
// 200287036
// Assignment 3: 5.4
//
#include <iostream>
#include <ctime> // Needed for time function
#include <cstdlib> // Needed for the srand and rand functions
using namespace std;

int main()
{
	int correctCount = 0; // Count the number of correct answers
	int incorrectCount = 0;
	int count = 0; // Count the number of questions
	long startTime = time(0);
	const int NUMBER_OF_QUESTIONS = 5;
	int correct_answer;

	srand(time(0)); // Set a random seed

	while (count < NUMBER_OF_QUESTIONS)
	{
		// 1. Generate two random single-digit integers
		int number1 = rand() % 10;
		int number2 = rand() % 10;

		// 2. If number1 < number2, swap number1 with number2
		if (number1 < number2)
		{
			int temp = number1;
			number1 = number2;
			number2 = temp;
		}

		switch (rand() % 3)
		{
			// subtraction selected
		case 0: cout << "What is " << number1 << " - " << number2 << "? ";
			correct_answer = number1 - number2;
			break;

			// addition selected
		case 1: cout << "What is " << number1 << " + " << number2 << "? ";
			correct_answer = number1 + number2;
			break;

			// multiplication selected
		case 2: cout << "What is " << number1 << " * " << number2 << "? ";
			correct_answer = number1 * number2;
			break;
		}

			int answer;
			cin >> answer;
			long endTime = time(0);
			long testTime = endTime - startTime;

			cout << "The number of attempts it took is " << incorrectCount++ << endl;
			cout << "The correct count is: " << correctCount++ << endl;
			cout << "\nTest time is " << testTime << " seconds\n" << endl;
		
		
		// while...
		// what condition needs to be true?
		while (answer != correct_answer)
		{
			if (number1 - number2 != answer)
			{
				cout << "Your answer is wrong. Please try again \n" << endl;
				cin >> answer;
				incorrectCount++;
				cout << "The number of attempts it took is " << incorrectCount++ << endl;
			}
			else if (answer == correct_answer)
			{
				cout << "You are correct!\n" << endl;
				correctCount++;
			}
		}


		// Increase the count
		count++;
	}

	long endTime = time(0);
	long testTime = endTime - startTime;

	cout << "Total Correct count is " << correctCount << "\n Average Test time is "
		<< (testTime/5) << " seconds\n";

	return 0;
}