#include <iostream>
#include <iostream>
using namespace std;

int main()
{
	int minVal = 0;
	int maxVal = 101;
	char responce1;
	char responce2;
	int guess;
	int number;
		

		cout << "Enter an integer between 0 and 100 and I will try to guess it!" << endl;
		cin >> number;

		do {
			cout << "Is the number " << (guess = (minVal + maxVal) / 2) << "? Input 'y' for yes and 'n' for no: ";
			cin >> responce1;
			if (responce1 == 'n')
			{
				cout << "Was my guess too high? ";
				cin >> responce2;
				if (responce2 == 'y')
					maxVal = guess;
				else
					minVal = guess;
			}
		} while (responce1 == 'n');

		if (responce1 == 'y') 
			cout << "I got it! Your number is " << number << "!" << endl;
		
		return 0;
}