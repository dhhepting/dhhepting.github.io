//**************************************************************************
//
// Student name: Riley Peters
//
// Student number: 200 354 249
//
// Assignment number: #3 - Part 2
//
// Program name: Test Modification
//
// Date written: March 5th, 2015
//
// Problem statement: Test asking 5 math questions. Subtraction, addition, and multiplication.
//                      Each question repeats till a correct answer input.  It gives the total
//                      attempts and time used for each question and the final average attempts
//                      and time per question.
//
// Input: Answers to math questions
//
// Output: Whether answer is correct or not.  Attempts and time for each question and average
//          attempts and time per question for the whole test.
//
// Algorithm:   -> randomly chooses a type of question
//              -> prompt for answer
//              -> check if answer is correct
//              -> if not correct loop till correct answer is input.
//              -> Once correct answer is input, display the information for the question
//              -> continue looping till the total questions are asked
//              -> Output averages for attemps and questions for the total test after loop is exited
//              -> exit program
//
// Major variables: answer, question count, attempts per question, total attempts, starting and
//                  end times per question, question time, total time.
//
// Assumptions: User understands math problems and symbols
//
// Program limitations: -> Does not work with negative numbers
//                      -> Only single digit numbers being used in calculations
//                      -> limited to 5 questions
//
//**************************************************************************

#include <iostream>
#include <ctime> // Needed for time function
#include <cstdlib> // Needed for the srand and rand functions
using namespace std;

int main()
{
    
    int count = 0;                          /* Count the number of questions */
    const int NUMBER_OF_QUESTIONS = 5;      /* Const for total questions     */
    float totaltime;                        /* Total time for test           */
    float totalattempts;                    /* Total attempts for questions  */
    
    srand(time(0));                         /* Set a random seed             */
    
    // While to repeat questions till total questions are asked
    while (count < NUMBER_OF_QUESTIONS)
    {
        
        int number1 = rand() % 10;          /* Setting random numbers for calculations */
        int number2 = rand() % 10;
        int attempts = 1;                   /* Variable to count attempts    */
        int starttime = time(0);            /* Setting start time            */
        int answer;                         /* Input variable for the answer */
        
        //Switch statements chooses randomly whether to do subtraction, addition, or multiplication
        switch (rand() % 3)
        {
            // Subtraction
            case 0:
            {
                // If number1 < number2, swap number1 with number2
                if (number1 < number2)
                {
                    int temp = number1;
                    number1 = number2;
                    number2 = temp;
                }
        
                // Prompt the student to answer “what is number1 – number2?”
                cout << "What is " << number1 << " - " << number2 << "? ";
                cin >> answer;
        
                // Incorrect answer message.  Repeat till correct answer is input.  Attempts counted.
                while (number1 - number2 != answer)
                {
                    cout << "You are wrong. Try again" << endl;
                    cout << "What is " << number1 << " - " << number2 << " ?" << endl;
                    cin >> answer;
                    
                    attempts++;
                }
                
            }
                break;
            
            // Addition
            case 1:
            {
                // Prompt the student to answer “what is number1 + number2?”
                cout << "What is " << number1 << " + " << number2 << "? ";
                cin >> answer;
                
                // Incorrect answer message
                while (number1 + number2 != answer)
                {
                    cout << "You are wrong. Try again" << endl;
                    cout << "What is " << number1 << " + " << number2 << " ?" << endl;
                    cin >> answer;
                    
                    attempts++;
                }

            }
                break;
            
            // Multiplication
            case 2:
            {
                // Prompt the student to answer “what is number1 x number2?”
                cout << "What is " << number1 << " x " << number2 << "? ";
                cin >> answer;
                
                // Incorrect answer message
                while (number1 * number2 != answer)
                {
                    cout << "You are wrong. Try again" << endl;
                    cout << "What is " << number1 << " x " << number2 << " ?" << endl;
                    cin >> answer;
                    
                    attempts++;
                }

            }
                break;
                
        }
        // Correct answer message
        cout << "Correct answer" << endl;
        
        int endtime = time(0);                          /* sets endtime         */
        int questiontime = endtime - starttime;         /* finds question time  */
        totaltime += questiontime;                      /* adds total time      */
        totalattempts += attempts;                      /* adds total attempts  */
        
        // Displays question information
        cout << "Attempts: " << attempts << endl;
        cout << "Time taken: " << questiontime << endl;
        count++;                                        /* counts to question total */
    }
    
    // Gives test information
    cout << "Average number of attempts per question: " << totalattempts/count << endl;
    cout << "Average time taken per question: " << totaltime/count << " seconds" << endl;

    return 0;
}