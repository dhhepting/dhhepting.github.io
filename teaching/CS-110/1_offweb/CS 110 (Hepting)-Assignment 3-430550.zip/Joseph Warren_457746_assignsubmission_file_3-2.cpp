//**************************************************************************
//
// Student name: Joseph Warren
//
// Student number: 200241391
//
// Assignment number: 3-2
//
// Program name: Math Questions
//
// Date written: March 11, 2015
//
// Problem statement:  Create a program that will ask the user 5 math simple math            // questions, randomly switching between addition, subtraction, and multiplication.
//
// Input: Answers to 5 questions in integer form, from the user.
//
// Output:
//  5 questions, which are a random combination of addition, subtraction, and                    //  multiplication (one operation per question). Also a response to each of the user's          // answers, telling whether it is correct or not.  
//  
// Algorithm:
// 1. Generate 2 random integers
// 2. Perform a function that will generate 3 possible outcomes randomly, and match one   //     outcome to each type of operation (multiplication, subtraction, addition.)
// 3. Ask user to perform the selected operation on the 2 random numbers.
// 4. Check user's answer and tell user whether it is correct.
//
//
// Major variables: count, number1, number2, answer,
//
// Assumptions: User follows directions.
//
// Program limitations: Works only for integers.
//
//
//**************************************************************************

#include <iostream>
#include <ctime> // Needed for time function
#include <cstdlib> // Needed for the srand and rand functions
using namespace std;

int main()
{
	int correctCount = 0; // Count the number of correct answers
	int count = 0; // Count the number of questions
	long startTime = time(0);
	const int NUMBER_OF_QUESTIONS = 5;
	int answer;

	srand(time(0)); // Set a random seed

	while (count < NUMBER_OF_QUESTIONS)
	{
		// 1. Generate two random single-digit integers
		int number1 = rand() % 10;
		int number2 = rand() % 10;
		int type = rand() % 3; //determines whether the question is subtraction, multiplication, or addition.

		switch (type)
		{
		case 0: cout << "What is " << number1 << " - " << number2 << "? " << endl; //ask subtraction question

			cin >> answer;

			if (number1 - number2 == answer) //check correctness
			{
				cout << "You are correct!\n";
				correctCount++;
			}
			else
			{
				cout << "Your answer is wrong.\n" << number1 << " - " <<
					number2 << " should be " << (number1 - number2) << endl;
			}
			count++;
			break;

		case 1: cout << "What is " << number1 << " * " << number2 << " ? " << endl; //ask multiplication question
			cin >> answer;

			if (number1 * number2 == answer) //check correctness
			{
				cout << "You are correct!\n";
				correctCount++;
			}
			else
			{
				cout << "Your answer is wrong.\n" << number1 << " - " <<
					number2 << " should be " << (number1 * number2) << endl;
			}
			count++;
			break;

		case 2: cout << "What is " << number1 << " + " << number2 << " ? " << endl; //ask addition question
			cin >> answer;


			if (number1 + number2 == answer) //check correctness
			{
				cout << "You are correct!\n";
				correctCount++;
			}
			else
			{
				cout << "Your answer is wrong.\n" << number1 << " - " <<
					number2 << " should be " << (number1 + number2) << endl;
			}

		}
	}
	return 0;
}