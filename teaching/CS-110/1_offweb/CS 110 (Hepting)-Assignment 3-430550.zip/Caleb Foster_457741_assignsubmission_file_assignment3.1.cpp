//**************************************************************************
//
// Student name: Caleb Foster
//
// Student number: 200354226
//
// Assignment number: 3
//
// Program name: Listing 5.3 Modification
//
// Date written: March 10, 2015
//
// Problem statement: The user thinks of a number in his head and the computer
//   guesses the number in the user's head. The computer does a binary search
//   and asks the user to enter "too high," "too low," or "correct" based on
//   what his number is. The program stops when the computer guesses the "magic"
//   number.
//
// Input: too high, too low, or correct
//
// Output: Is the number ___ correct, too high or too low?
//
// Algorithm: Set the upper limit to 100 and the lower limit to 0. Then the
//  computer goes through a binary search using the upper and lower limit
//  and dividing it by two and gives a guess. The user then enters whether
//  the guess is too high, too low, or correct. If the guess is too high,
//  the computer will get rid of the top half of the limits. If the guess is
//  too low, the computer will drop the lower half of the limits. If the
//  computer narrows down the guess to one number and the user says it is
//  incorrect the computer will call out the user as giving inconsistent
//  information. Once the computer guesses a number and the user enters that
//  the guess is correct, the program stops.
//
// Major variables: guess, answer
//
// Assumptions: the user is thinking of a whole number between 0 and 100
//
// Program limitations: The program doesn't perform mathematical operations and
//  doesn't account for decimal numbers.
//
//**************************************************************************


#include <iostream>
#include <cstdlib>
#include <string>
using namespace std;

int main()
{	
	int upper_limit = 100;	// Set upper and lower limits
	int lower_limit = 0;

	cout << "Think of a magic number between 0 and 100." << endl;
	cout << "I will guess numbers until I am correct.";

	while (upper_limit - lower_limit > 1)
	{
		// Program guesses the number between the upper and lower limit
		int guess = (upper_limit + lower_limit) / 2;
		cout << "\nIs the number " << guess << " correct, too high' or too low? " << endl;
		string answer;
		getline(cin,answer); 

		// Determine new upper limit or lower limit based on answer
		if (answer == "too high")
			upper_limit = guess;
		else if (answer == "too low")
			lower_limit = guess;
		else if (answer == "correct")
			upper_limit = lower_limit = guess;

	} // End of loop
	if (upper_limit - lower_limit == 1)
		cout << "Lier! Your answers are not consistent" << endl;
	if (upper_limit == lower_limit)
		cout << "Thank you!" << endl;

	return 0;
}