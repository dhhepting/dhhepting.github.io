#include <iostream>
#include <ctime> // Needed for time function
#include <cstdlib> // Needed for the srand and rand functions
using namespace std;

int main()
{
  int correctCount = 0; // Count the number of correct answers
  int count = 0; // Count the number of questions
  long startTime = time(0);
  const int NUMBER_OF_QUESTIONS = 5;
int attempts=0;
int totalattempts=0;
long qstart;
long qend;

 srand(time(0)); // Set a random seed
cout << "Type any key to begin. You will be asked a series of math questions.";
cin.get(); //stalls the game until the user is ready

  while (count < NUMBER_OF_QUESTIONS)
  {
    // 1. Generate two random single-digit integers
    int number1 = rand() % 10;
    int number2 = rand() % 10;
attempts = 0;

	// 2. Determine the type of question to be asked:
	int type;
	type = rand() % 3;
	int answer = -10000;

switch (type)
{
case 0: //subtraction
{
qstart = time(0);
    // 1. If number1 < number2, swap number1 with number2
    if (number1 < number2)
    {
      int temp = number1;
      number1 = number2;
      number2 = temp;
    }

    // 2. Prompt the student to answer �what is number1 � number2?�
while (answer != number1 - number2)
{
    cout << "What is " << number1 << " - " << number2 << "? ";
    cin >> answer;
	attempts ++;
	totalattempts++;
    // 3. Grade the answer and display the result
    if (number1 - number2 == answer) 
    {	
		qend = time(0);
      cout << "You are correct!\n" << "                              You took " << attempts << " attempt(s) and " << (qend - qstart) << " second.\n";
      correctCount++;
	
    }
    else
      cout << "Your answer is wrong.\n";

}
break;
}
case 1: //addition
{
qstart = time(0);

    //1. Ask the question and loop if incorrect
while (answer != number1 + number2)
{
    cout << "What is " << number1 << " + " << number2 << "? ";
    cin >> answer;
	attempts ++;
totalattempts++;
    // 3. Grade the answer and display the result
    if (number1 + number2 == answer) 
    {	
		qend = time(0);
      cout << "You are correct!\n" << "                              You took " << attempts << " attempt(s) and " << (qend - qstart) << " second.\n";
      correctCount++;
	
    }
    else
      cout << "Your answer is wrong.\n";

}
break;
}
case 2: //multiplication
{
qstart = time(0);

    //1. Ask the question and loop if incorrect
while (answer != number1 * number2)
{
    cout << "What is " << number1 << " X " << number2 << "? ";
    cin >> answer;
	attempts ++;
totalattempts++;
    // 3. Grade the answer and display the result
    if (number1 * number2 == answer) 
    {	
		qend = time(0);
      cout << "You are correct!\n" << "                              You took " << attempts << " attempt(s) and " << (qend - qstart) << " second.\n";
      correctCount++;
	
    }
    else
      cout << "Your answer is wrong.\n";

}
break;
}
}
	

    // Increase the count
    count++;
}

  long endTime = time(0);
  long testTime = endTime - startTime;

  cout << "Correct count is " << correctCount << "\nTest time is "
       << testTime << " seconds\nThe average time per question is: " << (testTime/5.0) << "\nYou took " << totalattempts << " attempts\n"
		<< "You would recieve a " << ((totalattempts/5.0)*100) << "%.\n";

  return 0;
}