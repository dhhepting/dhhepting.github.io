//Student name : Yue Wang
// Studnet number: 200350793
// Assignment number: 3 part 1 
// Program name: source.cpp
// Date written: March 11, 2015
// Problem statement: This program will ask the computer to guess the number that the user inputs, 
//                    then stores the computers guesses and the users number in a file.
// Input: Users number.
// Output: Computer's guesses along with the right number.
// Algorithm: The computer will use if and else statements and find answe inbetween values.
// Major variables: max, min, tries
// Assumptions: None
// Program limitations: None
#include <iostream>
#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include <fstream>
using namespace std;

int main()
{
	ofstream outData;
	outData.open("compguess.txt");// output file opened and  stored
	                                 // users guess is stored
	srand(time(0));


	string hint;
	int max = 100, min = 1, tries = 0, number = 0;
	cout << "Think of a number between 1 and 100." << endl;//prompt

	do {
		number = (max + min) / 2;// Algorithm, computer guesses  in between the limits
		cout << endl << tries + 1 << " computer's guess is " << number << endl;
		cout << "Is the guess high, low, or correct?: ";
		cin >> hint;
		outData << hint << endl;// users guess is stored
		srand(time(0));

		if (hint == "high")
			max = number - 1;
		else if (hint == "low")
			min = number + 1;
		++tries;
	}
 while (hint != "correct");
	{
		if (hint == "correct")

		{
			outData << hint << endl;
			outData << "I knew it!" << endl;  // stores user's response
		}
		else
		{
			cout << "You haven't been trustworthy!!!*sad face*\n";
			outData << hint << endl;  // stores user's response and prompt 
		}
		cout << "\nThe computer's guess was correct after " << tries << " tries! yassssssss" << endl;
		cout << "\n\nThanks for playing. Press Enter...";
		cin.get();
		cin.get();
		return 0;
	}

}