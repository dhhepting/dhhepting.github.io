/*Shurouk Alhelou
	SID: 200336944
	Assignment#: 3
	Program: Visual Studio C++
	Date: March 11, 2015
*/

/*
Modify Listing 5.4 so that the user must answer the question correctly before proceeding. Also, your program should offer addition and 
multiplication questions (at random). For each question, print out the number of attempts on the question and the time taken. At the end 
of the quiz, print the average number of attempts and the average time taken.
*/

#include <iostream>
#include <ctime> // Needed for time function
#include <cstdlib> // Needed for the srand and rand functions
using namespace std;

int main()
{
	int correctCount = 0; // Count the number of correct answers
	int count = 0; // Count the number of questions
	long startTime = time(0);
	const int NUMBER_OF_QUESTIONS = 5;

	srand(time(0)); // Set a random seed

	while (count < NUMBER_OF_QUESTIONS)
	{
		// 1. Generate two random single-digit integers
		int number1 = rand() % 10;
		int number2 = rand() % 10;

		// 2. If number1 < number2, swap number1 with number2
		if (number1 < number2)
		{
			int temp = number1;
			number1 = number2;
			number2 = temp;
		}
// 3. Prompt the student to answer �what is number1 � number2?�

		/**************************************************************/
		cout << "What is " << number1 << " - " << number2 << "? ";
		int answer;
		do
		{	
		cin >> answer;
		if (number1 - number2 != answer)
			cout << "Your answer is wrong.\n, Please Try again" << endl;
		} while (number1 - number2 != answer);
		
		/*************************************************************/

		// 4. Grade the answer and display the result
		if (number1 - number2 == answer)
		{
			cout << "You are correct!\n";
			correctCount++;
		}
	
		// Increase the count
		count++;
	}

	long endTime = time(0);
	long testTime = endTime - startTime;

	cout << "Correct count is " << correctCount << "\nTest time is "
		<< testTime << " seconds\n";

	return 0;
}
