// STUDENT NAME: Emily Chea

// STUDENT NUMBER: 200352055

// ASSIGNMENT NUMBER: 3

// PROGRAM NAME: C++ Visual Studio 2013

// DATE WRITTEN: March 7, 2015

// PROBLEM STATEMENT: ask user to answer 5 math questions (mix of subtraction, multiplicaton and addition), mover on when user gets it right, reask if wrong

// INPUT: answers to math questions

// OUTPUT: math questions and if they are answered correctly

// ALGORITHM: 

// MAJOR VARIABLES: 

// ASSUMPTIONS: 

// PROGRAM LIMITATIONS: 

//**************************************************************************************************************************************************************

#include <iostream>
#include <fstream>
#include <ctime> // Needed for time function
#include <cstdlib> // Needed for the srand and rand functions
using namespace std;

int main()
{
	int correctCount = 0; // Count the number of correct answers
	int count = 0; // Count the number of questions
	long startTime = time(0);
	const int NUMBER_OF_QUESTIONS = 5;
	int answer;
	int op = rand() % 3; // assign numbers to each type of operand
	srand(time(0)); // Set a random seed
	ofstream outData;
	outData.open("assignment3.2.txt");

	if (op == 0) // Where 0 symbolizes a subtraction question
	{
		while (count < NUMBER_OF_QUESTIONS)
		{
			// 1. Generate two random single-digit integers
			int number1 = rand() % 10;
			int number2 = rand() % 10;
			int attempt = 1;

			// 2. If number1 < number2, swap number1 with number2
			if (number1 < number2)
			{
				int temp = number1;
				number1 = number2;
				number2 = temp;
			}
			// 3. Prompt the student to answer �what is number1 � number2?�
			cout << "What is " << number1 << " - " << number2 << "? ";
			cin >> answer;
			while (number1 - number2 != answer)
			{
				// 4. Grade the answer and display the result
				if (number1 - number2 == answer)
				{
					cout << "You are correct!\n";
					correctCount++;
					cout << attempt << endl;
					outData << attempt << endl;
				}
				else
				{
					cout << "Your answer is wrong." << endl;
					attempt++;
					number1 = number1;
					number2 = number2;
					cout << "What is " << number1 << " - " << number2 << "? ";
					cin >> answer;
				}
				// Increase the count
				count++;
				cout << attempt << endl;
				outData << attempt << endl;
			}
		}
	}
	else if (op == 1) //Where 1 represents an addition question
	{
		while (count < NUMBER_OF_QUESTIONS)
		{
			// 1. Generate two random single-digit integers
			int number1 = rand() % 10;
			int number2 = rand() % 10;
			int attempt = 1;

			// 2. Prompt the student to answer �what is number1 + number2?�
			cout << "What is " << number1 << " + " << number2 << "? ";
			cin >> answer;
			while (number1 + number2 != answer)
			{
				// 3. Grade the answer and display the result
				if (number1 + number2 == answer)
				{
					cout << "You are correct!\n";
					correctCount++;
				}
				else
				{
					cout << "Your answer is wrong.\n" << endl;
					attempt++;
					number1 = number1;
					number2 = number2;
					cout << "What is " << number1 << " + " << number2 << "? ";
					cin >> answer;
				}
					
				// Increase the count
				count++;
				cout << attempt << endl;
				outData << attempt << endl;
			}
		}
	}
	else
	{
		while (count < NUMBER_OF_QUESTIONS)
		{
			// 1. Generate two random single-digit integers
			int number1 = rand() % 10;
			int number2 = rand() % 10;
			int attempt = 1;

			// 2. Prompt the student to answer �what is number1 * number2?�
			cout << "What is " << number1 << " * " << number2 << "? ";
			cin >> answer;
			while (number1 * number2 != answer)
			{
				// 4. Grade the answer and display the result
				if (number1 * number2 == answer)
				{
					cout << "You are correct!\n";
					correctCount++;
				}
				else
				{
					cout << "Your answer is wrong." << endl;
					attempt++;
					number1 = number1;
					number2 = number2;
					cout << "What is " << number1 << " * " << number2 << "? ";
					cin >> answer;
				}
				// Increase the count
				count++;
				cout << attempt << endl;
				outData << attempt << endl;
			}
		}
	}
	
	long endTime = time(0);
	long testTime = (endTime - startTime) / NUMBER_OF_QUESTIONS;

	cout << "Correct count is " << correctCount / NUMBER_OF_QUESTIONS << "\nAverage test time is "
		<< testTime << " seconds\n";
	outData << "Average number of attempts: " << count << endl;
	outData << "Average test time: " << testTime << endl;

	return 0;
}
