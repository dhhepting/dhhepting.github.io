/***************************************************

This is the solution of assignemnt number 3/ 5.4 (modified)

Student name : Nasser Alhamed

Student ID : 200307983

Program name : "How fast you manage calculation)

Date written : Mar 10, 2015

Problem statement :

Input : Answers for simple calculations

Output : Average time and attempts

Algorithm : This program adds up how many time the user attempt for each type of question and gives the average
as well as the time spent. 

Major variables : 

Assumptions :

Program limitations: if entered a character, it would not run properly
*******************************************************************/
#include <iostream>
#include <ctime> 
#include <cstdlib>
using namespace std;
int main()
{
	// These are declaration of the integers to count how many times does the user attempt
	// Also declaration for time used during each type of question,
	// integerses to calculate the average time, attempts. 
	int AttForSub = 0;
	int AttForAdd = 0;
	int AttForProd = 0;
	int TotlaAtt = 0;
	
	// For time calculation
	long timeSub = 0;
	long timeAdd = 0;
	long timeProd = 0;
	double Avetime;
	int Totaltime = 0;
	// to seed real random valuse.
	srand(time(0));
	// here we choose how many time does the progarm run which is here five times.
	for (int i = 0; i < 5; i++)
	{
		// here we set three different type of question and C++ will randomly choose out of the three
		int typeQuestion = rand() % 3;
		if (typeQuestion == 0)
		{
			// to let the C++ randomly choose values between 0 and 9 and to start count time.
			long starttimeSub = time(0);
			int numbersub1 = rand() % 10;
			int numbersub2 = rand() % 10;
			// To swap numbers if any of them is bigger then the other.
			if (numbersub1 < numbersub2)
			{
				int temp = numbersub1;
				numbersub1 = numbersub2;
				numbersub2 = temp;
			}
			// To prompt to the user the question and if he answer wrong the program
			// will keep running and counting how many attempts until a correct answer is entered.
			cout << "What is " << numbersub1 << " - " << numbersub2 << "?\n ";
			int answer1;
			answer1 = -1;
			while (numbersub1 - numbersub2 != answer1)
			{
				cin >> answer1;
				AttForSub++;
				if (numbersub1 - numbersub2 != answer1)
				{
					cout << "Worng answer please try againa\n";
				}
				else
				{
					cout << "You are correct!\n";
				}
				
			}
			// To count how many time attempts and time taken.
			long endtimeSub = time(0);
			cout << "Number of attepmts is: " << AttForSub << "\n ";
			timeSub += endtimeSub - starttimeSub;
			cout << "Time taken is: " << timeSub << " \n";
		}
		// Same idea with diffrenet operation.
		else if (typeQuestion == 1)
		{
			long starttimeAdd = time(0);
			int numberadd1 = rand() % 10;
			int numberadd2 = rand() % 10;
			cout << "What is " << numberadd1 << " + " << numberadd2 << " =\n ";
			int answer2 = -1;
			while (numberadd1 + numberadd2 != answer2)
			{
				cin >> answer2;
				AttForAdd++;
				if (numberadd1 + numberadd2 != answer2)
				{
					cout << "wrong answer, Please try again!\n";
				}
				else
					cout << "Correct answer!\n";
				
			}
			long endtimeAdd = time(0);
			timeAdd += endtimeAdd - starttimeAdd;
			cout << "Number of attempts " << AttForAdd << "\n";
			cout << "Time taken is " << timeAdd << " \n";
		}
		// Another type of question with diffrent opreation.
		else if (typeQuestion == 2)
		{
			long starttimeprod = time(0);
			int numberprod1 = rand() % 10;
			int numberprod2 = rand() % 10;
			int ansewr3 = -1;
			cout << "What is " << numberprod1 << " * " << numberprod2 << "=\n ";
			while (numberprod1 * numberprod2 != ansewr3)
			{
				cin >> ansewr3;
				AttForProd++;
				if (numberprod1 * numberprod2 != ansewr3)
				{
					cout << "Worng result, Please try again\n";

				}
				else
				{
					cout << "Correct!\n";
				}
			}
			long endtimeprod = time(0);
			timeProd += endtimeprod - starttimeprod;
			cout << "Number of attempts is " << AttForProd << " \n";
			cout << "Time taken is " << timeProd << " \n";
		}
		
	}
	// Here to calcualte the average time taken and attempts.
	Totaltime += timeAdd + timeProd + timeSub;
	Avetime = (double) Totaltime / 5;
	TotlaAtt = AttForAdd + AttForProd + AttForSub;
	cout << "Totlat attempts is " << TotlaAtt << endl;
	double AveAtt = (double) TotlaAtt / 5;
	cout << "Average attempts is: " << AveAtt << endl;
	cout << "Total time spend is: " << Totaltime << " and Average is: " << Avetime << endl;


	return 0;
	// end program
}