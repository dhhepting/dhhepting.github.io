#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;

int main()
{
  const int NUMBER_OF_QUESTIONS = 5;					//Declare the number of questions as a constant, and declare two 
  int anTimes[NUMBER_OF_QUESTIONS] = { 0 };				//arrays to store the time taken and number of attempts for each
  int anAttempts[NUMBER_OF_QUESTIONS] = { 0 };			//question.

  srand(time(0));

  for(int nCount = 0; nCount < NUMBER_OF_QUESTIONS; nCount++)		//Loop repeats for the number of questions there are.
  {
    int nNumber1 = rand() % 10;				//Declare two numbers between 0 and 9, then make the first (nNumber1) the
    int nNumber2 = rand() % 10;				//larger of the two.

	if (nNumber1 < nNumber2)
		swap (nNumber1, nNumber2);

	int nOperation = rand() % 3;			//Randomly declare a integer from 0 to 2, each corresponding to an operation.
	int nAnswer = -1;
	int nGuess = 0;
	long lStartTime = time(0);				//Set the start time for this question.
	int nAttempts = 0;

	do
	{
		switch (nOperation)															//Depending on the operation, output 
		{																			//the correct question to the console
		case 0: cout << "What is " << nNumber1 << " + " << nNumber2 << "? ";		//and assign the correct value to the
			nAnswer = nNumber1 + nNumber2;											//answer variable.
			break;
		case 1: cout << "What is " << nNumber1 << " - " << nNumber2 << "? ";
			nAnswer = nNumber1 - nNumber2;
			break;
		case 2: cout << "What is " << nNumber1 << " * " << nNumber2 << "? ";
			nAnswer = nNumber1 * nNumber2;
			break;
		}

		cin >> nGuess;

		if (nGuess != nAnswer)
			cout << "Incorrect. Please try again."<< endl;

		nAttempts++;
	}
	while (nGuess != nAnswer);		//If the user's guess is not the correct answer, then begin the loop again.

	cout << "Correct!" << endl;

	anTimes[nCount] = time(0) - lStartTime;			//Assign the time and attempts for the question to the correct data
	anAttempts[nCount] = nAttempts;					//value in the array.

  }

  float fAverageTime = 0;
  float fAverageAttempts = 0;

  cout << endl << endl;

  //The following loop outputs the gathered values for times and attempts of each question, as well as calculating the
  //average for both of these values.
  
  for(int iii = 0; iii < NUMBER_OF_QUESTIONS; iii++)
  {
	  cout << "Question #" << (iii + 1) << " was answered in " << anTimes[iii] << " seconds and "
		  << anAttempts[iii] << " attempts." << endl;

	  fAverageTime += static_cast<float>(anTimes[iii]) / NUMBER_OF_QUESTIONS;
	  fAverageAttempts += static_cast<float>(anAttempts[iii]) / NUMBER_OF_QUESTIONS;
  }

  cout << "Questions were answered in an average of " << fAverageTime << " seconds and " << fAverageAttempts
	  << " attempts." << endl;

  return 0;
}