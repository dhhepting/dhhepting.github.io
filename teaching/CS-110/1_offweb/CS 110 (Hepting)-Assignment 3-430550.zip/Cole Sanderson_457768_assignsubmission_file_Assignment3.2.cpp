// Student Name : Cole Sanderson
//
// Student Number: 200355179
//
// Assignment Number: 3
//
// Program Name: Modification to Listing 5.4
//
// Date Written: March 8, 2015
//
// Problem Statement: The user has the responsibility to correctly answer either an additions subtraction or multiplication statement chosen by the computer. 
//
// Input: I expect the user to input a solution to the problem provided to him/her by the computer. 
//
// Output: I expect that the computer will output a valid addition, subtraction or multiplication statement to the user.
//
// Algorithm: I will inform the computer to select two numbers and than choose what mathematical problem it so desires to do with those two numbers. From there the user will do there best to solve the given problem. After solving the 5 problems the computer will output the average time taken along with the number of attempts in total and per question. 
//
// Major Variables: int number1, int number2, int answer, int count.
//
// Assumptions: I assume that the user has a basic understanding of simple mathematical problems (i.e. Addition, Subtraction, Multiplication).
//
// Program Limitations: This program is limited to only addition, subtraction and multplication problems. Also the number of questions that are asked is 5.  
//
#include <iostream>
#include <ctime> // Needed for time function
#include <cstdlib> // Needed for the srand and rand functions
using namespace std;

int main()
{
	int correctCount = 0; // Count the number of correct answers
	int count = 0; // Count the number of questions
	long startTime = time(0);
	const int NUMBER_OF_QUESTIONS = 5; // Total questions given to the user for each quiz attempt
	int answer = -1;

	srand(time(0)); // Set a random seed

	while (count < NUMBER_OF_QUESTIONS) // Use of a while loop
	{
		int number1 = rand() % 10; // Use of the modulus operator to select the 2 given numbers required to solve the problem
		int number2 = rand() % 10;
		int operationselector = rand() % 3; // Utilized to confirm that only addition, subtraction or multiplication problems can be given


		if (number1 < number2) // Too make sure that a negative answer does not appear as a soltion
		{
			int temp = number1;
			number1 = number2;
			number2 = temp;
		}
		if (operationselector == 0) // operationselector 0 is equivalent to subtraction
		{

			int count1 = 0;
			long startTime1 = time(0); // Too confirm that the start time starts at "zero" too be able to inform the user the time per question
			while (answer != number1 - number2) // Use of a while loop for the subtraction problems
			{
				cout << "What is " << number1 << " - " << number2 << "? ";
				cin >> answer;
				count1++;
			}
			if (number1 - number2 == answer) //  Use of the if statement to cout a statement to the user when they are correct and the time taken for that given problem
			{
				cout << "You are correct!\n";
				cout << "Number of attempts for that question was: " << count1 << endl; // Provided to the user to inform them how they have done
				correctCount++;
			}


			long endTime1 = time(0);
			long questionTime1 = endTime1 - startTime1; // This operation is used to inform the user of the time it took to complete the problem
			cout << "The time taken for that question was: " << questionTime1 << " seconds" << endl;
		}

		if (operationselector == 1) // operationselector 1 is equivalent to addion
		{

			int count2 = 0;
			long startTime2 = time(0); // Too confirm that the start time starts at "zero" too be able to inform the user the time per question
			while (answer != number1 + number2)
			{
				cout << "What is " << number1 << " + " << number2 << "? ";
				cin >> answer;
				count2++;
			}
			if (number1 + number2 == answer) // Use of the if statement to cout a statement to the user when they are correct and the time taken for that given problem
			{
				cout << "You are correct!\n";
				cout << "Number of attempts for that question was: " << count2 << endl;
				correctCount++;
			}


			long endTime2 = time(0);
			long questionTime2 = endTime2 - startTime2;  // This operation is used to inform the user of the time it took to complete the problem
			cout << "The time taken for that question was: " << questionTime2 << " seconds" << endl;
		}

		if (operationselector == 2) // operationselector 2 is equivalent to multiplication
		{

			int count3 = 0;
			long startTime3 = time(0); // Too confirm that the start time starts at "zero" too be able to inform the user the time per question
			while (answer != number1 * number2)
			{
				cout << "What is " << number1 << " * " << number2 << "? ";
				cin >> answer;
				count3++;
			}
			if (number1 * number2 == answer) //  Use of the if statement to cout a statement to the user when they are correct and the time taken for that given problem
			{
				cout << "You are correct!\n";
				cout << "Number of attempts for that question was: " << count3 << endl;
				correctCount++;
			}


			long endTime3 = time(0);
			long questionTime3 = endTime3 - startTime3;  // This operation is used to inform the user of the time it took to complete the problem
			cout << "The time taken for that question was: " << questionTime3 << " seconds" << endl;
		}

		// Increase the count
		count++;
	}

	long endTime = time(0);
	long testTime = endTime - startTime; // Too inform the user have there total time to complete the test

	cout << "Correct count is " << correctCount << "\nTest time is "
		<< testTime << " seconds\n";

	return 0;
}