//**************************************************************************
//
// Student name: Julie Ziemer
//
// Student number: 200342432
//
// Assignment number: Assignment 3
//
// Program name: Assignment 3 Guess a Number.cpp
//
// Date written: March 11, 2015
//
// Problem statement: The computer guesses a number that the user provides. Write the guesses from the program and the user's answers to a file. 
//					  Print a message if the computer detects that the user has not been trustworthy in their answers. Use the upper and lower limits
//					  technique that we discussed in class today.
//
// Input: User enters their number.  User informs the computer whether the guess was "high" "low" or "correct".
//
// Output: "Please enter a number between 0 and 100.  The computer will try to guess your number and it will be stored to a file.", 
//          "If the number is too high, please enter \"high\". If the number is too low, please enter \"low\". ", "If the guess was correct, 
//			 please enter \"correct\".", "The guess is ", "Is the guess too high, low, or correct?", "Thank you for being honest.  Your number is ",
//			 "Your answers are inconsistent.  The number cannot be guessed with your input." 
//
// Algorithm: User enters their number which is stored to an outfile.  The computer sets an upper and lower limit and outputs the average of the limits.
//			 User is asked to confirm whether the guess is too high, low, or correct.  If the answer is not correct, the upper and lower limits are reset accordingly.
//
// Major variables: int lowerlimit = 0, int upperlimit = 100, computerGuess; string user_confirm; ofstream out_number; int user_number;
//
// Assumptions:  The user will consistently answer questions and will choose a number within the range of 0 and 100.
//
// Program limitations: The user cannot choose a number outside the range of 0 and 100.
//
//**************************************************************************
#include <iostream>
#include <cstdlib>
#include <fstream> 
#include <string>
using namespace std;

int main()
{

	int lowerlimit = 0;
	int upperlimit = 100;
	int computerGuess;
	string user_confirm;
	ofstream out_number;
	int user_number;

	cout << "Please enter a number between 0 and 100.  The computer will try to guess your number and it will be stored to a file." << endl;
	cin >> user_number;

	out_number.open("Assignment 3 User_Number.txt");  // open the output file
	if (!out_number)  // test whether or not out_number can open
	{
		cout << "Error";
		return 1;
	}

	out_number << user_number << endl; // store the user_number in the output file

	cout << "If the number is too high, please enter \"high\". If the number is too low, please enter \"low\". ";
	cout << "If the guess was correct, please enter \"correct\"." << endl;

	// a while statement allows the loop to continue when the difference between the upperlimit and lowerlimit 
	// is greater than zero, meaning that the number has not been correctly guessed.  

	// The value of the upperlimit and lowerlimit changes each time the user responds

	while (upperlimit - lowerlimit > 0)
	{
		computerGuess = (upperlimit + lowerlimit) / 2;  // The average found between limits becomes the computer's guess
		cout << "The guess is " << computerGuess << endl;
		out_number << computerGuess << endl;  // stores the computer's guess in the output file
		
		cout << "Is the guess too high, low, or correct?" << endl;

		cin >> user_confirm;
		out_number << user_confirm << endl;  // stores user answer to the output file
		
		if (user_confirm == "high")
		{
			upperlimit = computerGuess;
		}
		if (user_confirm == "low")
		{
			lowerlimit = computerGuess;
		}
				if (user_confirm == "correct")  // The program ends once the number is guessed correctly.  The loop comes to an end.
				{ 
					cout << "Thank you for being honest.  Your number is " << computerGuess << endl;
					return 0;
				}
	}

	// when the conditions of the while loop are not satisfied, the computer tells the user
	// that the answers were not consistent.  If the number was between 0 and 100, it would have been guessed correctly
	// once the number of guesses reached 100.

	cout << "Your answers are inconsistent.  The number cannot be guessed with your input." << endl;

	out_number.close(); // close the output file
	return 0;  // end program

}