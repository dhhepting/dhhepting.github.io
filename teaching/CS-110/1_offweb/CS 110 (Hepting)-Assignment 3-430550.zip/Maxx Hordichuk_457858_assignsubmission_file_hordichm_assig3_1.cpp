// Name: Maxx Hordichuk
// Student #: 200353849
// Assignment: 3.1
// Program Name: Magic Number Guesser
// Date: 03/11/15
/* Problem statement: Modify Listing 5.3 so that the computer guesses a number that the user provides
(switch the roles of user and computer from Listing 5.3). Write the guesses from the program and the user's answers to a file.
Print a message if the computer detects that the user has not been trustworthy in her answers.
Use the technique that we discussed in class today. */
// Input: 0 or 1 depending on the computers question.
// Output: Guesses and a "lie" statement.
// Algorithm: Ask the user to think of a number -> make guesses of the number using a mathematical formula  -> determine if the user is lying.
// Variables: guess, option1, option2, counter.
// Assumptions: That the user will choose a number between 0-100 and be truthful as to whether the number is higher or lower.
/* Program limitations: The program will guess numbers outside of the 0-100 range if close to 0 or 100. Additionally,
the program cannot determine immediately if the user is lying. It determines the user is lying if the count exceeds 131072 - a number
of guesses that is beyond what would normally take the program to determine the number. */

#include <iostream>
#include <cstdlib>
using namespace std;

int main()
{

	int guess = 50; // Initial guess.
	int option1;
	int option2;
	int counter;
	counter = 1; // Acts as a variable in the "correction" function below as well as a "Liar Limit."
	
	// Prompt user to think of a number.

	cout << "Think of a number between 0-100 and I will guess it." << endl;
	cout << "My first guess is: " << guess << endl;

	// Asks if "50" is correct.

	cout << "Am I correct? (1 = Yes | 0 = No)" << endl;
	cin >> option1;

	// Initiates guess calculator.

	do
	{

		// Determines the user is lying if count exceeds 131072.

		if (counter == 131072)
		{
			cout << "You're lying!" << endl;

			return 1;
		}

		// Asks if the number is higher or lower and makes "counter" larger to narrow search.

		cout << "Is your number higher (1) or lower (0)?" << endl;
		cin >> option2;
		counter = counter * 2;

		// If higher...

		while (option2 == 1)
		{

			guess = ((guess / counter) + guess + 1);

			cout << "My new guess is: " << guess << endl;
			cout << "Am I correct? (1 = Yes | 0 = No)" << endl;
			cin >> option1;

			break;
		}

		// If lower...

		while (option2 == 0)
		{

			guess = (guess - (guess / counter) - 1);

			cout << "My new guess is: " << guess << endl;
			cout << "Am I correct? (1 = Yes | 0 = No)" << endl;
			cin >> option1;

			break;
		}

	} while (option1 != 1);

	// End message at the end of loop.

	cout << "Thanks for playing! Your number was: " << guess << endl;

	return 0;
}
