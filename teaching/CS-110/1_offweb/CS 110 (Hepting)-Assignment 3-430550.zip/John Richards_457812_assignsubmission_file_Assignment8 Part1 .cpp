// John Richards
// 200351524
// CS 110
//Assignment 3
// A program to get the computer to guess a number that the user provieds
// program uses a binary process to eliminate wrong answers
// program outputs all inputs from the user into a text folder
#include <iostream>
#include <fstream>
using namespace std;
int main()
{

	int high = 100;
	int low = 0;
	char guess;
	ofstream outData;
	outData.open("answer.txt");

	cout << "This is a program to guess a number that you choose between 0 and 100" << endl << endl;

	while (low != high)
	{
		cout <<"Is your number " << (high + low) / 2 << "?\n" << endl
			<< "Press 'y' for yes or 'n' for no" << endl;
			cin >> guess;
			outData << guess << " ";
		if (guess == 'n')
		{
			cout << "If the guess is to low press 'l'" << endl
				<< "If the guess is to high press 'h'" << endl;
			cin >> guess;
			outData << guess << endl;

			if (guess == 'h')
			{
				high = (high + low) / 2;
			}
			else if (guess == 'l')
			{
				low = (high + low) / 2;
			}
			else
			{
				cout << "Not a valid input." << endl;
			}
		}
		else if (guess == 'y')
		{
			cout << "Yay! I guesed your number correctly!" << endl << endl;
			return 0;
		}
		else
			cout << "Not a valid input. Try again" << endl << endl;
	}

	

	cout << "This has to be your answer" << endl;


	return 0;

}
