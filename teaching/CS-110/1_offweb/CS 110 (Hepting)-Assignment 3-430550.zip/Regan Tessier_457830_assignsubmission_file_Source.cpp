//**************************************************************************
//
// Student name:Regan Tessier
//
// Student number: 200300419	
//
// Assignment number: 3
//
// Program name: Math questions
//
// Date written: March 11 2015
//
// Problem statement: Output questions, answer the questions, keep track of attempts, and time for questions, at the end show average attemps and average time
//
// Input:Answers
//
// Output:Math equations and number of attempts and time taken
//
// Algorithm: while statement with if statements
//
// Major variables: totalsum, NUMBER_OF_QUESTIONS, questionmarker, answer
//
// Assumptions: 
//
// Program limitations:
//
//**************************************************************************
#include <iostream>
#include <ctime> // Needed for time function
#include <cstdlib> // Needed for the srand and rand functions
using namespace std;

int main()
{
	long totaltime = 0;
	int totalsum = 0; // Count the number of correct answers
	int count = 0; // Count the number of questions
	int selectednumberofquestions;
	
	cout << "How many questions would you like to do?" << endl;
	cin >> selectednumberofquestions;
	if (selectednumberofquestions <= 0)//ensure user enters a valid number of questions and also not a letter.
	{
		cout << "You must be soooo cool!" << endl;
		return 1;
	}

	const int NUMBER_OF_QUESTIONS = selectednumberofquestions;

	srand(time(0)); // Set a random seed
	while (count < NUMBER_OF_QUESTIONS)
	{
		long starttime = time(0); 
		int incorrectcount = 0;
		// Generate two random single-digit integers
		int number1 = rand() % 10;
		int number2 = rand() % 10;

		if (number1 < number2)
		{
			int temp = number1;
			number1 = number2;
			number2 = temp;
		}
		int question = rand() % 3;// Select ONE OF subtraction, addition, or multiplication - AT RANDOM
		// Prompt the user for an answer, based on the question type selected
		int questionmarker = 0;
		int correctanswer;
		if (question == 2){// subtraction selected
			cout << "What is " << number1 << " - " << number2 << "? ";
			correctanswer = number1 - number2;
			questionmarker++;
		}
		if (question == 1)
		{// addition selected
			cout << "What is " << number1 << " + " << number2 << "? ";
			correctanswer = number1 + number2;
			questionmarker++;
		}
		if (question == 0)// multiplication selected
		{
			cout << "What is " << number1 << " * " << number2 << "? ";
			correctanswer = number1 * number2;
			questionmarker++;
		}
		int answer;
		incorrectcount++;
		cin >> answer;
		int pl;


		while (answer != correctanswer)
		{
			cout << "Not quite" << endl;// what needs to happen in this loop?  
			cout << "Try again" << endl;
			incorrectcount++;
			int answer1;
			cin >> answer;


			// Does it need to executed at least once?
		}
		if (answer == correctanswer)
		{
			cout << "good work!" << endl;
			cout << "Number of attempts" << " " << incorrectcount << " " << endl;

		}

		long endTime = time(0);
		long testTime = endTime - starttime;
		cout << "questiontime:" << testTime << "seconds"<< endl;
		totalsum = totalsum + incorrectcount;
		totaltime += testTime;
		// Increase the count
		count++;
	}
	cout << endl;// what will get printed here?
	cout << "The average of attempts for each question is " << double(double(totalsum) / double(NUMBER_OF_QUESTIONS)) << " ";
	cout << endl;
	cout << "The average amount of time for each question is " << totaltime / NUMBER_OF_QUESTIONS << "seconds" << endl; //testTime << " seconds\n";

	return 0;
}