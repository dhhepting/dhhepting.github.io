#include <iostream>
#include <ctime> // Needed for time function
#include <cstdlib> // Needed for the srand and rand functions
using namespace std;

int main()
{
	int TryCount1 = 0;// Count the number of try answers
	int TryCount2 = 0;
	int TryCount3 = 0;
	int count1 = 0;// Count the number of questions
	int count2 = 0;
	int count3 = 0;
	long startTime = time(0);
	
	const int NUMBER_OF_QUESTIONS = 5;
	int answer1 = 0;
	int answer2 = 0;
	int answer3 = 0;

	srand(time(0)); // Set a random seed

	cout << "please answer question 1:" << endl;
	while (count1 < NUMBER_OF_QUESTIONS)
	{
		// 1. Generate two random single-digit integers
		int number1 = rand() % 10;
		int number2 = rand() % 10;
	 
		// 2. If number1 < number2, swap number1 with number2
		if (number1 < number2)
		{
			int temp = number1;
			number1 = number2;
			number2 = temp;
		}

		// 3. Prompt the student to answer ��what is number1 �C number2?��
		while (answer1 != number1 - number2)
		{
			
			cout << "What is " << number1 << " - " << number2 << "? ";
			cin >> answer1;

			if (number1 - number2 == answer1)
			{
				cout << "You are correct!" << endl;
			}
			else
			{
				cout << "Your answer is wrong." << endl;
				cout << "please try again." << endl;
				TryCount1++;
			}

		}
		count1++;
	}

	long endTime = time(0);
	long testTime1 = endTime - startTime;

	startTime = time(0);

	cout << endl;
	cout << "please answer the question 2:" << endl;

	while (count2 < NUMBER_OF_QUESTIONS)// addition
	{
		
		int number3 = rand() % 10;
		int number4 = rand() % 10;
		while (answer2 != number3 + number4)
		{
			cout << "What is " << number3 << " + " << number4 << " ? ";
			cin >> answer2;
			if (number3 + number4 == answer2)
			{
				cout << "You are correct!" << endl;
			}
			else
			{
				cout << "Your answer is wrong." << endl;
				cout << "please try again." << endl;
				TryCount2++;
			}

		}
		count2++;
	}

	endTime = time(0);
	long testTime2 = endTime - startTime;

	startTime = time(0);
	cout << endl;
	cout << "please answer the question 3:" << endl;

	while (count3 < NUMBER_OF_QUESTIONS)//multiplication
	{
		int number5 = rand() % 10;
		int number6 = rand() % 10;

		while (answer3 != number5 * number6)
		{
			cout << "What is " << number5 << " * " << number6 << " ? ";
			cin >> answer3;
			if (number5 * number6 == answer3)
			{
				cout << "You are correct!" << endl;
			}
			else
			{
				cout << "Your answer is wrong." << endl;
				cout << "please try again." << endl;
				TryCount3++;
			}

		}
		count3++;
	}
	endTime = time(0);
	long testTime3 = endTime - startTime;

	cout << "number of attempts on subtraction is " << TryCount1 << endl;
	cout << "number of attempts on addition is " << TryCount2 << endl;
	cout << "number of attempts on multiplication is " << TryCount3 << endl;
	
	int avg = (TryCount1 + TryCount2 + TryCount3) / 3;
	cout << "average number of attempts: " << avg << endl;
	
	cout << "testtime1: " << testTime1 << endl;
	cout << "testtime2: " << testTime2 << endl;
	cout << "testtime3: " << testTime3 << endl;
	
	long avgtime = (testTime1 + testTime2 + testTime3) / 3;
	cout << "the average time taken: " << avgtime << endl;

	return 0;
}