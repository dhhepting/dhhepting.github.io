//**************************************************************************
//
// Student name: Congning Yang
//
// Student number: 200350457
//
// Assignment number: Assignment #3 (listing 5.4)
//
// Program name: CS 110
//
// Date written: March 11th, 2015
//
// Problem statement: Modify Listing 5.4 so that the user must answer the question correctly before proceeding. Also, your program should offer addition and multiplication questions (at random). For each question, print out the number of attempts on the question and the time taken. At the end of the quiz, print the average number of attempts and the average time taken.
//
// Input: NUMBER_OF_QUESTIONS; answer
//
// Output:the number of question the user would like to answer; "You are correct."; "Your answer is wrong, please try again."; the number of attemps that the user tried; how long does the user take to answer each question; average attemps the user uses; average time the user uses to finish all questions.
//
// Algorithm 1: Set up three interger: number1, number2. number 1 and number 2 can change their positions when doing the subtraction
// Algorithm 2: Let "0" be subtraction, "1" be addition and "2" be "*"
// Algorithm 3: In subtraction: correctAnswer= number1-nuber2; in addition: correctAnswer=number1 + number2; in multiplication: correctAnswer= number1*number2
// Algorithm 4: At the beginning of the quiz, the user has to enter how many numbers of question he/she would like to answer. 
// Algorithm 5: The user has to answer each question correctly.Otherwise, the program will go into a loop and display "try again" until the user's answer is correct.
// Algorithm 6: When the user is considering the quesition, the program is calculating the time that the user take to answer each question: testTime = endTime - startTime.
// Algorithm 7: After the user answered all questions correct, the program will display the average time that the user take: averageTime += testTime; averageTime /= NUMBER_OF_QUESTIONS;
// Algorithm 8: The program will also display the average attempts that the user usese to answer each question: averageAttempts += attempts; averageAttempts /= NUMBER_OF_QUESTIONS;
//
// Major variables: correctCount, count, averageAttempts, averageTime, startTime, endTime, testTime, number1, number2, temp, cal, correctAnswer, answer
//
// Assumptions: Three types of questions in random (multiplication, addition and subtraction)
//
// Program limitations: Any mathmatic operations does not include multiplication, addition and subtraction.
//
// Comment: The code I created can run succefully 
//**************************************************************************
#include <iostream>
#include <ctime> 
#include <cstdlib> 
using namespace std;

int main()
{
	int correctCount = 0;
	int count = 0;
	int averageAttempts = 0;
	long averageTime = 0;
	int NUMBER_OF_QUESTIONS;

	srand(time(0));

	cout << "Please enter how many questions you would like to answer:";
	cin >> NUMBER_OF_QUESTIONS;

	while (count < NUMBER_OF_QUESTIONS)
	{
		long startTime = time(0);
		int number1 = rand() % 10;
		int number2 = rand() % 10;

		if (number1 < number2)
		{
			int temp = number1;
			number1 = number2;
			number2 = temp;
		}

		cout << "What is " << number1;
		int cal = rand() % 3;
		int correctAnswer;
		if (cal == 0)
		{
			cout << "-";
			correctAnswer = number1 - number2;
		}
		else if (cal == 1)
		{
			cout << "+";
			correctAnswer = number1 + number2;
		}
		else
		{
			cout << "*";
			correctAnswer = number1*number2;
		}
		cout << number2 << "?";

		int answer, attempts = 0;
		do
		{
			cin >> answer;
			attempts++;
			if (correctAnswer == answer)
				cout << "You are correct!\n";
			else
				cout << "Your answer is wrong.\nPlease try again.\n";
		} while (correctAnswer != answer);

		count++;
		long endTime = time(0);
		long testTime = endTime - startTime;
		cout << "You have tried " << attempts << " times.\nYour test time for this question is " << testTime << " seconds.\n\n";

		averageTime += testTime;
		averageAttempts += attempts;
	}

	averageTime /= NUMBER_OF_QUESTIONS;
	averageAttempts /= NUMBER_OF_QUESTIONS;
	cout << "Average number of attempts is " << averageAttempts << "\nAverage test time is "
		<< averageTime << " seconds\n";

	return 0;
}
