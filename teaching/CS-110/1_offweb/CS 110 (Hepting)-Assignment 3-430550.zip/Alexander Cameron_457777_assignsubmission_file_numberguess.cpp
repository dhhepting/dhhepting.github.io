/*********************************************************************************************************
 
 Student Name: Alexander Cameron
 
 Student Number: 200 246 288
 
 Assignment Number: 3.1
 
 Program Name: Number Guesser
 
 Date Written: 11 March, 2015
 
 Problem Statement: This program is created to guess your number between 0 and 100 inclusive
 
 Input: input 'high', 'low', or 'yes' if the number output is too high, too low, or correct respectively
 
 Output: a number between 0 and 100 until number is found correct, or answers are found to be inconsistant.
 
 Algorithm: The computer will tell the user that it can guess user's number, it will ask the user to input his name when ready. It will then keep guessing what the users number is by adding the extremes (too high and too low) and dividing by two(2) to eliminate the largest amount of numbers at a time. If the user inputs yes, the program will cout an excited message displaying how smart it is. If the user is inconsistant in his answers the computer will output its displeasure and end the program.
 
 Major Variables: int, and bool are the big ones, string just to
 
 Assumptions: This program assumes that the user is indeed thinking of a number between 0 and 100, also that the user is consistant
 
 Program Limitations: This program is limited to guessing numbers between 0 and 100, and can't go back if a user messes up.
 
 
 ********************************************************************************************************/
#include <iostream>
#include <ctime>
#include <cstdlib>

using namespace std;

int main ()

{
    bool notDone=true; //ensures loop will run
    string answer; //sets up the program to accept string answers
    int tooLow=-1; //ensures that the number will never guess anything below zero
    int tooHigh=101;//ensures that the computer will never guess above 100
    int guess;    //declairs the integer that will be the guess of the computer
    srand(time(0));
    
    cout<< "I can guess your number!"<<endl;
    cout<<"Please think of a number between 0 and 100."<<endl;
    cout<<"Enter your name when you are ready to begin."<<endl; //this was mainl to ensure the user is ready before the computer guesses
    string name;
    cin>>name;
    
    do{
        
        
        guess=(tooLow+tooHigh)/2; //creates a guess to eliminate the largest amounts of numbers possible

        
            
        cout<<name<<", is your number "<<guess<<"?"<<endl; //outputs the guess and asks for feedback
        
            cout<<"Enter 'High' if the number is too high, 'Low' if the number is too low, or 'yes' if it is correct."<<endl;//prompt for answer
        
            cin>>answer;//enter answer
        
            if (answer=="High"||answer=="high") //if the number is too high, it makes sure that the guess will go no higher
                tooHigh=guess; //redefines the tooHigh value
    
            else if (answer=="Low"||answer=="low")//if number is too low, sets the tooLow variable to ensure it doesnt go any lower
                tooLow=guess;
            else if (answer=="yes"||answer=="Yes")
                notDone=false; //sets notDone bool to false and breaks the loop
            else
                cout<<"Not a valid answer"; //if answer isnt one of the specified the answer is considered invalid
            if (tooHigh==tooLow || tooHigh<tooLow||tooHigh==tooLow+1)//if the tooHigh or tooLow variables end up too close, or flipped
            {
                if (answer=="high"||answer=="High"||answer=="low"||answer=="Low")//if the answer isnt yes, the program will end
                {
                cout<<"Your answers were not consistant, that is not fun! Good bye."<<endl; //ends program if the people are inconsistant
                return 1;
                }
            }
                
            
        
        } while (notDone);
    
    cout<<"I am so smart! Thank you for playing with me!"<<endl; //outputs its pleasure at having guessed the number
    
    return 0;
    
}