//Ashlyn Gelowitz
// March 3/15
// Visual Studios

#include <iostream>
#include <cstdlib>
#include <ctime>
#include <fstream>

using namespace std;

int main()
{
	srand(time(0));

	int usernumber = -1;
	int guess;

	int numberofguesses = 0;

	ofstream outData;
	outData.open("guessess.txt");

	do
	{
		cout << "Please enter a number between 0 and 100: " << endl;
		cin >> usernumber;

	} while (usernumber < 0 || usernumber > 100);

	do
	{

		guess = rand() % 101;

		outData << guess << endl;

		numberofguesses++;
	} while (guess != usernumber);

	cout << "The number of guesses it took were " << numberofguesses << endl;

	return 0;
}