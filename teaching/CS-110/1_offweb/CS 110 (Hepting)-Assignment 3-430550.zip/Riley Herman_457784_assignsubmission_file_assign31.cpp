/*Riley Herman
200352833
Assignment 3
Adding a Subcode
March 11 / 2015
"Modify Listing 5.4 so that the user must answer the question correctly before proceeding. Also, 
your program should offer addition and multiplication questions (at random). For each question, 
print out the number of attempts on the question and the time taken. At the end of the quiz, 
print the average number of attempts and the average time taken."
Input: Answers to simple mathematical operations
Output: Mathematical problems; whether the user got the problem right or not, the number of attempts,
the time taken for the attempts, and the average number of attempts and time taken.
The program generates two random single digit numbers, and a random operation. It then asks the user to 
answer the question. If the answer is wrong, the user must try again until they get it right. When they 
get it right, it will calculate how many attempts ad how much time it has taken them to get the right answer.
Finally, it will calculate the whole time of the test and the average time/number of attempts it took the user 
to do the quiz.
Major Variables: count- controls the main loop and exits the loop afer 5. startt- short for start time; when 
the test starts. attnumtot- short for attempt number total; the total amount of attempts for the quiz. 
number1/number2- the numbers being multiplied, added or subtracted. answer- the user inputted answer. attnum-
short for number of attempts; the amount of attempts to do one specific problem. midt- short fr middle time; 
the time to do each problem. oper- short for operation; which operation to perform on the two numbers. testt-
short for test time; the total time for the whole test. endt- short for ending time; the ending time of the test. 
Assumptions: We assume that the user will eventually input the right answer in the righ form; we also assume 
that they participate properly. 
Program Limitations: This program is limited to single digit numbers and multiplication, addition, and subtraction. 
It is also only 5 questions long. 
*/
#include <iostream>			// include statements which include libraries for the input and ouput streams, time, 
#include <ctime>			//		and random functions. 
#include <cstdlib> 
using namespace std;		// using the standard way of naming things

int main()			// the beginning of the main fuction
{
	int count = 0;				// loop counter
	long startt = time(0);		// the timer for the start begins
	float attnumtot = 0;		// attempt number total

	srand(time(0));			// random seeder which is dependant on time(0) (time(0) changes every second so it picks a 
							//		different set of random nunbers every second
	while (count < 5)		// count controlled loop which will run the code inside 5 times
	{

		int number1 = rand() % 10;		// generating random numbers 1 and 2, which are then %10 to make them single digit 
		int number2 = rand() % 10;
		int oper = rand() % 3;		// operation is determined in the same manner, except there are 3 operations so %3
		int answer;				// the variable answer for the user to input into
		int attnum = 1;				// attempt number is 1 because they have to attempt at least once
		long midt = time(0);		// the timer for the question takes this value

		if (oper = 0)		// if the random number % 3 happens to be 0
		{
			if (number1 < number2)		// since we will be subtracting and don't want negatives, the numbers will be switched 
			{							//		if the first one is larger
				int temp = number1;
				number1 = number2;
				number2 = temp;
			}
			cout << "What is " << number1 << " - " << number2 << "? ";		// giving the user the question and recieving the input
			cin >> answer;
			while (number1 - number2 != answer)			// if they got it wrong and until thy get it right...
			{
				cout << "You are incorrect!\n";
				cin >> answer;				// get in a new answer and add to the number of attempts for the question
				attnum++;
			}
			cout << "You are correct!\n It took you " << attnum << " attempts and " << midt - startt << " seconds to do the question.\n";
		} // the above line prints out the values which the user wants to see (no. of attempts and time)

		else if (oper = 1)			// this and the next else if statement are nearly identical to the first one, except this one is 
		{							//		for addition and the next one is multiplication and neither one switches the numbers like 
			cout << "What is " << number1 << " + " << number2 << "? "; //		the subtraction one
			cin >> answer;
			while (number1 + number2 != answer)
			{
				cout << "You are incorrect!\n";
				cin >> answer;
				attnum++;
			}
			cout << "You are correct!\n It took you " << attnum << " attempts and " << midt - startt << " seconds to do the question.\n";
		}

		else if (oper = 2)
		{
			cout << "What is " << number1 << " * " << number2 << "? ";
			cin >> answer;
			while (number1 * number2 != answer)
			{
				cout << "You are incorrect!\n";
				cin >> answer;
				attnum++;
			}
			cout << "You are correct!\n It took you " << attnum << " attempts and " << midt - startt << " seconds to do the question.\n";
		}

		count++;		// increents the counter to one more, so that the loop will exit when it has incremented 5 times
		attnumtot += attnum;		// the total number of attempts is added to the previous total number of atempts
	}

	long endt = time(0);		// the ending time is now since the loop has been run 5 times and exited
	long testt = endt - startt;			// the test time is the end - the start

	cout << "Test time is " << testt << " seconds\n";		// printing out the test time, average time and average attempts
	cout << "Average time per question is " << testt / 5 << " seconds\n";
	cout << "Average number of attempts is " << attnumtot / 5.0 << endl;

	return 0;		// return a value of 0 to the main function and close it to end the program
}