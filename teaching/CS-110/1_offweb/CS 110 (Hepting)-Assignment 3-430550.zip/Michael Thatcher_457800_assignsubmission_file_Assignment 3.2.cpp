/*
 Name: Michael Thatcher
 
 Student Number: 200 353 864
 
 Assignment 3.1: CS 110
 
 Program Name: Math Question Tester
 
 Date: March 11, 2015
 
 Problem statement:
 
   Modify Listing 5.4 so that the user must answer the question correctly before proceeding.
   Also, your program should offer addition and multiplication questions (at random). 
   For each question, print out the number of attempts on the question and the time taken. 
   At the end of the quiz, print the average number of attempts and the average time taken.

 
 Input: Answers to mathematical problems
 
 Output: Random addition, subtraction, and multiplication questions
 
 Algorithm: generate two random numbers and use if statements (and modulus) to randomly generate addition/subtraction/multiplication questions. Take user input for questions and evaluate if correct/incorrect. repeat for 10 questions and then print out average time taken, questions correct, and number of attempts.
 Major variables: | correctCount | count | startTime | NUMBER_OF_QUESTIONS | incorrectCount | number1 | number2 | number3 | questionIncorrect1 | questionIncorrect2 | questionIncorrect3 | QuestionTime |
 
 
 Assumptions: User will only enter numbers for their answers (ie. 3 instead of three)
 
 Program limitations: Only offers single digit multiplication/addition/subtraction questions. Only displays average time taken to the nearest second.
 
 */


#include <iostream>
#include <ctime> // Needed for time function
#include <cstdlib> // Needed for the srand and rand functions
using namespace std;

int main()
{
  int correctCount = 0; // Count the number of correct answers
  int count = 0; // Count the number of questions
  long startTime = time(0);
  const int NUMBER_OF_QUESTIONS = 10;
  
  int incorrectCount = 0;

  srand(time(0)); // Set a random seed

  while (count < NUMBER_OF_QUESTIONS)
  {
    // 1. Generate two random single-digit integers
    int number1 = rand() % 10;
    int number2 = rand() % 10;
    int number3 = rand() % 3 ;
    
    
    
    
    int questionIncorrect1 = 1;
    int questionIncorrect2 = 1;
    int questionIncorrect0 = 1;
    
    
    
    if (number3 == 1)
    {

    // 2. If number1 < number2, swap number1 with number2
    if (number1 < number2)
    {
      int temp = number1;
      number1 = number2;
      number2 = temp;
    }

    // 3. Prompt the student to answer “what is number1 – number2?”
    int answer;
        while (number1 - number2 != answer)
        {
    cout << "What is " << number1 << " - " << number2 << "? ";
    
    cin >> answer;
            if (number1 - number2 == answer)
            
               {
                    cout << "You are correct!\n";
                    correctCount++;
                    
                    cout << "It took you " << questionIncorrect1 << " attempts to answer this question \n";
                    long endTime = time(0);
                    long QuestionTime = endTime - startTime;
                    
                    cout << "It took you " << QuestionTime << " seconds to answer" << endl;
                }
    
            
            else if (number1 - number2 != answer)
            
                incorrectCount++;
                questionIncorrect1++;
        }
    // 4. Grade the answer and display the result
    if (number1 - number2 == answer) 
    
    // Increase the count
    count++;
    }
    
    
    
    
    
   if (number3 == 2)
    {

    // 2. If number1 < number2, swap number1 with number2
    if (number1 < number2)
    {
      int temp = number1;
      number1 = number2;
      number2 = temp;
    }

    // 3. Prompt the student to answer “what is number1 – number2?”
    int answer;
        while (number1 + number2 != answer)
        {
    cout << "What is " << number1 << " + " << number2 << "? ";
    
    cin >> answer;
            if (number1 + number2 == answer)
            
               {
                    cout << "You are correct!\n";
                    correctCount++;
                    
                     cout << "It took you " << questionIncorrect2 << " attempts to answer this question \n";
                     
                     long endTime = time(0);
                    long QuestionTime = endTime - startTime;
                    
                    cout << "It took you " << QuestionTime << " seconds to answer" << endl;
                }
    
            
            else if (number1 + number2 != answer)
            
                incorrectCount++;
                questionIncorrect2++;
        }
    // 4. Grade the answer and display the result
    if (number1 + number2 == answer) 
    
    // Increase the count
    count++;
    }
    
    
    
    
    
    
    
    
    
    
    
    
    if (number3 == 0)
    {

    // 2. If number1 < number2, swap number1 with number2
    if (number1 < number2)
    {
      int temp = number1;
      number1 = number2;
      number2 = temp;
    }

    // 3. Prompt the student to answer “what is number1 – number2?”
    int answer;
        while (number1 * number2 != answer)
        {
    cout << "What is " << number1 << " x " << number2 << "? ";
    
    cin >> answer;
            if (number1 * number2 == answer)
            
               {
                    cout << "You are correct!\n";
                    correctCount++;
                    
                     cout << "It took you " << questionIncorrect0 << " attempts to answer this question \n";
                     
                     long endTime = time(0);
                    long QuestionTime = endTime - startTime;
                    
                    cout << "It took you " << QuestionTime << " seconds to answer" << endl;
                }
    
            
            else if (number1 * number2 != answer)
            
                incorrectCount++;
              
        }
    // 4. Grade the answer and display the result
    if (number1 * number2 == answer) 
    
    // Increase the count
    count++;
    }
    
    
    
  }

  long endTime = time(0);
  long testTime = endTime - startTime;
  
  long testTimeAvg = testTime / 10.0;

  cout << "Correct count is " << correctCount << "\nTest time is "
       << testTime << " seconds\n";
       
  cout << "The average amount of time taken on each question was approximately" << testTimeAvg << "seconds per question." << endl;
       
  cout << "Number of incorrect guesses is " << incorrectCount;

  return 0;
}