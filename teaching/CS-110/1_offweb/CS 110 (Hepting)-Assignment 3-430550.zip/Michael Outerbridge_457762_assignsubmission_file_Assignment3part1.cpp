/*
Michael Outerbridge
200352016
March 11, 2015
Computer guess
Modify Listing 5.3 so that the computer guesses a number that the user provides 
(switch the roles of user and computer from Listing 5.3). Write the guesses from
the program and the user's answers to a file. Print a message if the computer 
detects that the user has not been trustworthy in her answers
*/

#include <iostream>
#include <cstdlib>
#include <ctime> 
#include <fstream>
#include <string>
using namespace std;

int main()
{
	ofstream outData;
	outData.open("output.txt");
	int max = 100, min = 0, num, g = 25, right = 0, guess = 50;
	srand(time(0));
	string response;
	while (right == 0)
	{
		cout << "Insert a number between 0-100 and the computer will try to guess it!\n";
		cin >> num;
		outData << num << endl;
		if (num >= 0 && num <= 100) // This will tell the user if their number fits in the range
		{
			cout << "This is a valid number\n";
			outData << "This is a valid number\n";
			right = 1;
		}
		else
		{
			cout << "The number is invalid\n";
			outData << "The number is invalid\n";
		}
	}
		while (guess != num)
		{
			cout << "The computer guessed:" << guess << endl;
			cout << "Please tell the computer if the number is too 'high' or too 'low'.\n";
			cin >> response;
			if (g == 0)
				g = 1;
			if (response == "high")
			{
				if (guess > num) 
				{
					cout << "The computers guess was too high!\n";
					outData << "guess too high\n";
					guess -= g; // This helps narrow down the possible answers by dividing the guessed number by 2 when its too high
					g /= 2;
				}
				else
				{
					cout << "You lied!\n"; //This will tell the user if they cheated by giving the wrong answer
					outData << "You lied!\n";
				}
			}
			else if (response == "low")
			{
				if (guess < num)
				{
					cout << "The computer's guess was too low!\n";
					outData << "guess too low\n";
					guess += g;
					g /= 2;
				}
				else
				{
					cout << "You lied!\n";
					outData << "You lied!\n";
				}
			}
		}
		cout << "Your number is: " << guess << "\n";
	}

