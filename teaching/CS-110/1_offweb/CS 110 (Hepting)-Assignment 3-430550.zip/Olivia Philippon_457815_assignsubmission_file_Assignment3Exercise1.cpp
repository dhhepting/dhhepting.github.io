//**************************************************************************
//
// Student name: Olivia Philippon		
//
// Student number: 200294151
//
// Assignment number: 3
//
// Program name: Assignment3Exercise1
//
// Date written: Mar. 11, 2015
//
// Problem statement: The problem that I am trying to solve with my code is developing a way in which the computer can guess 
//      the number that the user has entered. The program must present these guesses in a file. Overall, by asking the user 
//      if the number is too high or too low, the computer should be able to detect whether or not the user has been truthful
//      in providing their answer. 
//
// Input: The user will enter a number that the computer must guess. The user must also indicate whether or not the 
//     computer has guessed correctly. If the computer has not yet guessed correctly, the user will indicate if the guess was 
//     too low or too high. 
//
// Output: I expect the output to be the computer's guess. The computer will present a guess according to the user's indication 
//     of the guess being correct, too high, or too low. 
//
// Algorithm: In order to solve the stated problem, I will instruct the computer to ask for a number from the user between 0 and 100, check
//    to see if that number is actually within that range, and then begin the guessing process. The while loop will continue if the number is 
//    within that range. The computer then generates a random number within this range. The computer will output it's answer to an output file 
//    and the user must indicate with a "1" if the guess was too low, a "2" is the guess was too high, or a "3" if the guess was correct. Depending on these 
//    conditions, the corresponding if statement will be selected. Depending on what the user has selected, the computer's guess will either become 
//    the new lowest or highest possible number. The program will then determine the middle number to create a new guess. The middle number is 
//    created by subtracting the lowest number from the highest number and divided this answer by two. The new comptuer guess will either subtract 
//    or add the calculated middle number depending on if the user said that the number was too high or too low. The user will continue to indicate 
//    whether the comptuer's guess was too high or too low. This process will continue until the user indicates that the guess is correct or the 
//    highest possible number equals the lowest possible number. In this case, all possible guesses have been exhausted and this indicates that the 
//    user has not been truthful in saying that the comptuer's guess was correct. After this is complete, the user will have the chance to begin 
//    the program again as the loop presents the question that asks for a number from the user. 
//
// Major variables: Two major variables are the assigned highest and lowest numbers. This provides the computer with a starting point 
//    of what the orginal high and low numbers can be. The user's input is an important variable because this is the number that the comptuer must
//    guess. The variable of the user's answer is also important because this will indicate whether the computer's guess needs to proceed and guess 
//    again based on the indcation that the guess was too high or too low. This variable of providing the answer is also important in order to tell 
//    the computer if it has guessed correctly. This leads to another important variable, the middle number, that helps the computer decrease 
//    the possible number that it will use when guessing. The computer's guess is also a major variable because the program is designed to guess the user's 
//    number. 
//
// Assumptions:The assumptions of the program are that the user wants the computer to guess a number between 0 and 100. 
//
// Program limitations: The limitations of this program include that this program is set to only guess numbers between 0 and 100. It also
//    does not keep track of the number of guesses it has made. This program does not continue if the user enters a number that is out of the 
//    the range. 
//
//**************************************************************************
#include <iostream>
#include <time.h>
#include <fstream> 

using namespace std;

int main()
{
	//This function allows a random number to be generated for the first guess. 
	srand(time(NULL));

	//This provides an indication of where the program should go after the computer has guessed the number correctly. 
	stop:

	//Declaring the variables- the highest and lowest possible numbers are assigned by the listing 5.3 question which requests a range between 0 and 100. 
	int number = 0;
	int computerGuess = 0;
	int lowestPossibleNumber = 0;
	int highestPossibleNumber = 100;
	int middleNumber = 0; 
	int count = 0;
	int answer = 0;

	ofstream outData;			// declares output stream

	outData.open("outputfile.txt");

	//Testing the state of the stream
	if (!outData)
	{
		cout << "Can't open the output file successfuly." << endl;
		return 2;
	}
 
	//The loop will end if the number is not between 0 and 100.
	while (number >= 0 && number <= 100)
	{
		cout << "Please enter a number between 0 and 100. The computer will guess your number.";
		cin >> number;
		//This generates the computer guess. 
		computerGuess = rand() % 101;

		//This allows the program to guess further if the number is between 0 and 100. 
		if (number >= 0 && number <= 100)
		{
			//This loop will continue until the highest possible number, determined by the computer, equals the lowest possible number, also determined by the computer.
			while (lowestPossibleNumber != highestPossibleNumber)
			{
				int answer;
				outData << "The computer has guessed: " << computerGuess << endl;			
				cout << "Please indicate if this guess is correct by entering \"3\". If the guess is too low, please enter \"1\", or too high, please enter \"2\"." << endl;
				cin >> answer;
				outData << "The user's answer is: " << answer << endl;
				count++;

				//For each condition, the comptuer's guess will change according to the previous conditions. As in, if the computer has guessed once, and the user indicates 
				//that the guess is too low, the computer's guess will now become the new lowest number. This will stay consistant until the user says that the new guess is 
				//also too low; the new guess then becomes the new lowest possible number. By determining the middle number, the comptuer is able to provide a new guess that 
				//will lead it in the right direction based on the user's answer. If the computer guesses half of the original guess, the user can indicate if this guess is too low or 
				//too high, and this can narrow the range as half of the numbers from this middle point can be excluded. 
				if (answer == 1)//too low
				{
					lowestPossibleNumber = computerGuess;
					middleNumber = ((highestPossibleNumber - lowestPossibleNumber) / 2);
					computerGuess = (computerGuess + middleNumber);
				}
				else if (answer == 2)//too high
				{
					highestPossibleNumber = computerGuess;
					middleNumber = ((highestPossibleNumber - lowestPossibleNumber) / 2);
					computerGuess = (computerGuess - middleNumber);
				}
				else if (answer == 3)//correct
				{
					cout << "The guess is correct." << endl;
					goto stop; //this determines where the program goes from here. It will go back to the start of the loop to give the user 
					//the opportunity to enter another number. 
				}
			}
			outData << "That is not correct. You are not being truthful in your answer." << endl;
		}		
		outData << "The number you have entered is not between 0 and 100." << endl;
	}
	

	return 0;
}



