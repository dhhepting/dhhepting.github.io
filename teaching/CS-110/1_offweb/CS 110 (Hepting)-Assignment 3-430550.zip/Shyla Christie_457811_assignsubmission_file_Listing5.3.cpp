// Shyla Christie
// 200337036
// Assignment #3
// Listing 5.3
// March 10th, 2015

#include <iostream>
#include <cstdlib>
#include <ctime> // Needed for the time function
#include <string>
using namespace std;

int main()
{
	// Generate a random number to be guessed
	srand(time(0));
	int number = rand() % 101;
	
	// Declare variables to be used
	int guess;
	int tries = 0;
	char reply;

	// Prompt user to enter in their value. This does not tell the compuer the value.
	cout << "Enter a number between 1 and 100!" << endl;
	cin >> guess;
	
	// Computer will guess a number
	cout << "The computer will now guess what the magic number is!" << endl;
	cout << " Is your number " << number << " ?" << endl;
	
	// Prompt user to answer whether the guess is true or false
	cout << "Is that the right number? Enter 't' for true and 'f' for false!" << endl;
	cin >> reply;
	
	// Add a continuous loop to guess the users number until correct
	// While statement shows output if guess is inncorect
	while (reply == 'f')
	{
		cout << "Oops, that must have been the wrong number, let me guess again...." << endl;
		int number = rand() % 101;
		cout << "Is your number " << number << " ?" << endl;
		cout << "Is that the right number?";
		cin >> reply;
		tries++;
	}

	// If the guess is correct, the program will print the number of total guesses the computer made
	if (reply == 't')
	{
		cout << "Your number has been guessed!" << endl;
		cout << "I made " << tries << " guesses!" << endl;
	}

	// If user input invalid letter the program quits
	else if (reply != 't' && reply != 'f')
	{
		cout << "That is invalid input, the program will end now!" << endl;
	}
	return 0;
}

	
