//*******************************************************
//Student Name: Matthew Vician
//
//Student Number: 200344933
//
//Assignment Number: 3
//
//Program Name: Guessing Game 
//
//Date Written: March 7, 2015
//
//Problem Statement: The user is asked to enter there number and the computer will guess the number. If the computer doesn't get the number the user
//					 must enter high or low depending on the number.
//Input: User needs to enter there desired value between 0-100.
//
//Output: The computer will guess and the user must say whether they are to high or to low and the computer will guess again.
//		  
//        
//     
//Algorithm: Prompt the user to enter a number between 0-100. The computer will then guess at your number.
//			 If the computer is wrong than the user must enter to high or to low based on your oriignal value.
//			 The computer will keep trying until it gives a message of the user not being truthful.
// 
// Major Variables: int main(), #include <iostream>,#include <cstdlib>,#include <fstream>,#include <string>,#include <ctime> 
//
//Assumptions: We are assuming that the user follows the instructions indicated on screen.
//Program limitations: This program can will guess at a number and if its wrong, the user will tell the computer if they guessed to high or to low.
//*******************************************************

#include <iostream>
#include <cstdlib>
#include <fstream>
#include <string>
#include <ctime> 
using namespace std;

int main()
{
	ofstream outData;
	outData.open("outputfile.txt");
	srand(time(0));
	int number;
	string response;
	cout << "Please input a number from 0-100\n";
	cin >> number;
	outData << number << endl;
	if (number >= 0 && number <= 100)
	{
		cout << "This is a valid number\n";
		outData << "This is a valid number\n";
		int guess = rand() % 101;
		cout << "The computer guessed: " << guess << endl;
		outData << "The computer guessed: " << guess << endl;
		while (guess != number)
		{
			cout << "The computer guessed:" << guess << endl;
			cout << "Please tell the computer if its guess is high or low\n";
			cin >> response;
			if (response == "high")
			{
				if (guess > number)
				{
					cout << "The guess was too high\n";
					outData << "TOO HIGH\n";
					guess = rand() % (guess + 1);
					outData << guess << endl;
				}
				else if (guess < number)
				{
					cout << "You haven't been trustworthy!!!\n";
					outData << "You haven't been trustworthy!!!\n";
					return 0;
				}
				else if (guess == number)
				{
					cout << "Good work you guessed right!" << endl;
					outData << guess << endl;
					outData << "Good work you guessed right!" << endl;
				}
			}
			else if (response == "low")
			{
				if (guess < number)
				{
					cout << "The guess was too low\n";
					outData << "too low\n";
					guess = (100 + guess) / 2;
					cout << "The computer guessed: " << guess << endl;
					outData << guess << endl;
				}
				else if (guess > number)
				{
					cout << "You haven't been trustworthy!!!\n";
					outData << "You haven't been trustworthy!!!\n";
					return 0;
				}
				else if (guess == number)
				{
					cout << "Good work you guessed right!" << endl;
					outData << guess << endl;
					outData << "Good work you guessed right!" << endl;
				}
			}
		}
	}

	return 0;
}
		
		

