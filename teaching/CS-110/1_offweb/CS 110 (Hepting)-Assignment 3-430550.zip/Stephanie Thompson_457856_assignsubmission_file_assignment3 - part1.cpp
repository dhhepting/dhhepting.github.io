
//**************************************************************************
//
// Student name: Stephanie Thompson	
//
// Student number: 200355041
//
// Assignment number: Assignment 3 - Part 2
//
// Program name: Pick a Number
//
// Date written: March 10, 2015
//
// Problem statement: The computer needs to guess the number that the user entered.
//
// Input: The user will input the number they want the program to guess.  The user will also be required to input according to the computer guesses, responding with an H, L, or Y 
//			if the guess is too high, too low, or the same as the number they originally entered.
//
// Output: The computer will output a number of values as guesses until the guess matches the users number.
//
// Algorithm: The user will first be asked to enter a value between 0 and 100.  The program will test the input and detect if the value is acceptable, once the number has been
//				approved the computer will begin guessing the number.  This is done by finding the average of the upper and lower limits.  Each time the user responds with an 
//				H or L the value of the upper or lower limit will change accordingly.  When the user inputs a Y this indicates the guess is correct and the program will end.
//				If the number of guesses exceeds 100 the computer will print a message and the program will end.  All of the output in the program will be written to a file
//				name "output".
//
// Major variables: Major variables include guess, number, highest, lowest,  and answer.
//
// Assumptions: The user will only input numerical values until required to input letters in response to the computers guesses.  
//
// Program limitations: The program will not be able to adjust for user mistakes (example: if the user inputs L instead of H the computer will be unable to undo its previous 
//						 calculation)
//
//**************************************************************************
#include <iostream>
#include <cstdlib>
#include <ctime> // Needed for the time function
#include <string>
#include <fstream>
using namespace std;

int main()
{
	// Delclaring and initializing of variables
	srand(time(0));
	int number;
	int highest = 100;
	int lowest = 0;
	int guess;
	string answer;
	bool stillplaying = true;
	int numberofguesses = 0;
	ofstream output;
	output.open("output.txt"); // Opens the output file

	// Prompts the user for input
	cout << "Enter a number between 0 and 100 for the computer to guess." << endl;
	cin >> number;

	// Tests the value of the number
	while (number > highest || number < lowest)
	{
		cout << "The number you entered does not fall between the limits.  Please enter a new number that falls between " << highest << " and " << lowest << endl;
		cin >> number;
	}
	cout << "The computer will now try and guess the number you entered.  If the number is too high type 'H', if the number is too low type 'L', if the guess is the number type 'Y'." << endl;
	guess = (highest + lowest) / 2; // Formula for computer guesses
	cout << "Is the number " << guess << "?" << endl;
	output << guess << endl;

	// Creates a loop that changes the computers guess according to user response
	while (stillplaying)
	{
		cin >> answer;
		output << answer << endl;
		if (answer == "Y")
		{
			cout << "Thanks for playing." << endl;
			stillplaying = false;
		}
		if (answer == "H")
		{
			highest = guess;
			guess = (highest + lowest) / 2;
			cout << "Is the number " << guess << "?" << endl;
			output << guess << endl;
		}
		if (answer == "L")
		{
			lowest = guess;
			guess = (highest + lowest) / 2;
			cout << "Is the number " << guess << "?" << endl;
			output << guess << endl;
		}
		if (numberofguesses > 100) // Tests if the user is being dishonest
		{
			cout << "You are being dishonest." << endl;
			stillplaying = false;
		}
		numberofguesses++;
	} // End of loop

	return 0;
}