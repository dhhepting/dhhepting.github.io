/*Shurouk Alhelou
SID: 200336944
Assignment#: 3
Program: Visual Studio C++
Date: March 11, 2015
*/

/*
Modify Listing 5.3 so that the computer guesses a number that the user provides (switch the roles of user and computer from Listing 5.3).
Write the guesses from the program and the user's answers to a file. Print a message if the computer detects that the user has not been
trustworthy in her answers.
*/


#include <iostream>
#include <cstdlib>
#include <ctime> // Needed for the time function
#include <fstream>
using namespace std;

int main()
{
	ifstream inData;
	ofstream outData;
	
	// Generate a random number to be guessed
	srand(time(0));
	int number = rand() % 101;
	
	outData.open("compguess.txt");
	cout << "Guess a magic number between 0 and 100";
	outData << number << endl;

		int guess = -1;
		inData.open("myguess.txt");
		inData >> guess;
		while (guess != number)
		{
			// Prompt the user to guess the number
			cout << "\nEnter your guess: ";
			cin >> guess;

			if (guess == number)
				cout << "Yes, the number is " << number << endl;
			else if (guess > number)
				cout << "Your guess is too high" << endl;
			else
				cout << "Your guess is too low" << endl;		
		} // End of loop
		
		inData.close();
	outData.close();

	return 0;
}






