/*
NAME: Part 2.cpp
AUTHOR: Josh Leidl
SID: 200350878
*/

#include <iostream>
#include <ctime>
#include <cstdlib>

using namespace std;



int main()
{
	//Ensure random numbers
	srand(time(0));
	
	const int NUMBER_QUESTIONS = 5.0;
	long startTime;
	int questionDeterminer;
	int totalTime = 0;
	int totalAttempts = 0;
	int num1, num2;
	int answer;
	int attempts = 0;
	int input;
	int first, second;
	int counter = 0;
	double avgAttempts = 0, avgTime = 0;
	
	bool flag = true;
	
	
	//Prompt the user that it is time to start
	cout << "Welcome to the math tutor." << endl;
	
	cout << "Press enter to start" << endl;
	cin.ignore();
	
	startTime = time(0);
	
	while (counter < NUMBER_QUESTIONS)
	{
		questionDeterminer = rand() % 3;
		// Determine whether to ask an addition, subtraction, or multiplycation question
		if (questionDeterminer == 0)
		{
			
			num1 = rand() % 10;
			num2 = rand() % 10;
			
			do
			{
				//Calculate the answer
				answer = num1 + num2;
				
				cout << num1 << " + " << num2 << endl;
				cin >> input;
				
				attempts++;
				
				//Check if the answer is correct
				if(input == answer)
				{
					flag = false;
					totalTime += time(0) - startTime;
					totalAttempts += attempts;
					cout << "The question was answered correctly after " << attempts << " attempt(s) and took " << time(0) - startTime << " seconds." << endl;
				}
				
			}while (flag);
			
			//Reset the variables
			flag = true;
			attempts = 0;
			startTime = time(0);
			
			counter++;
		}
		else if (questionDeterminer == 1)
		{
			
			num1 = rand() % 10;
			num2 = rand() % 10;
			do
			{
				//Form a subtraction question that doesn't have a negative answer
				if (num1 > num2)
				{
					answer = num1 - num2;
					first = num1;
					second = num2;
				}
				else if (num1 < num2)
				{
					answer = num2 - num1;
					first = num2;
					second = num1;
				}
				else
				{
					answer = 0;
					first = num1;
					second = num2;
				}
					
				cout << first << " - " << second << endl;
				cin >> input;
					
				attempts++;
				
				//Determine if the answer is correct
				if(input == answer)
				{
					flag = false;
					totalTime += time(0) - startTime;
					totalAttempts += attempts;
					cout << "The question was answered correctly after " << attempts << " attempt(s) and took " << time(0) - startTime << " seconds." << endl;
				}
				
			}while (flag);
			
			//Reset variables
			flag = true;
			attempts = 0;
			startTime = time(0);
			
			counter++;
		}
		else
		{
			num1 = rand() % 10;
			num2 = rand() % 10;
			
			//Generate a multiplication question
			do
			{
				answer = num1 * num2;
				
				cout << num1 << " * " << num2 << endl;
				cin >> input;
				
				attempts++;
				
				//Determine if the answer was correct
				if(input == answer)
				{
					flag = false;
					totalTime += time(0) - startTime;
					totalAttempts += attempts;
					cout << "The question was answered correctly after " << attempts << " attempt(s) and took " << time(0) - startTime << " seconds." << endl;
				}
				
			}while (flag);
			
			//Reset the variables
			flag = true;
			attempts = 0;
			startTime = time(0);
			
			counter++;
		}
	}
	//Calculate the average attempts and time per question
	avgAttempts = totalAttempts / NUMBER_QUESTIONS;
	avgTime = totalTime / NUMBER_QUESTIONS;
	
	// Output the final results
	cout << endl << "The average amount of time for each question was: " << avgTime << endl;
	cout << "The average amount of attempts for each question was: " << avgAttempts << endl;
	
	
	return 0;
}
