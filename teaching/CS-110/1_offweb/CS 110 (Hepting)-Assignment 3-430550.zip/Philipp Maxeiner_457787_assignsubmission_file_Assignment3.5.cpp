//**************************************************************************
//
// Student name: Philipp Maxeiner
//
// Student number: 200343181
//
// Assignment number: 3
//
// Program name: Modified Listing 5.4
//
// Date written: March 11 / 2015
//
// Problem statement: Write a program where the user does a few math problems generated from random numbers
//
// Input: Two random number generated at the beginning of the program, followed by the input of the user
//
// Output: The computer will determine if the calculation done by the user is correct and proceed from there
//
// Algorithm: Write a program that generates two random integers and prompts the user to enter the result of 
// a mathematical formula. If the user is correct, the program proceeds to the next question. If the user is 
// wrong, the program halts until the equation is answered correctly.
//
// Major variables: number1, number2, correctCount, incorrectCount, answer, startTime, endTime, testTime
//
// Assumptions: The computer will only ask 5 different questions, but the number of questions is allowed
// to be much higher than 5
//
// Program limitations: 
//**************************************************************************





#include <iostream>
#include <ctime> // Needed for time function
#include <cstdlib> // Needed for the srand and rand functions
using namespace std;

int main()
{
  int correctCount = 0; // Count the number of correct answers
  int incorrectCount = 0; // Count the number of incorrect answers
  int count = 0; // Count the number of questions
  long startTime = time(0);

  srand(time(0)); // Set a random seed

  while (correctCount < 5)
  {
    // 1. Generate two random single-digit integers
    int number1 = rand() % 10;
    int number2 = rand() % 10;

    // 2. If number1 < number2, swap number1 with number2
    if (number1 < number2)
    {
      int temp = number1;
      number1 = number2;
      number2 = temp;
    }

    // 3. Find a value for the answer
    int answer;
    answer = number1 - number2;   

    // 4. Grade the answer until the question is answered correctly
    do
    {
        cout << "What is " << number1 << " - " << number2 << "? ";
        cin >> answer;
    } while (number1 - number2 != answer);
      
    // 5. Increment correct counter 
    if (number1 - number2 == answer)
      {
        cout << "You are correct!\n";
        correctCount++;
      }
      
    // 6. Increment incorrect counter
   else if (number1 - number2 != answer)
        incorrectCount++;
      
    // Increase the count
    count++;
  }

  long endTime = time(0);
  long testTime = endTime - startTime;

  cout << "Correct count is " << correctCount << "\nTest time is "
       << testTime << " seconds\n";
  cout << "Incorrect count is " << incorrectCount << endl;


  return 0;
}
