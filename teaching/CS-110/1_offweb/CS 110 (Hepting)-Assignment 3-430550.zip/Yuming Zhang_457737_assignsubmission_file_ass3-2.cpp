
///**************************************************************************
//
// Student name: YumingZhang
//
// Student number: 200338416
//
// Assignment number: num3
//
// Program name: quiz
//
// Date written: 11th March 2015
//
// Problem statement: Do 5 random substitution, addition and multiplication questions, the user has infinity time try the correct answer, the program will display the time tried and time takes, also the average value of them.
//
// Input: answer
//
// Output: random substitution, addition and multiplication questions, time tried, time takes, and the average value of that
//
// Algorithm: 

//               Program ask user the correct answer of random substitution, addition and multiplication questions, the count will increment.If the count is lower than 5, the user will continue get questions. cal will produce random number in the range 0-3, and each number will lead the program to display different sign for calculation.
//               And if the answer is not the correctanswer, the program will continue to ask input, and the attempts will continue add up until the user get correct answer.
//			  
//			  
//
// Major variables: correctCount,count,averageAttempts,averageTime, number1, number2
//
// Assumptions: we assume the answer is integer
//
// Program limitations: The user might do same type of question multiple times.
//
//**************************************************************************
#include <iostream>
#include <ctime> 
#include <cstdlib> 
using namespace std;
int main()
{
	int correctCount = 0;
	int count = 5;
	int averageAttempts = 0;
	long averageTime = 0;
	srand(time(0));
	while (count < 5)
	{
		long startTime = time(0);
		int number1 = rand() % 10;
		int number2 = rand() % 10;
		if (number1 < number2)
		{
			int temp = number1;
			number1 = number2;
			number2 = temp;
		}
		cout << "What is " << number1;
		int cal = rand() % 3;
		int correctAnswer;
		if (cal == 0)
		{
			cout << "-";
			correctAnswer = number1 - number2;
		}
		else if (cal == 1)
		{
			cout << "+";
			correctAnswer = number1 + number2;
		}
		else
		{
			cout << "*";
			correctAnswer = number1*number2;
		}
		cout << number2 << "?";
		int answer, attempts = 0;
		do
		{
			cin >> answer;
			attempts++;
			if (correctAnswer == answer)
				cout << "You are correct!\n";
			else
				cout << "Your answer is wrong.\nPlease try again.\n";
		} while (correctAnswer != answer);
		count++;
		long endTime = time(0);
		long testTime = endTime - startTime;
		cout << "You have tried " << attempts << " times.\nYour test time for this question is " << testTime << " seconds.\n\n";
		averageTime += testTime;
		averageAttempts += attempts;
	}
	averageTime /= count;
	averageAttempts /= count;
	cout << "Average number of attempts is " << averageAttempts << "\nAverage test time is "
		<< averageTime << " seconds\n";
	return 0;
}