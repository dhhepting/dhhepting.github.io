/*
name: Lei Nie
student ID: 200304372
assignment number:3.1
program name: computer guess my number
date written: march 7
*/

#include <iostream>
#include <cstdlib>
#include <ctime> 
#include<fstream>
using namespace std;

int main()
{
	int min;
	int max;
	int userguess;
	ofstream output;
	output.open("outputfile.txt");

	cout << "please enter the max number: ";
	cin >> max;
	cout << "please enter the min number: ";
	cin >> min;
	if (max < min)
	{
		int temp = max;
		max = min;
		min = temp;
	}
	cout << "Guess a number between " << min << " and " << max << " ." << endl;
	cout << "please enter your number: ";
	cin >> userguess;

	int guess = 0;
	while (guess != userguess)
	{
		srand(time(0));
		guess = rand() % (max - min + 1)+min;

		if (guess == userguess)
			output << "Yes, the number is " << userguess << endl;
		else if (guess > userguess)
		{
			cout << "computer guess is " << guess << endl;
			cout << "computer guess is too high" << endl;
			max = guess;
		}
		else
		{
			cout << "computer guess is " << guess << endl;
			cout << "computer guess is too low" << endl;
			min = guess;
		}
	} 

	return 0;
}