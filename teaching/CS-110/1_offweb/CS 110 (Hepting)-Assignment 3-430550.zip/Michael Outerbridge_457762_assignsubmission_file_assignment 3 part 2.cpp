/*
Michael Outerbridge
200352016
March 11, 2015
Test
Modify Listing 5.4 so that the user must answer the question correctly before proceeding.
Also, your program should offer addition and multiplication questions (at random).
For each question, print out the number of attempts on the question and the time taken.
At the end of the quiz, print the average number of attempts and the average time taken.
*/

#include <iostream>
#include <ctime> // Needed for time function
#include <cstdlib> // Needed for the srand and rand functions
using namespace std;

int main()
{
	int correctCount = 0; // Count the number of correct answers
	int count = 0; // Count the number of questions
	int counts;
	long startTime = time(0);
	int timed = 0;
	const int NUMBER_OF_QUESTIONS = 5;

	srand(time(0)); // Set a random seed

	while (count < NUMBER_OF_QUESTIONS)
	{

		int number1 = rand() % 10; //numbers 1 and 2 pick the integers to be used in the equations
		int number2 = rand() % 10;
		int number3 = rand() % 3; //number 3 makes the choice of it being +, - or *
		// 2. If number1 < number2, swap number1 with number2
		if (number1 < number2)
		{
			int temp = number1;
			number1 = number2;
			number2 = temp;
		}
		if (number3 == 0)
		{
			counts = 0;
			// 3. Prompt the student to answer �what is number1 � number2?�
			cout << "What is " << number1 << " - " << number2 << "? ";
			int answer;
			cin >> answer;
			while (number1 - number2 != answer)
			{
				cout << "Your answer is wrong. Please try again.\n";
				correctCount++;
				counts++; // counts the number of attempts for the question
				cin >> answer;
			}
			// Increase the count
			cout << "You are correct!\n";
			correctCount++;
			counts++;
			long endTime = time(0);
			long testTime = endTime - startTime; // amount of time taken to do the question
			cout << "This questions time is: " << testTime << endl;
			cout << "There were " << counts << " attempts on this question" << endl;
			timed += testTime;
			startTime = time(0);
			count++;
		}
		else if (number3 == 1)
		{
			counts = 0;
			cout << "What is " << number1 << " + " << number2 << "? ";
			int answer;
			cin >> answer;

			while (number1 + number2 != answer) // loops the question until the correct answer is given
			{
				cout << "Your answer is wrong. Please try again.\n";
				correctCount++;
				counts++;
				cin >> answer;
			}
			cout << "You are correct!\n";
			correctCount++;
			counts++;
			long endTime = time(0);
			long testTime = endTime - startTime;
			cout << "This questions time is: " << testTime << endl;
			cout << "There were " << counts << " attempts on this question" << endl;
			timed += testTime;
			startTime = time(0);
			count++;
		}
		else if (number3 == 2)
		{
			counts = 0;
			cout << "What is " << number1 << " * " << number2 << "? ";
			int answer;
			cin >> answer;
			while (number1 * number2 != answer)
			{
				cout << "Your answer is wrong. Please try again.\n";
				correctCount++;
				counts++;
				cin >> answer;
			}
			cout << "You are correct!\n";
			correctCount++;
			counts++;
			long endTime = time(0);
			long testTime = endTime - startTime;
			cout << "This questions time is: " << testTime << endl;
			cout << "There were " << counts << " attempts on this question" << endl;
			timed += testTime;
			startTime = time(0);
			count++;
		}
	}
	timed /= NUMBER_OF_QUESTIONS; // calculates the average time per question
	correctCount /= NUMBER_OF_QUESTIONS; // calculates the average number of attempts per question
	cout << "The average attempts per question is " << correctCount << "\nThe average question time is "
		<< timed << " seconds\n";

	return 0;
}