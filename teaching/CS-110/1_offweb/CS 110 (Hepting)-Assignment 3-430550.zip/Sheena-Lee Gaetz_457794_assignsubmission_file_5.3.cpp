// 
//**************************************************************************
//
// Student name: Sheena-Lee Gaetz
//
// Student number: 200317727
//
// Assignment number: 3
//
// Program name: 5.3
//
// Date written: March 9, 2015
//
// Problem statement: The user will input a number and the computer will guess what the number is. The program will also
//                    determine if the user is being honest or not.
//
// Input: The user will input the number to be guessed
//
// Output: The computer will output a guess generated randomly.
//
// Algorithm: The user will input a number between 0 and 100 and the cmoputer will generate a random guess. The computer will ask
//			if it is correct or not. If it is incorrect, a binary series is used to eliminate half the numbers each time a guess
//			is incorrect using if statements and a while loop. The program will also determine if the user is being truthful or not.
//
// Major variables: number, guess, higherlimit, lowerlimit
//
// Assumptions: None
//
// Program limitations: None
//
//**************************************************************************

#include <iostream>
#include <cstdlib>
#include <ctime> 
#include <fstream> //used for output stream
#include <string>
using namespace std;
int main()
{
	ofstream outData;
	outData.open("5.3.txt");  //opening output data file
	srand(time(0));
	int number;
	int guess = rand() % 101; //generating a random first guess for the computer
	int newguess;
	int upperlimit;
	int lowerlimit;
	int newlimit = 0;
	string answer;
	string answer1;

	cout << "Please enter a number the computer can guess from 0-100: "; //asking user to input there magic number
	cin >> number;
	outData << number << endl; //recording data in output file

	cout << "I guess the number is: " << guess << endl; //computer making a first guess
	outData << guess << endl;

	cout << "Is this number correct or incorrect? "; //asking the user if the computers guess is right
	cin >> answer;

	if (answer == "incorrect") //this will test if the user is being honest
	{
			upperlimit = 100; //setting our limits
			lowerlimit = 0;

			while (lowerlimit != upperlimit) //beginning a while loop
			{
				newguess = (lowerlimit + upperlimit) / 2; //will change the computers guess when it wrong
				newlimit = (lowerlimit + upperlimit) / 2; //changing limits to test if user is being truthful (reducing numbers available by 1/2)
				cout << "guess again: " << newguess << endl; 
				outData << newguess << endl; //output all the guesses required in an output file 5.3.txt
				
				cout << "Is this guess too high, low, or equal?"; 
				cin >> answer1;
				if (answer1 == "high")
					{
						if (newguess < number || newguess == number)
							cout << "You are being dishonest" << endl;
						else
						upperlimit = newlimit; //changing the upperlimit 
					}
				if (answer1 == "low")
					{
						if (newguess > number || newguess == number)
							cout << "You are being dishonest" << endl;
						
						else
						lowerlimit = newlimit; //changing the lowerlimit
					}

				if (answer1 == "equal")
					{
						if (newguess != number)
							cout << "You are being dishonest" << endl;
						else
						{
							cout << "The number is " << newlimit << endl;
							lowerlimit = upperlimit;//setting lowerlimit = upperlimit will end the loop
						}
					}
					
		} 
		

	}
	if (answer == "incorrect" && number==guess) //Testing if the user is being honest with the computer
	{
		cout << "You are being dishonest!" << endl;
	}
	if (answer == "correct" && number != guess)
	{
		cout << "You are being dishonest!" << endl;
	}
	if (answer == "correct" && number == guess)
	{
		cout << "You are correct!" << endl;
	}

return 0;

}