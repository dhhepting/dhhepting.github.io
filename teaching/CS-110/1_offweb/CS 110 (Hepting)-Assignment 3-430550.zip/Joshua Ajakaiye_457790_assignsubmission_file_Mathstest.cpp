/**************************************************************************************
Student Name: Joshua Ajakaiye
Student Number: 200348270
Assignment Number: 3
program Name: Mathstest
Date Written: 3/11/2015
problem statement: program offers addition multiplication and subtraction questions at
                   random, also required to print out the number of attempts on the 
				   question and the time taken. 
input: answer
output: time taken, amount of trials on a question.
Algorithm: use srand function too generate two random integers, swap them if the order
           is wrong. select a question at random a multiplication , an addition or a
		   subtraction one use a switch statement.
Major Variables: correctcount, count, startTime, NUMBER_OF_QUESTIONS, correct_answer,
                 number1, number2, endTime, testTime
assumptions: it will randomly select a question
limitations: can only do multiplication, addition and subtraction questions.
**************************************************************************************/
#include <iostream>
#include <ctime> // Needed for time function
#include <cstdlib> // Needed for the srand and rand functions
#include<string>
using namespace std;

int main()
{
	int correctCount = 0; // Count the number of correct answers
	int count = 0; // Count the number of questions
	long startTime = time(0);
	const int NUMBER_OF_QUESTIONS = 5;
	double correct_answer = 0;

	srand(time(0)); // Set a random seed

	while (count < NUMBER_OF_QUESTIONS)
	{
		// 1. Generate two random single-digit integers
		int number1 = rand() % 10;
		int number2 = rand() % 10;

		// 2. If number1 < number2, swap number1 with number2
		if (number1 < number2)
		{
			int temp = number1;
			number1 = number2;
			number2 = temp;
		}

		

		cout << "please choose the kind of math question you want:\n";
		cout << "type subtraction, addition or multiplication\n";
		


			// subtraction selected
			cout << "What is" << number1 << " - " << number2 << " ? ";
			correct_answer = number1 - number2;
	
			
			// addition selected
			cout << "What is" << number1 << " + " << number2 << " ? ";
			correct_answer = number1 + number2;
			
				
			// multiplication selected
			cout << "What is" << number1 << " * " << number2 << " ? ";
			correct_answer = number1 * number2;
				
				

		int answer;
		cin >> answer;

		// while statement
		while (answer != correct_answer)
		{

			if (answer == number1 - number2)
			{
				if (answer == number1 + number2)
				{
					if (answer == number1*number2)
					{
						cout << "You are correct!\n";
						correctCount++;
					}

					else
					{
						cout << "Your answer is wrong.\n" << endl;
						cout << "try again.";
					}

					

					long endTime = time(0);
					long testTime = endTime - startTime;

					cout << "the number of attempts is: " << correctCount << "\nTime taken is: ";
					cout << testTime << " seconds\n";

					// Increase the count
					count++;
				}

				long endTime = time(0);
				long testTime = endTime - startTime;

				cout << "Correct count is " << correctCount << "\nTest time is ";
				cout << testTime << " seconds\n";

				return 0;
			}
		}
	}
}