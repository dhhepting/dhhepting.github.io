//**************************************************************************
//
// Student name: Brayden Tang
//
// Student number: 200350623
//
// Assignment number: 3, Part 2 
//
// Program name: Subtraction/Addition/Multiplication Quiz for Values From 0 to 9
//
// Date written: March 9, 2015
//
// Problem statement: Modify Listing 5.4 so that the user must answer the question correctly before proceeding. Also, your program should offer addition and multiplication questions (at random). For each question, print out the number of attempts on the question and the time taken. At the end of the quiz, print the average number of attempts and the average time taken.
//
// Input: The answer to a random addition, subtraction, or multiplication question with digits ranging from 0 to 9.
//
// Output: The time taken for a specific question, the number of tries on a specific question, if the user was wrong or not in the addition/subtraction/multiplication, the average number of attempts per question, and the average time taken per question.
//
// Algorithm: Algorithm relies on various functions, most notably the rand() and time() functions to generate random numbers and also to generate values from 0-2 to randomly pick an addition, subtraction, or multiplication question. Loops are also used to force the user into getting the question right before moving on to the next question.
//
// Major variables: count, startTime, testTIME, endTIME, answer, NUMBER_OF_QUESTIONS, numberOFtriesSUBTRACTION, numberOFtriesADDITION, numberOFtriesMULTIPLICATION, subtractionTIME, subtractionTIMEend, additionTIME, additionTIMEend, multiplicationTIME, multiplicationTIMEend
//
// Assumptions: That the user will enter an interger and not some random character when they attempt to answer the random question. If they type in a random character like 'a' the program will enter an infinite loop.
//
// Program limitations: If the user enters a random character like 'a' for the answer to the question, the program enters an infinite loop and essentially becomes useless.
//
//**************************************************************************

#include <iostream>
#include <cstdlib>  //for srand function
#include <ctime>     //for the time function
using namespace std;
int main()

{
	int total_attempts = 0;  //initialize total_attempts to be at zero
	int count = 0;      //initialize count at 0 so the loop is entered
	long startTime = time(0);   //get the starting time for the overall test
	const int NUMBER_OF_QUESTIONS = 5;   //after five questions the loop will terminate
	int answer;
	long subtractionTIME;               //various declarations for the time functions of specific questions
	long subtractionTIMEend;
	long additionTIME;
	long additionTIMEend;
	long multiplicationTIME;
	long multiplicationTIMEend;

	srand(time(0));

	while (count < NUMBER_OF_QUESTIONS)
	{
		int numberOFtriesSUBTRACTION = 1;  //there will at least be one attempt when doing a question, also placed at the beginning of the loop to reset the counter each time the loop is ran
		int numberOFtriesADDITION = 1;
		int numberOFtriesMULTIPLICATION = 1;
		int number1 = rand() % 10;          //generates two random values in the range of 0 to 9
		int number2 = rand() % 10;
		int addition_subtration_multiplication = rand() % 3;  //generates a random value from 0-2 to randomly "select" a multiplication, subtraction, or addition question.

		if (number1 < number2)              //switches values, only matters for subtraction. For addition and multiplication it makes no difference.
		{
			int temp = number1;
			number1 = number2;
			number2 = temp;
		}



		if (addition_subtration_multiplication == 0)  //choose subtraction 
		{
			total_attempts++;
			subtractionTIME = time(0);  //get the time before this question is completed
			cout << "What is " << number1 << " - " << number2 << "?" << endl;
			cin >> answer;
			if (number1 - number2 == answer)    //if the user in one attempt gets the question correct, this is displayed.
			{
				subtractionTIMEend = time(0);  //get the time after this question has been completed
				cout << "You are correct!" << endl;
				cout << "The number of tries for this question was: " << numberOFtriesSUBTRACTION << endl;
				cout << "The time taken for this question was: " << subtractionTIMEend - subtractionTIME << " second(s)." << endl;  //the difference between the starting and ending times should be the time taken for the specific question
				count++;  //count is increased by one 
			}
			while (number1 - number2 != answer)  //if the user fails to answer the question correctly, they enter this loop. 
			{
				total_attempts++;  //increase total attempts by one everytime this loop is repeated
				numberOFtriesSUBTRACTION++;   //the number of tries for this question is increased by one everytime this loop is repeated
				cout << "You are wrong. Try again. What is " << number1 << "-" << number2 << "?" << endl;  //display to the user they are wrong
				cin >> answer;
				if (number1 - number2 == answer)     //if they get the answer correct after entering this loop, this will be displayed. They will then exit this loop but reenter the main loop if count is less than five.
				{
					subtractionTIMEend = time(0);
					cout << "You are correct!" << endl;
					cout << "The number of tries for this question was: " << numberOFtriesSUBTRACTION << endl;
					cout << "The time taken for this question was: " << subtractionTIMEend - subtractionTIME << " second(s)." << endl;
					count++;  //count is increased by one
				}
			}

		}
		else if (addition_subtration_multiplication == 1) //choose addition, the code for this is the same thing as the above if statement excpet this involves addition instead rather than subtraction.
		{
			total_attempts++;
			additionTIME = time(0);
			cout << "What is " << number1 << " + " << number2 << "?" << endl;
			cin >> answer;

			if (number1 + number2 == answer)
			{
				additionTIMEend = time(0);
				cout << "You are correct!" << endl;
				cout << "The number of tries for this question was: " << numberOFtriesADDITION << endl;
				cout << "The time taken for this question was " << additionTIMEend - additionTIME << " second(s)." << endl;
				count++;
			}
			while (number1 + number2 != answer)
			{
				total_attempts++;
				numberOFtriesADDITION++;
				cout << "You are wrong. Try again. What is " << number1 << " + " << number2 << "?" << endl;
				cin >> answer;
				if (number1 + number2 == answer)
				{
					additionTIMEend = time(0);
					cout << "You are correct!" << endl;
					cout << "The number of tries for this question was: " << numberOFtriesADDITION << endl;
					cout << "The time taken for this question was " << additionTIMEend - additionTIME << " second(s). " << endl;
					count++;
				}
			}
		}
		else if (addition_subtration_multiplication == 2) //choose multiplication, again this is the same thing as above except with multiplication instead
		{
			total_attempts++;
			multiplicationTIME = time(0);
			cout << "What is " << number1 << " x " << number2 << "?" << endl;
			cin >> answer;

			if (number1 * number2 == answer)
			{
				multiplicationTIMEend = time(0);
				cout << "You are correct!" << endl;
				cout << "The number of tries for this question was: " << numberOFtriesMULTIPLICATION << endl;
				cout << "The time taken for this question was " << multiplicationTIMEend - multiplicationTIME << " second(s)." << endl;
				count++;
			}
			while (number1 * number2 != answer)
			{
				total_attempts++;
				numberOFtriesMULTIPLICATION++;
				cout << "You are wrong. Try again. What is " << number1 << " x " << number2 << "?" << endl;
				cin >> answer;
				if (number1 * number2 == answer)
				{
					multiplicationTIMEend = time(0);
					cout << "You are correct!" << endl;
					cout << "The number of tries for this question was: " << numberOFtriesMULTIPLICATION << endl;
					cout << "The time taken for this question was " << multiplicationTIMEend - multiplicationTIME << " second(s). " << endl;
					count++;
				}
			}
		}
	}

	long endTIME = time(0);     //obtain the ending time after the quiz is completed
	long testTIME = endTIME - startTime;  //obtain the time taken for the quiz to be completed by subtracting the time at the end from the time at the beginning
	
	cout << "End of the quiz!" << endl;
	cout << "Average number of attempts per question was: " << total_attempts / 5 << endl;  //average number of attempts per question is simply the number of tries for each question added together divided by the number of questions given
	cout << "Average time taken per question was " << testTIME / 5.0 << " second(s). " << endl;  //the total time taken for the test to be completed divided by the number of questions should give the average time taken per question

	return 0;



}