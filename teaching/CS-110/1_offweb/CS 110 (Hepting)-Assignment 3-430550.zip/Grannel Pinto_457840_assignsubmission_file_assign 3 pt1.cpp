/*

 problem statement, input, output, algorithm, major variables, assumptions, and program limitations) and inline documentation.
Grannel Pinto
200351222
Assignment #3
Microsoft Visual Studio 
2015-03-11
This program will tell you to pick a number between 0 and 100, the program will guess on a output txt file what your number is and it will tell you how many tries it took.
The numbers it chooses is totally random.

*/


#include <iostream>
#include <cstdlib>
#include <ctime>
#include <fstream>

using namespace std;

int main()
{
	// Randomize numbers
	srand(time(0));
	
	int userNumber = -1;
	int guess;
	int numberOfGuesses = 0;

	ofstream outData;
	outData.open("guesses.txt");

	do
	{
		cout << "Please enter a number between 0 and 100: ";
		cin >> userNumber;
	} while (userNumber < 0 || userNumber > 100);

	do
	{
		guess = rand() % 101;

		outData << guess << endl; 

		numberOfGuesses++;
	} while (guess != userNumber);

	cout << "The number of guesses it took were " << numberOfGuesses << endl; 

	return 0;
}	