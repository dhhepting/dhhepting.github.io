//Ian Cowan
//Student ID 200229343
//Dr. Daryl Hepting's CS 110 Assignment 3, part 2 - Modify Listing 5.4 
//(http://www.cs.armstrong.edu/liang/cpp3e/html/SubtractionQuizLoop.html)
//so that the user must answer the question correctly before proceeding. Also, your program should offer addition and 
//multiplication questions (at random). For each question, print out the number of attempts on the question and the time 
//taken. At the end of the quiz, print the average number of attempts and the average time taken.

#include <iostream>
#include <ctime> // Needed for time function
#include <cstdlib> // Needed for the srand and rand functions
using namespace std;

int main()
{
  int correctCount = 0; // Count the number of correct answers
  int qattemptCount = 0;
  int totalattemptCount = 0;
  long startTime = time(0);
  const int NUMBER_OF_QUESTIONS = 5;

  srand(time(0)); // Set a random seed

  while (correctCount < NUMBER_OF_QUESTIONS)    //REDEFINED TO COUNT /CORRECT/ QUESTIONS
  {
    // 1. Generate three random single-digit integers
    int number1 = rand() % 10;
    int number2 = rand() % 10;
    int operation = rand() % 3;   // The third random integer determines whether the question will be subtraction, addition, or multiplication.
    long qTime = 0;
    long qstartTime = time(0);
    // 2. If number1 < number2, swap number1 with number2
    if (number1 < number2)
    {
      int temp = number1;
      number1 = number2;
      number2 = temp;
    }
    
    if (operation == 0)         //if operation = subtraction
    {
        // 3sub. Prompt the student to answer �What is number1 � number2?�
        cout << "What is " << number1 << " - " << number2 << "? ";
        int answer;
        cin >> answer;
        
        // 4sub. Grade the answer and display the result
        if (number1 - number2 == answer)            //if student answers correctly
        {
            qattemptCount = 0;
            long qendTime = time(0);
            qTime = qendTime - qstartTime;
            cout << "You are correct!\n";
            correctCount++;
            qattemptCount++;
            totalattemptCount++;
            
            cout << "The question took you " << qattemptCount << " attempts over " << qTime 
            << " seconds." << endl;
        }
        else                                        //if student answers falsely
        {
            cout << "Your answer is wrong. Please try again.\n" << endl;   

            // Increase the count
            qattemptCount++;
            totalattemptCount++;
        }
    }
    else    //if operation != subtraction)
    {
        if (operation == 1)     //if operation = additon
        {   
            // 3add. Prompt the student to answer "What is number1 + number2?"
            cout << "What is " << number1 << " + " << number2 << "? ";
            int answer;
            cin >> answer;
            
            // 4add. Grade the answer and display the result
            if (number1 + number2 == answer) 
            {
                long qendTime = time(0);
                qTime += qendTime - qstartTime;
                cout << "You are correct!\n";
                correctCount++;
                qattemptCount++;
                totalattemptCount++;
                
                cout << "The question took you " << qattemptCount << " attempts over " << qTime 
                << " seconds." << endl;
            }
            else
            {
                cout << "Your answer is wrong.\n" << "Please try again." << endl;
            
                // Increase the count
                qattemptCount++;
                totalattemptCount++;
            }
        }
        else        //if operation != subtraction, addition
        {
            if (operation == 2)         //if operation = multiplication
            {       
                // 3mlt. Prompt the student to answer "What is number1 * number2?"
                cout << "What is " << number1 << " x " << number2 << "? ";
                int answer;
                cin >> answer;
                
                // 4mlt. Grade the answer and display the result
                if (number1 * number2 == answer) 
                {
                    long qendTime = time(0);
                    qTime += qendTime - qstartTime;
                    cout << "You are correct!\n";
                    correctCount++;
                    qattemptCount++;
                    totalattemptCount++;
                    
                    cout << "The question took you " << qattemptCount << " attempts over " << qTime 
                    << " seconds." << endl;
                }
                else
                {
                    cout << "Your answer is wrong.\n" << "Please try again." << endl;
                
                    // Increase the count
                    qattemptCount++;
                    totalattemptCount++;
                }
            }
            else
            {
                cout << "Failure in RNG part of program." << endl;
            }
        }
    }    
    
  }

  long endTime = time(0);                       
  long testTime = endTime - startTime;
  cout << "You've answered " << correctCount << " questions correctly in " <<  totalattemptCount << " attempts over " << testTime << " seconds.\n";

  return 0;
}
