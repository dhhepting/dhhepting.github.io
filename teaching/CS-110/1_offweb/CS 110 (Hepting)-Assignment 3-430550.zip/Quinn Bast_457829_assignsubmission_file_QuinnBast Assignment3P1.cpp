/*
Quinn Bast
200352973
Assignment 3 Part 1

Computer guesses a user inputted number. (even thought it can easily take the number from the variable)
Algorithm: using rand() and a set of boundaries to redefine what range the computer should guess between.
*/

#include <iostream>
#include <cstdlib>
#include <fstream> //used for the file output
#include <iomanip> //used for line spacing
#include <ctime> // Needed for the time function
using namespace std;

int main()
{
 srand(time(0)); //seeds the time
 int number;
  cout << "Enter a magic number between 0 and 100.\n";
 cin >> number; //the number for the computer to guess

int guess; //computer's guess
char response;
 

ofstream(out); //initiates the file output as 'out'
out.open("output.txt"); //initiates the file
out << "The user input: " << number << "\n";  // outputs the user's number to the file.

int bound = 100; //sets the bounds of how many numbers to guess
int minimum = 0; //minimum bound to guess
int maximum = 100; //maximum bound to guess
bool liar = false; //is the user a liar?
do
 {
guess = (rand() % (bound + 1)) + minimum; //random number within the bounds so it is logical from the last guesses.

cout << setw(30) <<"Is " << guess << " your number?\n\n     h - Too high.\n     l - Too low.\n                             ";
if (guess != number) // prevents asking for a user input if correct number is guessed.
{   
liar = false; 
cin >> response;

out << "\n[Computer]:" << guess << "\n"; //putput the response
out << "[User]: " << response << "\n"; //outputs the response

//tell the user they are lying if they lied:
if (guess < number && response != 'l' )
	{
cout << "                             You lied to me." << endl;
liar = true;
out << "USER LIED!";
	}
if (guess > number && response != 'h' )
	{
cout << "                             You lied to me." << endl;
liar = true;
out << "The user lied!\n";
	}




}

// update the bounds of the random number generator
if (guess > number)
	{
	maximum = (guess -1); //-1 because it shouldnt guess the number it just guessed twice
	bound = maximum - minimum; //bound for the random
	}
if (guess < number)
	{
	minimum = (guess+1); //+1 because it shouldn't guess the same number twice.
	bound = maximum - minimum; //bound for the random.
	}
}
while (guess != number); //end of loop

out << "\nThe computer guessed the correct number, " << guess; //output corret guess.
return 0;
}