// Kian Blanchette
// 200354600
// Assignment #3
// TauntingTheComputer.cpp
// 10 March 2015
// Problem Statement: Write a program that has the user enter a number between 0 and 100 and have the computer conduct a binary search to guess the user's number
//					  and then write the number and the guesses to a file.
// Input: The user's number
// Output: The computer's guesses and the user's number are output to the screen and also written to a file.
// Algorithm: Initialize the limits at 0 and 100 first. Then the user enters her number and the number is written to the file output.txt. The computer is asked to
//			  guess and its guess is initialized at 50. Enter a loop that will run through every integer on [0,100] if need be. Inside the loop, check using
//            a global function how the computer's guess relates to the user's number and continue until either the user's number is found or all the integers
//			  on [0,100] have been eliminated. If all the integers are eliminated and the user's number is not found, the user lied and entered a number not on the 
//			  interval.
// Major Variables: upperLimit - The highest possible number on the interval
//				    lowerLimit - The lowest possible number on the interval
//                  number - The user's number
//				    guess - The computer's guess(es)
//				    response - The string returned by the global function checkGuess that determines how the loop progresses
//				    outData - The thing that writes the number and the guesses to the file output.txt
// Assumptions: This program assumes the user has entered an integer value.
// Program Limitations: The program runs the loop from start to finish and displays all output at once instead of having the user respond personally
//						after each guess.
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

string checkGuess(int, int); //Prototype function to check if the guess is correct
int main()
{
	int upperLimit = 100; //This program will check integers on the interval [0,100]
	int lowerLimit = 0;

	int number;
	cout << "Enter an integer between 0 and 100: "; 
	cin >> number;									//The user enters the number for the computer to guess

	ofstream outData;
	outData.open("output.txt");
	outData << "number: " << number << endl; //Write the user's number to a file
	
	cout << "Guess my number, fool." << endl;
	int guess = (upperLimit + lowerLimit) / 2; //Set the guess to be the middle of the interval
	cout << guess << endl;

	while (upperLimit - lowerLimit >= 0) //Loop until user's number is found or the user is found to be dishonest
	{
		
		string response = checkGuess(guess, number); //Depending on the relationship between the guess and the user's number, this function returns a string
		if (response == "Yes") //If this statement evaluates true, the computer has guessed the number and the program ends
		{
			cout << "Yes. That's my number. Pretty good for a mindless machine." << endl;
			return 0;
		}
		else if (response == "Too high") //However, if the computer is incorrect and this statement evaluates true, the interval changes by replacing the
		{								 //old upper limit with the number below the prior guess. It then evaluates its next guess by taking the midpoint of 
			upperLimit = guess - 1;		 //this new interval.
			guess = (upperLimit + lowerLimit) / 2;
			cout << "Too high. Guess again, chump. \n";
			cout << guess << endl;
			outData << guess << endl;
		}
		else if (response == "Too low") //Likewise, if the computer is incorrect and this statement evaluates true, the interval changes by replacing the
		{								//old lower limit with the number above the prior guess. It then evaluates its next guess by taking the midpoint of
			lowerLimit = guess + 1;		//this new interval.
			guess = (upperLimit + lowerLimit) / 2;
			cout << "Too low. Guess again, turd. \n";
			cout << guess << endl;
			outData << guess << endl;
		}
	}

	cout << "YOU DECEIVED ME! HUMANS CANNOT BE TRUSTED SO THEY MUST BE EXTERMINATED!" << endl; //If the user picked a number not on the interval [0,100],
	return 0;																				   //the program exits the loop and displays this message.
}
string checkGuess(int g, int num) //This function checks whether or not the guess equals the user's number and returns a string back to main
{
	if (g == num)
		return "Yes";
	else if (g > num)
		return "Too high";
	else return "Too low";

}