//**************************************************************************
//
// Student name: Stephanie Thompson	
//
// Student number: 200355041
//
// Assignment number: Assignment 3 - Part 2
//
// Program name: Math Quiz
//
// Date written: March 10, 2015
//
// Problem statement: The user needs to answers 5 math questions and get each question right, knowing the number of attempts and how long the question took them to do,
//						before proceeding to the next question.  
//
// Input: The user will input values as answers to the questions that are randomly generated.
//
// Output: The program will randomly output a total of five different questions, including subtraction, addition, or multiplication.  The program will tell the user if their answer
//			is wrong and repeat the same output until the answer is right.  Once the answer is correct the program will tell the user how many times the question was attempted 
//			and how long they took to answer the question.  At the end of the quiz, the program will display the average number of attempts per question and the average time taken 
//			per question.
//
// Algorithm: The program will generate a random number whose remainder will determine the question type, subtraction, addition, or multiplication.  The user will be asked a
//				math question based on two numbers, also randomly generated.  This question must be answered correctly before the program will proceed to give another question.  The
//				loop will continue asking questions until it has asked and the user has answered 5 correct questions.  Once each question has been answered correctly the program
//				will calculate and display the number of attempts by the user and how long the question took the user to do.  After the quiz is done the average number of attempts
//				per question (as an integer number) and the average time per question (in seconds) will be calculated for the user to view.
//
// Major variables: Major variables include correctcount, number1, number2, typeofquestion, answer, subtraction count, addition count, multiplication count, averagequestioncount,
//					 totalquestioncount, averagetime, and totaltime.
//
// Assumptions: The program operates under the assumption that the user will not want to quit the quiz at any time and the user will eventually get the right answer for all questions.
//
// Program limitations: The program can only do subtraction, addition, or multiplication questions involving numbers between 0 and 9.
//
//**************************************************************************
#include <iostream>
#include <ctime> // Needed for time function
#include <cstdlib> // Needed for the srand and rand functions
using namespace std;

int main()
{
	// Decleration of variables
	int correctcount = 0;
	const int NUMBER_OF_QUESTIONS = 5;
	int number1;
	int number2;
	int typeofquestion;
	int answer;
	int subtractioncount = 0;
	int totalsubtractioncount = 0;
	int additioncount = 0;
	int totaladditioncount = 0;
	int multiplicationcount = 0;
	int totalmultiplicationcount = 0;
	int averagequestioncount = 0;
	int totalquestioncount = 0;
	long totalsubractiontime = 0;
	long totaladditiontime = 0;
	long totalmultiplicationtime = 0;
	long totaltime = 0;
	long averagetime = 0;

	srand(time(0)); // Set a random seed

	// Creates a loop that runs for five correct answers to given question
	while (correctcount < NUMBER_OF_QUESTIONS)
	{
		typeofquestion = rand() % 4; // Generates a random number for a type of question

		if (typeofquestion == 1)
		{	
			long subtractionstarttime = time(0);
			subtractioncount = 1;
			number1 = rand() % 10;
			number2 = rand() % 10;
			if (number1 < number2) // Switches numbers if number1 is smaller than number2
			{
				int temp = number1;
				number1 = number2;
				number2 = temp;
			}	
			// Prompts user for input
			cout << "What is " << number1 << " - " << number2 << "? ";
			cin >> answer;
			while (number1 - number2 != answer) // Tests value of the user's answer
			{
				cout << "Your answer is wrong. Try again." << endl;
				cout << "What is " << number1 << " - " << number2 << "? ";
				cin >> answer;
				subtractioncount++;
			}

			long subtractionendtime = time(0);
			long subtractiontotaltime = subtractionendtime - subtractionstarttime;

			// Displays users number of attempts and time taken
			cout << "You are correct! You tried this question " << subtractioncount << " time(s) for a total of " << subtractiontotaltime << " seconds." << endl;
			correctcount++;
			totalsubtractioncount += subtractioncount;
			totalsubractiontime += subtractiontotaltime;
		}
		if (typeofquestion == 2)
		{
			long additionstarttime = time(0);
			additioncount = 1;
			number1 = rand() % 10;
			number2 = rand() % 10;

			// Prompts user for input
			cout << "What is " << number1 << " + " << number2 << "? ";
			cin >> answer;
			while (number1 + number2 != answer) // Tests the value of the user's input
			{
				cout << "Your answer is wrong. Try again." << endl;
				cout << "What is " << number1 << " + " << number2 << "? ";
				cin >> answer;
				additioncount++;
			}

			long additionendtime = time(0);
			long additiontotaltime = additionendtime - additionstarttime;

			// Displays the number of attempts and total time taken for the question
			cout << "You are correct! You tried this question " << additioncount << " time(s) for a total of " << additiontotaltime << " seconds." << endl;
			correctcount++;
			totaladditioncount += additioncount;
			totaladditiontime += additiontotaltime;
		}
		if (typeofquestion == 3)
		{
			long multiplicationstarttime = time(0);
			multiplicationcount = 1;
			number1 = rand() % 10;
			number2 = rand() % 10;
			// Prompts the user for input
			cout << "What is " << number1 << " * " << number2 << "? ";
			cin >> answer;
			while (number1 * number2 != answer) // Tests the user's input
			{
				cout << "Your answer is wrong. Try again." << endl;
				cout << "What is " << number1 << " * " << number2 << "? ";
				cin >> answer;
				multiplicationcount++;
			}

			long multiplicationendtime = time(0);
			long multiplicationtotaltime = multiplicationendtime - multiplicationstarttime;

			// Displays the number of attempts and the time taken for the question
			cout << "You are correct! You tried this question " << multiplicationcount << " time(s) for a total of " << multiplicationtotaltime << " seconds." << endl;
			correctcount++;
			totalmultiplicationcount += multiplicationcount;
			totalmultiplicationtime += multiplicationtotaltime;
		}
	}

	// Calculates the average amount of attempts per question
	totalquestioncount = totalsubtractioncount + totaladditioncount + totalmultiplicationcount;
	averagequestioncount = totalquestioncount / 5;

	// Calculates the average amount of time per question
	totaltime = totalsubractiontime + totaladditiontime + totalmultiplicationtime;
	averagetime = totaltime / 5;

	// Displays the average attempts and time taken per question
	cout << "The average number of attempts per question was " << averagequestioncount << " and the average time per question was " << averagetime << "." << endl;

	return 0;
}