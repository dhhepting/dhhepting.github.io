/**********************************************************************************************
*	Student Name:			Mohammed Alghadhban
*	Student Number:			200318904
*	Assignment Number:		3.2
*	Program Name:			Assignment3.2
*	Date Written:			March 11, 2015
*
*	Problem Statement:		The program should generate random math problems (addition,
*							subtraction and multiplication) and check if the user enters
*							the correct answers. To progress to the next question the
*							user must answer the current question correctly. The time
*							taken to answer each question, the number of attempts, the
*							average number of attempts and the total time taken to 
*							complete the quiz should all be recorder and displayed to the
*							user.
*
*	Input:					User's response to each question
*
*	Output:					Response to user's answer (correct/incorrect)
*							Number of attempts for each question
*							Time taken the answer each question
*							Total number of correct answers
*							Total number of incorrect answers
*							Average number of attempts per question
*							Total time taken to solve the quiz
*							Average time per question
*
*	Algorithm:				The program will randomly generate math questions of the form:
							(a . b) where a and b are randomly generated integers between 
							0 and 9 and . is an a randomly generated arithmetical operator 
							which can be +,- or x. This program uses nested while loops to
							generate a variable number of questions and to make sure the user
							can only progress when a question can be answered correctly.
							There number of attempts per question, correct answers and
							incorrect answers are kept as counters.
*
*	Major variables:		incorrectCount:
*								Counts the number of incorrect answers
*							attempts:
*								Counts the number of attempts per question
*							qStartTime, qEndTime
*								start and end times for each question
*
*	Assumptions:			none
*
*	Program limitations:	none
*
**********************************************************************************************/

#include <iostream>
#include <ctime> // Needed for time function
#include <cstdlib> // Needed for the srand and rand functions
using namespace std;

int main()
{
	int correctCount = 0; // Count the number of correct answers
	int incorrectCount = 0; // Count the number of incorrect answers
	int count = 0; // Count the number of questions
	long startTime = time(0);
	const int NUMBER_OF_QUESTIONS = 5;

	srand(time(0)); // Set a random seed

	while (count < NUMBER_OF_QUESTIONS)
	{
		// 1. Generate two random single-digit integers
		int number1 = rand() % 10;
		int number2 = rand() % 10;

		// 2. Generate a third random single-digit integer (0-2)
		int questionType = rand() % 3;

		// 3. If number1 < number2, swap number1 with number2
		if (number1 < number2)
		{
			int temp = number1;
			number1 = number2;
			number2 = temp;
		}

		int attempts = 0; // Count the number of attempts
		long qStartTime = time(0); // Start time for the question

		// 4. Infinte loop, will stop when the user enters the correct answer
		while (true)
		{
			int correctAnswer; // variable to hold the correct answer

			if (questionType == 0) // Subtraction question if questionType equals 0
			{
				// 5. Prompt the student to answer �what is number1 � number2?�
				cout << "What is " << number1 << " - " << number2 << "? ";

				// 6. Compute the correct answer
				correctAnswer = number1 - number2;
			}

			else if (questionType == 1) // Addition question if questionType equals 1
			{
				// 5. Prompt the student to answer �what is number1 + number2?�
				cout << "What is " << number1 << " + " << number2 << "? ";

				// 6. Compute the correct answer
				correctAnswer = number1 + number2;
			}

			else // Multiplication question if questionType equals 2
			{
				// 5. Prompt the student to answer �what is number1 * number2?�
				cout << "What is " << number1 << " x " << number2 << "? ";

				// 6. Compute the correct answer
				correctAnswer = number1 * number2;
			}

			int answer;
			cin >> answer;	// Get answer from the user

			// 7. Grade the answer and display the result
			if (answer == correctAnswer)
			{
				attempts++; // Increase the attempt count
				long qEndTime = time(0); // End time for the question
				cout << "You are correct!\n";
				cout << "Attempts: " << attempts << endl;
				cout << "Time: " << qEndTime - qStartTime << " seconds\n" << endl;
				correctCount++;
				break;
			}

			else
			{
				cout << "Your answer is wrong.\n" << endl;
				cout << "Try again" << endl;
				attempts++;	 // Increase the attempt count
				incorrectCount++;  // Increase the incorrect count
			}
		}

		// Increase the count
		count++;
	}

	long endTime = time(0);
	long testTime = endTime - startTime;

	// Display all the relevent stats
	cout << "Correct count: " << correctCount << endl;
	cout << "Incorrect count: " << incorrectCount << endl;
	cout << "Average attempts: " << static_cast<double>(correctCount + incorrectCount) / NUMBER_OF_QUESTIONS << endl;
	cout << "Total time: " << testTime << " seconds" << endl;
	cout << "Average time: " << static_cast<double>(testTime) / NUMBER_OF_QUESTIONS << " seconds" << endl;

	return 0;
}