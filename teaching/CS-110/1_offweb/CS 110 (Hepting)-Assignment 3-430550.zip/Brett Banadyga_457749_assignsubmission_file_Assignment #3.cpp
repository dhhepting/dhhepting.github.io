/*
Name: Brett Banadyga
Student #: 200318551
Assignment #3
Random Number Guesser
Date Written: March 11, 2015
Problem statement: Modify the program so that the computer guesses a number that the user provides. 
Input: User inputs if guess is high or low.
Output: Computer guesses random numbers. 

*/

#include <iostream>
#include <string> // Uses string for user input
using namespace std;

int main()

{
	int guess;
	int highestPossible = 100;
	int lowestPossible = 0;
	int average;
	string userinput;
	int count = 0;

	cout << "Please pick a number between 0-100, if guess is too high then tell computer its to high by saying 'high' if guess is to low then tell computer its to low by saying 'low' if guess is correct then tell computer its correct by saying 'correct'" << endl;

	guess = -1;
	while (userinput != "correct")

	{

		guess = (highestPossible + lowestPossible) / 2;
		cout << "Computer guess is: " << guess << endl; // Shows the first guess the computer makes
		cin >> userinput;

		// Different if statements based on the input the user gives

		if (userinput == "high")
		{

			cout << "guess is too high" << endl;
			highestPossible = guess - 1;

		}

		if (userinput == "low")
		{

			cout << "guess is too low" << endl;
			lowestPossible = guess + 1;

		}

		if (userinput == "correct")
		{
			cout << "Thanks for playing this great game!" << endl;

		}

		if (lowestPossible == highestPossible && userinput != "correct")
		{

			count += 1;

		}

		if (count == 2 || highestPossible < lowestPossible || lowestPossible > highestPossible)

		{

			cout << "I think you are lying to me" << endl; // Statement that will appear if the user has lied and the computer has already guessed the number
			userinput == "correct";
			return 0;
		}	
	}
	// End program
	return 0;
}