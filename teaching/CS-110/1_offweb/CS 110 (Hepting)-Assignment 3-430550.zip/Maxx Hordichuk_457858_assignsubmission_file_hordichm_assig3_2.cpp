// Name: Maxx Hordichuk
// Student #: 200353849
// Assignment: 3.2
// Program Name: Math Tester
// Date: 03/11/15
/* Problem statement: Modify Listing 5.4 so that the user must answer the question correctly before proceeding. Also, your
program should offer addition and multiplication questions (at random). For each question, print out the number of attempts
on the question and the time taken. At the end of the quiz, print the average number of attempts and the average time taken. */
//Input: Answers to problems.
// Output: Randomized addition, subtraction, and multiplication problems.
/* Algorithm: Generate two random numbers -> if statements with modulus to randomly decide between addition, subtraction, and multiplication ->
Take user input for questions and evaluate if input is correct or not -> Repeat for 10 questions -> and then print out average time taken,
number of correct answers, and number of attempts. */
// Variables: number1, number2, number3, correctCount, incorrectCount, count, totalQuestions, 
// Assumptions: User will only enter numbers and not letters. Ex) 3 vs "three"
// Program limitations: Only displays average time taken to the nearest second. Cannot compute "lettered numbers".

#include <iostream>
#include <ctime> // Required for time function.
#include <cstdlib> // Required for srand and rand functions.
using namespace std;

int main()
{
	int correctCount = 0; // Counts the number of correct answers.
	int count = 0; // Counts the number of questions in total.
	long startTime = time(0);
	const int totalQuestions = 10;
	int incorrectCount = 0;
	int answer = 500;
	srand(time(0)); // Sets a random seed.

	while (count < totalQuestions)
	{

		// Generate two random single-digit integers.

		int number1 = rand() % 10;
		int number2 = rand() % 10;
		int number3 = rand() % 3;

		int incorrect1 = 1;
		int incorrect2 = 1;
		int incorrect0 = 1;

		// When number3 = 1, give subtraction question

		if (number3 == 1)
		{
			// If number1 < number2, swap number1 with number2

			if (number1 < number2)
			{
				int temp = number1;
				number1 = number2;
				number2 = temp;
			}
			
			// Prompt to answer for number1 � number2 and evaluate if right or wrong.
			
			while (number1 - number2 != answer)
			{
				
				cout << "What is " << number1 << " - " << number2 << "? ";

				cin >> answer;

				if (number1 - number2 == answer)

				{
					cout << "Correct." << endl;
					correctCount++;

					cout << "Question attempts: " << incorrect1 << endl;
					long endTime = time(0);
					long QuestionTime = endTime - startTime;

					cout << "Time taken: " << QuestionTime << endl;
				}


				else if (number1 - number2 != answer)

					incorrectCount++;
				    incorrect1++;
			}

			// Increase number of correct answers.

			if (number1 - number2 == answer)

				count++;
		}


		if (number3 == 2)
		{
			// If number1 < number2, swap number1 with number2.

			if (number1 < number2)
			{
				int temp = number1;
				number1 = number2;
				number2 = temp;
			}
			
			// Prompt to answer for number1 + number2 and evaluate if right or wrong.
			
			while (number1 + number2 != answer)
			{
				
				cout << "What is " << number1 << " + " << number2 << "? ";

				cin >> answer;

				if (number1 + number2 == answer)
				{
					cout << "Correct." << endl;

					correctCount++;

					cout << "Question attempts: " << incorrect2 << endl;

					long endTime = time(0);
					long QuestionTime = endTime - startTime;

					cout << "Time taken: " << QuestionTime << endl;
				}


				else if (number1 + number2 != answer)

					incorrectCount++;
				incorrect2++;
			}

			// Increase the correct count.

			if (number1 + number2 == answer)

				count++;
		}

		if (number3 == 0)
		{
			// If number1 < number2, swap number1 with number2.

			if (number1 < number2)
			{
				int temp = number1;
				number1 = number2;
				number2 = temp;
			}

			// Prompt to answer for number1 x number2 and evaluate if right or wrong.
			
			while (number1 * number2 != answer)
			{
				cout << "What is " << number1 << " x " << number2 << "? ";
				
				cin >> answer;
				if (number1 * number2 == answer)

				{
					cout << "Correct." << endl;
					correctCount++;

					cout << "Question attempts: " << incorrect0 << endl;

					long endTime = time(0);
					long QuestionTime = endTime - startTime;

					cout << "Time taken: " << QuestionTime << endl;
				}


				else if (number1 * number2 != answer)

					incorrectCount++;
					incorrect0++;
			}

			// Increase the correct count.

			if (number1 * number2 == answer)

				count++;
		}



	}

	// Calculate and display final statistics.

	long endTime = time(0);
	long testTime = endTime - startTime;

	long testTimeAvg = testTime / 10.0;

	cout << "Correct count: " << correctCount << endl;
	cout << "Test time: " << testTime << " seconds" << endl;

	cout << "Average seconds/question: " << testTimeAvg << endl;

	cout << "Average attempts: " << ((incorrectCount + correctCount) / 10.0);

	return 0;
}
