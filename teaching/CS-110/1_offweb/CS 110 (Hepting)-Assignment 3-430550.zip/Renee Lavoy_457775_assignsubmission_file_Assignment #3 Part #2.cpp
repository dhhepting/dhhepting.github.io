#include <iostream>
#include <ctime> // Needed for time function
#include <cstdlib> // Needed for the srand and rand functions
using namespace std;

int main()
{
	int attemptCount0 = 1; //
	int attemptCount1 = 1; // Count the number of attemps
	int attemptCount2 = 1; //
	int correctCount = 0; // Count the number of correct answers
	int count = 0; // Count the number of questions
	
	const int NUMBER_OF_QUESTIONS = 5;


	srand(time(0)); // Set a random seed

	while (correctCount < NUMBER_OF_QUESTIONS)
	{
		// 1. Generate two random single-digit integers
		int number1 = rand() % 10;
		int number2 = rand() % 10;

		// 2. If number1 < number2, swap number1 with number2
		if (number1 < number2)
		{
			int temp = number1;
			number1 = number2;
			number2 = temp;
		}



		int operation = rand() % 3;

		if (operation == 0)
		{
			long startTime = time(0);
			cout << "What is " << number1 << " - " << number2 << "? ";
			int answer;
			cin >> answer;
			while (number1 - number2 != answer)
			{
				cout << "That is incorrect. Please try again." << endl;
				cin >> answer;
				attemptCount0++;
			}
			if (number1 - number2 == answer)
				cout << "You are correct! Number of attempts: " << attemptCount0 << endl;

			correctCount++;
			long endTime = time(0);
			long testTime = endTime - startTime;
			cout << "Time taken: " << testTime << " seconds." << endl;
		}
		
		if (operation == 1)
		{
			long startTime = time(0);
			cout << "What is " << number1 << " + " << number2 << "? ";
			int answer;
			cin >> answer;
			while (number1 + number2 != answer)
			{
				cout << "That is incorrect. Please try again." << endl;
				cin >> answer;
				attemptCount1++;
			}
			if (number1 + number2 == answer)
				cout << "You are correct! Number of attempts: " << attemptCount1 << endl;

			correctCount++;
			long endTime = time(0);
			long testTime = endTime - startTime;
			cout << "Time taken: " << testTime << " seconds." << endl;
		}
		

		if (operation == 2)
		{
			long startTime = time(0);
			cout << "What is " << number1 << " * " << number2 << "? ";
			int answer;
			cin >> answer;
			while (number1 * number2 != answer)
			{
				cout << "That is incorrect. Please try again." << endl;
				cin >> answer;
				attemptCount2++;
			}
			if (number1 * number2 == answer)
				cout << "You are correct! Number of attempts: " << attemptCount2 << endl;

			correctCount++;
			long endTime = time(0);
			long testTime = endTime - startTime;
			cout << "Time taken: " << testTime << " seconds." << endl;
		}
	}

	cout << "The average number of attempts is " << ((attemptCount0 + attemptCount1 + attemptCount2) / 3) << " ." << endl;
	cout << "The average time taken per question is " << endl;
	return 0;
}