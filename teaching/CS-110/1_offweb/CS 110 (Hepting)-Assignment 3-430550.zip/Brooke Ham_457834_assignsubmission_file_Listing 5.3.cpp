/*
Student name: Brooke Ham
Student number: 200353759
Assignment number: 3
Program name: Listing 5.3
Date: written for Mar. 9, 2015
Problem Statement: Modify Listing 5.3 so that the computer guesses a number that the user provides (switch the roles of user and computer 
	from Listing 5.3). Write the guesses from the program and the user's answers to a file. Print a message if the computer detects that the 
	user has not been trustworthy in her answers.
Input: A number between 0 and 100 (inclusive), although other inputs will give an output on this program.
Output: Guesses as to what the number the user entered will be outputted, as well as if the user's response to if the guess was correct. If the 
	number was not between 0 and 100, a message stating this will be relayed.
Algorithm: The user will enter a whole number (after being prompted to do so) and the computer will begin guessing at 50, and based on if the guess 
	is too high or too low, the new guess will be +/- 0.5 x the previous guess summed with the previous guess. If statements will evaluate the
	truthfulness of the user.
Major variables: num, compGuess, answer
Assumptions: The program will compile and run correctly, no syntax or logic or runtime errors are present in the code.
Program Limitations: A positive whole number between 0 and 100 must be inputted to obtain a result.
*/

#include <iostream>																					// Used to enable inputs and outputs
#include <string>																					// Used for strings
#include <fstream>																					// Used to create an output file

using namespace std;																				// Standard namespace is used in this code

int main()																							// The main funciton intitates the program by creating an integer and an argument (which is the code below).
{
	ofstream output;																				// The output file stream variable is declared 
	output.open("outputfile.txt");																	// The text file called "outputfile" will be created for the output from the code

	cout << "Hey, if you enter any whole number between 0 and 100 (inclusive)," << endl;			// The user is told to enter a number between 0 and 100 inclusive.
	cout << "then I'll try to guess what you entered!" << endl;
	int num;																						// The integer num (short for number) is declared
	cin >> num;																						// The input from the user is assigned to the variable num

	while (num < 0 || num > 100)																	// If the user didn't enter the correct input, they will have to reenter numbers until they enter a number in the correct range
	{
		cout << "No, you noob! That wasn't a valid input. Try again." << endl;
		cin >> num;
	}

	int lowest = 0;																					// The variable lowest represents the lowest possible number that the input could be. It is 0 before guesses start eliminating numbers.
	int highest = 100;																				// The variable highest represents the highest possible number that the input could be. It is 100 before guesses start eliminating numbers.
	int compGuess = -1;																				// The varable compGuess represents the computers guesses as to what the user inputted 

	while (compGuess != num)																		// The while loop is entered because the user could not have entered -1: it is outside the range of accepted numbers
	{
		compGuess = ((highest - lowest) / 2) + lowest;												// The computer's guess is in the middle of the highest and lowest possible numbers

		if (compGuess < num)																		// If the computer's guess is too low, then the highest possible number remains unchanged and the lowest possible number becomes the computer's guess
			lowest = compGuess;

		if (compGuess > num)																		// If the computer's guess is too high, then the highest possible number becomes the computer's guess and the lowest possible number remains unchanged
			
			highest = compGuess;

		cout << "Is " << compGuess << " the number that you entered?" << endl;						// This message, asking if the guess was correct, is relayed
		cout << "Enter 'yes' if it is, and 'no' if it isn't." << endl;
		string answer;																				// The string which will store the user's answer is created
		cin >> answer;																				// The user's answer is saved

		if (answer == "yes")																		// If the answer is yes, then the computer will verify this. If the guess equals the number, then the code will exit the while loop. If the guess doen't equal
		{																							// the number, then the computer will continue guessing.
			if (compGuess == num)
				cout << "Awesome, it is!" << endl;
			else
				cout << "Are you sure?" << endl;
		}

		if (answer == "no")																			// If the answer is no, then the computer will verify this. If the guess equals the number, then the code will exit the while loop. If the guess doesn't equal 
		{																							// the number, then the computer will continue guessing.
			if (compGuess == num)
				cout << "Are you sure?" << endl;

			else
				cout << "Shucks, you're right." << endl;
		}
		output << "Guess: " << compGuess << endl;													// The computer's guesses will be listed
	}
	return 0;																						// The main function returns the value 0 and quits the code
}