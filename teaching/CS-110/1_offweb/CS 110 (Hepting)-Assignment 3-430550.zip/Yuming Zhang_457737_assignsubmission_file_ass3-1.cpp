///**************************************************************************
//
// Student name: YumingZhang
//
// Student number: 200338416
//
// Assignment number: num3
//
// Program name: quiz
//
// Date written: 11th March 2015
//
// Problem statement: The program will displays the number guessed, and test if the user has been truthful or not 
//
// Input: b,y,s
//
// Output: the guessing number and if the user has been truthful of not 
//
// Algorithm: 

//               Program guesses the user's number, and the guessing adds up per circle, if the range is close to one number and the answer is not y, the program output lier. 
//               
//			  
//			  
//
// Major variables: temp, up, low, upt, lowt, count
//
// Assumptions: we assume the input is b,y,s
//
// Program limitations: The test for truthless might not imidiatiatly
//
//**************************************************************************

#include <iostream>
#include <cstdlib>

#include <ctime> // Needed for the time function
using namespace std;

int main()
{

	char guess;
	int temp, up, low, upt = 100, lowt = 0, count = 1;
	temp = upt / 2;
	cout << temp << endl;
	//cout << "please if it is right, press y, if it is bigger than your number press b, or s" << endl;
	//cin >> guess;

	do
	{


		cout << "the number i guess is :" << temp << endl;
		cout << "please if it is right, press y, if it is bigger than your number press b, or s" << endl;
		cin >> guess;
		if (guess == 'b')
			upt = temp;
		else
			lowt = temp;
		count++;



		switch (guess)
		{
		case 'y': cout << "you got right number" << endl;

			break;


		case 'b':temp = (temp + lowt) / 2;
			cout << temp << endl;
			break;


		case 's':temp = (temp + upt) / 2;
			cout << temp << endl;
			if (temp == 99)
				temp = temp + 1;
			break;


		}
	} while ((guess != 'y') && (count < 12));

	cout << "you are lying!" << endl;
	return 0;
}




