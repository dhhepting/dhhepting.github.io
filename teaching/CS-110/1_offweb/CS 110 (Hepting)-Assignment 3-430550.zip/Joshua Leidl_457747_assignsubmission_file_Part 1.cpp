/*
NAME: Part 1.cpp
AUTHOR: Josh Leidl
SID: 200350878
*/

#include <iostream>
#include <ctime> 
#include <cstdlib>
#include <fstream>

using namespace std;

int main()
{
	//Ensure random numbers
	srand(time(0));
	
	int userNumber = 0;
	int guess = 0;
	int numGuesses = 0;
	bool flag = true;
	
	
	//Access the file to output the numbers to
	ofstream outData;
	outData.open("guessedNumbers.txt");
	
	//Ensure access was successful
	if (!outData)
	{
		return 1;
	}
	
	do
	{
		//Prompt the user for and acquire the number to be guessed
		cout << "Please enter a number between 0 and 100: ";
		cin >> userNumber;
		
		//Ensure valid input
		if (userNumber > 100 || userNumber < 0)
		{
			cout << "Please enter a valid number." << endl;
		}
		else
		{
			flag = false;
		}
	} while (flag);
	
	//Take a guess at the number, write it to the file and increment the guess counter
	do
	{
		guess = rand() % 101;
		
		numGuesses++;
		
		outData << guess << endl;
		
		
	}while (guess != userNumber);
	
	//Let the user know how many guesses were made
	cout << "The number was guessed correctly after " << numGuesses << " tries.";

	
	return 0;
}
