//**************************************************************
//
// Student name: Emmanuella Akobundu
// Studnet number: 200359057
// Assignment number: 3.2
// Program name: Assignment3-listing5.4.cpp
// Date written: March 11, 2015
// Problem statement: This program will ask the user to answer the question assigned, 
//					  and then print out the number of attempts on the question and  
//					  the time taken. At the end of the quiz, the average number of 
//					  attempted and the average time taken are printed.
// Input: User's answers
// Output: Number of attempts, time taken, Average number of attempts,
//		   and the average time taken.
// Algorithm: The code consists of if and else statements as well as loops.
// Major variables: 
// Assumptions: None
// Program limitations: None
//
//**************************************************************

#include <iostream>
#include <ctime> // Needed for time function
#include <cstdlib> // Needed for the srand and rand functions
using namespace std;

int main()
{
	int correctCount = 0; // Count the number of correct answers
	int count = 0; // Count the number of questions
	long startTime = time(0);
	const int NUMBER_OF_QUESTIONS = 5;
	int correct_answer;

	srand(time(0)); // Set a random seed

	while (count < NUMBER_OF_QUESTIONS)
	{
		// 1. Generate two random single-digit integers
		int number1 = rand() % 10;
		int number2 = rand() % 10;


		// Select ONE OF subtraction, addition, or multiplication - AT RANDOM
		// Prompt the user for an answer, based on the question type selected


		// subtraction selected
		if (number1 < number2)
		{
			int temp = number1;
			number1 = number2;
			number2 = temp;
		}
		cout << "What is " << number1 << " - " << number2 << "? ";
		correct_answer = number1 - number2;

		// addition selected
		cout << "What is " << number1 << " + " << number2 << "? ";
		correct_answer = number1 + number2;

		// multiplication selected
		cout << "What is " << number1 << " * " << number2 << "? ";
		correct_answer = number1 * number2;

		int answer;
		cin >> answer;


		while (answer != correct_answer)
		{
			int number1 = rand() % 10;
			int number2 = rand() % 10;


			int randomNum = 1 + rand() % 30;
			
			if (randomNum >= 1 && randomNum <= 10)
			{
				cout << "What is " << number1 << " - " << number2 << "? ";
				correct_answer = number1 - number2;
				cin >> answer;
			}

			else if (randomNum >= 11 && randomNum <= 20)
			{
				cout << "What is " << number1 << " + " << number2 << "? ";
				correct_answer = number1 + number2;
				cin >> answer;
			}

			else if (randomNum >= 21 && randomNum <= 30)
			{
				cout << "What is " << number1 << " * " << number2 << "? ";
				correct_answer = number1 * number2;
				cin >> answer;
			}

			

		}


		correctCount++;

		long endTime = time(0);
		long  testTime = endTime - startTime;

		// Increase the count
		count++;
	}
	// what will get printed here?
	cout << "Correct count is: " << correctCount << endl;

	return 0;
}