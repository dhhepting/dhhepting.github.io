/***
Name: Shambhavi Kalra
Date: 3.11.2015

********/
#include <iostream>
using namespace std;
#include <string>
int main()

{

	int guess = 0;
	int upperlimit = 100, lowerlimit = 0;
	string yesno = " ";
	
	{
		cout << "We shall begin." << endl;
		guess = (upperlimit + lowerlimit) / 2;
		cout << "Is your number, or is it higher or lower " << guess << endl;
		cin >> yesno;
		while (yesno != "yes")
		{

			while (yesno == "higher")
			{
			
				lowerlimit = guess + 1;
				upperlimit = 100;
				guess = (upperlimit + lowerlimit)
				cout << "Is your number " << guess << endl;
				cin >> yesno;
				
			}
			while (yesno == "lower")
			{
				guess = (lowerlimit + (upperlimit -1)) / 2;
				cout << "Is your number " << guess << endl;
				cin >> yesno;

			}
		}
		
	}
		return 0;















}