//******************************************************************
//
//Student name: Ronglian Wang
//
//Student number: 200269662
//
//Assignment number: 3
//
//Program name: number guessing game 
//
//Date written: 2015-03-11
//
//Problem statement:  Computer guessing number game
//
//Input: char y or b or s
//
//Output: guessing numbers
//
//Algorithm:  char,boolean, while loop, if statement
//
//Major variables: int,chars
//
//Assumptions: 
//
//Program limitations: Only takes number 0-100
//
//*********************************************************************


#include <iostream>
#include <cstdlib>
#include <fstream>

using namespace std;

int main()
{	//create outputfile
	ofstream outdata;
	outdata.open("outputfile.txt");
	char guess;
	//set up values
	int temp, upt = 100, lowt = 0, count = 1;
	temp = upt / 2;
	// Prompt the user to think of a number
	cout << "Think of a number between 0-100, let me guess it." << endl;
	//loop
	do
	{


		cout << "The number I guess is :" << temp << endl;
		outdata << "The number I guess is :" << temp << endl;
		cout << "If it is right, enter y" << endl;
		cout << "if it is bigger than your number then enter b" << endl;
		cout << "or if it is smaller than your number then enter s" << endl;
		outdata << "If it is right, enter y" << endl;
		outdata << "if it is bigger than your number then enter b" << endl;
		outdata << "or if it is smaller than your number then enter s" << endl;

		cin >> guess;
		if (guess == 'b')
			upt = temp;
		else
			lowt = temp;
		count++;

		//cases compare

		switch (guess)
		{
		case 'y': cout << "Yeah, I got the right number" << endl;
			outdata << "Yeah, I got the right number" << endl;
			break;


		case 'b':
			if (temp == 0)
			{
				cout << "you are lying!" << endl;
				outdata << "you are lying!" << endl;
				break;
			}

			temp = (temp + lowt - 1) / 2;
			cout << temp << endl;
			outdata << temp << endl;

			break;


		case 's':

			if (temp == 100)
			{
				cout << "you are lying!" << endl;
				outdata << "you are lying!" << endl;
				break;
			}

			temp = (temp + upt + 1) / 2;
			cout << temp << endl;
			outdata << temp << endl;



		}
		if (count > 7)
		{
			cout << "you are lying!" << endl;
			outdata << "you are lying!" << endl;
		}
	} while ((guess != 'y') && (count <8));


	return 0;


}

