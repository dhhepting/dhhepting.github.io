// Student Name : Cole Sanderson
//
// Student Number: 200355179
//
// Assignment Number: 3
//
// Program Name: Modification to Listing 5.4
//
// Date Written: March 8, 2015
//
// Problem Statement: The user has the responsibility to correctly answer either an addition or multiplication statement chosen by the computer. 
//
// Input: I expect to see the computers guess appear as the first statement. This guess should be the number 50 because it is halfway between 0-100. 
//
// Output: I expect to output to the computer if it is: 'high', 'low', or 'correct'. 
//
// Algorithm: I will insruct the computer whether or not it is: 'high', 'low', or 'correct'. From there the computer will take its previous guess and state a new number to the user for evaluation. 
//
// Major Variables: int guess, int highestPossible, int lowestPossible, int average, string userinput.
//
// Assumptions: I would assume that the user knows there numbers from 0-100 and can inform the computer if it is correct based off of the numbers it provides the user and there desired magic number. 
//
// Program Limitations: The program is limited to the computer only guessing and not the user guessing the computers magic number. 
//

#include <iostream>
#include <string>
using namespace std;

int main()

// In my first step I am declaring all of the major integers and variables I will be working with for the program to successfully run. 
{
	int guess;
	int highestPossible = 100;
	int lowestPossible = 0;
	int average;
	string userinput;
	int count = 0;

	// Informing the user what to properly say if the computers guess is not correct the first time and so on. 
	cout << "Please pick a number between 0-100, if guess is too high then tell computer its to high by saying 'high' if guess is to low then tell computer its to low by saying 'low' if guess is correct then tell computer its correct by saying 'correct'" << endl;

	// Here the guess must be set at -1 because if the guess was set at a number between 0-100 than that could interfere with what numbers the computer can choose. 
	// Utilizing the while loop for this program. 
	guess = -1;
	while (userinput != "correct")
	{
		guess = (highestPossible + lowestPossible) / 2;
		cout << "Computer guess is: " << guess << endl; // Ouputs the computers initial guess
		cin >> userinput;

		// Utilizing if statements to allow for different situations to occur and how they will be handled.
		if (userinput == "high")
		{
			cout << "guess is to high" << endl;
			highestPossible = guess - 1;
		}

		if (userinput == "low")
		{
			cout << "guess is to low" << endl;
			lowestPossible = guess + 1; // Changes the lower limit

		}

		if (userinput == "correct") // Outputted to the computer if they accomplish the task of guessing the magic number
		{
			cout << "Thanks for playing" << endl;
		}

		if (lowestPossible == highestPossible && userinput != "correct")
		{
			count += 1;
		}
		if (count == 2 || highestPossible < lowestPossible || lowestPossible > highestPossible)
		{
			cout << "I think you are lying to me" << endl; // Statement that will appear if the computer has correctly answered the number but the user is not telling the truth
			userinput == "correct";
			return 0; // Successful exit
		}


	}

	// Successful exit.
	return 0;
}