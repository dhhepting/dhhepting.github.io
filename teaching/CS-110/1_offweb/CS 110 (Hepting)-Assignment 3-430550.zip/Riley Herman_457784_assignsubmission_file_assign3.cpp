/*Riley Herman
200352833
Assignment 3
Guessing Game
March 11 / 2015
"Modify Listing 5.3 so that the computer guesses a number that the user provides (switch the roles of user 
and computer from Listing 5.3). Write the guesses from the program and the user's answers to a file. Print 
a message if the computer detects that the user has not been trustworthy in her answers."
Input: A target number; feedback on how well the computer did to guess the number
Output: Guesses as to the number; the output file outputfile.txt records the guesses themselves
The program takes in the goal number, then guesses a number in return. It keeps guessing (using halfway 
between the highest possible answer and the lowest possible answer as the guess) until it reaches the number.
Along the way, it is continuously checking whether or not the user is lying.
Major Variables: goal- This is the number the user puts in which the computer wants to find. puterg - short
for computer guess; it is the calculated guess which the computer uses to find the number. hilo- short for 
high or low; it is the input from the user telling the computer whether it's guess is too high or too low.
output- the output file variable name. lowest/highest- the lowest/highest posssible number for the computer 
to guess. yn- short for yes or no; it is the answer from the user as to whether or not the computer guessed 
right or not.
Assumptions: The program tests whether or not the user is telling the truth and whether or not they put in a 
valid number. However, we assume that they put in a valid input (integers when they need to be integers, yes 
or no when they need to be yes or no, etc.). 
This program is limited to numbers between 0 and 100 (inclusive), it is limited to numbers (instead of sequences
of characters), and uses an algorthm which means that it will need to guess at least a few times before it finds 
the right number. 
*/
#include <iostream>			// include statement include the libraries for the input and output stream, as well as 
#include <string>			//		the file stream and	strings.																
#include <fstream>
using namespace std;		// using the standard way of naming things

int main()			// the beginning of the main fuction
{
	cout << "Hey, enter a number between 0 and 100 (inclusive) and I'll try to guess what it is! \n";
	int goal;
	cin >> goal;		// prompting the user for input and proceeding to recieve input of a number for the computer to guess.

	while (goal > 100 || goal < 0)		// a while loop that will check whether or not the user inputted a  proper value (and repeat until the user does)
	{
		cout << "Invalid input. Try again.\n";
		cin >> goal;
	}

	int puterg = 50;		// puterg is short for computer guess; the guess from the computer variable; it is 50 because that will always be the first guess
	string hilo;			// the variable that the user inputs into to tell the computer whether the guess is too high or too low
	ofstream output;		// the variable that relates to the output file which stores the guesses
	output.open("outputfile.txt");		// opens the .txt document which stores the history of guesses
	int lowest = 0;			// the lowet posible integer and the highest possible integer start at the two extremes
	int highest = 100;

	while (puterg != goal)			 // this loop runs until the computer figures out the number which the user wanted it to find
	{
		cout << puterg << endl;
		cout << "Is my guess too high or too low?\n";		// asking the user whether or not the printed value is the number or not and taking in that answer
		cin >> hilo;

		if (hilo == "low" && puterg < goal)			// if the guess is too low and indeed the user is telling the truth, then...
		{
			lowest = puterg;		// change the lowest possbile number to the previous guess
			puterg = ((highest - lowest) / 2) + lowest;			// the next guess will be the middle number between the highest and lowest
		}
		else if (hilo == "high" && puterg > goal)		// if the guess was too high and they aren't lying...
		{
			highest = puterg;		// change the highes possible number to the prior guess
			puterg = ((highest - lowest) / 2) + lowest;			// the next guess will be similar to above
		}
		else		// if the user inputted something the program does't regognize, it won't change the guess at all, but just be confused
		{
			cout << "Huh?\n";
		}

		output << "Guess: " << puterg << endl;			// storing the guess in the output file
	}

	cout << "Is the number " << puterg << "?\n";		// the final and presumably correct guess
	string yn;			// the variable representing whether or not the user inputs that it is indeed the right guess or not; inputting said variable
	cin >> yn;

	if (yn == "yes" && puterg == goal)			// if the user inputs yes and it is actually yes, then it celebrates
			cout << "Hooray for me!\n";
	else if (yn == "no" && puterg == goal)		// if the user inputs no yet it is actualy a yes, then it is confused.
			cout << "You sure about that?\n";
	
	return 0;		// return a value of 0 to the main function and close it to end the program
}