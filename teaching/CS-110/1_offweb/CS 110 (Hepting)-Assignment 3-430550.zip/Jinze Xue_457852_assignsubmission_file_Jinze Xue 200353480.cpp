//**************************************************************************
//
// Student name: Jinze Xue
//
// Student number: 200353480
//
// Assignment number: #3
//
// Program name: Answer question
//
// Date written: March 10/2015
//
// Problem statement: the computer show the question,the answer is right can answer next question.If the answer is wrong, still answer that question.
//
// Input: Answer
//
// Output: Question,right or wrong, time, count
//
// Algorithm: question ->answer
// Major variables: answer
//
// Assumptions:the process can continue
//
// Program limitations:No.
//
//**************************************************************************

#include <iostream>
#include <ctime> // Needed for time function
#include <cstdlib> // Needed for the srand and rand functions
using namespace std;

int main()
{
	int correctCount = 0; // Count the number of correct answers
	int count = 0; // Count the number of questions
	long startTime = time(0);
	const int NUMBER_OF_QUESTIONS = 5;

	srand(time(0)); // Set a random seed

	while (correctCount < NUMBER_OF_QUESTIONS)
	{
		// 1. Generate two random single-digit integers
		int number1 = rand() % 10;
		int number2 = rand() % 10;

		// 2. If number1 < number2, swap number1 with number2
		if (number1 < number2)
		{
			int temp = number1;
			number1 = number2;
			number2 = temp;
		}
			while (1)
		{

			int fquestionCount = 0;
			long questionstartTime = time(0);
			// 3. Prompt the student to answer ��what is number1 �C number2?��
			cout << "What is " << number1 <<" -"<< number2 << "? ";
			int answer;
			cin >> answer;

			// 4. Grade the answer and display the result
			if (number1 -number2 == answer)
			{
				cout << "You are correct!\n";
				count++;
				fquestionCount++;
				correctCount++;
				long questionendTime = time(0);
				long questiontestTime = questionendTime - questionstartTime;
				cout << "The questionCount is " << fquestionCount << "\nTest time is "
					<< questiontestTime << " seconds\n";
		
			
				break;
			}
			else

				cout << "Your answer is wrong.\n" << endl;

			// Increase the count
			fquestionCount++;

		}
		
			if (correctCount < 5)
			{

				int number3 = rand() % 10;
				int number4 = rand() % 10;

				// 2. If number1 < number2, swap number1 with number2


				while (2)
				{

					int squestionCount = 0;
					long questionstartTime = time(0);
					// 3. Prompt the student to answer ��what is number1 �C number2?��
					cout << "What is " << number3 << " +" << number4 << "? ";
					int answer;
					cin >> answer;

					// 4. Grade the answer and display the result
					if (number3 + number4 == answer)
					{
						cout << "You are correct!\n";
						count++;
						squestionCount++;
						correctCount++;
						long questionendTime = time(0);
						long questiontestTime = questionendTime - questionstartTime;
						cout << "The questionCount is " << squestionCount << "\nTest time is "
							<< questiontestTime << " seconds\n";
						break;
					}
					else

						cout << "Your answer is wrong.\n" << endl;

					// Increase the count
					squestionCount++;


				}
			}
			int number5 = rand() % 10;
			int number6 = rand() % 10;

			// 2. If number1 < number2, swap number1 with number2

			if (correctCount < 5)
			{

				while (3)
				{

					int tquestionCount = 0;
					long questionstartTime = time(0);
					// 3. Prompt the student to answer ��what is number1 �C number2?��
					cout << "What is " << number5 << " *" << number6 << "? ";
					int answer;
					cin >> answer;

					// 4. Grade the answer and display the result
					if (number5 * number6 == answer)
					{
						cout << "You are correct!\n";
						count++;
						tquestionCount++;
						correctCount++;
						long questionendTime = time(0);
						long questiontestTime = questionendTime - questionstartTime;
						cout << "The questionCount is " << tquestionCount << "\nTest time is "
							<< questiontestTime << " seconds\n";
						break;
					}
					else

						cout << "Your answer is wrong.\n" << endl;

					// Increase the count
					tquestionCount++;


				}
			}
			int number7 = rand() % 10;
			int number8 = rand() % 10;

			// 2. If number1 < number2, swap number1 with number2

			if (correctCount < 5)
			{

				while (4)
				{

					int foquestionCount = 0;
					long questionstartTime = time(0);
					// 3. Prompt the student to answer ��what is number1 �C number2?��
					cout << "What is " << number7 << " /" << number8 << "? ";
					int answer;
					cin >> answer;

					// 4. Grade the answer and display the result
					if (number7 / number8 == answer)
					{
						cout << "You are correct!\n";
						count++;
						foquestionCount++;
						correctCount++;
						long questionendTime = time(0);
						long questiontestTime = questionendTime - questionstartTime;
						cout << "The questionCount is " << foquestionCount << "\nTest time is "
							<< questiontestTime << " seconds\n";
						break;
					}
					else

						cout << "Your answer is wrong.\n" << endl;

					// Increase the count
					foquestionCount++;


				}
			}
	}
	

	long endTime = time(0);
	long testTime = endTime - startTime;

	cout << "Correct count is " << correctCount << "\nTest time is "
		<< testTime << " seconds\n";

	return 0;
}