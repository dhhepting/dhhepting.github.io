//**************************************************************************
// Student name: EMIOLA EBUNLOLU
//
// Student number: 200348870
//
// Assignment number: #3
//
// Program name: GuessNumber
//
// Date written: 10-03-15
//
// Problem statement: intput a magic number
//
// Input: Computer Guess of numbers
// Major variables: int userNumber, int upper lim, int LowerLim, int computerNumber and int tries. 
//
// Assumptions:
//
// Program limitations: 
//
// Output:guess if numbers are high and low 
//
// Algorithm: Ask the user generate magic number repeatedly in a loop.
//
//
//**************************************************************************



#include <iostream>
#include <string>
#include <cstdlib>        // Needed for the srand and rand functions.
#include <ctime>        // Needed for time function
#include <fstream>

using namespace std;

int main()
{
	string user;
	int userNumber;
	int UpperLim = 100;
	int LowerLim = 0;
	int computerNumber;
	int tries = 0;
	string response;
	ofstream outData;
	outData.open("result.txt");
	if (!outData)
	{
		cout << "Error opening output file. Exiting..." << endl;
		return 1;
	}
	cout << "Welcome to guess my number!!!" << endl;

	cout << "What is your name ? " << endl;

	getline(cin, user);
	cout << user << " Please enter a magic number between 0 and 100 : " << endl;
	cin >> userNumber;
	computerNumber = rand() % 101;
	do
	{
		computerNumber = rand() % (UpperLim - LowerLim) + LowerLim;

		outData << "Computer's guess: ";
		outData << computerNumber;
		++tries;

		if (userNumber > computerNumber)
		{
			outData << "Too low..!\n\n" << endl;
			LowerLim = computerNumber + 1;
		}
		else if (userNumber < computerNumber)
		{
			outData << "Too high..!\n\n" << endl;
			UpperLim = computerNumber - 1;
		}
		if (userNumber == computerNumber)
		{
			do
			{
				cout << endl << "Is " << userNumber << " your number? If yes type yes, if not type no. " << endl;
				cin >> response;
				if (response == "yes")
					outData << "I got your number in just " << tries << " tries! ;) " << endl;
				else if (response == "no")
					cout << user << "!!! I think you are lying." << endl;
				else
					cout << "invalid input try again " << endl;
			} while (response != "yes");
		}
	} while (userNumber != computerNumber);
	return 0;
}