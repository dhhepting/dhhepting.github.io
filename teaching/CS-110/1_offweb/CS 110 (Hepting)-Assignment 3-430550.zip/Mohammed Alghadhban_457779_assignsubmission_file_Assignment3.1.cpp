/**********************************************************************************************
*	Student Name:			Mohammed Alghadhban
*	Student Number:			200318904
*	Assignment Number:		3.1
*	Program Name:			Assignment3.1
*	Date Written:			March 11, 2015
*
*	Problem Statement:		The program should guess an unknown number decided by the user
*							by only asking the user if the guess is lower than , higher than
*							or equal to the correct number
*
*	Input:					The range in which the user's number lies,
*							The number that the user has decided
*							User's response to each guess
*
*	Output:					The guesses, user's responses and the number of attemptes are
*							written on to the screen and the text file guesses.txt
*
*	Algorithm:				The program starts with an inital range, and keeps shrinking it
*							by asking the user if the number lies in the upper or the lower
*							half of the range. The program converges to the true solution as
*							it progressively discards half of the range at each iteration
*
*	Major variables:		lowerBound, upperBound:
*								upper and lower limits of the range
*							guess:
*								current guess, the geometric mean of the limits
*							userNumber:
*								The number that the user has decided
*							userInput:
*								string for user response
*							count:
*								count of the number of attempts
*							is_correct:
*								boolean variable
*								TRUE: if the user enters "correct"
*								FALSE: if the user doesn't enter "correct"
*
*	Assumptions:			The user responds with the following case-sensitive strings:
*								lower, Lower, higher, Higher, correct, equal, right
*
*	Program limitations:	none
*
**********************************************************************************************/

#include <iostream>
#include <string>	// getline()	
#include <fstream>	// File I/O

using namespace std;

int main()
{
	// Upper and lower bound of the range
	int lowerBound;
	int upperBound;

	// Current guess
	int guess;

	// The number to be guessed
	int userNumber;

	// User's responses
	string userInput;

	// Attempt count
	unsigned count = 0;

	// User verification flag
	bool is_correct = false;

	// File output stream
	ofstream outFile;
	outFile.open("guesses.txt", ios::app);

	// Error checking
	if (!outFile)
	{
		cout << "Could not open file: guesses.txt" << endl;
		return 0;
	}

	// Prompt the user to enter the lower limit of the range
	cout << "Enter the lower limit: ";
	cin >> lowerBound;

	// Prompt the user to enter the upper limit of the range
	cout << "Enter the upper limit: ";
	cin >> upperBound;

	// Swith limits if lower limit is greater than upper limit
	if (upperBound < lowerBound)
	{
		int temp = upperBound;
		upperBound = lowerBound;
		lowerBound = temp;
	}

	// Prompt the user to enter their number
	cout << "Enter a number between " << lowerBound << " and " << upperBound << ": ";
	cin >> userNumber;

	// Write the range and user's number to the output file
	outFile << "User defined range (" << lowerBound << " - " << upperBound << ")" << endl;
	outFile << "User's number: " << userNumber << endl;

	// Flush cin buffer
	cin.clear();
	fflush(stdin);

	// Loop until range shrinks to zero
	while (upperBound - lowerBound > 0)
	{
		// Current guess is the geometric mean of the range
		guess = (lowerBound + upperBound) / 2;

		// Ask for user's response on the current guess
		cout << "I have guessed " << guess << endl;
		getline(cin, userInput);

		// Increase the attempt counter
		count++;

		// Write current guess to file
		outFile << "Guess" << count << ": " << guess;

		// If user's response is "lower"
		if (userInput == "Lower" || userInput == "lower")
		{
			// User's number is lower than the current guess
			// Shrink the range to [lowerBound, guess-1]
			upperBound = guess - 1;

			// Write user's response to the output file
			outFile << "  User entered: lower" << endl;
		}

		// If user's response is "higher"
		else if (userInput == "higher" || userInput == "higher")
		{
			// User's number is higher than the current guess
			// Shrink the range to [guess+1, upperBound]
			lowerBound = guess + 1;

			// Write user's response to the output file
			outFile << "  User entered: higher" << endl;
		}

		// If user's response is "correct"
		else if (userInput == "correct" || userInput == "equal" || userInput == "right")
		{
			// Set user verification flag to true
			is_correct = true;

			// Write user's response to the output file
			outFile << "  User entered: correct" << endl;

			// Exit the loop, we are done here
			break;
		}

		// Undefined response
		else
		{
			cout << "Invalid response: Should be lower, higher or correct" << endl;
		}
	}

	// If we are here and is_correct is false then the range was down to zero and
	// the user never called the answer correct. He/she is probably lying
	if (!is_correct)
	{
		// Tell the user he/she is a liar, sugar-coat it maybe
		cout << endl << "Not pointing any fingers here but it seems you have cheated (-_-)" << endl;

		// Also write it to the output file
		outFile << "So basically, he cheated" << endl << endl;

		// Exit program
		return 0;
	}

	// If we are here then the program has successfully guessed the correct number
	// Print the correct number and the number of attempts it took to get there to
	// the screen
	cout << endl << "Your number is " << guess << endl;
	cout << "It took " << count << " attempts to guess your number" << endl;

	// Also write it to the output file
	outFile << "The correct number " << guess << " was guessed in " << count << " attempts" << endl << endl;
	outFile.close();

	// Exit program
	return 0;
}