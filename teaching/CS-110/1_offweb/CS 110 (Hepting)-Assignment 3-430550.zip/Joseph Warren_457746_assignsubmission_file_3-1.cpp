//**************************************************************************
//
// Student name: Joseph Warren
//
// Student number: 200241391
//
// Assignment number: 3-1
//
// Program name: Guess the Number
//
// Date written: March 11, 2015
//
// Problem statement:  Design a program to guess a random number between 1 and 100 as chosen by the user.
//
// Input:  User must enter "h" each time the computer's guess is too high, "l" each time it is too low, and "c" if it is correct.
//
// Output:  Guesses of numbers between 1 and 100.
// 
//
//
// Algorithm:
// 1. Ask user to think of a number between 1 and 100.
// 2. Have computer guess 50, because it is halfway between the limits.
// 3. If 50 is incorrect (user does not enter "c"), continue asking numbers halfway between the lower and higher limit, as   // determined by whether the user enters "l" or "h."
// 4. Program finishes when user enters "c."
//
// Major variables: upperlimit, lowerlimit, response
//
//
// Assumptions: User will enter only "h," "l," or "c," each time the computer asks a question.
//
// Program limitations: Works only for integers between 1 and 100.
//
//
//**************************************************************************

#include <iostream>
using namespace std;

int main()
{
	float upperlimit = 100;
	float lowerlimit = 0;
	char response = 'r';

	//ask user too think of a number
	cout << "Think of a number between 0 and 100 and the computer will try to guess it. If the computer's guess is too low,	enter l.If the computer's guess is too high, enter h." << endl;

	while (lowerlimit < upperlimit && response != 'c') //start loop of computer guesses
	{
		cout << "Is your number " << ((upperlimit + lowerlimit) / 2) << "?" << endl;
		cin >> response;
		if (response == 'l')
		{
			lowerlimit = (upperlimit / 2);
		}
		if (response == 'h')
		{
			upperlimit = (upperlimit / 2);
		}

	}

	if (response == 'c') //if user guessed correctly
	{
		cout << "Thank you for playing." << endl;
	}

	if (lowerlimit == upperlimit && response != 'c') //if user was dishonest about their number
	{
		cout << "You are being dishonest.";
	}

	return 0;
}