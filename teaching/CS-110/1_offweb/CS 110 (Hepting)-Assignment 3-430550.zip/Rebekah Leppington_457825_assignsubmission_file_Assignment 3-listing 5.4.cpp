// *********************************************************
//
// Student name: Rebekah Leppington
// Studnet number: 200 343 095
// Assignment number: 3.2
// Program name: Assignment 3-listing 5.4.cpp
// Date written: March 11, 2015
// Problem statement: This program will quiz the user in basic math and continue when the user has answered correctly.
//                    Then the program will calculate the average attempts taken as well as average time taken per question.
// Input: Numerical answers.
// Output: averge number of attempts, average time taken, and quiz questions.
// Algorithm: The computer will use the rand() function to generate basic math problems (+,*), and loops.
// Major variables: val1 - val20, correctCount, count, NUMBER_OF_QUESTIONS, sumA, sumT, averageA, averageT, guess, answer, attempt,
//                  PLUS, SUBTRACT, MULTIPLY, outData, inData, outDAta2, inData2, op, temp, number1, number2, qTime, startTime, endTime,
//                  attemptsTotal, timeTotal, attemptsAverage, timeAverage.
// Assumptions: None
// Program limitations: None
//
//****************************************************************

#include <iostream>
#include <ctime>                                                // Needed for time function
#include <cstdlib>                                              // Needed for the srand and rand functions
#include <fstream>                                              // Needed for input/output stuff
using namespace std;

int main()
{
	int correctCount = 0;                                       // Count the number of correct answers
	int count = 0;                                              // Count the number of questions
	
	const int NUMBER_OF_QUESTIONS = 5;                          // Limit of 5 different questions asked 
	int val1, val2, val3, val4, val5, val6, val7, val8, val9, val10, val11, val12, val13, val14, val15, val16, val17, val18, val19, val20;
	int sumA;
	double sumT;
	double averageA;
	double averageT;
	int guess;                                                  // User's input variable
	int answer;                                                 // answer variable
	int attempt = 1;                                            // Baseline of attempts
	const int PLUS = 0;                                         // assigning 0 to the + function
	const int SUBTRACT = 1;                                     // assigning 1 to the - function
	const int MULTIPLY = 2;                                     // assigning 2 to the * function
	ofstream outData;
	ofstream outData2;

	srand(time(0));                                             // Set a random seed

	outData.open("attempt.txt");
	outData2.open("qTime.txt");

	while (count < NUMBER_OF_QUESTIONS)
	{
		// 1. Generate two random single-digit integers
		int number1 = rand() % 10;
		int number2 = rand() % 10;
		int op = rand() % 3;                                      // % 3 will assign either + or * or -
		
		// 2. If number1 < number2, swap number1 with number2
		if (number1 < number2)
		{
			int temp = number1;
			number1 = number2;
			number2 = temp;
		}

		// 3. Prompt the student to answer �what is number1 + number2?�
		do
		{
			long startTime = time(0);                            // starts the 'timer' at the begining of the question
			
			switch (op)                                          // switch statement used to do either + or * or - operations
			{
			case PLUS:

				answer = number1 + number2;                      // variables activated
				cout << "what is " << number1 << " + " << number2 << "?\n";
				cin >> guess;
				break;

			case SUBTRACT:

				answer = number1 - number2;                      // variables activated
				cout << "what is " << number1 << " - " << number2 << "?\n";
				cin >> guess;
				break;

			case MULTIPLY:

				answer = number1 * number2;                     // variables activated
				cout << "what is " << number1 << " * " << number2 << "?\n";
				cin >> guess;
				break;

			}
			
			// 4. Grade the answer and display the result
			if (answer == guess)
			{
				long endTime = time(0);                         // stops timer
				long qTime = endTime - startTime;               // finds the time taken for each individual question
				cout << "You are correct!\n";
				cout << "Attempts: " << attempt << "\nTime: "
					<< qTime << " seconds\n";
				outData << attempt << endl;                     // outputs the values to a text file to be calculated later
				outData2 << qTime << endl;
				correctCount++;                                 
				
				qTime = startTime;
			}
			else 
				cout << "Your answer is wrong. Try again.\n" << endl;
			attempt++;

		} while (answer != guess);
		{
			attempt = attempt - 1;
			count++;                                                          // Increase the count
		}                                                   

	}

	outData.close();
	outData2.close();

	ifstream inData;

		inData.open("attempt.txt");

	inData >> val1 >> val2 >> val3 >> val4 >> val5;    // inputs 5 values

	sumA = val1 + val2 + val3 + val4 + val5;

	ifstream inData2;

		inData2.open("qTime.txt");

	inData2 >> val1 >> val2 >> val3 >> val4 >> val5;    // inputs 5 values

	sumT = val1 + val2 + val3 + val4 + val5;

	int attemptsTotal = sumA;
	double attemptsAverage = (attemptsTotal) / 5.0;
	int timeTotal = sumT;
	double timeAverage = (timeTotal) / 5.0;
	cout << "Average attempts per question: " << attemptsAverage << endl;
	cout << "Average time taken per question: " << timeAverage << " seconds\n" << endl;

	return 0;
}
