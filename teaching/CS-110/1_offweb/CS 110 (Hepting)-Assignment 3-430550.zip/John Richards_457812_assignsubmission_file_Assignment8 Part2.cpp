//John Richards
//200351524
//CS 110
//Assignment 8
//Program to create 5 random math questions and check for right answers
//Program keeps the time for the questions
//Program tracks the trys for the questions

#include <iostream>
#include <ctime> 
#include <cstdlib> 
using namespace std;

int main()
{
	int answer;
	int corcount = 0;
	int qcount = 0;
	long starttime = time(0);
	srand(time(0));
	while (qcount < 5)
	{
		int number1 = rand() % 10;
		int number2 = rand() % 10;
		int number3 = rand() % 3;

		if(number3 == 0)
		{
			do
			{
				cout << "What is " << number1 << " - " << number2 << "? ";
				cin >> answer;
				corcount++;
			}while (answer != (number1 - number2));

		}
		else if (number3 == 1)
		{
			do
			{
				cout << "What is " << number1 << " + " << number2 << "? ";
				cin >> answer;
				corcount++;
			}while(answer != (number1 + number2));

		}
		else
		{
			do
			{
				cout << "What is " << number1 << " * " << number2 << "? ";
				cin >> answer;
				corcount++;
			}while (answer != (number1 * number2));

		}
		long endtime = time(0);
		cout << "Your number of attemps so far is " << corcount << endl << endl;
		cout << "Your time so far is " << endtime - starttime << " seconds" << endl << endl;
		qcount++;
	}
	long endtime = time(0);
	cout << "Your average time for the 5 questions was " << (endtime - starttime) / 5.0 << " seconds" << endl << endl;
	cout << "Your average attemps for the 5 questions was " << corcount / 5.0 << endl << endl;



return 0;

}