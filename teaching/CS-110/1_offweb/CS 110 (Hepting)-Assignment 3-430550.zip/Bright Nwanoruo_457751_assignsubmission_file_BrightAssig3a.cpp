//**************************************************************************
//
// Student name:Bright Nwanoruo
//
// Student number: 200337192
//
// Assignment number: #3
//
// Program name: BrightAssig3a.cpp
//
// Date written: 8/3/2015
//
// Problem statement:
//
//Modify Listing 5.3 so that the computer guesses a number that the user provides 
//(switch the roles of user and computer from Listing 5.3). Write the guesses from the program and the user's answers to a file.
//Print a message if the computer detects that the user has not been trustworthy in her answers. Use the technique that we discussed
//in class today.
//
// Input: Enter 'h' if it is too high, enter 'l' if it is too low or enter 'c' if it is correct. 
//
// Output: The computer out puts an instruction on how the program works and what letter you are to enter to proceed, it then outputs a 
// guess if the a guess is too high or too low it outputs higher or lower than the initial guess according to your inputs; but if the user
// lied in his inputs the computer outputs two "you lied!!!."
//
// Algorithm:
//
//declare your upper limit for the program to be 100 so that the user can possibly have a guess of 100.
//declare yoyr lower limit for the program to be 0, so that the user can possibly have a guess of 0.
//set the bool variable to be false on the start of the program, so that the computer automatically makes a guess at the first run 
//of the program.
//declare  your response variable with data type char, and with letters 'h' or 'l' or 'c' as the inputs letters. where by h = too high,
//l= too low, and c= correct if actually the computer makes the right guess.
//open an output file, where the users inputs will be displayed.
//use a while loop that will continue to run the program as the user makes inputs his inputs lettes, in the while loop is the average
//average of the upper limit and the lower limit this helps the computer to makes it guess easily.
//
// Major variables: 
//
// UpperLimmit
// LowerLimit
// guessCorrect
// Response;
// ComputerGuess
//
// Assumptions: The guess is from 0 to 100; the inputs are but h,l or c.
//
// Program limitations: The computer only guesses values 0 to 100; the computer repeats each guess if the user enters wrong letter,
// letters not h or l or c.
//
//**************************************************************************


#include<iostream>
#include<fstream>
using namespace std;

int main()
{
	//declare your upper limit.
	int UpperLimmit = 100;

	//declare your lower limit.
	int LowerLimit = 0;

	//delcare guessCorrect to be false.  
	bool guessCorrect = false;

	//declare your response to be a datatype char, since you are using a single letter.
	char Response;

	//dclare the a variable, computer guess and initialize it to 0.
	int ComputerGuess = 0;

	//delcare an output datatype
	ofstream outdata;
	outdata.open("Output.txt");
	
	//welcome message
	cout << "Hello! You Are Welcome!! " << endl;
		cout<<"Think of a number 0 to 100 that computer will guess";
		cout << "if the computer guess is too high enter 'h', if too low enter 'l', and if correct enter 'c'" << endl;
		cout << " " << endl;
		//use while to set the guess and to set the condition for the guess
		while (UpperLimmit - LowerLimit >= 0 && guessCorrect == false)

		{
			//formula that the computer uses to make it guesses
			ComputerGuess = (UpperLimmit + LowerLimit) / 2;

			//display computer guess
			cout << "computer guess " << ComputerGuess << endl;
			cout << " " << endl;
			cout << " Is it too hight(h), too low(l), correct(c)" << endl;

			//write to a file the computer guess
			outdata << "Computer guessed : " << ComputerGuess << endl;
			cin >> Response;

			//write to a file the users response
			outdata << "The user entered : " << Response << endl;

			//declare variable c for correct guess
			if (Response == 'c')
			{
				//correct output message
				cout << "Awesome!! you got it" << endl;
				guessCorrect = true;
			}
			// declare variable h for too high
			else if (Response == 'h')
			{
				//formula for guessing new upper limits
				UpperLimmit = ComputerGuess - 1;
			}
			//declare variable l for too low
			else if (Response == 'l')
			{
				//formula for guessing new lower limit
				LowerLimit = ComputerGuess + 1;

			}

			
		
		}
		// copdition to dectect when the user is lying
          if (guessCorrect == false)

			  //output message when the user lies
			cout << "You lied!!!!" << endl;

		  //return nothing if the program runs well
		return 0;
}