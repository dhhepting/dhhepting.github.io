/***************************************************

This is the solution of assignemnt number 3/ 5.3 (modified)

Student name : Nasser Alhamed

Student ID : 200307983

Program name : "How fast you manage calculation)

Date written : Mar 10, 2015

Problem statement :

Input : to make the program guess

Output : a number between 0 and 100 

Algorithm : the progarme takes the stored number entered by the user and the by entering char like high or low
the progarm will do calc and dispalys to the user. If the char is "yes" then it's the right guess

Major variables :

Assumptions :

Program limitations: if entered a character, it would not run properly
*******************************************************************/
#include <iostream>
#include <cstdlib>
#include <ctime> 
#include <fstream>
#include <string>
using namespace std;

int main()
{
	ofstream outData;
	string response;
	outData.open("outputfile.txt");
	srand(time(0));
	int number;
	int guess = rand() % 101;
	int x;
	
	
		cout << "Please input a number from 0 and 100\n";
		cin >> number;
		outData << number << endl;
	

	
	
	if (number >= 0 && number <= 100)
	{
		cout << "This is a valid number\n";
		outData << "This is a valid number\n";

		outData << "The program's guess is: " << guess << endl;

		while (guess != number)
		{
			// herre I use the for loop to give the user the program 7 chance to guess the answer 
			//and after that the program will display a message about the user being unhonedt
			for (x = 1; x <= 7; x++)
			{
				cout << "The program's guessed:" << guess << endl;
				cout << "is the guess high or low?\n";
				cin >> response;
				if (response == "high")
				{
					
					outData << "TOO HIGH\n";
					guess =  (guess + 5);
					outData << guess << endl;
				}



				else if (response == "low")
				{

					cout << "The guess was too low\n";
					outData << "too low\n";
					guess = (guess ++);
					cout << "The computer guessed: " << guess << endl;
					outData << guess << endl;
				}

				else if (response == "yes")
				{
					cout << "Good work you guessed right!" << endl;
					outData << guess << endl;

				}
			}
			cout << "You are kidding me!, You havn't been trustworthy" << endl;
		}
		
		}





	
	return 0;
}
// end program