/*
Name: Naizhao Tan
Student Number: 200353140
Assignment Number: 3
Program name: Assignment 3
Data: Mar 08 2015
Problem Statement:
Modify Listing 5.4 so that the user must answer the question correctly before proceeding. 
Also, your program should offer addition and multiplication questions (at random).
For each question, print out the number of attempts on the question and the time taken. 
At the end of the quiz, print the average number of attempts and the average time taken

Input: Answer of the question
Output: Time taken for every time and average time taken for total, and attempt too.
Algorithm:
Step 1: Show the question randomly and ask user to answer it.
Step 2: Check if user's answer is correct
Step 3: Record time taken and attempts of user for each question
Step 4: Output the average time taken and average attempt for each question.

Major variables:
count: Used to record how many question have been released.
NUMBER_OF_QUESTION: Total number of question.
answer:	Used to record user's answer.
solution: Correct answer.
attempt: Used to record how many time the user tries to do the question.
totalAttempt: The total number of attempts.
startTime: Used to record the start time of every question.
endTime: used to record the end time of every question.
totalTime: used to record the total time of all questions.
timeTake: How long the user spend in each question.
number1, number2: The variable used in question.
operation: used to control the operation between addition and multipilication.
*/


#include <iostream>
#include <ctime> // Needed for time function
#include <cstdlib> // Needed for the srand and rand functions
using namespace std;

int main()
{
	int count = 0; // Count the number of questions
	const int NUMBER_OF_QUESTIONS = 5;
	int answer, solution, attempt, totalAttempt = 0;
	long startTime, endTime, totalTime = 0, timeTake;

	srand(time(0)); // Set a random seed

	while (count < NUMBER_OF_QUESTIONS)
	{
		// 1. Generate two random single-digit integers
		int number1 = rand() % 10;
		int number2 = rand() % 10;
		int operation = rand() % 2;
		startTime = time(0);
		timeTake = 0;
		attempt = 0;
		do{
			if (operation == 0){
				cout << "What is " << number1 << " + " << number2 << "? " << endl;
				cin >> answer;
				solution = number1 + number2;
			}
			else{
				cout << "What is " << number1 << " X " << number2 << "? " << endl;
				cin >> answer;
				solution = number1 * number2;
			}

			if (answer == solution){
				attempt = 1;
				cout << "Your answer is right" << endl;
				endTime = time(0);
				timeTake = endTime - startTime;
				cout << "You have spent " << timeTake << " seconds" << endl;
				totalTime = totalTime + timeTake;
				count++;
			}
			else if (answer != solution){
				cout << "Your answer is wrong" << endl;
				attempt++;

				cout << "You have tried " << attempt << " time" << endl;
			}
			totalAttempt = totalAttempt + attempt;
		} while (answer != solution);



	}
	cout << "Your average time taken is " << static_cast<int>(totalTime) / 5 << endl;
	cout << "Your average number of attempt is " << totalAttempt / 5 << endl;
	cout << "Your total attempt is " << totalAttempt << endl;
	return 0;
}