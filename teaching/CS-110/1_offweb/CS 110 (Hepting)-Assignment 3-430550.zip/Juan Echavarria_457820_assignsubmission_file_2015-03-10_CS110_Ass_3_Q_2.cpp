//**************************************************************************
//
// Student name:Juan Echavarria	
//
// Student number: 200360759
//
// Assignment number: 3
//
// Program name: 5.4
//
// Date written: 11-03-2015
//
// Problem statement: Modify Listing 5.4 so that the user must answer the question correctly before proceeding. Also, your program should offer addition and multiplication questions (at random). For each question, print out the number of attempts on the question and the time taken. At the end of the quiz, print the average number of attempts and the average time taken.
//
// Input: answer
//
// Output: seconds
//
// Algorithm: Loop
//
// Major variables:int a, answer; string b;
//
// Assumptions:
//
// Program limitations:
//
//**************************************************************************
#include <iostream>
#include <ctime>        // Needed for time function
#include <cstdlib>
#include "string"
// Needed for the srand and rand functions
using namespace std;
int a, answer;
string b;
long startTime2;
int main()
{
	int correctCount = 0; // Count the number of correct answers
	int count = 0; // Count the number of questions
	long startTime = time(0);
	const int NUMBER_OF_QUESTIONS = 5;

	srand(time(0)); // Set a random seed

	while (count < NUMBER_OF_QUESTIONS)
	{
		// 1. Generate two random single-digit integers
		int number1 = 1 + rand() % 10;
		int number2 = 1 + rand() % 10;

		// 2. If number1 < number2, swap number1 with number2
		if (number1 < number2)
		{
			int temp = number1;
			number1 = number2;
			number2 = temp;
		}

		int randomchoice = 1 + rand() % 3;

		if (randomchoice == 1)
			b = "-";
		if (randomchoice == 2)
			b = "+";
		if (randomchoice == 3)
			b = "*";

		// 3. Prompt the student to answer �what is number1 � number2?�
		cout << "What is " << number1 << " " << b << " " << number2 << "? ";
		if (randomchoice == 1)
		{
			startTime2 = time(0);
			cin >> answer;
			if (number1 - number2 == answer)
			{
				cout << "You are correct\n";
				correctCount++;
			}
			while (number1 - number2 != answer){

				cout << "Your answer is wrong." << endl;
				cin >> answer;
				a++;
			}
		}
		else
			if (randomchoice == 2)
			{
			startTime2 = time(0);
			cin >> answer;
			if (number1 + number2 == answer)
			{
				cout << "You are correct\n";
				correctCount++;
			}
			while (number1 + number2 != answer){

				cout << "Your answer is wrong." << endl;
				cin >> answer;
				a++;
			}
			}
			else if (randomchoice == 3)
			{
				startTime2 = time(0);
				cin >> answer;
				if (number1 * number2 == answer)
				{
					cout << "You are correct\n";
					correctCount++;
				}
				while (number1 * number2 != answer){

					cout << "Your answer is wrong." << endl;
					cin >> answer;
					a++;
				}
			}

		long endTime2 = time(0);
		long testTime2 = endTime2 - startTime2;
		cout << "The number of attempts to the question was " << a << " and the time taken was " << testTime2 << " seconds" << endl;
		// Increase the count
		count++;
		a = 0;

	}

	long endTime = time(0);
	long testTime = endTime - startTime;

	cout << "Correct count is " << correctCount << "\nTest time is " << testTime << " seconds\n";


	return 0;
}