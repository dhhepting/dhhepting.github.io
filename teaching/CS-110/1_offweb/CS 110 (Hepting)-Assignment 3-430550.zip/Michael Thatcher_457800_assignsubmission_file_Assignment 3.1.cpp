/*
 Name: Michael Thatcher
 
 Student Number: 200 353 864
 
 Assignment 3.1: CS 110
 
 Program Name: Number Guesser
 
 Date: March 11, 2015
 
 Problem statement:
 
    Modify Listing 5.3 so that the computer guesses a number that the user provides (switch the roles of user and computer from Listing 5.3). 
    Write the guesses from the program and the user's answers to a file. 
    Print a message if the computer detects that the user has not been trustworthy in her answers. 

 
 Input: True/False and Greater/Less than statements from user
 
 Output: Computer generated guesses for a number between 0 and 100
 
 Algorithm: Start guess at 50, ask user if guess is correct and then ask if incorrect wether greater or less than. Repeat (using a loop) until the correct number is guessed by the computer. If computer guesses same number twice, user was not truthful.
 
 Major variables: | number | option1 | option2 | denominator | attempts_count | is_answer_wrong |
 
 number is stored as an integer and represents the initial guess by the computer
 option1 is used to take input from the user
 option2 is used to take input from the user
 denominator is used to create the next guess for the computer
 attempts_count keeps track of how many guesses the computer has made
 is_answer_wrong is used to continue the loop until the answer is guessed
 
 
 Assumptions: User will only think of a number between 0 and 100
 
 Program limitations: Only suitable for guessing numbers between 0 and 100
 
 */


#include <iostream>

using namespace std;

int main()
{
  cout << "Think a number between 0-100 in your mind and computer will guess the number." << endl;
  
  
  
  bool is_answer_wrong = true; //this will exit the while loop if the computer gets the answer
  
  
  
  int number = 50;
  int option1 = 0;
  int option2 = 0;
  
  int denominator = 100; //keeps track of how much should be added/subtracted from our previous answer
  int attempts_count = 0; //this keep track of how many times computer tried to guess the number
  
  while(is_answer_wrong == true) // loop will continue until computer gets answer
  {
    attempts_count++;
    
   
    
    denominator = denominator / 2;
    
    if(option2 == 1) 
    //if guessed number is less than actual then add denominator to guessed number
    {
      number = number + denominator;
    }
    else if(option2 == 2) 
    
    //if guessed number is less than actual then subtract denominator from guessed number
    {
      number = number - denominator;
    }
    cout << "Attempt " << attempts_count << ") Number is " << number << endl;
    //asking user if guessed number is correct or false
    cout << "Is it true?(Press 1 for true and 2 for false) : ";
    cin >> option1;
    
    if (denominator / 2 == denominator)
     {   
        cout << "You are lying." << endl;
        return 1;
    
     }
    
    
    if(option1 == 1) // if guessed number is correct, terminate while loop
    {
      is_answer_wrong = false;
      cout << "Computer guessed your number" << endl;;
    }
    else if(option1 == 2) //if incorrect number guessed, ask if greater or less
    {
      cout << "Press 1 if guessed number is less than your number " << endl;
      cout << "Press 2 if guessed number is greater than your number " << endl;
      cin >> option2;
      
        if (denominator / 2 == denominator)
     {   
        cout << "You are lying." << endl;
        return 1;
     }
      
    }
  }
  
  
  cout << "It took the computer " << attempts_count << " tries to guess the number" << endl;
  
  return 0;
}


// End of program