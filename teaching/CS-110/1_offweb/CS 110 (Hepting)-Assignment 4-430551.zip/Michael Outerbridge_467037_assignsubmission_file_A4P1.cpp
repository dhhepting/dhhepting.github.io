/*
Michael Outerbridge

Student ID: 200352016

Assignment 4 part 1

Program name: Integer calculations w/ functions

Date Written: 24/03/2015

Modify Assignment 1 code so that the calculations it
does are located within a function. The main() function
that calls this function should let the user input any
desired about of numbers, until a negative number is input.
*/




#include <iostream>
#include <vector>
#include <string>
using namespace std;

void calculate(int); //Function that does all the calculation

int main()
{
	int num = 0;
	while (num >= 0) // only allows positive numbers
	{
		bool truth = false; //truth sets up the loop while it is false ie. the number is invalid
		while (truth == false)//begins loop
		{
			cout << "Please enter a number between 0 and 10000\n"; //prompts user to input their number
			cin >> num;
			if (num > 10000) //sets a max of 10000 that the user can enter
				cout << "That number is invalid\n" << endl;//the extra endl adds space
			else
				truth = true; //continues to the next portion
		}
		if (num >= 0) //if the user enters only 0, the program will end
			calculate(num);
		else
			cout << "Goodbye\n";
	}
}

void calculate(int num) //calculation function
{
	int amount = 0, change, sum = 0, product;
	double average;
	vector<int> number;
	string y = to_string(num);
	change = y.length(); //number of digits
	for (int i = 0; i < change; i++)
	{
		amount++;
		number.resize(amount);
		number[i] = num % 10;
		num /= 10; //this creates an array for dividing the numbers individualy
	}
	for (int i = 0; i < number.size(); i++)
	{
		sum += number[i]; //sum
	}
	average = sum / (change * 1.0); //average
	product = number[1];
	for (int i = 1; i < number.size(); i++)
	{
		product *= number[i]; //product
	}
	cout << "Number of digits: " << change << endl;
	cout << "Sum of digits: " << sum << endl;
	cout << "Average of digits: " << average << endl;
	cout << "Product of digits: " << product << endl << endl;
}