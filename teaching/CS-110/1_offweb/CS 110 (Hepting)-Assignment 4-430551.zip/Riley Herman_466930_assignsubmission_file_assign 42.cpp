/*
Riley Herman
200352833
Assignment 4
Area Code Code 2.0
March 25/2015
Problem: "Modify Assignment 2 so that the validation of the telephone format is done in one function and the test
to see if the area code is from Canada is done in another function."
Input: a phone number
Output: the place of which the area code is from
Algorithm: The program takes in a phone number, then checks if it valid: if it is it finds the place in which the area
code is from. If not, then it will tell the user that. If the input is q, the program quits: if not it keeps accepting input
Major Variables: inp1, phnum1, provterr, acode, placename, phnum, yesno
Assumptions: The user inputs a North American phone number, the program runs errorlessly
Program Limitations: The program is limited to North American phone numbers, and only recognizes those which are from Canada
*/
#include <iostream>															// include the libraries for input/output stream
#include <string>

using namespace std;														// using a standard namespace

void VALIDPH(string, bool &);												// function prototypes for the two major functions
void AREACODE(string);														//		including the types of data they will be 
																			//		using. Notice the "&"- it means that that
int main()																	//		particular variable takes up the samespace 
{																			//		in memory regardless of where it lies
	while (true)															// begin the main function/infinite loop which is
	{																		//		only exitted if the user types a 'q'
		cout << "You should enter a phone number (format ddd-ddd-dddd),\n";	// prompting the user for input
		cout << "and I'll tell you where it's from!\n" << endl;
		cout << "Or enter q to quit.\n";
		char inp1;															// establishing the variable which will only take in
		cin >> inp1;														//		the first letter to test whether or not it's
																			//		'q'; taking in that variable
		if (inp1 == 'q' || inp1 == 'Q')										// if it is indeed 'q', then quit the program
			return 0;

		string phnum1, acode;												// establishing variables for the rest of the phone number
		bool yesno = true;													//		after the first digit and the area code.
		getline(cin, phnum1);												// the variable which is the result of whether or not the
		string & phnum = inp1 + phnum1;										//		phone number is correctly inputted.
		VALIDPH(phnum, yesno);												// Then the program intakes the rest of the phone number
																			//		and adds it to the first character to create the whole 
		if (yesno)															//		number. After that, the function call with the parameters
		{																	//		for the phone number and whether or not it is correctly
			acode = phnum.substr(0, 3);										//		formatted. Then, if the format is correct, find where
			cout << "The area code is from ";								//		the area code (the first three characters in the phone 
			AREACODE(acode);												//		number is from using the AREACODE function (this is
		}																	//		the function call; function is below. If the phone number
		else																//		isn't correct, try again.
		{
			cout << "Your input is incorrect; please try again.\n";
		}
	}
}

void VALIDPH(string phnum, bool & yesno)									// function definition for the function which tests validity
{																			// below are the plethera of conditions that test if the phone 
	if (phnum.length() == 12 && phnum[0] >= '0' && phnum[0] <= '9' && phnum[1] >= '0' && phnum[1] <= '9' &&				//number is valid
		phnum[2] >= '0' && phnum[2] <= '9' && phnum[3] == '-' && phnum[4] >= '0' && phnum[4] <= '9' && phnum[5] >= '0' &&
		phnum[5] <= '9' && phnum[6] >= '0' && phnum[6] <= '9' && phnum[7] == '-' && phnum[8] >= '0' && phnum[8] <= '9' &&
		phnum[9] >= '0' && phnum[9] <= '9' && phnum[10] >= '0' && phnum[10] <= '9' && phnum[11] >= '0' && phnum[11] <= '9')	
		yesno = true;														// if it is valid, then this is true and the "if" above will run
	else
		yesno = false;														// if it isn't valid, then the else above will run
	return;
}

void AREACODE(string acode)													// the funtion which tests where the area code is from
{
	if (acode == "403" || acode == "587" || acode == "780")					// this group of if, else if, else statements are all of the 
		cout << "Alberta\n";												//		Canadian area codes. They are tested and if one is true, 
	else if (acode == "236" || acode == "250" || acode == "604" || acode == "778")	// it's name will be printed
		cout << "British Columbia\n";
	else if (acode == "204" || acode == "431")
		cout << "Manitoba\n";
	else if (acode == "506")
		cout << "New Brunswick\n";
	else if (acode == "709")
		cout << "Newfoundland and Labrador\n";
	else if (acode == "782" || acode == "902")
		cout << "Nova Scotia\n";
	else if (acode == "548" || acode == "249" || acode == "289" || acode == "343" || acode == "365" || acode == "416"
		|| acode == "437" || acode == "519" || acode == "226" || acode == "613" || acode == "647" || acode == "705"
		|| acode == "807" || acode == "905")
		cout << "Ontario\n";
	else if (acode == "782" || acode == "902")
		cout << "Prince Edward Island\n";
	else if (acode == "418" || acode == "438" || acode == "450" || acode == "514" || acode == "579" || acode == "581"
		|| acode == "819" || acode == "873")
		cout << "Quebec\n";
	else if (acode == "306" || acode == "639")
		cout << "Saskatchewan\n";
	else if (acode == "867")
		cout << "Yukon, Northwest Territories, or Nunavut\n";
	else
		cout << "Mordor (probably)\n";										// This is just if the area code isn't from Canada
}


