// Nandha Bijumon
// 200355253
// march 25th, 2015
// assignment 4
#include <iostream>
using namespace std;

int Addition(int, int, int, int, int);
int Product(int, int, int, int);
int Average(int, int, int, int, int, int);
int Count(int, int, int, int, int);

int main()
{
	int number;
	int num1 = 0;
	int num2 = 0;
	int num3 = 0;
	int num4 = 0;
	int num5 = 0;
	int plc;
	int avg;
	int add;
	int prod;

	cout << "Enter a number between 0 and 10000." << endl;
	cin >> number;

	if (number >= 0 || number <= 10000)
	{
		cout << "Thank you for following instructions!" << endl;

		num1 = (number / 1) % 10;
		num2 = (number / 10) % 10;
		num3 = (number / 100) % 10;
		num4 = (number / 1000) % 10;
		num5 = (number / 10000) % 10;

		cout << "Digits: " << num5 << " , ";
		cout << num4 << " , " << num3 << " , ";
		cout << num2 << " , " << num1 << endl;

	}
	else
	{
		cout << "Number not in Range" << endl;
	}

	plc = Count(num1, num2, num3, num4, num5);
		cout << "the number of digits is: " << plc << endl;

		avg = Average(num1, num2, num3, num4, num5, plc);
		cout << "the Average value of the digits is: " << avg << endl;

		prod = Product(num1, num2, num3, num4);
		cout << "The Product of the digits is: " << prod << endl;

		add = Addition(num1, num2, num3, num4, num5);
		cout << "The Addition of the digits is: " << add << endl;

	return 0;
}

int Count(int num1, int num2, int num3, int num4, int num5)
{

	int plc;

	if (num1 > 0)
	{
		plc = 1;
		if (num2 > 0)
		{
			plc = 2;
			if (num3 > 0)
			{
				plc = 3;
				if (num4 > 0)
				{
					plc = 4;
					if (num5 > 0)
					{
						plc = 5;
					}
				}
			}
		}
	}

	return(plc);

}

int Average(int num1, int num2, int num3, int num4, int num5, int plc)
{
	int avg;
	int sum;

	sum = num1 + num2 + num3 + num4 + num5;
	avg = sum / plc;

	return(avg);
}

int Product(int num1, int num2, int num3, int num4)
{
	int prod;

	prod = num2 * num3 * num4 * num1;

	return(prod);
}

int Addition(int num1, int num2, int num3, int num4, int num5)
{
	int add;

	add = num1 + num2 + num3 + num4 + num5;

	return(add);
}