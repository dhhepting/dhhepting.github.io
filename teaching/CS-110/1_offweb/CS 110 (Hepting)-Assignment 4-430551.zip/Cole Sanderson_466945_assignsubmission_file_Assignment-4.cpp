// Student Name : Cole Sanderson
//
// Student Number: 200355179
//
// Assignment Number: 4
//
// Program Name: Modification to Assignment #1 code
//
// Date Written: March 24, 2015
//
// Problem Statement: Manipulate Assignment #1 to make it do the calculations within a function.
//
// Input: I expect the user to enter a number between 0-10000
//
// Output: I expect the program to inform the user what area code is being entered and to end the program when "q" is entered.
//
// Major Variables: int number
//
// Assumptions: I would assume the user to be able to create a number between 0-10000 in order for the function to properly run
//
// Program Limitations: Limitations to the program include the program only being able to do numbers between 0-10000

#include <iostream>
using namespace std;

// Utilizing void function
void calc(int);

int main()
{
	int number = 0;
	// get input
	// Utilizing the while loop to keep asking for a number until user wants to end program
	while (number >= 0)
	{
		cout << "Please enter a number between 0 and 10000. A negative number will end the program" << endl;
		cin >> number;

		calc(number);
	}

	cout << "End of program" << endl;

	return 0;
}

// Utilizing void function
void calc(int number)
{
	// extract digits
	if (number >= 0 && number <= 10000)
	{
		int sum = 0;
		int prod = 1;
		int num_digits = 0;
		bool non_zero = false;
		int digit = 0;

		// 10000's place (1 or none)
		digit = number / 10000;
		number -= (digit * 10000);
		if (digit > 0 || non_zero == true)
		{
			non_zero = true;
			sum += digit;
			prod *= digit;
			num_digits++;
		}

		// 1000's place (0 - 9)
		digit = number / 1000;
		number -= (digit * 1000);
		if (digit > 0 || non_zero == true)
		{
			non_zero = true;
			sum += digit;
			prod *= digit;
			num_digits++;
		}

		// 100's place (0 - 9)
		digit = number / 100;
		number -= (digit * 100);
		if (digit > 0 || non_zero == true)
		{
			non_zero = true;
			sum += digit;
			prod *= digit;
			num_digits++;
		}

		// 10's place (0 - 9)
		digit = number / 10;
		number -= (digit * 10);
		if (digit > 0 || non_zero == true)
		{
			non_zero = true;
			sum += digit;
			prod *= digit;
			num_digits++;
		}

		// 1's place (0 - 9)
		sum += number;
		prod *= number;
		num_digits++;

		cout << "Number of digits: " << num_digits << endl;
		cout << "Sum of digits: " << sum << endl;
		cout << "Product of digits: " << prod << endl;
		cout << "Average of digits: " << sum / static_cast<float>(num_digits) << endl;
	}
	// Utilizing else statement to not continue with program because number is to small or to large
	else
	{
		cout << "Number not between 0 & 10000, inclusive" << endl;
	}

}