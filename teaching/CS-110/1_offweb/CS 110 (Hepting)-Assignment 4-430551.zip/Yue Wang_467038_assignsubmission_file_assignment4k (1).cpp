//**************************************************************************
//
// Student name: Yue Wang
//
// Student number: 200350793
//
// Assignment number: 4
//
// Program name: assignment4
//
// Date written: 25th March, 2015
//
// Problem statement: Modify Assignment 1 code so that the calculations it does are located within a function. The main() function that calls this function should let the user input any desired about of numbers, until a negative number is input.
//                   program  which reads the digits contained in a number from 0 to 10000 entered by the user.
//					  The code then proceeds to calculate and display the number of digits, the sum of the digits,
//					  the average of the digits, and the product of the digits.
//
// Input: The user is expected to input an integer between 0 and 10000 .
//
// Output: The output should display the number of digits, the sum of the digits, the average of the digits,
//		   and the product of the digits on the screen.
//
// Algorithm: In order to solve the assigned problem, the computer is instructed to first ensure that the number entered
//			  by the user satisfies the condition that it must be between 0 and 10000 by using nested if statements.
//			  Thereafter, the modulus function in order to separate the digits of the inputed number. If statements are
//			  incorporated in the code again in order to find the number of digits contained in the number.
//			  After this, the sum of digits is found by adding all the digits together; the average of the digits is found
//			  by dividing the sum of digits by the number of digits. And lastly, the product of the digits is found by
//			  multiplying all of the digits together depending on how many digits there are (using numDigits).
//			  The results are finally outputed to the screen.
//
// Major variables: The highly important variables include: number, digitn (where n ranges from 1 to 5), numDigits, and sumDigits.
//
// Assumptions: The only assumption noted is that the user inputs a number ranging from 0 to 10000.
//
// Program limitations:	The program does not assign a result for any input that does not meet the range requirement.

#include <iostream>
using namespace std;

int number(int i, int prod, int sum, int number_digits)
{
	if (i > 0 && i < 10000)
	{//Finding the number of digits
		int digit1 = i % 10;
		i /= 10;
		int digit2 = i % 10;
		i /= 10;
		int digit3 = i % 10;
		i /= 10;
		int digit4 = i % 10;
		i /= 10;
		int digit5 = i % 10;

		int number_digits = 1;
		if (digit5 > 0)
		{
			number_digits = 5;
		}
		else if (digit4 > 0)
		{
			number_digits = 4;
		}
		else if (digit3 > 0)
		{
			number_digits = 3;
		}
		else if (digit2 > 0)
		{
			number_digits = 2;
		}


		int sum = digit1;
		int prod = digit1;

		int current_digit = 1;
		if (current_digit < number_digits)
		{
			sum += digit2;
			prod *= digit2;
			if (++current_digit < number_digits)
			{
				sum += digit3;
				prod *= digit3;
				if (++current_digit < number_digits)
				{
					sum += digit4;
					prod *= digit4;
					if (++current_digit < number_digits)
					{
						sum += digit5;
						prod *= digit5;
					}
				}
			}
		}


	}
}

	int main()


	{int i, prod,  sum,  current_digit, number_digits;
		cout << "Please enter a number between 0 and 10000" << endl;
		cin >> i;
        cout << "Number of digits: " << number_digits << endl;
		cout << "Sum of digits: " << sum << endl;
		cout << "Product of digits: " << prod << endl;
		cout << "Average of digits: " << sum / static_cast<float>(number_digits) << endl;


		return 0;
	}

