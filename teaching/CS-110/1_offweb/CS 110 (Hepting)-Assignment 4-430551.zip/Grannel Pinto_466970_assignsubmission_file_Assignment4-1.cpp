
// Student name: Grannel Pinto
//
// Student number: 200351222
//
// Assignment number: 4-1
//
// Program name: Assignment4-1
//
// Date written: 25/3/2015
//
// Problem statement:Modify Assignment 1 code so that the calculations it does are located within a function. The main() function 
//that calls this function should let the user input any desired about of numbers, until a negative number is input.
//
// Input:  Input an integer between 0 and 10000
//
// Output: The output will give you the Sum of digits, the Average of digits, the Product of digits and the number of all digits



#include <iostream>
using namespace std;


void process_number(int number);
int number_digits(int digit5, int digit4, int digit3, int digit2);
int sum_digits(int digit1, int digit2, int digit3, int digit4, int digit5);
int prod_digits(int digit1s, int digit10s, int digit100s, int digit1000s, int digit10000s, int number_digits);

int main()
{
	// get input
	cout << "Please enter a number between 0 and 10000" << endl;
	int number;
	cin >> number;

	while (number >= 0)
	{
		// if number is in the proper range
		if (number >= 0 && number <= 10000)
		{
			process_number(number);
		}
		else
		{
			cout << "Number not between 0 & 10000, inclusive" << endl;
		}
		// get input
		cout << "Please enter a number between 0 and 10000" << endl;
		cin >> number;
	}
	return 0;
}
void process_number(int number)
{
	// extract digits
	int digit1 = number % 10;
	number /= 10;
	int digit2 = number % 10;
	number /= 10;
	int digit3 = number % 10;
	number /= 10;
	int digit4 = number % 10;
	number /= 10;
	int digit5 = number % 10;

	// perform computations -- there is at least 1 digit,
	// so initialize variables with it, even if it is 0

	int numDigits = number_digits(digit5, digit4, digit3, digit2);

	cout << "Number of digits: " << number_digits(digit5, digit4, digit3, digit2) << endl;
	cout << "Sum of digits: " << sum_digits(digit1, digit2, digit3, digit4, digit5) << endl;
	cout << "Product of digits: " << prod_digits(digit1, digit2, digit3, digit4, digit5, numDigits) << endl;
	cout << "Average of digits: " << sum_digits(digit1, digit2, digit3, digit4, digit5) / static_cast<float>(number_digits(digit5, digit4, digit3, digit2)) << endl;
}
//function for the number of digits
int number_digits(int digit5, int digit4, int digit3, int digit2)
{
	int count_digits = 1;
	if (digit5 > 0)
	{
		count_digits = 5;
	}
	else if (digit4 > 0)
	{
		count_digits = 4;
	}
	else if (digit3 > 0)
	{
		count_digits = 3;
	}
	else if (digit2 > 0)
	{
		count_digits = 2;
	}
	return count_digits;
}

//function for the sum of digits
int sum_digits(int digit1, int digit2, int digit3, int digit4, int digit5)
{
	return digit1 + digit2 + digit3 + digit4 + digit5;
}
//functions for product of digits
int prod_digits(int digit1s, int digit10s, int digit100s, int digit1000s, int digit10000s, int number_digits)
{
	// handle case for at least 1 digit
	int prod = digit1s;
	// handle case for at least 2 digits
	if (number_digits >= 2)
	{
		prod = prod * digit10s;
	}
	// handle case for at least 3 digits
	if (number_digits >= 3)
	{
		prod = prod * digit100s;
	}
	// handle case for at least 4 digits
	if (number_digits >= 4)
	{
		prod = prod * digit1000s;
	}
	if (number_digits >= 5)
	{
		prod = prod * digit10000s;
	}
	// if number_digits == 5, the digit can only be 1, so it won't affect product
	return prod;
}