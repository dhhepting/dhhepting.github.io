/**********************************************************************************************
*	Student Name:			Mohammed Alghadhban
*	Student Number:			200318904
*	Assignment Number:		4.2
*	Program Name:			Assignment4.2
*	Date Written:			March 25, 2015
*
*	Problem Statement:		The program should take as input a string, make sure it is valid
*							phone number and then ascertain which area code it belongs to
*
*	Input:					A string
*
*	Output:					The province which the number belongs to
*
*	Algorithm:				The program is a modification of Assignment 2, where validation
*							and processing of the string is done in seperate functions
*
*	Major variables:		userInput:
*								the string entered by the user
*							areacode:
*								the first three digits of the string
*
*	Assumptions:			none
*
*	Program limitations:	none
*
**********************************************************************************************/

#include <iostream>
#include <string>
#include <ctype.h>

using namespace std;

bool validateString(string);
string checkAreaCode(string);

//Func: isInteger(string)
//	Input: A string of characters
//	Output:
//		- TRUE: If all characters in the string are digits
//		- FALSE: If any character in the string is not a digit
inline bool isInteger(const string str)
{
	//Convert string to a char array
	const char *cstr = str.c_str();

	//Iterate through the character array
	for (unsigned i = 0; i < str.length(); i++)
	{
		//return false if a non-digit character is found
		if (!isdigit(cstr[i]))
			return false;
	}

	//return true if all the characters are digits
	return true;
}

int main()
{
	//String variable to hold the telephone number
	string userInput;

	//Remove existing content
	userInput.clear();

	while (true)
	{
		//Prompt the user to enter a telephone number
		cout << "Enter a telephone number (q to end): ";

		//Get input from the user
		getline(cin, userInput);

		if (userInput == "q")
		{
			//Quit program
			return 0;
		}

		if (validateString(userInput))
		{
			cout << checkAreaCode(userInput) << endl;
		}

		else
		{
			//Display Error Message
			cout << "Invalid input" << endl;
			cout << "Format should be: ddd-ddd-dddd" << endl;
		}
	}

	// Invalid length

	return 0;
}

bool validateString(string userInput)
{
	//Acceptable input formats:
	// 1.	ddd-ddd-dddd
	//		chars: 12
	//
	// 2.	dddddddddd
	//		chars: 10

	//Format 1 if the string has 12 chars 
	if (userInput.length() == 12)
	{
		//Check if the hypens are at the correct positions
		if (userInput[3] == '-' && userInput[7] == '-')
		{
			// Remove hyphens
			userInput.erase(3, 1);
			userInput.erase(6, 1);

			goto trimmed;
		}

		else
			return false;
	}

	//Format 2 if the string has 10 chars
	else if (userInput.length() == 10)
	{
	trimmed:

		//Check if all the char is an integer
		if (!isInteger(userInput))
		{
			return false;
		}

		return true;
	}

	else
		return false;
}

string checkAreaCode(string userInput)
{
	//Convert first 3 chars of the string to int to get area code 
	int areaCode = stoi(userInput.substr(0, 3));

	//Check where the area code belongs to and display the appropriate message 
	if (areaCode == 403 || areaCode == 587 || areaCode == 780 || areaCode == 825)
		return "Alberta";
	else if (areaCode == 236 || areaCode == 250 || areaCode == 604 || areaCode == 672 || areaCode == 778)
		return "British Columbia";
	else if (areaCode == 204 || areaCode == 431)
		return "Manitoba";
	else if (areaCode == 506)
		return "New Brunswick";
	else if (areaCode == 709)
		return "Newfoundland and Labrador";
	else if (areaCode == 782 || areaCode == 902)
		return "Nova Scotia";
	else if (areaCode == 548 || areaCode == 249 || areaCode == 289 || areaCode == 343 || areaCode == 365
		|| areaCode == 387 || areaCode == 416 || areaCode == 437 || areaCode == 519 || areaCode == 226
		|| areaCode == 613 || areaCode == 647 || areaCode == 705 || areaCode == 742 || areaCode == 807
		|| areaCode == 905)
		return "Ontario";
	else if (areaCode == 782 || areaCode == 902)
		return "Prince Edward Island";
	else if (areaCode == 418 || areaCode == 438 || areaCode == 450 || areaCode == 514 || areaCode == 579
		|| areaCode == 581 || areaCode == 819 || areaCode == 873)
		return "Quebec";
	else if (areaCode == 306 || areaCode == 639)
		return "Saskatchewan";
	else if (areaCode == 867)
		return "Yukon, Northwest Territories, and Nunavut";
	else
		return "Non-Canadian Area Code";
}