/*
Name: Naizhao Tan
Student Number: 200353140
Assignment Number: 4
Program name: Assignment 2
Due Date: Mar 25 2015
Data: Mar 23 2015
Problem Statement:
Modify Assignment 2 so that the validation of the telephone format is done in 
one function and the test to see if the area code is from Canada is done in another function.

Input: Phone Number
Output: Phone Number and where it below
Algorithm:
Step 1: Read in the phone number
Step 2: Judge if the input is the right format
Step 3: Find the region of this phonenumber
Step 4: Output the region and phone number
Major variables:
phoneNumber: the input number
checkFormat: varibles used to check if there is "-" in the input
checkNumber: varibles used to check if the input is all numbers
firstPart/f: first three digits of the input used to find the region
region/g: the varible used to accept the region
lastThree: last eight digits of the input
length: the length of the input
finalResult/a: the varible used to check if it reach the condition in formatCheck function

*/

#include <iostream>
#include <string>
using namespace std;

bool formatCheck(string);

string checkRegion(string);

int main(){
	string phoneNumber, region;
	bool a;
	do{
		// Input the phone number
		cout << "Please enter your phoneNumber" << endl;
		cin >> phoneNumber;
		if (phoneNumber != "q"){
			// Obtain the result of formatCheck function
			a = formatCheck(phoneNumber);
			if (a){
				// Call the function that find the region of the phone number
				region = checkRegion(phoneNumber);
				cout << "Your region is: " << region << endl;
				cout << "Your phone number is: " << phoneNumber << endl;
			}


		}
	// Stop the loop when the input is "q"
	} while (phoneNumber != "q");



	return 0;
}

bool formatCheck(string phoneNumber ){
	int checkFormat1, checkFormat2;
	bool checkNumber1, checkNumber2, checkNumber3, finalResult;
	int length = phoneNumber.length();
	checkFormat1 = 0;
	checkFormat2 = 0;
	checkNumber1 = false;
	checkNumber2 = false;
	checkNumber3 = false;
	// Check if there are 12 characters length in the input
	if (length == 12){
		// Check if there is "-" in the input and find where it is
		string secondPart = phoneNumber.substr(4, 11);
		checkFormat1 = phoneNumber.find("-");
		checkFormat2 = secondPart.find("-");
		string firstPart = phoneNumber.substr(0, 3);
		// Check if the input is in the right format
		if (checkFormat1 == 3 && checkFormat2 == 3){
			// Used three loops to see if the input is all numbers
			for (int i = 0; i <= 2; i++){
				if (phoneNumber[i] >= '0' && phoneNumber[i] <= '9'){
					checkNumber1 = true;
				}
				else{
					checkNumber1 = false;
					break;
				}
			}
			for (int i = 4; i <= 6; i++){
				if (phoneNumber[i] >= '0' && phoneNumber[i] <= '9'){
					checkNumber2 = true;
				}
				else{
					checkNumber2 = false;
					break;
				}
			}
			for (int i = 8; i <= 11; i++){
				if (phoneNumber[i] >= '0' && phoneNumber[i] <= '9'){
					checkNumber3 = true;
				}
				else{
					checkNumber3 = false;
					break;
				}
			}
			if (checkNumber1 && checkNumber2 && checkNumber3){
				finalResult = true;
			}
			else{
				cout << "There are characters in your input" << endl;
				finalResult = false;
			}
		}
		else{
			cout << "Please enter in right format" << endl;
			finalResult = false;
		}

		
		

	}
	else{
		cout << "The length of the input is not correct" << endl;
		finalResult = false;
	}
	// Return a boolean value
	return finalResult;
}

string checkRegion(string phoneNumber){
	// Check where this phoneNumber belows
	string f = phoneNumber.substr(0, 3);
	string g = " ";
	if (f == "403" || f == "587" || f == "780" || f == "825"){
		g = "Alberta";
	}
	else if (f == "236" || f == "250" || f == "604" || f == "672" || f == "778"){
		g = "British Columbia";

	}
	else if (f == "204" || f == "431"){
		g = "Manitoba";
	}
	else if (f == "506"){
		g = "New Brunswick";
	}
	else if (f == "709"){
		g = "Newfoundland and Labrador";
	}
	else if (f == "782" || f == "902"){
		g = "Nova Scotia";
	}
	else if (f == "548" || f == "249" || f == "289" || f == "343" || f == "365" || f == "387" || f == "416" || f == "437" ||
		f == "519" || f == "226" || f == "613" || f == "647" || f == "705" || f == "742" || f == "807" || f == "905"){
		g = "Ontario";
	}
	else if (f == "782" || f == "902"){
		g = "Prince Edward Island";
	}
	else if (f == "418" || f == "438" || f == "450" || f == "514" || f == "579" || f == "581" || f == "819" || f == "873"){
		g = "Quebec";
	}
	else if (f == "306" || f == "639"){
		g = "Saskatchewan";
	}
	else if (f == "867"){
		g = "Yukon, Northwest Territories, and Nunavut";
	}
	else{
		g = "Abroad";
	}
	// Output the result if the input meet the conditions
	return g;
}




