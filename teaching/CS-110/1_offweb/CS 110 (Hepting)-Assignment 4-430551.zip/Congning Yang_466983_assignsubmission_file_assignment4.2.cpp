//********************************************************************
//Name: Congning Yang
//
//Student number: 200350457
//
//Assignment number: Assignment 4.2
//Program name: Testing and check if the phone number has a Canadian area code
//
//Date written: March 24th, 2015
//
//Problem statement: Modify Assignment 2 so that the validation of the telephone format is done in one function and the test to see if the area code is from Canada is done in another function.
//
//Input: A valid 12 digits telephone number
//
//Output: Correct area code from a province from Canada.
//
//Algorithm 1: Set up a function prototype
//Algorithm 2: Input a telephonenumber as a string.
//Algorithm 2: Use "While loop" to test if the input telephonenumber is valid of not or it is letter "q"("Exit the program" will display and the program is over.)
//Algorithm 3: If the input telephonenumber'length is 12, the program will check if the first three digits are from Canada'area code or not.
//Algorithm 4: Check the lenght of the input telephonenumber.
//Algorithm 5: Check the areacode. If the first three digits are from Canada's area code, the program should tell which area does the number belong to.If the first three digits are not from Canada's area code, the number is invalid.
//
//Major variables: telephonenumber, areacode, st
//
//Assumptions:  The program helps users to test the telephonenumbers. Any international telephone number or number from other areas outside Canada will be invalid.
//
//Program limitations:The telephone number should only come from Canada area.
//**********************************************************************

#include <iostream>
#include <string>
using namespace std;

int check(string st);
void acheck(string st);

int main()
{
	string telephonenumber;
	string areacode;
	
	while (telephonenumber != "q")
	{
		cout << "Please enter a telephone number in the format ddd-ddd-dddd, where d is digit." << endl;
		cin >> telephonenumber;

		if (telephonenumber == "q")
		{
			cout << "Exit the program." << endl;
			return 0;
		}
		
		if (check(telephonenumber)) 
		{
		  cout << "the input is valid " << endl;
		  areacode = telephonenumber.substr(0, 3);
		  acheck(areacode);
	    }
		else
		  cout << "the input is not valid" << endl; 
		  
		cout <<endl;      
	}
	
	return 0;
}

int check(string st)
{
	if (st.length() != 12) return 0;
	if (!(st.at(0) >= '0' && st.at(0) <= '9')) return 0;
	if (!(st.at(1) >= '0' && st.at(1) <= '9')) return 0;
	if (!(st.at(2) >= '0' && st.at(2) <= '9')) return 0;
	if (st.at(3) != '-') return 0;
	if (!(st.at(4) >= '0' && st.at(4) <= '9')) return 0;
	if (!(st.at(5) >= '0' && st.at(5) <= '9')) return 0;
	if (!(st.at(6) >= '0' && st.at(6) <= '9')) return 0;
	if (st.at(7) != '-') return 0;
	if (!(st.at(8) >= '0' && st.at(8) <= '9')) return 0;
	if (!(st.at(9) >= '0' && st.at(9) <= '9')) return 0;											
	if (!(st.at(10) >= '0' && st.at(10) <= '9')) return 0;
	if (!(st.at(11) >= '0' && st.at(11) <= '9')) return 0;
	return 1;
}


void acheck(string st)
{
	cout << "The area code is " << st << endl;
	if (st == "403" || st == "587" || st == "780" || st == "825")
		cout << "This number's area code is from Alberta." << endl;
	else if (st == "236" || st == "250" || st == "604" || st == "672" || st == "778")
		cout << "This number's area code is from British Columbia." << endl;
	else if (st == "204" || st == "431")
		cout << "This number's area code is from Manitoba." << endl;
	else if (st == "236" || st == "250" || st == "604" || st == "672" || st == "778")
		cout << "This number's area code is from New Brunswick." << endl;
	else if (st == "709")
		cout << "This number's area code is from Newfoundland and Labrador." << endl;
	else if (st == "782" || st == "902")
		cout << "This number's area code is from Nova Scotia." << endl;
	else if (st == "548" || st == "249" || st == "289" || st == "343" || st == "365" || st == "387" || st == "416" || st == "437" || st == "519" || st == "226" || st == "613" || st == "647" || st == "705" || st == "742" || st == "807" || st == "905")
		cout << "This number's area code is from New Brunswick." << endl;
	else if (st == "782" || st == "902")
    	cout << "This number's area code is from Prince Edward Island." << endl;
	else if (st == "418" || st == "438" || st == "450" || st == "514" || st == "579" || st == "581" || st == "819" || st == "873")
		cout << "This number's area code is from Quebec." << endl;
	else if (st == "306" || st == "639")
		cout << "TThis number's area code is from Saskatchewan." << endl;
	else if (st == "867")
		cout << "This number's area code is from Yukon, Northwest Territories, and Nunavut." << endl;
	else
		cout << "This number's area code is not from Canada." << endl;
}
