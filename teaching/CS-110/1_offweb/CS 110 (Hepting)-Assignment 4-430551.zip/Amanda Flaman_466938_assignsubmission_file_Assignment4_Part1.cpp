//**************************************************************************
//
// Student name: Amanda Flaman
//
// Student number: 200340561
//
// Assignment number: 4
//
// Program name: Assignment4_Part1.cpp
//
// Date written: March 24/2015
//
// Problem statement:  a program that reads an integer between 0 and 10000 and 
// then calculates and displays the number of digits and the sum, average, and
// product of all the digits
//
// Input: Number
//
// Output: Number of digits, Sum of digits, Average of digits, Product of digits
//
// Algorithm: The program uses four prototypes to call functions. First it asks the user 
// to enter a number between 0 and 10000. A while loop is used to see if the program 
// should continue or not: it will quit if the user enters a negative number. Then it uses
// % 10 to test how many digits are in the user’s input. A function is then called to tell 
// the user how many digits are in the number. After that another function call leads the
// program to a function that calculates and tells the user the product of the digits in 
// the number by use if statements. Then the program returns to the main function and
// another function calls for the calculation of the sum of all the digits in the number 
// by simply adding them. After returning to the main function, it is then called for a 
// final time to determine the average of all the digits in the number by dividing the sum 
// by the number of digits. The program outputs all of the calculations and then 
// terminates.
//
// Major variables: number, digit1,digit2, digit3, digit4, numbdig, sumdig, productdig, 
// average, one, two, three, four, numdig, sum
//
// Assumptions: The user will enter an integer and not a letter.
//
// Program limitations: It doesn't divide the digits and doesn't deal with decimal numbers.
//
//**************************************************************************

#include <iostream>

using namespace std;

int NUMO_DIGITS(int, int, int, int, int);
int PRODO_DIGITS(int, int, int, int);
int SUMO_DIGITS(int, int, int, int);
float AVGO_DIGITS(int);


int main()
{
    int number;
    int digit1;
    int digit2;
    int digit3;
    int digit4;
    int numbdig;
    int sumdig;
    int productdig;
    float average;
    
   number = 1;
    while (number > 0)
    {
      cout << "Please enter an integer between 0 and 10000: ";
      cin >> number;
        
    if(number < 0)
        cout << "Finished." << endl;
 
        else if(number < 10000)
        {
            digit1 = number % 10;
            number /= 10;
            digit2 = number % 10;
            number /= 10;
            digit3 = number % 10;
            number /= 10;
            digit4 = number % 10;
            
            numbdig = NUMO_DIGITS(digit1, digit2, digit3, digit4, number);
            cout << "Number of digits: " << numbdig << endl;
            
            productdig = PRODO_DIGITS(digit1, digit2, digit3, digit4);
            cout << "Product of all the digits: " << productdig << endl;
            
            sumdig = SUMO_DIGITS(digit1, digit2, digit3, digit4);
            cout << "Sum of digits: " << sumdig << endl;
            
            average = AVGO_DIGITS(sumdig, numbdig);
            cout << "Average of all the digits: " << average << endl;
        
        }
        else
        {
            cout << "That number is too big!" << endl;
        }
    }
   
    
    return 0;
}

int NUMO_DIGITS(int one, int two, int three, int four, int numdig)
{
            
            
            numdig = 0;
        
            if (one > 0)
            {
                numdig = 1;
        
            }
            if (two > 0)
            {
                numdig = 2;
                
                
            }
            if (three > 0)
            {
                numdig = 3;
            
                
            }
            if (four > 0)
            {
                numdig = 4;
                
            }
            
            cout << "Number of digits: " << numdig << endl;
            return numdig;
}

int PRODO_DIGITS(int one, int two, int three, int four)
{
    
            proddig = 0;
        
            if (one > 0)
            {
                proddig = one;
        
            }
            if (two > 0)
            {
                proddig= one * two;
                
                
            }
            if (three > 0)
            {
                proddig = one * two * three;
            
                
            }
            if (four > 0)
            {
                proddig = one * two * three * four;
                
            }
            
            return proddig;
}

int SUMO_DIGITS(one, two, three, four)
{
   int sum = one + two + three + four;
   return sum;
}

float AVGO_DIGITS(int sum, int numdig)
{
    float avg = sum / float(numdig);
    return avg;
}
