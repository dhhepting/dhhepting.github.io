// Kian Blanchette
// 200354600
// Assignment #4
// Ass1-TheReUp
// 19 March 2015
// Problem Statement: Modify assignment 1 using functions to do the calculations, allowing the user to enter numbers until she inputs a negative number
// Input: An integer between 0 and 10000
// Output: The number of digits, the sum of the digits, the average of the digits, the product of the digits
// Algorithm: The user enters a number between 0 and 10000. Then using a do while loop and multiple functions, extract the digits and calculate the number of digits,
//			  the sum, the average, and the product. Display these values.
// Major Variables: number - the user's number
//					numberofDigits - how many digits the number has
//					sum - the total sum of the digits
//					average - the average of the digits
//					product - the product of the digits
// Assumptions: The most important assumption is that the user enters a number. If something that isn't a number is entered inside the loop, it goes into an infinite
//				loop and I have no idea why. I tried to fix it, but I can't figure out how. As long as the user enters a number the code will work properly.
// Limitations: The code only works for numbers between 0 and 10000. Also, since the number is stored as an integer, a number that is too large for storage will
//				cause an infinite loop.
#include <iostream>
using namespace std;

//These are the function prototypes used in this code
void GetDigits(int, int&, int&, int&, int&, int&); // Pass the digits by reference so I don't have to bother returning them each separately.
int NumOfDigits(int, int, int, int, int);
int Sum(int, int, int, int, int);
double Average(int, int);
int Product(int, int, int, int, int, int);
int main()
{
	float number; //By declaring number as a float, this takes care of the possibility that the user enters a float by converting it from float to int.

	do
	{	//Prompt the user to enter an integer between 0 and 10000
	 	cout << "Please enter an integer between 0 and 10000. When you wish to exit,\nenter a negative number: " << endl;
		cin >> number;
		static_cast<int>(number);
		
		if (number >= 0 && number <= 10000) //Check if the number is on the interval. If so the calculations will be done.
		{
			int d1, d2, d3, d4, d5;
			GetDigits(number, d1, d2, d3, d4, d5); //This function call takes the user's number and determines its digits.

			int numberofDigits = NumOfDigits(d1, d2, d3, d4, d5); //This function call determines how many digits are in the number.
			cout << "The number of digits in your number: " << numberofDigits << endl;

			int sum = Sum(d1, d2, d3, d4, d5); //This function call computes the sum of the digits in the number.
			cout << "The sum of the digits in your number: " << sum << endl;

			double average = Average(sum, numberofDigits); //This function call computes the average of the digits in the number.
			cout << "The average of the digits in your number: " << average << endl;

			int product = Product(numberofDigits, d1, d2, d3, d4, d5); //This function computes the product of the digits in the number.
			cout << "The product of the digits in your number: " << product << endl;
			cout << endl;
		}
		else if (number > 10000) //If the number is too large, display this message and return to the beginning of the loop.
			{
				cout << "This input is invalid." << endl;
			}
	} while (number >= 0); // Loop until the user enters a negative number. 
	return 0;
}
void GetDigits(int num, int& d1, int& d2, int& d3, int& d4, int& d5) //Get the digits of the user's number by dividing out the numbers after the digit and then
{																	 //taking the modulus to get a single digit.

	d5 = num % 10;
	d4 = (num / 10) % 10;
	d3 = (num / 100) % 10;
	d2 = (num / 1000) % 10;
	d1 = (num / 10000) % 10;
}
int NumOfDigits(int d1, int d2, int d3, int d4, int d5) //Check how many digits are in the number by testing the first digit in succession until a nonzero digit is
{														//reached.
	int numberofDigits;
	if (d1 != 0)
		numberofDigits = 5;
	else if (d2 != 0)
		numberofDigits = 4;
	else if (d3 != 0)
		numberofDigits = 3;
	else if (d4 != 0)
		numberofDigits = 2;
	else if (d5 != 0)
		numberofDigits = 1;

	return numberofDigits; //This returns the number of digits back to main.
}
int Sum(int d1, int d2, int d3, int d4, int d5) //Compute the sum of the digits and return the value to main.
{
	int sum = d1 + d2 + d3 + d4 + d5;
	return sum;
}
double Average(int sum, int num) //Compute the average of the digits.
{
	double ave = static_cast<double>(sum) / num; //Cast the sum as a double so that the average will have a decimal value.
	return ave; //This returns the computed average back to main.
}
int Product(int num, int d1, int d2, int d3, int d4, int d5) //Compute the product of the digits by checking how many digits the number has so that the product
{															 //doesn't end up being 0.
	int product;
	if (num == 5)
		product = d1 * d2 * d3 * d4 * d5;
	else if (num == 4)
		product = d2 * d3 * d4 * d5;
	else if (num == 3)
		product = d3 * d4 * d5;
	else if (num == 2)
		product = d4 * d5;
	else if (num == 1)
		product = d5;
	return product; //This returns the computed value of the product back to main.
}