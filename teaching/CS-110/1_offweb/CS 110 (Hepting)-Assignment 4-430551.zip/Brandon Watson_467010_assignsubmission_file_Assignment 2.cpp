#include <iostream>
#include <string>
#include <cctype>
using namespace std;

void GetPhone(double);
float Numbers(double);
void PrintAnser(double);
int main()

{
void GetPhone(double);
	{
	cout << "Please enter a phone number in the format of ddd-ddd-dddd to find out if the phone number is from Canada." << endl;
	cout << "Enter the letter q to end the program." << endl;
	string phone;
	string areacode = phone.substr(0,3);
	cin >> phone;
	}

double Numbers(double);
	{

	while (phone[0] != 'q')
	{
		if (phone.length() == 12)
		{
		if (phone[3] == '-')
		{
		if (phone[7] == '-')
		{
		if (areacode == "306" || areacode == "639")
		{
		cout << "Phone number is from Saskatchewan." << endl;
		}
		{
		if (areacode == "250" || areacode == "778" || areacode == "604")
		{
		cout << "Phone number is from BC." << endl;
		}
		{
		if (areacode == "587" || areacode == "780" || areacode == "403")
		{
		cout << "Phone number is from Alberta." << endl;
		}
		{
		if (areacode == "204")
		{
		cout << "Phone number is from Manitoba." << endl;
		}
		{
		if (areacode == "226" || areacode == "249" || areacode == "289" || areacode == "343" || areacode == "365" || areacode == "416" || areacode == "437")
		{
		cout << "Phone number is from Ontario." << endl;
		}
		{
		if (areacode == "437" || areacode == "519" || areacode == "613" || areacode == "647" || areacode == "705" || areacode == "807" || areacode == "905")
		{
		cout << "Phone number is from Ontario." << endl;
		}
		{
		if (areacode == "506")
		{
		cout << "Phone number is from New Brunswick." << endl;
		}
		{
		if (areacode == "709")
		{
		cout << "Phone number is from Newfoundland and Labrador." << endl;
		}
		{
		if (areacode == "867")
		{
		cout << "Phone number is from Northwest Territories, Nunavut or Yukon." << endl;
		}
		{
		if (areacode == "782" || areacode == "902")
		{
		cout << "Phone number is from Nova Scotia or PEI." << endl;
		}
		{
		if (areacode == "418" || areacode == "438" || areacode == "450" || areacode == "514" || areacode == "579" || areacode == "581" || areacode == "819")
		{
		cout << "Phone number is from Quebec." << endl;
		}
		}
		}
		}
		}
		}
		}
		}
		}
		}
		}
		}
		else
		{
		cout << "Sorry. The phone number entered could not be read or is not from Canada." << endl;
		}
	}
void PrintAnswer(double);
	{


	cout << "Please enter another phone number." << endl;
	cin >> phone;
	}
	cout << "Thank you. Program ended." << endl;
	}
	return 0;
}
