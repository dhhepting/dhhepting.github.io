/*
calculations it does are located within a function
main() function that calls this function should let the user input
any desired amount of numbers, until a negative number is input
*/



#include <iostream>
using namespace std;

/*************************************
Student name: Kennedy Dollard
Student number: 200236150
Assignment number: 4
Program name: Assignment 4
Date written: 3.25.2015
Problem statement: program using functions to calculate and display the number, sum, average and product of digits in an integer between 0 and 10000
Input: an integer from user's keyboard
Output: the number, sum, average and product of the digits in the integer
Algorithm: uses functions to store space for integer variables, prompts user to enter a number, and then user enters a number and program calculates the problem statement
Major variables: My skills
Assumptions: I'm good at coding
Program limitations: I don't know enough, can only take values from 0-10000 and it does not run properly

***************************************/



// I don't know how to pass the value 'number' to the other functions. once I figure that out I think perhaps the problem should be solved.
//also, the product function was giving my trouble so i commented it out for now.



void GetData(int&);
int numofdigits(int, int, int, int, int); // takes 6 values
int Product(int, int, int, int, int, int); //takes all the d1d2....and product is equal to the product of the digits.
int AverageSum(int, int, int, int, int);

int main()
{

	int number, sum, average, d1, d2, d3, d4, d5; //integer variable number
	//int product;
	GetData(number);
	//product = 0;
	cout << "Please enter a number between 0 and 10000." << endl; //prompt user for input
	cin >> number; //user enters a number

	d1 = (number / 1) % 10; //remainder
	d2 = (number / 10) % 10;
	d3 = (number / 100) % 10;
	d4 = (number / 1000) % 10;
	d5 = (number / 10000) % 10;


	numofdigits(d1, d2, d3, d4, d5);
	//product = Product(d1, d2, d3, d4, d5, product);

	AverageSum(d1, d2, d3, d4, d5);





	//call product function
	//call sum function
	return 0;
}


void GetData(int& number)
{
	cout << "Please enter a number." << endl;
	cin >> number;
	if (number >= 0)
	{
		cout << "Your number is greater than or equal to 0 good." << endl;
		if (number <= 10000)
			cout << "Your number is less than or equal to 10,000" << endl;
	}
	else

	{
		cout << "Your number is out the range, please enter an appropiate number." << endl;
		return;
	}
}


int numofdigits(int d1, int d2, int d3, int d4, int d5)
{


	d1 = (number / 1) % 10; //remainder
	d2 = (number / 10) % 10;
	d3 = (number / 100) % 10;
	d4 = (number / 1000) % 10;
	d5 = (number / 10000) % 10;

	if (number >= 0)
	{

		if (number <= 10000)
		{

			{

				if (d1 >= 0)
				{
					number = 1; // there is always 1 digit

				}
				if (d2 > 0)
				{
					number = 2; //there are two digits

				}
				if (d3 > 0)
				{
					number = 3; //3 digits!!!!!!

				}
				if (d4 > 0)
				{
					number = 4; //omg 4 digits

				}
				if (d5 > 0)
				{
					number = 5; //woah so many digits (5)

				}

				cout << "Your number has " << number << " digits." << endl; //much info
				return number;
			}

		}
		else
			cout << "The number must be <= 10000." << endl; //follow instructions!!!!!
	}








	else
		cout << "The number must be >= 0" << endl; //follow instructions!!!!!

}

/**int product(int d1, int d2, int d3, int d4, int d5, int product)

{
int number = 0; //?
cin >> number;
d1 = (number / 1) % 10; //remainder
d2 = (number / 10) % 10;
d3 = (number / 100) % 10;
d4 = (number / 1000) % 10;
d5 = (number / 10000) % 10;

if (number >= 0)
{

if (number <= 10000)
{

{

if (d1 >= 0)
{
number = 1; // there is always 1 digit
product = d1;
}
if (d2 > 0)
{
number = 2; //there are two digits
product = d1*d2; //so zero doesn't mess everything up
}
if (d3 > 0)
{
number = 3; //3 digits!!!!!!
product = d1*d2*d3; //so zero doesn't mess everything up
}
if (d4 > 0)
{
number = 4; //omg 4 digits
product = d1*d2*d3*d4; //so zero doesn't mess everything up
}
if (d5 > 0)
{
number = 5; //woah so many digits (5)
product = d1*d2*d3*d4*d5; //if u have 0 it'll be 0 anyways but ok
}

cout << "Your product is " << product << " digits." << endl; //much info
return product;
}

}
}






}
***/
int AverageSum(int d1, int d2, int d3, int d4, int d5)
{
	int number = 0; //figure out way to get number from before!
	d1 = (number / 1) % 10; //remainder
	d2 = (number / 10) % 10;
	d3 = (number / 100) % 10;
	d4 = (number / 1000) % 10;
	d5 = (number / 10000) % 10;
	int sum = d1 + d2 + d3 + d4 + d5; //is there a way to pass sum rather than doing this?
	int average = sum / 5;
	return average;
	return sum;



}