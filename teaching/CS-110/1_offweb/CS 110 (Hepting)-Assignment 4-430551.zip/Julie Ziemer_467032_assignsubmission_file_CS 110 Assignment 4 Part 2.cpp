//**************************************************************************
//
// Student name: Julie Ziemer
//
// Student number: 200342432
//
// Assignment number: Assignment 4
//
// Program name: CS 110 Assignment 4 Part 2.cpp
//
// Date written: March 25, 2015
//
// Problem statement:  Modify Assignment 2 so that the validation of the telephone format is done in one function and the test to see 
//					   if the area code is from Canada is done in another function.
//
// Input: User enters the phone number using the format ddd-ddd-dddd.
//
// Output: "Enter 'q' and then return to quit the program.", "Enter phone number ddd-ddd-dddd.", "Sorry, that phone number does not follow the format."
//			"Number appears to be from Alberta.", "Number appears to be from British Columbia.", "Number appears to be from Manitoba.",
//			"YNumber appears to be from New Brunswick.", "Number appears to be from Newfoundland and Labrador.", "Number appears to be from Nova Scotia.",
//			"Number appears to be from Ontario.", "Number appears to be from Quebec.", "Number appears to be from Prince Edward Island.",
//			"Number appears to be from Saskatchewan.", "Number appears to be from Yukon, Northwest Territories, and Nunavut.", 
//			"Number not proper length: should be 10 digits with 2 hyphens"
//
// Algorithm: Prototype for testing both the format of the phone number and the area code for the number are declared separately using a string.  After user
//			  is prompted to enter the number in the main, a while statement is initiated. The while loop continues until the user enters 'q'.  Within the while
//			  loop, the call statements are made for the digit format and the area code functions.  Outide of the main, the definitions for these functions are declared.
//			  The digit format checks that phone number follows ddd-ddd-dddd format, meanwhile the area code check validates the number and prints out the region.
//
// Major variables: string test1, test2, telno; bool proper_format;
//
// Assumptions:  The user will follow the instructions and will enter a phone number that corresponds to the Canadian area codes.
//
// Program limitations: The user must enter the number using the proper format (ddd-ddd-dddd) including the dashes and no parenthesis. 
//
//**************************************************************************
#include <iostream>
#include <string>
using namespace std;
// prototype to test format
void test_format(string test1);

// prototype to test area code
void test_areacode(string test2);

int main()
{

	cout << "Enter 'q' and then return to quit the program." << endl;
		cout << "Enter phone number ddd-ddd-dddd" << endl;
		string telno;
		cin >> telno;
	while (telno[0] != 'q')
	{
		// call function to test format
		test_format(telno);


		// call function to test area code
		test_areacode(telno);

		cout << "Enter phone number ddd-ddd-dddd" << endl;
		cin >> telno;
	}

	return 0;
}
// function definition to test format
void test_format(string test1)
{
	if (test1.length() == 12) // proper length
	{
		// make use of loops here 
		bool proper_format = true;

		for (int i = 0; i < 12; i++)
		{
			if (i == 3 || i == 7)
			{
				if (test1[i] != '-')
				{
					proper_format = false;
				}
			}
			else
			{
				if (!isdigit(test1[i]))
				{
					proper_format = false;
				}
			}
		}
		if (proper_format = false)
		{
			cout << "Number not proper length: should be 10 digits with 2 hyphens" << endl;
		}
	}
}
	// function definition to test area code
	void test_areacode(string test2)
	{
			string area_code = test2.substr(0, 3);
			string region = "Outside of Canada";
			// Alberta:	403, 587, 780, 825
			if (area_code == "403" ||
				area_code == "587" ||
				area_code == "780" ||
				area_code == "825")
			{
				region = "Alberta";
			}
			// British Columbia	236, 250, 604, 672, 778
			else if (area_code == "236" ||
				area_code == "250" ||
				area_code == "604" ||
				area_code == "672" ||
				area_code == "778")
			{
				region = "British Columbia";
			}
			// Manitoba	204, 431
			else if (area_code == "204" ||
				area_code == "431")
			{
				region = "Manitoba";
			}
			// New Brunswick	506
			else if (area_code == "506")
			{
				region = "New Brunswick";
			}
			// Newfoundland and Labrador	709
			else if (area_code == "709")
			{
				region = "Newfoundland and Labrador ";
			}
			// Nova Scotia	782, 902
			else if (area_code == "782" ||
				area_code == "902")
			{
				region = "Nova Scotia";
			}
			// Ontario	548, 249, 289, 343, 365, 387, 416, 437, 
			//		519, 226, 613, 647, 705, 742, 807, 905
			else if (area_code == "548" ||
				area_code == "249" ||
				area_code == "289" ||
				area_code == "343" ||
				area_code == "365" ||
				area_code == "387" ||
				area_code == "416" ||
				area_code == "437" ||
				area_code == "519" ||
				area_code == "226" ||
				area_code == "613" ||
				area_code == "647" ||
				area_code == "705" ||
				area_code == "742" ||
				area_code == "807" ||
				area_code == "905")
			{
				region = "Ontario";
			}
			// Prince Edward Island	782, 902
			else if (area_code == "782" ||
				area_code == "902")
			{
				region = "Prince Edward Island";
			}
			// Quebec	418, 438, 450, 514, 579, 581, 819, 873
			if (area_code == "418" ||
				area_code == "438" ||
				area_code == "450" ||
				area_code == "514" ||
				area_code == "579" ||
				area_code == "581" ||
				area_code == "819" ||
				area_code == "873")
			{
				region = "Quebec";
			}
			// Saskatchewan	306, 639
			if (area_code == "306" ||
				area_code == "639")
			{
				region = "Saskatchewan";
			}
			//Yukon, Northwest Territories, and Nunavut	867
			else if (area_code == "867")
			{
				region = "Yukon, Northwest Territories, and Nunavut";
			}
			cout << "Number appears to be from: " << region << endl;
		}
