
// 
//**************************************************************************
//
// Student name: Sheena-Lee Gaetz
//
// Student number: 200317727
//
// Assignment Number: 4
//
// Program Name: Area Codes
//
// Date written: March 21, 2015
//
// Problem statement: Get a phone number input and use two different functions: one to test if the number is valid,
// and one to test what the area code is.
//
// Input: Input a phone number in the format ddd-ddd-dddd
//
// Output: The area code of that number or if the number is invalid.
//
// Algorithm: Using the first function it will test if the number is valid or not using if statments. If the number is valid,
// the number will move into the second function and will be tested for the area code using if statments. The appropriate area code is
// outputted.
//
// Major variables: string telno, string answer, string region
//
// Assumptions: The program will work with any number that is inputed.
// If the number is not in the right format it will continue to ask for more input.
//
// Program limitations: None
//
//**************************************************************************
#include <iostream>
#include <string>
using namespace std;

string Validation(string telno); //function prototypes
string AreaTest(string telno);

int main()
{
	string region;
	string answer;

	cout << "To quit the program type 'q'" << endl; //allow user to quit program when they want
	cout << "Enter phone number ddd-ddd-dddd" << endl;
	string telno;
	cin >> telno;

	while (telno[0] != 'q') //while loop to continue if the input is not q
	{

		answer = Validation(telno); //function call
		cout << answer << endl;

		while (answer == "invalid number") //continue loop until a valid number is inputed
		{
			cout << "Enter phone number ddd-ddd-dddd" << endl;
			string telno;
			cin >> telno;

			answer = Validation(telno); //function call
			cout << answer << endl;
		}


		region = AreaTest(telno); //function call
		cout << "This number is from:  " << region << endl;

		cout << "Enter phone number ddd-ddd-dddd" << endl; //continue testing until user inputs q
		cin >> telno;
	}

	return 0;
}




string Validation(string telno) //function definition with one parameter
{
	if (telno.length() != 12) //Testing for valid number
		return "invalid number";

	for (int i = 0; i < 12; i++)
	{
		if (i == 3 || i == 7)
		{
			if (telno[i] != '-')
			{
				return "invalid number";
			}
		}
		else
		{
			if (!isdigit(telno[i]))
			{
				return "invalid number";
			}
			else
				return "valid number";
		}
	}
}


	string AreaTest(string telno) //function definition with one parameter
	{
		string area_code = telno.substr(0, 3); //testing for area code

		string region = "Outside of Canada";

		if (area_code == "403" ||
			area_code == "587" ||
			area_code == "780" ||
			area_code == "825")
		{
			region = "Alberta";
			return region;
		}

		else if (area_code == "236" ||
			area_code == "250" ||
			area_code == "604" ||
			area_code == "672" ||
			area_code == "778")
		{
			region = "British Columbia";
			return region;
		}

		else if (area_code == "204" ||
			area_code == "431")
		{
			region = "Manitoba";
			return region;
		}

		else if (area_code == "506")
		{
			region = "New Brunswick";
			return region;
		}

		else if (area_code == "709")
		{
			region = "Newfoundland and Labrador ";
			return region;
		}

		else if (area_code == "782" ||
			area_code == "902")
		{
			region = "Nova Scotia";
			return region;
		}

		else if (area_code == "548" ||
			area_code == "249" ||
			area_code == "289" ||
			area_code == "343" ||
			area_code == "365" ||
			area_code == "387" ||
			area_code == "416" ||
			area_code == "437" ||
			area_code == "519" ||
			area_code == "226" ||
			area_code == "613" ||
			area_code == "647" ||
			area_code == "705" ||
			area_code == "742" ||
			area_code == "807" ||
			area_code == "905")
		{
			region = "Ontario";
			return region;
		}

		else if (area_code == "782" ||
			area_code == "902")
		{
			region = "Prince Edward Island";
			return region;
		}

		else if (area_code == "418" ||
			area_code == "438" ||
			area_code == "450" ||
			area_code == "514" ||
			area_code == "579" ||
			area_code == "581" ||
			area_code == "819" ||
			area_code == "873")
		{
			region = "Quebec";
			return region;
		}

		else if (area_code == "306" ||
			area_code == "639")
		{
			region = "Saskatchewan";
			return region;
		}

		else if (area_code == "867")
		{
			region = "Yukon, Northwest Territories, and Nunavut";
			return region;
		}
		else
		{
			region = "Outside of Canada.";
			return region;
		}


	}
