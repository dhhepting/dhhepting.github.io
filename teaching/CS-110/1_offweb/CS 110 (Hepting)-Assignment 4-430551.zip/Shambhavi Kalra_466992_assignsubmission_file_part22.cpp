/*
validation of the telephone format is done in one function
and the test to see if the area code is from Canada is done in another function
*/



/*************************************
Student name: Shambhavi Kalra
Student number: 200336705
Assignment number: 4
Program name: Assignment 4
Date written: 3.25.2015
Problem statement: Program which uses assignment 2, but now broken up in functions. one to check the format of the telephone number, and the other to determine the region.
Input: a phone number from user's keyboard
Output: the province that phone number is from
Algorithm: enter number, checks format, then outputs region 
Major variables: telephone number, loops
Assumptions: they enter it in the right format 
Program limitations: can only do canadian numbers. or determine canadian numbers that is.

***************************************/



#include <iostream>
#include <string>
using namespace std;

	
int main()
{
	string telno;
	while (telno[0] != 'q')
	{
		cout << "Enter phone number ddd-ddd-dddd" << endl;
		string telno;
		cin >> telno;
		void checkno(string telno);
		void checkcode(string area_code, string region);

	}
}

void checkno(string telno)
{

		if (telno.length() == 12) // proper length
		{
			// make use of loops here :-)
			bool proper_format = true;
			for (int i = 0; i < 12; i++)
			{
				if (i == 3 || i == 7)
				{
					if (telno[i] != '-')
					{
						proper_format = false;
					}
				}
				else
				{
					if (!isdigit(telno[i]))
					{
						proper_format = false;
					}
				}
			cout << "Number not in proper format" << endl;
			cout << "Enter phone number ddd-ddd-dddd" << endl;
				cin >> telno;
				return ;
				{
				
			}
			}
			cout << "Number is in proper format. " << endl;
		}
	}


void checkcode(string telno)
{
				string area_code = telno.substr(0, 3);
				string region = "Outside of Canada";
				// Alberta:	403, 587, 780, 825
				if (area_code == "403" ||
					area_code == "587" ||
					area_code == "780" ||
					area_code == "825")
				{
					region = "Alberta";
				}
				// British Columbia	236, 250, 604, 672, 778
				else if (area_code == "236" ||
					area_code == "250" ||
					area_code == "604" ||
					area_code == "672" ||
					area_code == "778")
				{
					region = "British Columbia";
				}
				// Manitoba	204, 431
				else if (area_code == "204" ||
					area_code == "431")
				{
					region = "Manitoba";
				}
				// New Brunswick	506
				else if (area_code == "506")
				{
					region = "New Brunswick";
				}
				// Newfoundland and Labrador	709
				else if (area_code == "709")
				{
					region = "Newfoundland and Labrador ";
				}
				// Nova Scotia	782, 902
				else if (area_code == "782" ||
					area_code == "902")
				{
					region = "Nova Scotia";
				}
				// Ontario	548, 249, 289, 343, 365, 387, 416, 437, 
				//		519, 226, 613, 647, 705, 742, 807, 905
				else if (area_code == "548" ||
					area_code == "249" ||
					area_code == "289" ||
					area_code == "343" ||
					area_code == "365" ||
					area_code == "387" ||
					area_code == "416" ||
					area_code == "437" ||
					area_code == "519" ||
					area_code == "226" ||
					area_code == "613" ||
					area_code == "647" ||
					area_code == "705" ||
					area_code == "742" ||
					area_code == "807" ||
					area_code == "905")
				{
					region = "Ontario";
				}
				// Prince Edward Island	782, 902
				else if (area_code == "782" ||
					area_code == "902")
				{
					region = "Prince Edward Island";
				}
				// Quebec	418, 438, 450, 514, 579, 581, 819, 873
				if (area_code == "418" ||
					area_code == "438" ||
					area_code == "450" ||
					area_code == "514" ||
					area_code == "579" ||
					area_code == "581" ||
					area_code == "819" ||
					area_code == "873")
				{
					region = "Quebec";
				}
				// Saskatchewan	306, 639
				if (area_code == "306" ||
					area_code == "639")
				{
					region = "Saskatchewan";
				}
				//Yukon, Northwest Territories, and Nunavut	867
				else if (area_code == "867")
				{
					region = "Yukon, Northwest Territories, and Nunavut";
				}
				cout << "Number appears to be from: " << region << endl;
			}