/**********************************************************************************************
*	Student Name:			Mohammed Alghadhban
*	Student Number:			200318904
*	Assignment Number:		4.1
*	Program Name:			Assignment4.1
*	Date Written:			March 25, 2015
*
*	Problem Statement:		The program should take as input a positive number, and should
*							find and print the number of digits in the number, the sum of
*							the digits, the average of the digits and the product of the
*							digits
*
*	Input:					an integer
*
*	Output:					No. of digits, sum of digits, average of digits, product of
*							digits
*
*	Algorithm:				The program is a modification of Assignment 1, where the number
*							is now processed in the function processInteger()
*
*	Major variables:		inputInteger:
*								The number entered by the user
*							processed[]:
*								An array of size 4, where:
*								 processed[0]: Number of digits
*								 processed[1]: Sum of digits
*								 processed[2]: Average of digits
*								 processed[3]: Product of digits
*
*	Assumptions:			none
*
*	Program limitations:	none
*
**********************************************************************************************/

#include <iostream> 

void processInteger(int, double[]);

int main()
{
	// Variable declerations
	int			inputInteger;
	double		processed[4];

	// Prompt the user to enter an integer between 0 and 10000
	while (true)
	{
		std::cout << "Enter an integer between 0 and 10000: ";
		std::cin >> inputInteger;

		if (inputInteger > 0)
		{
			processInteger(inputInteger, processed);

			// Display all the computed numbers
			std::cout << "Number of digits: " << processed[0] << std::endl;
			std::cout << "Sum of digits: " << processed[1] << std::endl;
			std::cout << "Average of digits: " << processed[2] << std::endl;
			std::cout << "Product of digits: " << processed[3] << std::endl << std::endl;
		}

		else
			break;
	} 

	return 0;
}

void processInteger(int inputInteger, double processed[])
{
	processed[0] = 0; // Number of digits
	processed[1] = 0; // Sum of digits
	processed[2] = 0; // Average of digits
	processed[3] = 1; // Product of digits

	// Run through all the digits of inputInteger as powers of 10
	while (inputInteger > 0)
	{
		// The remainder after division by ten is the least significant digit
		unsigned remainder = inputInteger - inputInteger / 10 * 10;

		// Add the current digit to the sum of all the last digits
		processed[1] = processed[1] + remainder;

		// Multiply the current digit with the product of all the last digits
		processed[3] = processed[3] * remainder;

		// Drop the current digit for next iteration
		inputInteger = inputInteger / 10;

		// Increment digit counter
		processed[0] = processed[0] + 1;
	}

	// Find average of all the digits
	processed[2] = processed[1] / processed[0];

	return;
}
