//**************************************************************************
//
// Student name: Caleigh Ritson
//
// Student number: 200253359
//
// Assignment number: 4.1
//
// Program name: assign4.ccp
//
// Date written: Mar. 25, 2015
//
// Problem statement: To use any integer between 0 and 10000 and find the number of digits, 
//					  the digit sum, the digit product and the digit average using a function.
//
// Input: An integer between 0 and 10000, otherwise the program will not work.
//
// Output: As long as the integer given by the user is between 0 and 10000, the program should
//		   output the number of digits in the integer, and the sum, product and average of the digits 
//
// Algorithm: The program will ask for user input for a number between 0-10000. The program will loop if the number is a positive number and will 
//			  then will only proceed with the number is less than 10000 with an if statement, otherwise the program ends. If the program matches 
//			  these parameters, the program will use a function to calculate the number of digits, the sum of the digits, the average of the digits
//			  and the product of the digits of the inputed number. Then the calculations are outputed and you are asked to repeat the same procedure 
//			  until you enter an invaild number.
//
// Major variables: number, digit1, digit2, digit3, digit4, digit5, digit, PrintNum, product, sum, num
//
// Assumptions: I have to assume the user will enter a number between 0 and 10000
//
// Program limitations: The program will not work with an integer out of the range of 0-10000 with a continuous loop that will not stop until an
//						invalid number is entered. 
//						
//
//**************************************************************************

#include <iostream>
using namespace std;

void PrintNum(int);

int main()
{
	int number;


	cout << "Please enter a number between 0-10000:" << endl;
	cin >> number;

	while (number >= 0)
	{ 
		if (number <= 10000)
		{
			cout << number << endl;
			PrintNum(number);
			cout << "Please enter a number between 0-10000:" << endl;
			cin >> number;
		}
		else
		{
			cout << "This is number is greater than 10000. Nice try." << endl;
			cout << "Please enter a number between 0-10000:" << endl;
			cin >> number;
		}
		
	}
	cout << "You entered a negative number. That is not a number between 0 and 10000." << endl;
	return 0;
}
void PrintNum(int num)
{

	int digit1;
	int digit2;
	int digit3;
	int digit4;
	int digit5;
	int digit;
	int sum;
	int product;
	if (num <= 10000)
	{
		digit1 = num % 10;
		num /= 10;
		digit2 = num % 10;
		num /= 10;
		digit3 = num % 10;
		num /= 10;
		digit4 = num % 10;
		num /= 10;
		digit5 = num % 10;
		num /= 10;


		if (digit5 > 0)
		{
			digit = 5;
			cout << "The number of digits is:" << digit << endl;

			sum = digit1 + digit2 + digit3 + digit4 + digit5;
			cout << "Sum of the digits:" << sum << endl;

			cout << "Average of the digits:" << (sum / digit) << endl;

			product = digit1 * digit2 * digit3 * digit4 * digit5;
			cout << "Product of the digits:" << product << endl;


		}

		else if (digit4 > 0)
		{
			digit = 4;
			cout << "The number of digits is:" << digit << endl;

			sum = digit1 + digit2 + digit3 + digit4;
			cout << "Sum of the digits:" << sum << endl;
			cout << "Average of the digits:" << (sum / digit) << endl;

			product = digit1 * digit2 * digit3 * digit4;
			cout << "Product of the digits:" << product << endl;


		}

		else if (digit3 > 0)
		{
			digit = 3;
			cout << "The number of digits is:" << digit << endl;

			sum = digit1 + digit2 + digit3;
			cout << "Sum of the digits:" << sum << endl;

			cout << "Average of the digits:" << (sum / digit) << endl;

			product = digit1 * digit2 * digit3;
			cout << "Product of the digits:" << product << endl;
		}

		else if (digit2 > 0)
		{
			digit = 2;
			cout << "The number of digits is:" << digit << endl;

			sum = digit1 + digit2;
			cout << "Sum of the digits:" << sum << endl;

			cout << "Average of the digits:" << (sum / digit) << endl;

			product = digit1 * digit2;
			cout << "Product of the digits:" << product << endl;
		}

		else if (digit1 > 0)
		{
			digit = 1;
			cout << "The number of digits is:" << digit << endl;

			sum = digit1;
			cout << "Sum of the digits:" << sum << endl;

			cout << "Average of the digits:" << (sum / digit) << endl;

			product = digit1;
			cout << "Product of the digits:" << product << endl;
		}
	}
}


			
			
				
