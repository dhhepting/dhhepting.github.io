// Student name: Callum Jacobson
//
// Student number: 200234874
//
// Assignment number: 4 Part 2
//
// Program name: Canadian Area Code Identifier (using functions)
//
// Date written: 24 March 2015
//
// Problem statement: 
//		The problems that need to be solved by this program are:
//		1) Recognize an area code from a 12 digit string entered by the used.
//		2) Determing if the area code is Canadian and which province it belongs to.
//
// Input:
//		The user inputs a phone number in the format ddd-ddd-dddd.
//
// Output:
//		After computation, the program will output the following:
//		1) Whether or not the inputted phone number is in the correct format.
//		2) The province the number belongs to based on the area code, if a Canadian area code was entered.
//
// Algorithm: 
//		1) User inputs phone number.
//		2) Using a function, the program checks the correctness of the format.
//		3) Using a function, the program checks the first 3 digits of the number for a match with Canadian area codes.
//		4) Program invokes the functions and outputs whether the format was valid or invalid and the province that the area code belongs to.
//		5) Program loops until user enters 'q'.
//
// Major variables: 
//		1) The 12 character phone number string entered by the user.
//		2) The area code (first 3 digits of the string).
//
// Assumptions:
//		1) Assumes that user will be able to successfully follow the given instructions for the phone number format.
//		2) Assumes that the area code data (sourced from Wikipedia) is accurate.
//
// Program limitations:
//		1) Phone number must be entered in a specific format for program to work
//		2) Limited to identifying Canadian area codes only.
//
//**************************************************************************

#include <iostream>
#include <string>
using namespace std;

//Test that the input is in the correct format 
// Is input 12 characters long?
// if yes then Does input match ddd-ddd-dddd?

void printValidation(string phone_number)
{

		if (phone_number.length() != 12)
		{
		cout << "The input is invalid." << endl;
		return;
		}

		if ((phone_number[0] >= '0') && (phone_number[0] <= '9'))
		{
			if ((phone_number[1] >= '0') && (phone_number[1] <= '9'))

				if ((phone_number[2] >= '0') && (phone_number[2] <= '9'))

					if (phone_number[3] == '-')

						if ((phone_number[4] >= '0') && (phone_number[4] <= '9'))

							if ((phone_number[5] >= '0') && (phone_number[5] <= '9'))

								if ((phone_number[6] >= '0') && (phone_number[6] <= '9'))

									if (phone_number[7] == '-')

										if ((phone_number[8] >= '0') && (phone_number[8] <= '9'))

											if ((phone_number[9] >= '0') && (phone_number[9] <= '9'))

												if ((phone_number[10] >= '0') && (phone_number[10] <= '9'))

													if ((phone_number[11] >= '0') && (phone_number[11] <= '9'))

														if ((phone_number[12] >= '0') && (phone_number[12] <= '9'))
														{
														cout << "The input is valid." << endl;
														}
		}
		else
		{
			cout << "The input is invalid." << endl;
		}
	}

//Does the area code match one of Canada's area codes?
void printCDNareacode(string code)
	{
		
		if (code == "403" || code == "587" || code == "780" || code == "825")
		{
			cout << "The phone number is located in Alberta." << endl;
		}
		else if (code == "236" || code == "250" || code == "604" || code == "672" || code == "778")
		{
			cout << "The phone number is located in British Columbia." << endl;
		}
		else if (code == "204" || code == "431")
		{
			cout << "The phone number is located in Manitoba." << endl;
		}
		else if (code == "506")
		{
			cout << "The phone number is located in New Brunswick." << endl;
		}
		else if (code == "709")
		{
			cout << "The phone number is located in Newfoundland and Labrador." << endl;
		}
		else if (code == "782" || code == "902")
		{
			cout << "The phone number is located in Nova Scotia or Prince Edward Island." << endl;
		}
		else if (code == "548" || code == "249" || code == "289" || code == "343" || code == "365" || code == "387" || code == "416" || code == "437" || code == "519" || code == "226" || code == "613" || code == "647" || code == "705" || code == "742" || code == "807" || code == "905")
		{
			cout << "The phone number is located in Ontario." << endl;
		}
		else if (code == "418" || code == "438" || code == "450" || code == "514" || code == "579" || code == "581" || code == "819" || code == "873")
		{
			cout << "The phone number is located in Quebec." << endl;
		}
		else if (code == "306" || code == "639")
		{
			cout << "The phone number is located in Saskatchewan." << endl;
		}
		else if (code == "867")
		{
			cout << "The phone number is located in Yukon, Northwest Territories or Nunavut." << endl;
		}
		else
		{
			cout << "The phone number does not have a Canadian area code.";
			cout << endl;
		}

}

int main()
{
	// User inputs phone number

	char qq;

	cout << "Enter a telephone number in the format ###-###-####: " << endl;

	do
	{
		string phone_number;
		getline(cin, phone_number);

		string code = phone_number.substr(0, 3);

		printValidation(phone_number);
		printCDNareacode(code);

		// Program will continue to process numbers until the user enters the letter q
		cout << "The program will continue to process numbers until 'q' is entered.  Enter another number" << endl;
		cin >> qq;
	}

	while (qq != 'q');

	return 0;
}