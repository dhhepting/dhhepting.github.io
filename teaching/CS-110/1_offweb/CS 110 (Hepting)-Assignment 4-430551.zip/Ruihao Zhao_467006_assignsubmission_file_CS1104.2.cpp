//**************************************************************************
//
// Student name:Ruihao Zhao	
//
// Student number: 200338484	
//
// Assignment number: #4 (part2)
//
// Program name: CS1104.2.cpp
//
// Date written: 25/3/2015
//
// Problem statement: Ask the user to input phone numbers until "q" is entered. Assess each phone number to see if it is valid
// and check if the area code (first 3 digits) is canadian and if it is canadian which province/territory it belongs to
//
// Input: string pnum (phone number)
//
// Output: phone number valid or not, checking if each digit is valid, the area code if the number is valid, and
// where in canada it is from or if it is not from canada
//
// Algorithm1:stringinput:input pnum as a string
//
// Algorithm2:lengthcheck:checking if pnum is 12 characters long
//
// Algorithm3:digitcheck:checking if digits are numbers or hyphens (in the correct spaces)
//
// Algorithm4(datareturnfunction):boolassignedtodigitcheck:if the digits checks are assigned to boolean variables
//
// Algorithm5(void):areacodecheck: use pnum.substr(0,3) to isolate the first three digits/characters(area code) and matches it with canadian area codes or to place it in incorrect category
//
// Major variables: pnum,areacode,pnumber,acode,pnum(1-11) and pnumber(1-11) 
//
// Assumptions:international numbers, should be given to canadian phone users, and they have to use dashes for the input of phone numbers. 
//
// Program limitations:the area code could be non-canadian that exist or non-canadian that do not exist. The code cannot tell them apart
// and cannot list non-canadian existing ones. 
//
//**************************************************************************
#include <iostream>
#include <string>
using namespace std;
int check(string);
void areacodecheck(string);

int main()
{

	string pnum;																//Algorithm1:start & end
	string areacode;
	
	while (pnum != "q")															//Algorithm2: start
	{
		cout << "Please enter a phone number in the form ddd-ddd-dddd\n";
		cin >> pnum;
		if (pnum == "q")
		{
			cout << "You entered q this program will terminate/n";
			break;
		}
		if (pnum.length() != 12)
		{
			cout << "Wrong length\n";
			return 0;
		}																		//Algorithm2:end
		if (check(pnum))
		{
			cout << "Valid phonenumber\n";
			areacode = pnum.substr(0, 3);
			areacodecheck(areacode);
		}
		else
			cout << "Input is invalid\n";
	}
	return 0;
}
int check(string pnumber)														//Algorithm3:start
{								
	if (pnumber[0] >= '0' && pnumber[0] <= '9')
		cout << "first digit is valid" << endl;
	else
		cout << "error first digit is invalid" << endl;
	if (pnumber[1] >= '0' && pnumber[1] <= '9')
		cout << "second digit is valid" << endl;
	else
		cout << "error second digit is invalid" << endl;
	if (pnumber[2] >= '0' && pnumber[2] <= '9')
		cout << "third digit is valid" << endl;
	else
		cout << "error third digit is invalid" << endl;
	if (pnumber[3] == '-')
		cout << "fourth digit is valid" << endl;
	else
		cout << "error fourth digit is invalid" << endl;
	if (pnumber[4] >= '0' && pnumber[4] <= '9')
		cout << "fifth digit is valid" << endl;
	else
		cout << "error fifth digit is invalid" << endl;
	if (pnumber[5] >= '0' && pnumber[5] <= '9')
		cout << "sixth digit is valid" << endl;
	else
		cout << "error sixth digit is invalid" << endl;
	if (pnumber[6] >= '0' && pnumber[6] <= '9')
		cout << "seventh digit is valid" << endl;
	else
		cout << "error seventh digit is invalid" << endl;
	if (pnumber[7] == '-')
		cout << "eighth digit is valid" << endl;
	else
		cout << "error eighth digit is invalid" << endl;
	if (pnumber[8] >= '0' && pnumber[8] <= '9')
		cout << "ninth digit is valid" << endl;
	else
		cout << "error ninth digit is invalid" << endl;
	if (pnumber[9] >= '0' && pnumber[9] <= '9')
		cout << "tenth digit is valid" << endl;
	else
		cout << "error tenth digit is invalid" << endl;
	if (pnumber[10] >= '0' && pnumber[10] <= '9')
		cout << "eleventh digit is valid" << endl;
	else
		cout << "error eleventh digit is invalid" << endl;
	if (pnumber[11] >= '0' && pnumber[11] <= '9')
		cout << "twelfth digit is valid" << endl;
	else
		cout << "error twelfth digit is invalid" << endl;					//Algorithm3:end
	bool length = pnumber.length() == 12;									//Algorithm4:start						
	bool pnum1 = pnumber[0] >= '0' && pnumber[0] <= '9';
	bool pnum2 = pnumber[1] >= '0' && pnumber[1] <= '9';
	bool pnum3 = pnumber[2] >= '0' && pnumber[2] <= '9';
	bool pnum4 = pnumber[3] == '-' && pnumber[3] == '-';
	bool pnum5 = pnumber[4] >= '0' && pnumber[4] <= '9';
	bool pnum6 = pnumber[5] >= '0' && pnumber[5] <= '9';
	bool pnum7 = pnumber[6] >= '0' && pnumber[6] <= '9';
	bool pnum8 = pnumber[7] == '-' && pnumber[7] == '-';
	bool pnum9 = pnumber[8] >= '0' && pnumber[8] <= '9';
	bool pnum10 = pnumber[9] >= '0' && pnumber[9] <= '9';
	bool pnum11 = pnumber[10] >= '0' && pnumber[10] <= '9';
	bool pnum12 = pnumber[11] >= '0' &&pnumber[11] <= '9';
	if (length&&pnum1&&pnum2&&pnum3&&pnum4&&pnum5&&pnum6&&pnum7&&pnum8&&pnum9&&pnum10&&pnum11&&pnum12)
		return 1;
	else
		return 0;															//Algorithm4:end
}																								
void areacodecheck(string acode)											//Algorithm5:start
{
	cout << "The area code is " << acode << endl;
	if (acode == "403" || acode == "587" || acode == "780" || acode == "825")
		cout << "This phone number's area code is from Alberta" << endl;
	else if (acode == "236" || acode == "250" || acode == "604" || acode == "672" || acode == "778")
		cout << "This phone number's area code is from British Columbia" << endl;
	else if (acode == "204" || acode == "431")
		cout << "This phone number's area code is from Manitoba" << endl;
	else if (acode == "506")
		cout << "This phone number's area code is from New Brunswick" << endl;
	else if (acode == "709")
		cout << "This phone number's area code is from Newfoundland and Labrador" << endl;
	else if (acode == "782" || acode == "902")
		cout << "This phone number's area code is from Nova Scotia" << endl;
	else if (acode == "548" || acode == "249" || acode == "289" || acode == "343" || acode == "365" || acode == "387" || acode == "416" || acode == "437" || acode == "519" || acode == "226" || acode == "613" || acode == "647" || acode == "705" || acode == "742" || acode == "807" || acode == "905")
		cout << "This phone number's area code is from Ontario" << endl;
	else if (acode == "782" || acode == "902")
		cout << "This phone number's area code is from Prince Edward Island" << endl;
	else if (acode == "418" || acode == "438" || acode == "450" || acode == "514" || acode == "579" || acode == "581" || acode == "819" || acode == "873")
		cout << "This phone number's area code is from Quebec" << endl;
	else if (acode == "306" || acode == "639")
		cout << "This phone number's area code is from Saskatchewan" << endl;
	else if (acode == "867")
		cout << "This phone number's area code is from Yukon, Northwest Territories, and/or Nunavut" << endl;
	else
		cout << "This phone number's area code is not from Canada" << endl;
	cout << endl;
}																			//Algorithm5:end