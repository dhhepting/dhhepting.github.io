#include <iostream>
using namespace std;


void num(int number)
{
	

	// extract digits
	if (number >= 0 && number <= 10000)
	{
		int digit1 = number % 10;
		number /= 10;
		int digit2 = number % 10;
		number /= 10;
		int digit3  = number % 10;
		number /= 10;
		int digit4 = number % 10;
		number /= 10;
		int digit5 = number % 10;
	
		// get number of digits
		int number_digits = 1;
		if (digit5 > 0)
		{
			number_digits = 5;
		}
		else if (digit4 > 0)
		{
			number_digits = 4;
		}
		else if (digit3 > 0)
		{
			number_digits = 3;
		}
		else if (digit2 > 0)
		{
			number_digits = 2;
		}
		// perform computations -- there is at least 1 digit,
		// so initialize variables with it, even if it is 0
		int sum = digit1;
		int prod = digit1;
	
		int current_digit = 1;
		if (current_digit < number_digits)
		{
			sum += digit2;
			prod *= digit2;
			if (++current_digit < number_digits)
			{
				sum += digit3;
				prod *= digit3;
				if (++current_digit < number_digits)
				{
					sum += digit4;
					prod *= digit4;
					if (++current_digit < number_digits)
					{
						sum += digit5;
						prod *= digit5;
					}
				}
			}
		}
		cout << "Number of digits: " << number_digits << endl;
		cout << "Sum of digits: " << sum << endl;
		cout << "Product of digits: " << prod << endl;
		cout << "Average of digits: " << sum / static_cast<float>(number_digits) << endl;
	}
	else
	{
		cout << "Number not between 0 & 10000, inclusive" << endl;
	}
}

int main ()
{
    int numb;
    cout << "plz enter your number"<<endl;
    cin>>numb;
	num(numb);
	
	return 0;
}
