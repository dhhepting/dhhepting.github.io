// Joseph Egyir
// 200357099
// 25/03/2015
#include <iostream>
using namespace std;

void Canadian(int, int, int);
void Validation(int, int, int);


int main()
{
	int areacode;
	int exchangenumber;
	int subcribernumber;
	
	cout << "Please enter a telephone number in the format ddd-ddd-dddd;" << endl;
	cout << "Where d is a digit and - is a space." << endl;
	cout << endl;
	cin >> areacode >> exchangenumber >> subcribernumber;
	cout << endl;
	Validation(areacode, exchangenumber, subcribernumber);
	 cout << endl;
	 Canadian(areacode, exchangenumber, subcribernumber);
	 cout << endl;
	return 0;
}

void Validation(int a, int b, int c)
{

	if (a >= 0 && a <= 999)
	{
		int digit1 = a % 10;
		a /= 10;
		int digit2 = a % 10;
		a /= 10;
		int digit3 = a % 10;
		a /= 10;


		int number_digits = 1;

		if (digit3 > 0)
		{
			number_digits = 3;
		}
		else if (digit2 > 0)
		{
			number_digits = 2;
		}
		else if (digit1 > 0)
		{
			number_digits = 1;
		}


		if (number_digits = 3)

			cout << "The area code that you have inputed is in a valid format." << endl;
		else
		{
			cout << "The area code that you have inputed is not in a valid format" << endl;
			cout << "Please input a 3 digit number." << endl;
		}
	}
	else
	{
		cout << "The area code that you have inputed is not in a valid format" << endl;
		cout << "Please input a 3 digit number." << endl;
	}
	cout << endl;
	if (b >= 0 && b <= 999)
	{
		int digit1 = b % 10;
		b /= 10;
		int digit2 = b % 10;
		b /= 10;
		int digit3 = b % 10;
		b /= 10;

		int number_digits = 1;

		if (digit3 > 0)
		{
			number_digits = 3;
		}
		else if (digit2 > 0)
		{
			number_digits = 2;
		}
		else if (digit1 > 0)
		{
			number_digits = 1;
		}

		if (number_digits = 3)

			cout << "The exchange number that you have inputed is in a valid format." << endl;
		else
		{
		cout << "The exchange number that you have inputed is not in a valid format" << endl;
		cout << "Please input a 3 digit number." << endl;
	}
}
		else 
		{
			cout << "The exchange number that you have inputed is not in a valid format" << endl;
			cout << "Please input a 3 digit number." << endl;
		}
	cout << endl;
		if (c >= 0 && c <= 9999)
		{
			int digit1 = c % 10;
			c /= 10;
			int digit2 = c % 10;
			c /= 10;
			int digit3 = c % 10;
			c /= 10;
			int digit4 = c % 10;
			c /= 10;


			int number_digits = 1;

			if (digit4 > 0)
			{
				number_digits = 4;
			}
			else if (digit3 > 0)
			{
				number_digits = 3;
			}
			else if (digit2 > 0)
			{
				number_digits = 2;
			}


			if (number_digits = 4)

				cout << "The subscriber number that you have inputed is in a valid format." << endl;
			else
			{
				cout << "The subscriber number that you have inputed is not in a valid format." << endl;
					cout << "Please input a 4 digit number." << endl;
			}
		}
		else
		{
			cout << "The subscriber number that you have inputed is not in a valid format." << endl;
			cout << "Please input a 4 digit number." << endl;
		}
		return;
	
}





	void Canadian(int a, int b, int c)

	{

		if (a == 403 || a == 587 || a == 780 || a == 825)
			cout << "The telephone number " << a << "-" << b << "-" << c << " is from Alberta, Canada." << endl;

		else if (a == 236 || a == 250 || a == 604 || a == 672 || a == 778)
			cout << "The telephone number " << a << "-" << b << "-" << c << " is from British Columbia, Canada." << endl;

		else if (a == 204 || a == 431)
			cout << "The telephone number " << a << "-" << b << "-" << c << " is from Manitoba, Canada." << endl;

		else if (a == 506)
			cout << "The telephone number " << a << "-" << b << "-" << c << " is from Newfoundland and Labrador, Canada." << endl;

		else if (a == 548 || a == 249 || a == 289 || a == 343 || a == 365 || a == 387 || a == 416 || a == 437 || a == 519 || a == 226 || a == 613 || a == 705 || a == 742 || a == 807 || a == 905)
			cout << "The telephone number " << a << "-" << b << "-" << c << " is from Ontario, Canada." << endl;

		else if (a == 782 || a == 902)
			cout << "The telephone number " << a << "-" << b << "-" << c << " is from Nova Scotia, Canada  or Prince Edward Island, Canada." << endl;

		else if (a == 418 || a == 438 || a == 450 || a == 514 || a == 579 || a == 581 || a == 819 || a == 873)

			cout << "The telephone number " << a << "-" << b << "-" << c << " is from Quebec, Canada." << endl;

		else if (a == 306 || a == 639)
		{
			cout << "The telephone number " << a << "-" << b << "-" << c << " is from Saskactchewan, Canada." << endl;
		}
		else if (a == 867)
		{
			cout << "The telephone number " << a << "-" << b << "-" << c << " is from Yukon, Northwest Territories, or Nunavut, Canada." << endl;
		}
		else
			cout << "This telephone number is not valid in Canada. Please enter a valid number." << endl;
		return;
	}