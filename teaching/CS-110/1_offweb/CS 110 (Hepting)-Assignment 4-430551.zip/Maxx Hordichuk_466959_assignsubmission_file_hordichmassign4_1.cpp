// Name: Maxx Hordichuk
// Student #: 200353849
// Assignment: 4.1
// Program Name: Maxx's Calculator
// Date Written: 03/25/15
/* Problem: Modify Assignment 1 code so that the calculations it does are located within a function. 
The main() function that calls this function should let the user input any desired about of numbers, until a negative number is input. */
// Input: A number (number1)
// Output: Number of digits, sum of digits, average of digits, product of digits.
/* Algorithm: Receive number > Identify size of number > Display number of digits >
Calculate each individual digit > Calculate sum of digits > Display sum of digits >
Determine size of number > Divide sum by the number of digits (given by size) > Display average of digits >
Determine size of number > Multiply digits based on size of number > Display product of digits. */
// Major variables: number1, numbersum, dig1, dig2, dig3, dig4, dig5
// Assumptions: User will not input a six digit number.
// Limitations: Cannot correctly compute output for 6 digit integers.

#include <iostream>
using namespace std;

// Functions defined.

int numofdig(int);
void sumofdig(int&, int&, int&, int&, int&, int&, int&);
int aveofdig(int, int, int);
void prodofdig(int&, int&, int&, int&, int&, int&, int&);

int main()

{

    int number1;
    int dig1;
    int dig2;
    int dig3;
    int dig4;
    int dig5;
    int numbersum = 0;
    int aofd = 0;
    int pofd;

    cout << "Enter an integer between 0 and 10000: ";
    cin >> number1;

do {   
    
    // PART A - Number of Digits

    numofdig(number1);
    
    cout << "Number of digits: " << numofdig(number1) << endl;

    // PART B - Sum of Digits

    sumofdig(number1, dig1, dig2, dig3, dig4, dig5, numbersum);
    
    cout << "Sum of digits: " << numbersum << endl;

    // PART C - Average of Digits

    cout << "Average of digits: " << aveofdig(number1, numbersum, aofd) << endl;
    
    // PART D

    prodofdig(number1, dig1, dig2, dig3, dig4, dig5, pofd);
    
    cout << "Product of digits: " << pofd << endl;

    cout << "Enter an integer between 0 and 10000: ";
    
    cin >> number1;
   
// Accept input until input is negative.
    
} while (number1 > 0);

return 0;

}

// PART A - Function

int numofdig(int number1)
{

if (number1 >= (10000)){
        return 5;
    }

    if (number1 <= 9999 && number1 >= 1000){
        return 4;
    }

    if (number1 <= 999 && number1 >= 100){
        return 3;
    }

    if (number1 <= 99 && number1 >= 10){
        return 2;
    }

    if (number1 <10){
        return 1;
    }    

}

// PART B - Function

void sumofdig(int& number1, int& dig1, int& dig2, int& dig3, int& dig4, int& dig5, int& numbersum)
    
{    
    dig1 = number1 % 10;

    dig2 = (number1 % 100 - dig1) / 10;

    dig3 = (number1 % 1000 - dig1 - dig2) / 100;

    dig4 = (number1 % 10000 - dig1 - dig2 - dig3) / 1000;

    dig5 = (number1 % 100000 - dig1 - dig2 - dig3 - dig4) / 10000; // Determines each digit.

    numbersum = (dig1 + dig2 + dig3 + dig4 + dig5);
    
}

// PART C - Function

int aveofdig(int number1, int numbersum, int aofd)
{

if (number1 >= (10000)){
        aofd = numbersum / 5;
    }

    if (number1 <= 9999 && number1 >= 1000){
        aofd = numbersum / 4;
    }

    if (number1 <= 999 && number1 >= 100){
    aofd = numbersum / 3;
    }

    if (number1 <= 99 && number1 >= 10){
        aofd = numbersum / 2;
    }

    if (number1 <10){
        aofd = numbersum / 1;
    }

return aofd;

}

// PART D - Function

void prodofdig(int& number1, int& dig1, int& dig2, int& dig3, int& dig4, int& dig5, int& pofd)
    
{
    if (number1 >= (10000)){
        
        pofd = dig1*dig2*dig3*dig4*dig5;

    }

    if (number1 <= 9999 && number1 >= 1000){
        
        pofd = dig1*dig2*dig3*dig4;
    }

    if (number1 <= 999 && number1 >= 100){
        
        pofd = dig1*dig2*dig3;
    }

    if (number1 <= 99 && number1 >= 10){
        
        pofd = dig1*dig2;
    }

    if (number1 <10){
        
        pofd = dig1;
    }
}