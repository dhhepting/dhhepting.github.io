//**************************************************************************
//
// Student name: Emmanuella Akobundu
//
// Student number: 200359057
//
// Assignment number: 2
//
// Program name: Integer reader
//
// Date written: 25th March, 2015
//
// Problem statement: The program is aimed at reading the digits contained in a number from 0 to 10000 entered by the user.
//					  The code then proceeds to calculate and display the number of digits, the sum of the digits, 
//					  the average of the digits, and the product of the digits.
//
// Input: The user is expected to input an integer between 0 and 10000 (inclusive).
//
// Output: The output should display the number of digits, the sum of the digits, the average of the digits, 
//		   and the product of the digits on the screen.
//
// Algorithm: In order to solve the assigned problem, The code uses the function computeNumber to calculate the number of digits, 
//			  the sum of the digits, the average of the digits, and the product of the digits,and these are all displayed on the screen.	    
//			  The program is terminated when the user enters a negative number.
//			  Within the function, the computer is instructed to first ensure that the number entered by the user satisfies the condition 
//			  that it must be between 0 and 10000 by using nested if statements. 
//			  Thereafter, the modulus function in order to separate the digits of the inputed number. If statements are 
//			  incorporated in the code again in order to find the number of digits contained in the number. 
//			  After this, the sum of digits is found by adding all the digits together; the average of the digits is found 
//			  by dividing the sum of digits by the number of digits. And lastly, the product of the digits is found by 
//			  multiplying all of the digits together depending on how many digits there are (using numDigits). 
//			  The results are finally outputed to the screen in the main function.
//
// Major variables: The highly important variables include: num, numDigits, sumDigits, aveDigits, prodDigits (where n ranges from 1 to 5), 
//					numDigits, and sumDigits.
//
// Assumptions: The only assumption noted is that the user inputs a number ranging from 0 to 10000.
//
// Program limitations:	None
//
//**************************************************************************

#include <iostream>
using namespace std;

// Function Prototype
void computeNumber(int&, int&, int&, float&, int&);

// Main Function
int main()
{
	int num, numDigits, sumDigits, prodDigits;
	float aveDigits;

	cout << "Enter an integer from 0 to 10000: ";
	cin >> num;

	while (num > 0)
	{
		if (num >= 0 && num <= 10000)
		{
			computeNumber(num, numDigits, sumDigits, aveDigits, prodDigits);

			cout << "Number of digits: " << numDigits << endl;
			cout << "Sum of digits: " << sumDigits << endl;
			cout << "Product of digits: " << prodDigits << endl;
			cout << "Average of digits: " << aveDigits << endl;
		}
		else
			cout << "Number not between 0 & 10000, inclusive" << endl;

	}
	return 0;
}

void computeNumber(int& number, int& number_digits, int& sum, float& ave, int& prod)
{

	// extract digits
	int digit1 = number % 10;
	number /= 10;
	int digit2 = number % 10;
	number /= 10;
	int digit3 = number % 10;
	number /= 10;
	int digit4 = number % 10;
	number /= 10;
	int digit5 = number % 10;


	// get number of digits
	number_digits;

	if (digit1 >= 0)
	{
		number_digits = 1;
	}
	if (digit2 > 0)
	{
		number_digits = 2;
	}
	if (digit3 > 0)
	{
		number_digits = 3;
	}
	if (digit4 > 0)
	{
		number_digits = 4;
	}
	if (digit5 > 0)
	{
		number_digits = 5;
	}

	// find the sum of digits.
	sum = digit1 + digit2 + digit3 + digit4 + digit5;

	// find the avergae of the digits.
	ave = static_cast<float>(sum / number_digits);

	//To find the product of the digits.
	prod;
	if (number_digits == 1)
	{
		prod = digit1;
	}
	if (number_digits == 2)
	{
		prod = digit1 * digit2;
	}
	if (number_digits == 3)
	{
		prod = digit1 * digit2 * digit3;
	}
	if (number_digits == 4)
	{
		prod = digit1 * digit2 * digit3 * digit4;
	}
	if (number_digits == 5)
	{
		prod = digit1 * digit2 * digit3 * digit4 * digit5;
	}

}
