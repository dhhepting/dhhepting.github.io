/*
Gabriel Tiegen
200351654
Assignment 4-1

January 28, 2015
Problem: To take an integer between 0 and 10 000, and give:
- The length of the integer
- The sum of all digits
- The average of the digits
- The product of the digits
Input:
- A value between 0 and 10 000
Output:
- See Problem
Algorithm:
Length:
- Converts 'numin' to a string in a seperate variable in able to call '.length' This allows for easy access to the length of the number

Separating digits:
- Each digit is found by using % 10, giving the number in the ones place
- The number is divided by ten to shift all digits one decimal place down
- The process repeats for however many digits there are, given by 'len'

Sum:
- Adds all digits found together.

Average:
- Adds all digits together and divides, based on length in order to not divide by any unnecessary zeroes that may exist in 'dig5' for example.

Product:

Variables:
Contained at the start of the executable section of the program.
Major variables include:
- numin  -  Contains the user's input
- len    -  Holds the number of digits that are in the number
- sum    -  Holds the sum of the digits
- avg    -  Holds the average of the digits
- prod   -  The final product of the digits
- done   -  Variable that keeps the program looping until it evaluates to 1
Assumptions:

Program Limitations:
- When a letter is input, the program becomes stuck in an infinite loop
- Only allows numbers from 0 to 10 000, though it could easily be expanded
*/

#include <iostream>
#include <string>
using namespace std;

int numin;																													//All of the variables are declared here, and will be explained further on
float dig1;
float dig2;
float dig3;
float dig4;
float dig5;
int temp;
string templen;
int len;
int sum;
float avg;																													//The variable "avg" is a float variable so that it can contain decimal places.
int prod;
int first = 1;
int done = 0;
void calcnum(int);


int main()
{
	while (done != 1){																										//This keeps the program looping until the user tells it to stop
		if (first == 1)																										//Will only display the first time, once the user loops the program
		{																													//this section will not run since the var "first" is set to 0
			cout << "This program will take integers between 0 and 10,000 and give back information about them until a negative number is input." << endl;
			first = 0;
		}
		cout << "Please enter a number:" << endl;
		cin >> numin;																										//Takes the user's input
		if (numin > 10000)
		{
			cout << "Did you enter a number outside of the parameters? Please try again." << endl;							//If the user input a number outside of the range 0 to 10 000
		}																													//the program will loop, and wont calculate the number
		else if (numin < 0)
		{
			cout << "A negative number has been input. We will now close." << endl;
			cin >> done;
			break;
		}
		else if ((numin >= 0) && (numin <= 10000))
		{
			calcnum(numin);

		}
		else																												//If, somehow, the user inputted something other than numbers,																											//the program will display this error message and loop.
		{																													//the program will display this error message and loop.
			cout << "There was a problem with your input. Please try again." << endl;
		}
	}
}


void calcnum(int num){


	templen = to_string(num);																						//Sets a placeholder variable "templen" to the string value of "num".
	len = templen.length();																							//This allows the .length to be called in order to find the number of digits
																													//in the user's number with minimal effort.

	dig1 = (num % 10);																							//Modulo will determine what number is in the ones place
	temp = (num / 10);																							//Dividing by ten will get rid of the digit we have already found

	if (len > 1)																									//If the "numin" variable is at least 2 digits in length,
	{																												//it will find the second digit, now in the ones place.
		dig2 = (temp % 10);
		temp = (temp / 10);
	}
	if (len > 2)																									//The process repeats for every digit that is in "numin"
	{																												//These lines will only execute if the number is long enough.
		dig3 = (temp % 10);
		temp = (temp / 10);
	}
	if (len > 3)
	{
		dig4 = (temp % 10);
		temp = (temp / 10);
	}
	if (len > 4)
	{
		dig5 = (temp % 10);
		temp = (temp / 10);
	}

	sum = (dig1 + dig2 + dig3 + dig4 + dig5);																		//Takes the sum of all the digits found, and stores it in "sum"
	if (len == 1) {																									//This section will take the average of all the digits. It needs to check
		prod = dig1;																								//The length so that any ending 0's aren't counted, and so that it can divide by the right number
		avg = dig1;
	}
	if (len == 2) {
		prod = (dig1 * dig2);
		avg = (dig1 + dig2) / 2;
	}
	if (len == 3) {
		prod = (dig1 * dig2 * dig3);
		avg = (dig1 + dig2 + dig3) / 3;
	}
	if (len == 4) {
		prod = (dig1 * dig2 * dig3 * dig4);
		avg = (dig1 + dig2 + dig3 + dig4) / 4;
	}
	if (len == 5) {
		prod = (dig1 * dig2 * dig3 * dig4 * dig5);
		avg = (dig1 + dig2 + dig3 + dig4 + dig5) / 5;
	}

	cout << "The length is: " << len << endl;																		//This section just spits out all of the values found
	cout << "The sum of the digits is: " << sum << endl;
	cout << "The product of the digits is: " << prod << endl;
	cout << "The average of the digits is: " << avg << endl;
	dig1 = 0;  dig2 = 0;  dig3 = 0;  dig4 = 0;  dig5 = 0;
}