// Nandha Bijumon
// 200355253
// march 25th, 2015
// assignment 4

#include <iostream>
using namespace std;

void recognize(int, int, int);

int main()
{
	int areacode;
	int exchangenumber;
	int subcribernumber;

	cout << "Please enter a telephone number in the format ddd-ddd-dddd, where d is a digit and - is a space" << endl;
	cin >> areacode >> exchangenumber >> subcribernumber;


	recognize(areacode, exchangenumber, subcribernumber);

	return 0;
}

void recognize(int areacode, int exchangenumber, int subcribernumber)
{
	if (areacode == 403 || areacode == 587 || areacode == 780 || areacode == 825)
		cout << " The telephone number " << areacode << "-" << exchangenumber << "-" << subcribernumber << " is from Alberta" << endl;

	else if (areacode == 236 || areacode == 250 || areacode == 604 || areacode == 672 || areacode == 778)
		cout << "The telephone number " << areacode << "-" << exchangenumber << "-" << subcribernumber << " is from British Columbia" << endl;

	else if (areacode == 204 || areacode == 431)
		cout << "The telephone number " << areacode << "-" << exchangenumber << "-" << subcribernumber << " is from Manitoba" << endl;

	else if (areacode == 506)
		cout << "The telephone number " << areacode << "-" << exchangenumber << "-" << subcribernumber << " is from Newfoundland and Labrador" << endl;

	else if (areacode == 548 || areacode == 249 || areacode == 289 || areacode == 343 || areacode == 365 || areacode == 387 || areacode == 416 || areacode == 437 || areacode == 519 || areacode == 226 || areacode == 613 || areacode == 705 || areacode == 742 || areacode == 807 || areacode == 905)
		cout << "The telephone number " << areacode << "-" << exchangenumber << "-" << subcribernumber << " is from Ontario" << endl;

	else if (areacode == 782 || areacode == 902)
		cout << "The telephone number " << areacode << "-" << exchangenumber << "-" << subcribernumber << " is from Nova Scotia or Prince Edward Island" << endl;

	else if (areacode == 418 || areacode == 438 || areacode == 450 || areacode == 514 || areacode == 579 || areacode == 581 || areacode == 819 || areacode == 873)
		cout << "The telephone number " << areacode << "-" << exchangenumber << "-" << subcribernumber << " is from Quebec" << endl;

	else if (areacode == 306 || areacode == 639)
		cout << "The telephone number " << areacode << "-" << exchangenumber << "-" << subcribernumber << " is from Saskactchewan" << endl;

	else if (areacode == 867)
		cout << "The telephone number " << areacode << "-" << exchangenumber << "-" << subcribernumber << " is from Yukon, Northwest Territories, or Nunavut	" << endl;
	else
		cout << "telephone number is not valid in Canada. Please enter a valid number" << endl;
}