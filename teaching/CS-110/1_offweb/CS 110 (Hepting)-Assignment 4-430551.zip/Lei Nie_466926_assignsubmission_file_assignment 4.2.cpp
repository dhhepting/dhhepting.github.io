
#include <iostream>
#include <string>
using namespace std;
void Getnumber(string&);
bool checknumber(string);
string placenumber(string);


void Getnumber(string& telno)
{
	cout << "Enter phone number ddd-ddd-dddd" << endl;
	cin >> telno;
}

bool checknumber(string telno)
{
	bool proper_format = true;
		// make use of loops here :-)
	if (telno.length() == 12) // proper length
	{
		for (int i = 0; i < 12; i++)
		{
			if (i == 3 || i == 7)
			{
				if (telno[i] != '-')
				{
					proper_format = false;
				}
			}
			else
			{
				if (!isdigit(telno[i]))
				{
					proper_format = false;
				}
			}
		}
	}
	else
		proper_format = false;

	return proper_format;
}
	

string placenumber(string telno)
{
	bool proper_format=true;
	if (proper_format)
	{
		string area_code = telno.substr(0, 3);
		string region = "Outside of Canada";
		// Alberta:	403, 587, 780, 825
		if (area_code == "403" ||
			area_code == "587" ||
			area_code == "780" ||
			area_code == "825")
		{
			region = "Alberta";
		}
		// British Columbia	236, 250, 604, 672, 778
		else if (area_code == "236" ||
			area_code == "250" ||
			area_code == "604" ||
			area_code == "672" ||
			area_code == "778")
		{
			region = "British Columbia";
		}
		// Manitoba	204, 431
		else if (area_code == "204" ||
			area_code == "431")
		{
			region = "Manitoba";
		}
		// New Brunswick	506
		else if (area_code == "506")
		{
			region = "New Brunswick";
		}
		// Newfoundland and Labrador	709
		else if (area_code == "709")
		{
			region = "Newfoundland and Labrador ";
		}
		// Nova Scotia	782, 902
		else if (area_code == "782" ||
			area_code == "902")
		{
			region = "Nova Scotia";
		}
		// Ontario	548, 249, 289, 343, 365, 387, 416, 437, 
		//		519, 226, 613, 647, 705, 742, 807, 905
		else if (area_code == "548" ||
			area_code == "249" ||
			area_code == "289" ||
			area_code == "343" ||
			area_code == "365" ||
			area_code == "387" ||
			area_code == "416" ||
			area_code == "437" ||
			area_code == "519" ||
			area_code == "226" ||
			area_code == "613" ||
			area_code == "647" ||
			area_code == "705" ||
			area_code == "742" ||
			area_code == "807" ||
			area_code == "905")
		{
			region = "Ontario";
		}
		// Prince Edward Island	782, 902
		else if (area_code == "782" ||
			area_code == "902")
		{
			region = "Prince Edward Island";
		}
		// Quebec	418, 438, 450, 514, 579, 581, 819, 873
		if (area_code == "418" ||
			area_code == "438" ||
			area_code == "450" ||
			area_code == "514" ||
			area_code == "579" ||
			area_code == "581" ||
			area_code == "819" ||
			area_code == "873")
		{
			region = "Quebec";
		}
		// Saskatchewan	306, 639
		if (area_code == "306" ||
			area_code == "639")
		{
			region = "Saskatchewan";
		}
		//Yukon, Northwest Territories, and Nunavut	867
		else if (area_code == "867")
		{
			region = "Yukon, Northwest Territories, and Nunavut";
		}

		return region;
	}
}
		

int main()
{
	string number;
	bool check;
	
	while (number[0] != 'q')
	{	
		
			Getnumber(number);
			check=checknumber(number);
			if (check == true)
			{
				string Region = placenumber(number);
				cout << "Number appears to be from: " << Region << endl;
			}
			else
				cout << "please enter right phone number" << endl;
		
	}


}
