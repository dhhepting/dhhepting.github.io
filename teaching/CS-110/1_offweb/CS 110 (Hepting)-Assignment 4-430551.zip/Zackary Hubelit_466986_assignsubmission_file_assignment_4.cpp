/*

Student Name: Zackary Hubelit

Student Number: 200351286

Assignment Number: 1

Program Name: Integer Reader

Date Write: March 23th/15 - Jan. 31st/15

Problem Statement: Tells user information based on the input

Input: User inputs an integer between 0 and 10000

Output: Program outputs the number of digits in the integer, sum of the digits, product of the digits, and average of the digits.

Algorithm: uses modulus, addition, multiplication, and division

Major Variables: d1 - d5, input, sum, product, avg, digits

Assumptions: user knows not to input letters and only inputs integers

Program Limitations: program cannot handle integers greater than int can hold (ie. 999999999)

*/

#include <iostream>
#include <iomanip>

using namespace std;

int input;
int d1, d2, d3, d4, d5;
int digits;
float sum;
float avg;
int product;
char choice;

float GetSum(int, int, int, int, int);
float GetAvg(float, int);
int GetProduct(int, int, int, int, int, int);

int main()
{
	do
	{

	do
	{
		cout << "Please input an integer between 0 and 10000: ";
		cin >> input;
		if (input < 0)
			{
				cout << "That number is too small!" << endl;
			}
	
		if (input > 10000)
			{
				cout << "That number is too big!" << endl;
			}
	}
	while (input < 0 || input > 10000);

	cout << "The integer you chose was " << input << "." << endl;

	//finding digits 1 through 5

	d1 = input%10;
	input = input/10;
	d2 = input%10;
	input = input/10;
	d3 = input%10;
	input = input/10;
	d4 = input%10;
	input = input/10;
	d5 = input%10;

	//setting number of digits

	if (d1 > 0)
	{
		digits = 1;
	}

	if (d2 > 0)
	{
		digits = 2;
	}

	if (d3 > 0)
	{
		digits = 3;
	}

	if (d4 > 0)
	{
		digits = 4;
	}

	if (d5 > 0)
	{
		digits = 5;
	}

	//setting product
	product = GetProduct(d1, d2, d3, d4, d5, digits);

	/*if (digits == 1)
	{
		product = d1;
	}

	if (digits == 2)
	{
		product = d1*d2;
	}

	if (digits == 3)
	{
		product = d1*d2*d3;
	}

	if (digits == 4)
	{
		product = d1*d2*d3*d4;
	}

	if (digits == 5)
	{
		product = d1*d2*d3*d4*d5;
	}*/

	//finding sum and average

	sum = GetSum(d1, d2, d3, d4, d5);
	avg = GetAvg(sum, digits);

	//sum = d1 + d2 + d3 + d4 + d5;
	//avg = sum / digits;

	cout << "Number of digits: " << digits << endl;
	cout << "Sum of digits: " << sum << endl;
	cout << "Average of the digits: " << setprecision(2) << avg << endl;
	cout << "Product of the digits: " << product << endl;

	//asks the user if they want to enter another number

	cout << "Would you like to enter another number? (Y/N): ";
	cin >> choice;
	}
	while (choice != 'n');

	return 0;
}

float GetSum(float digit1, float digit2, float digit3, float digit4, float digit5)
{
	float sum = digit1 + digit2 + digit3 + digit4 + digit5;

	return sum;
}

float GetAvg(float sum1, int dig)
{
	float avg = sum1/dig;

	return avg;
}

int GetProduct(float digit1, float digit2, float digit3, float digit4, float digit5, int numDigits)
{
	int product;

	if (numDigits == 5)
	{
		product = digit1*digit2*digit3*digit4*digit5;
	}

	else if (numDigits == 4)
	{
		product = digit1*digit2*digit3*digit4;
	}

	else if (numDigits == 3)
	{
		product = digit1*digit2*digit3;
	}

	else if (numDigits == 2)
	{
		product = digit1*digit2;
	}

	else
	{
		product = digit1;
	}

	return product;
}