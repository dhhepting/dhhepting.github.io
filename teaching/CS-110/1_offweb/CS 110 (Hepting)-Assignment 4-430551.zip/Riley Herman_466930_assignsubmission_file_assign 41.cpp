/*
Riley Herman
200352833
Assignment 4
Functional Number Functions
March 25/2015
Problem: "Modify Assignment 1 code so that the calculations it does are located within a function. The main() function 
that calls this function should let the user input any desired about of numbers, until a negative number is input."
Input: an integer between 0 and 10000 inclusive
Output: the number of digits, the sum of those digits, the product of those digits, and the average of the digits
Algorithm: The program starts by taking in a number, and tests to see if it is a valid input. Then calls value returning 
functions to compute the number of digits, the sum of those digits, the product of those digits, and the average of the 
digits. It then displays the result. 
Major Variables: input, numberofdigits, sumofdigits, productofdigits, averageofdigits, originput1, originput2, originput3, 
sumdig, numdig.
Assumptions: The user inputs an integer, the program runs errorlessly
Program Limitations: The program is limited to numbers between 0 and 10000 inclusive, as well as only the number of digits, 
the sum of those digits, the product of those digits, and the average of the digits in the number.
*/
#include <iostream>															// include the input and output streams

using namespace std;														// using a standard namespace

int NUMDIGIT(int);															// function prototypes: need to initialize the functions.
int SUMDIGIT(int);															//		the functions are named according to what they compute.
int PRODIGIT(int);															//		the "int"s in parenthesis are the types of variables 
double AVEDIGIT(int, int);													//		the arguments take on.

int main()																	// beginning the main function
{
	while (true)															// infinte loop; only exits when it hits the return 0 after the 
	{																		//		user inputs a negative number.
		cout << "Hey, you should enter a number, and I'll tell you some stuff about it.\n";
		cout << "To quit, just enter a negative number.\n";					// prompt user for input
		int input;															// declare the variable for the user's input
		cin >> input;														// input the variable

		while (input > 10000)												// until the user inputs a number less than 10000, run the code 
		{																	//		which will reintake another input
			cout << "That's not quite right... Try again. \n";
			cin >> input;
		}
		
		if (input < 0)														// the way in which the user exits the program is whe they input
		{																	//		a negative number. This checks that every time the infinite
			cout << "Fine. I see how it is. Bye.\n";						//		loop runs.
			return 0;
		}

		int numberofdigits = NUMDIGIT(input);								// function calls: the numberofdigits, sumofdigits, productofdigits, and 
		int sumofdigits = SUMDIGIT(input);									//		averageofdigits variables are assigned to the values returned 
		int productofdigits = PRODIGIT(input);								//		by the functions which are called here.
		double averageofdigits = AVEDIGIT(sumofdigits, numberofdigits);

		cout << "Number of digits: " << numberofdigits << endl;				// the values which are computed by the functions are printed here
		cout << "Sum of digits: " << sumofdigits << endl;
		cout << "Product of digits: " << productofdigits << endl;
		cout << "Average of digits: " << averageofdigits << endl << endl;
	}
}

int NUMDIGIT(int originput1)												// The beginnning (function definition) of the function which 
{																			//		calculates the number of digits in the given number.
	if (originput1 < 10)													//		the originput1 variable is created and is linked to the 
		return 1;															//		input variable in the function call above.
	else if (originput1 >= 10 && originput1 < 100)							// these if, else if, and else statements will return different
		return 2;															//		values (the number of digits) depending on how large 
	else if (originput1 >= 100 && originput1 < 1000)						//		the inputted value is
		return 3;
	else if (originput1 >= 1000 && originput1 < 10000)
		return 4;
	else																	// The only other possibilty is that te number is 10000, which has 5 digits
		return 5;
}

int SUMDIGIT(int originput2)												// The function defintion of the function which computes the 
{																			//		sum of the digits, which has the parameter originput2
	int sumdig = 0;															//		(that corresponds to the input variable)
	while (originput2 > 0)													// This loop cuts the ones decimal place one by one until there
	{																		//		are no more numbers left. Each cut number is systematically 
		sumdig += originput2 % 10;											//		added to the total sum.
		originput2 /= 10;
	}
	return sumdig;															// return the computed value of sumdig (sum of digits) to the function call
}

int PRODIGIT(int originput3)												// This function (which computes the product of all of the digits)
{																			//		is quite similar to the above function, with the exception of 
	int prodig = 1;															//		variable names and the multiplication operation in the loop 
	while (originput3 > 0)													//		and the starting value of prodig being 1.
	{
		prodig *= originput3 % 10;
		originput3 /= 10;
	}
	return prodig;
}

double AVEDIGIT(int sumdig, int numdig)										// This function will return the average, which is computed using the sum 
{																			//		of the digits and the number of digits (computed above)
	return (static_cast<double>(sumdig) / numdig);							//		It then returns that value.
}