//*****************************************************************
//
// Student name: Stephanie Thompson
//
// Student number: 200355041
//
// Assignment number: Assignmnet 4 - Part 2
//
// Program name: Area Code Tester
//
// Date written: March 25, 2015
//
// Problem statement: The user needs to know the province or territory of Canada that that area code applies to.
//
// Input: The user will input a phone number to find where in Canada the number belongs to, or the letter Q if they wish to close the program.
//
// Output: The program will output a message to prompt the user to enter a phone number.  After testing the areacode the program will display what Canadian province
//				or territory the areacode belongs to.
//
// Algorithm: The program will first prompt the user to enter a ten digit phone number with a certain format.  Once the number is entered the program will
//				test if the value is equal to Q (if it is the program will close).  If the input does not equal Q the program will enter a loop.  Inside the loop are
//				a series of if statements.  If the format of the number is correct (tested in a seperate function) the program will open another function that ouputs where the
//				areacode belongs to.  If the format is not correct it will display an error message.  The first function will test for the correct format including length, dashes, and letters.
//				At the end of the loop the user will be asked to input another number or if they want to quit the program.
//
// Major variables: The major variables in the program include phonenumber, result, quit, and areacode.
//
// Assumptions: The user will only input Canadian phone numbers.
//
// Program limitations: The program will only be able to tell the area code of a province or territory of Canada (any area codes outside of Canada cannot be assigned to a state,
//							province, territory, etc.) that is entered with a phone number.
//
//*******************************************************************************
#include <iostream>
#include <string>
using namespace std;

bool validnumbercheck(string);
void Areacode(string);

int main()
{
	// Initializing variables
	string phonenumber;

	// Prompting the user to enter a phone number
	cout << "Please enter a ten digit phone number in the form ddd-ddd-dddd where d is a digit.  If you wish to close the program press the letter 'Q'." << endl;
	cin >> phonenumber;

	// Initializing variables
	bool result = validnumbercheck(phonenumber); // Calls the function to check the format of the input
	string quit = phonenumber.substr(0, 1);

	// Starts a loop
	while (quit != "Q")
	{
		result = validnumbercheck(phonenumber);
		if (result)
		{
			string areacode = phonenumber.substr(0, 3); // Assigns a variable to the first three characters of the phone number (separates the areacode from the rest of the number)
			Areacode(areacode); // Calls the function to check the code
		}
		if (!result)
		{
			cout << "That number is invalid." << endl; // Displays an error message if the phone number is not in the right format
		}
		cout << "Please enter a ten digit phone number in the form ddd-ddd-dddd where d is a digit.  If you wish to close the program press the letter 'Q'." << endl;
		cin >> phonenumber;
		quit = phonenumber.substr(0, 1); // Assigns the first value of the input to a variable to test if the user wants to quit the program
	} // End of loop

	cout << "Thank you." << endl;

	return 0;
}

// Function to check the format of the number
bool validnumbercheck(string num)
{
	// Initializing variables that check the format
	string dash1;
	string dash2;
	string digit1;
	string digit2;
	string digit3;
	string digit4;
	string digit5;
	string digit6;
	string digit7;
	string digit8;
	string digit9;
	string digit10;
	bool isvalid = true;

	if (num.length() == 12) // Tests the format of the users input
	{
		dash1 = num.substr(3, 1);
		dash2 = num.substr(7, 1);
		digit1 = num.substr(0, 1);
		digit2 = num.substr(1, 1);
		digit3 = num.substr(2, 1);
		digit4 = num.substr(4, 1);
		digit5 = num.substr(5, 1);
		digit6 = num.substr(6, 1);
		digit7 = num.substr(8, 1);
		digit8 = num.substr(9, 1);
		digit9 = num.substr(10, 1);
		digit10 = num.substr(11, 1);

		if (dash1 == "-" && dash2 == "-" && digit1 >= "0" && digit1 <= "9" && digit2 >= "0" && digit2 <= "9" && digit3 >= "0" && digit3 <= "9" && digit4 >= "0" && digit4 <= "9" && digit5 >= "0" && digit5 <= "9" && digit6 >= "0" && digit6 <= "9" && digit7 >= "0" && digit7 <= "9" && digit8 >= "0" && digit8 <= "9" && digit9 >= "0" && digit9 <= "9" && digit10 >= "0" && digit10 <= "9") // Tests the format of the users input (for dashes and letters)
		{
			isvalid = true;
		}
		else
		{
			isvalid = false;
		}
	}
	else
	{
		isvalid = false;
	}

	return isvalid; // Returns if the format is valid to the main function
}

// Function to connect the areacode to the province or territory
void Areacode(string areacode)
{
	// Tests the area code of the phone number and displays the province or territory it belongs to
	if (areacode == "403" || areacode == "587" || areacode == "780" || areacode == "825")
	{
		cout << "The area code of the phone number you have entered belongs to Alberta." << endl;
	}
	if (areacode == "236" || areacode == "250" || areacode == "604" || areacode == "672" || areacode == "778")
	{
		cout << "The area code of the phone number you have entered belongs to British Columbia." << endl;
	}
	if (areacode == "204" || areacode == "431")
	{
		cout << "The area code of the phone number you have entered belongs to Manitoba." << endl;
	}
	if (areacode == "506")
	{
		cout << "The area code of the phone number you have entered belongs to Newfoundland and Labrador." << endl;
	}
	if (areacode == "782" || areacode == "902")
	{
		cout << "The area code of the phone number you have entered belongs to Nova Scotia." << endl;
	}
	if (areacode == "548" || areacode == "249" || areacode == "289" || areacode == "343" || areacode == "365" || areacode == "387" || areacode == "416" ||
		areacode == "437" || areacode == "519" || areacode == "226" || areacode == "613" || areacode == "647" || areacode == "705" || areacode == "742" || areacode == "807" || areacode == "905")
	{
		cout << "The area code of the phone number you have entered belongs to Ontario." << endl;
	}
	if (areacode == "789" || areacode == "902")
	{
		cout << "The area code of the phone number you have entered belongs to Prince Edward Island." << endl;
	}
	if (areacode == "418" || areacode == "438" || areacode == "450" || areacode == "514" || areacode == "579" || areacode == "581" || areacode == "819" || areacode == "873")
	{
		cout << "The area code of the phone number you have entered belongs to Quebec." << endl;
	}
	if (areacode == "306" || areacode == "639")
	{
		cout << "The area code of the phone number you have entered belongs to Saskatchewan." << endl;
	}
	if (areacode == "867")
	{
		cout << "The area code of the phone number you have entered belongs to the Yukon, Northwest Territories, and Nunavut." << endl;
	}
	if (areacode != "403" && areacode != "587" && areacode != "780" && areacode != "825" && areacode != "236" && areacode != "250" && areacode != "604" && areacode != "672" && areacode != "778" && areacode != "204" && areacode != "431" && areacode != "506" && areacode != "782" && areacode != "902" && areacode != "548" && areacode != "249" && areacode != "289" && areacode != "343" && areacode != "365" && areacode != "387" && areacode != "416" &&
		areacode != "437" && areacode != "519" && areacode != "226" && areacode != "613" && areacode != "647" && areacode != "705" && areacode != "742" && areacode != "807" && areacode != "905" && areacode != "789" && areacode != "902" && areacode != "418" && areacode != "438" && areacode != "450" && areacode != "514" && areacode != "579" && areacode != "581" && areacode != "819" && areacode != "873" && areacode != "306" && areacode != "639" && areacode != "867")
	{
		cout << "The area code of the phone number you have entered does not belong to a Canadian province or territory." << endl;
	}
}