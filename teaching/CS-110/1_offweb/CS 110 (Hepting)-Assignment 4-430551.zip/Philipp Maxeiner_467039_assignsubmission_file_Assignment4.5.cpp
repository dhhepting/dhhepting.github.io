/*
Student name: Philipp Maxeiner
Student number: 200343181
Assignment number: 4
Program name: Area Code detector
Date Written: March 2015
Problem Statement: Determine the north american area code that a user inputs
Input: Some telephone number in the form of (ddd-ddd-dddd)
Output: Output the province from which the area code originates
Algorithm: A loop style program that performs the task until the user enters 'q'
Major Variables: telNum, code
Assumptions: The user will enter a North American telephone number
Program Limitations: The prgram will only be able to comprehend area codes from Canada
*/

#include <iostream>
#include <string>
using namespace std;
int main()

{
// We want this program to act as a conditional loop
// When the user enters 'q', the program should close
// Declare 'q' as false
bool q = false;
while (true)
{
// Declare telNum a string

string telNum;

// Request input from user

cout << "Please enter a phone number from Canada/North America (ddd-ddd-dddd): " << endl;

cin >> telNum;

// Test input to determine if it is valid

if (telNum.length() == 12)

	cout << "Valid North American telephone number has been entered." << endl;

else if (telNum.length() != 12)

	cout << "Invalid phone number." << endl;



// Determine the first three variables in the string

// The first three will always be the area code

string aCode = telNum.substr(0,3);



// Determine which province the area code is from

if (aCode == "403" || aCode == "587" || aCode == "780" || aCode == "825")

    cout << "Alberta" << endl;

if (aCode == "236" || aCode == "250" || aCode == "604" || aCode == "672" || aCode == "778")

    cout << "British Columbia" << endl;

if (aCode == "204" || aCode == "431")

    cout << "Manitoba" << endl;

if (aCode == "506")

    cout << "New Brunswick" << endl;

if (aCode == "709")

    cout << "Newfoundland and Labrador" << endl;

if (aCode == "782" || aCode == "902")

    cout << "Nova Scotia" << endl;

if (aCode == "548" || aCode == "249" || aCode == "289" || aCode == "343" || aCode == "365")

    cout << "Ontario" << endl;

if (aCode == "387" || aCode == "416" || aCode == "437" || aCode == "519" || aCode == "226")

    cout << "Ontario" << endl;

if (aCode == "613" || aCode == "647" || aCode == "705" || aCode == "742" || aCode == "807" || aCode == "905")

    cout << "Ontario" << endl;

if (aCode == "782" || aCode == "902")

    cout << "Prince Edward Island" << endl;

if (aCode == "418" || aCode == "438" || aCode == "450" || aCode == "514" || aCode == "579")

    cout << "Quebec" << endl;

if (aCode == "581" || aCode == "819" || aCode == "873")
    cout << "Quebec" << endl;

if (aCode == "306" || aCode == "639")

    cout << "Saskatchewan" << endl;

if (aCode == "867")

    cout << "Yukon, Northwest Territories, and Nunavut" << endl;




return 0;
}
}