//**************************************************************************
//
// Student name: Linda Kuruvila
//
// Student number: 200354184
//
// Assignment number: 4
//
// Program name: Integer reader
//
// Date written: March 25, 2015
//
// Problem statement: The program is aimed at reading the digits contained in a number from 0 to 10000 entered by the user.
//					  The code then proceeds to calculate and display the number of digits, the sum of the digits, 
//					  the average of the digits, and the product of the digits.
//
// Input: The user will input an integer between 0 and 10000 
// Output: The output displays the number of digits, the sum of the digits, the average of the digits, 
//		   and the product of the digits.
//
// Algorithm: The number is entered by the user until he/she satisfies the condition that it must be between 0 and 10000 by using nested if statements.
//			  Modulus function is used to separate the digits of the inputed number. If statements are being used to find the number of digits existing in the number. 
//			  The sum of digits is done by adding all the digits and the average of the digits is calculated 
//			  by dividing the sum of digits by the number of digits. The product of the digits is calculated by 
//			  multiplying all of the digits. 
//			 
// Major variables: digittotal, sumtotal, averagetotal, producttotal 
//
// Assumptions: The only assumption noted is that the user inputs a number ranging from 0 to 10000.
//
// Program limitations:	The program runs until a negative number is inputted.
//
//**************************************************************************

#include <iostream>
using namespace std;

int digittotal(int);// function prototype
int sumtotal(int);
int averagetotal(int);
int producttotal(int);

int main()
{
	cout << "Enter a number between 0-10000 " << endl << endl;
	int number;
	cin >> number;

	if (number < 0 || number > 10000)
	{
		cout << "not valid " << endl << endl;
	}
	else
	{
		cout << "Number of digits: " << digittotal(number) << endl << endl;
		cout << "Sum of digits: " << sumtotal(number) << endl << endl;
		cout << "Average of digits: " << averagetotal(number) << endl << endl;
		cout << "Product of digits: " << producttotal(number) << endl << endl;
	}
	while (number >= 0)
	{
		cout << "Enter a number between 0-10000 " << endl << endl;
		int number;
		cin >> number;
		if (number < 0 || number>10000)
			break;
		cout << "Number of digits: " << digittotal(number) << endl << endl;
		cout << "Sum of digits: " << sumtotal(number) << endl << endl;
		cout << "Average of digits: " << averagetotal(number) << endl << endl;
		cout << "Product of digits: " << producttotal(number) << endl << endl;
	}
	return 0;
}
//function definition
int digittotal(int number)
{
	int digit1 = 0;
	int digit2 = 0;
	int digit3 = 0;
	int digit4 = 0;
	int digit5 = 0;
	int numberOfDigit2;
	int sum = 0;
	int average = 0;
    int product = 0;

	if (number >= 0 && number <= 10000)
	{
		digit1 = number % 10;
		number /= 10;
		digit2 = number % 10;
		number /= 10;
		digit3 = number % 10;
		number /= 10;
		digit4 = number % 10;
		number /= 10;
		digit5 = number % 10;
		number /= 10;
		if (digit5 > 0)
		{
			numberOfDigit2 = 5;
		}
		if (digit4 >= 0 && digit5 == 0)
		{
			numberOfDigit2 = 4;
		}
		if (digit3 >= 0 && digit4 == 0 && digit5 == 0)
		{
			numberOfDigit2 = 3;
		}
		if (digit2 >= 0 && digit3 == 0 && digit4 == 0 && digit5 == 0)
		{
			numberOfDigit2 = 2;
		}
		if (digit1 >= 0 && digit2 == 0 && digit3 == 0 && digit4 == 0 && digit5 == 0)
		{
			numberOfDigit2 = 1;
		}
	}
	return numberOfDigit2;
}
int sumtotal(int number)
{
	int sum;
	int digit1 = 0;
	int digit2 = 0;
	int digit3 = 0;
	int digit4 = 0;
	int digit5 = 0;

	digit1 = number % 10;
	number /= 10;
	digit2 = number % 10;
	number /= 10;
	digit3 = number % 10;
	number /= 10;
	digit4 = number % 10;
	number /= 10;
	digit5 = number % 10;
	number /= 10;
	if (digit5 > 0)
	{
		sum = digit1 + digit2 + digit3 + digit4 + digit5;
	}
	if (digit4 >= 0 && digit5 == 0)
	{
		sum = digit1 + digit2 + digit3 + digit4;
	}
	if (digit3 >= 0 && digit4 == 0 && digit5 == 0)
	{
		sum = digit1 + digit2 + digit3;
	}
	if (digit2 >= 0 && digit3 == 0 && digit4 == 0 && digit5 == 0)
	{
		sum = digit1 + digit2;
	}
	if (digit1 >= 0 && digit2 == 0 && digit3 == 0 && digit4 == 0 && digit5 == 0)
	{
		sum = digit1;
	}
	return sum;
}

int averagetotal(int number)

{
	int average2;
	int digit1 = 0;
	int digit2 = 0;
	int digit3 = 0;
	int digit4 = 0;
	int digit5 = 0;
	int numberOfDigit = 0;
	int sum = 0;
	int average = 0;

	if (number >= 0 && number <= 10000)
	{
		digit1 = number % 10;
		number /= 10;
		digit2 = number % 10;
		number /= 10;
		digit3 = number % 10;
		number /= 10;
		digit4 = number % 10;
		number /= 10;
		digit5 = number % 10;
		number /= 10;
		if (digit5 >0)
		{
			numberOfDigit = 5;
			sum = digit1 + digit2 + digit3 + digit4 + digit5;
			average2 = sum / numberOfDigit;
		}
		if (digit4 >= 0 && digit5 == 0)
		{
			numberOfDigit = 4;
			sum = digit1 + digit2 + digit3 + digit4;
			average2 = sum / numberOfDigit;
		}
		if (digit3 >= 0 && digit4 == 0 && digit5 == 0)
		{
			numberOfDigit = 3;
			sum = digit1 + digit2 + digit3;
			average2 = sum / numberOfDigit;
		}
		if (digit2 >= 0 && digit3 == 0 && digit4 == 0 && digit5 == 0)
		{
			numberOfDigit = 2;
			sum = digit1 + digit2;
			average2 = sum / numberOfDigit;
		}
		if (digit1 >= 0 && digit2 == 0 && digit3 == 0 && digit4 == 0 && digit5 == 0)
		{
			average2 = digit1;
		}
	}
	return average2;
}
int producttotal(int number)
{
	int product2;
	int digit1 = 0;
	int digit2 = 0;
	int digit3 = 0;
	int digit4 = 0;
	int digit5 = 0;
	int numberOfDigit = 0;
	int sum = 0;
	int average = 0;

	digit1 = number % 10;
	number /= 10;
	digit2 = number % 10;
	number /= 10;
	digit3 = number % 10;
	number /= 10;
	digit4 = number % 10;
	number /= 10;
	digit5 = number % 10;
	number /= 10;
	if (digit5 >0)
	{
		product2 = digit1*digit2*digit3*digit4*digit5;
	}
	if (digit4 >= 0 && digit5 == 0)
	{
		product2 = digit1*digit2*digit3*digit4;
	}
	if (digit3 >= 0 && digit4 == 0 && digit5 == 0)
	{
		product2 = digit1*digit2*digit3;
	}
	if (digit2 >= 0 && digit3 == 0 && digit4 == 0 && digit5 == 0)
	{
		product2 = digit1*digit2;
	}
	if (digit1 >= 0 && digit2 == 0 && digit3 == 0 && digit4 == 0 && digit5 == 0)
	{
		product2 = digit1;
	}
	return product2;
}
