//**************************************************************************
//
// Student name: Ruihao Zhao	
//
// Student number: 200338484	
//
// Assignment number: #4 (part 1)
//
// Program name: CS1104.1
//
// Date written: 25/3/2015
//
// Problem statement: input an integer from 0-10000 and find out # of digits, sum, average and product (continue til a negative number is inputted)
//
// Input: a number from 0-10000 (or repeat unless it is negative)
//
// Output: # of digits, sum, average and product
//
// Algorithm1:Input Checking: To ensure that the input is between 0-10000, I made an if else statement and if the input activated the else function then the code would return 0; or close
// 
// Algorithm2:Digit Finder: The next part is to give each digit a numerical value. To do this I used the modulus and divion operators. Firstly I used modulus to find the value of the digit on the ones digit.
// then i divided the number by 10 and multiples of ten to find the desired digit's value. 
//
// Algorithm3:Displaying Number of Digits: I went from left to right checking the value of the largest digit and the first digit that is not one causes the code to output that digit's place as the number of digits.
// as well it gives a way to output a response to 0.
//
// Algorithm4:Sum and average: summing was simple as all I had to do was add all the values of the digits together (even if they were 0), however for the average I had to elimate the same way as displaying the number
// of digits by checking left to right and dividing by the number of digits that way.
//
// Algorithm5:Product: Product was similar to averaging and displaying number of digits. Start with the largest digit value that was not 0 and then multiply all the values after that. 
//
// Algorithm6:Looping: until negative is inputted 
//
// Major variables: num, average, length, sum, prod, and x.
//
// Assumptions: only whole numbers and only between 0-10000
//
// Program limitations: cannot do any numbers outside the range of 0-10000
//
//**************************************************************************
#include <iostream>
using namespace std;
void Digs(int);
int main()
{
	int num;
	do 
	{																//Algorithm6:start
		cout << "Please input a number from 0-10000\n";
		cin >> num;
		if (num >= 0 && num <= 10000)								//Algorithm1:start
			Digs(num);
		else
		{
			cout << "You entered an invalid number\n\n";
			continue;
		}															//Algorithm1:end
	} while (num >= 0);
	return 0;
}
void Digs(int x)
{
	int length = 0, sum = 0, prod = 1;
	double average, lengthcalc;
	int a[5];
	while (x > 0)
	{
		a[length] = x % 10;											//Algorithm2:start
		x /= 10;
		length++;
	}																//Algorithm2:end	
	cout << "This integer has " << length << " digits " << endl;	//Algorithm3:start //Algorithm3:end
	for (int i = 0; i<length; i++)
	{
		if (a[i] == 0)
			continue;
		sum += a[i];												//Algorithm4:start	//Algorithm4:end
		prod*= a[i];												//Algorithm5:start	//Algorithm5:end
		
	}
	lengthcalc = length;
	average = sum / lengthcalc;
	if (lengthcalc == 0)
		average =0;
	if (average == 0)
		prod = 0; 
	cout << "The sum of these digits is: " << sum << endl;
	cout << "The average of these digits is:" << average << endl;
	cout << "The product of these digits is:" << prod << endl << endl;
}																	//Algorithm6:end

