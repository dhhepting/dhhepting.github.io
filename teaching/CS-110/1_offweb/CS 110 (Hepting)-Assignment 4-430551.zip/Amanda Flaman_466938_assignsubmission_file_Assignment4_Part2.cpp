//**************************************************************************
//
// Student name: Amanda Flaman
//
// Student number: 200340561
//
// Assignment number: 4
//
// Program name: Assignment4_Part2.cpp
//
// Date written: March 25/2015
//
// Problem statement:  a program that asks the user for a phone number of 
// certain format and take the first 3 digits of that phonenumber and tells 
// which province the area code belongs to or if the area code does not belong 
// to a Canadian province. If the phone number entered is not in the correct 
// format then the program will tell the user "wrong format" and if the user 
// wants to quit the program they press 'q'.
//
// Input: Phone Number
//
// Output: The province that the area code belongs to (if any).
//
// Algorithm: Before main there are 2 prototypes to functions: one to test the format of
// the phone number entered and another to test where the area code is from. Ask user to
// enter a phone number of the format ddd-ddd-dddd. Then the program calls a function and
// goes to the function which uses a bool statement to test if the phone number is in the
// ddd-ddd-dddd format. Once that function is complete the program goes back to the main
// function where, if format is correct, it will come to another function call which leads
// to a function that tests if the area code is from Canada or not.A while loop is used 
// in the second function so that phone numbers can be entered continually. The program 
// then gives the option to press 'q'. If the user presses 'q' the program quits.
//
// Major variables: telno, proper_format, proper, number, area_code, region
//
// Assumptions: The user is entering numbers and not letters
//
// Program limitations: It doesn't tell area codes for places outside of Canada
//
//**************************************************************************
#include <iostream>
#include <string>
using namespace std;

bool is_format_correct(string);
void AREACODE(string);


int main()
{
	cout << "Enter phone number ddd-ddd-dddd" << endl;
	string telno;
	cin >> telno;
	while (telno[0] != 'q')
	{
		
		bool proper_format = is_format_correct(telno);
		
		if (proper_format == true)
		{
			AREACODE(telno);
		}
		else 
		{
			cout << "Number not in proper format" << endl;
		}
	
		
		cout << "Enter phone number ddd-ddd-dddd" << endl;
		cin >> telno;
	}
		
	return 0;
}

bool is_format_correct(string number)
{
    bool proper = false;
    
    if (number.length() == 12) // proper length
	{
		// make use of loops here :-)
		proper = true;
		for (int i = 0;i < 12; i++)
		{
			if (i == 3 || i == 7)
			{
				if (number[i] != '-')
				{
					proper = false;
				}
			}
			else
			{
				if (!isdigit(number[i]))
				{
					proper = false;
				}
			}
		}
	}
	return proper; 
}

void AREACODE(string number)
{
    string area_code = number.substr(0,3);
				string region = "Outside of Canada";
				// Alberta:	403, 587, 780, 825
				if (area_code == "403" || 
				    area_code == "587" ||
				    area_code == "780" ||
				    area_code == "825")
				{
					region = "Alberta";
				}		
				// British Columbia	236, 250, 604, 672, 778
				else if (area_code == "236" || 
				         area_code == "250" ||
				    	 area_code == "604" ||
				    	 area_code == "672" ||
				     	 area_code == "778")
				{
					region = "British Columbia";
				}		
				// Manitoba	204, 431
				else if (area_code == "204" || 
				         area_code == "431")
				{
					region = "Manitoba";
				}		
				// New Brunswick	506
				else if (area_code == "506")
				{
					region = "New Brunswick";
				}		
				// Newfoundland and Labrador	709
				else if (area_code == "709")
				{
					region = "Newfoundland and Labrador ";
				}		
				// Nova Scotia	782, 902
				else if (area_code == "782" || 
				    	 area_code == "902")
				{
					region = "Nova Scotia";
				}		
				// Ontario	548, 249, 289, 343, 365, 387, 416, 437, 
				//		519, 226, 613, 647, 705, 742, 807, 905
				else if (area_code == "548" || 
				         area_code == "249" ||
				         area_code == "289" ||
				         area_code == "343" ||
				         area_code == "365" ||
				         area_code == "387" ||
				         area_code == "416" ||
				         area_code == "437" ||
				         area_code == "519" ||
				         area_code == "226" ||
				         area_code == "613" ||
				         area_code == "647" ||
				         area_code == "705" ||
				         area_code == "742" ||
				         area_code == "807" ||
				         area_code == "905")
				{
					region = "Ontario";
				}		
				// Prince Edward Island	782, 902
				else if (area_code == "782" || 
				         area_code == "902")
				{
					region = "Prince Edward Island";
				}		
				// Quebec	418, 438, 450, 514, 579, 581, 819, 873
				if (area_code == "418" || 
				    area_code == "438" ||
				    area_code == "450" ||
				    area_code == "514" ||
				    area_code == "579" ||
				    area_code == "581" ||
				    area_code == "819" ||
				    area_code == "873")
				{
					region = "Quebec";
				}		
				// Saskatchewan	306, 639
				if (area_code == "306" || 
				    area_code == "639")
				{
					region = "Saskatchewan";
				}		
				//Yukon, Northwest Territories, and Nunavut	867
				else if (area_code == "867")
				{
					region = "Yukon, Northwest Territories, and Nunavut";
				}		
				cout << "Number appears to be from: " << region << endl;
}
