//**************************************************************************
//
// Student name: Caleb Foster
//
// Student number: 200354226
//
// Assignment number: 4
//
// Program name: Part1
//
// Date written: March 25, 2015
//
// Problem statement:  a program that reads an integer between 0 and 10000 and
// then calculates and displays the number of digits and the sum, average, and
// product of all the digits
//
// Input: Number
//
// Output: Number of digits, Sum of digits, Average of digits, Product of digits
//
// Algorithm: The program uses four prototypes to call functions. First it asks the user
// to enter a number between 0 and 10000. A while loop is used to see if the program
// should continue or not: it will quit if the user enters a negative number. Then it uses
// % 10 to test how many digits are in the user�s input. A function is then called to tell
// the user how many digits are in the number. After that another function call leads the
// program to a function that calculates and tells the user the product of the digits in
// the number by use if statements. Then the program returns to the main function and
// another function calls for the calculation of the sum of all the digits in the number
// by simply adding them. After returning to the main function, it is then called for a
// final time to determine the average of all the digits in the number by dividing the sum
// by the number of digits. The program outputs all of the calculations and then
// terminates.
//
// Major variables: number, digit1, digit2, digit3, digit4, numdigits, sumdig, proddigits, average, a, b, c, d, num, sum, numdig, prodig, avg
//
// Assumptions: The user will enter an integer and not a letter.
//
// Program limitations: It doesn't divide the digits and doesn't deal with decimal numbers.
//
//**************************************************************************

#include <iostream>

using namespace std;

int DIGITS(int, int, int, int, int);
int PRODUCT(int, int, int, int);
int SUM(int, int, int, int);
float AVERAGE(int, int);


int main()
{
	int number;
	int digit1;
	int digit2;
	int digit3;
	int digit4;
	int numdigits;
	int sumdig;
	int proddigits;
	float average;


	number = 1;

	while (number > 0)
	{
		cout << "Please enter an integer between 0 and 10000: ";
		cin >> number;

		if (number < 0)
			cout << "Finished." << endl;

		else if (number < 10000)
		{
			digit1 = number % 10;
			number /= 10;
			digit2 = number % 10;
			number /= 10;
			digit3 = number % 10;
			number /= 10;
			digit4 = number % 10;

			numdigits = DIGITS(digit1, digit2, digit3, digit4, number);
			cout << "number of digits: " << numdigits << endl;

			proddigits = PRODUCT(digit1, digit2, digit3, digit4);
			cout << "Product of all the digits: " << proddigits << endl;

			sumdig = SUM(digit1, digit2, digit3, digit4);
			cout << "Sum of digits: " << sumdig << endl;

			average = AVERAGE(sumdig, numdigits);
			cout << "Average of all the digits: " << average << endl;

		}
		else
		{
			cout << "That number is too big!" << endl;
		}
	}
	return 0;
}

int DIGITS(int a, int b, int c, int d, int num)
{
	int numdig;
	numdig = 0;

	if (a > 0)
	{
		numdig = 1;
	}
	if (b > 0)
	{
		numdig = 2;

	}
	if (c > 0)
	{
		numdig = 3;

	}
	if (d > 0)
	{
		numdig = 4;
	}

	return numdig;
}
int PRODUCT(int a, int b, int c, int d)
{
	int proddig = 0;
	if (a > 0)
	{
		proddig = a;
	}
	if (b > 0)
	{
		proddig = a * b;
	}
	if (c > 0)
	{
		proddig = a * b * c;

	}
	if (d > 0)
	{
		proddig = a * b * c * d;
	}
	return proddig;
}
int SUM(int a, int b, int c, int d)
{
	int sum = a + b + c + d;
	return sum;
}
float AVERAGE(int sum, int numdig)
{
	float avg = sum / float(numdig);
	return avg;
}
