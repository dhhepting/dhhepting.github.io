//**************************************************************************
//
// Student name: Brayden Tang
//
// Student number: 200350623
//
// Assignment number: 4 
//
// Program name: Determining where a phone number orginates from in Canada after inputted in the format "ddd-ddd-dddd" where d is a digit using functions
//
// Date written: March 21st, 2015
//
// Problem statement: Write a program that prompts the user to enter a telephone number in the format ddd-ddd-dddd, where d is digit. This is the format for telephone numbers in North America. Test that the input is in the correct format and further check if the phone number has a Canadian area code (see the list of Canadian area codes). The program will report if the input is valid or not. If the input includes a Canadian area code, the program will display the name of the province or territory with that area code. The program will continue to process numbers until the user enters the letter q.
//Use one function to check validation of input and use another function to display where the area code originates from.
// Input: A telephone number in the format ddd-ddd-dddd where d is a digit, and char C or q (though q can be any value) to reenter or discontinue the loop respectively.
//
// Output: The validity of the inputted telephone number format, and if valid, the area (based on the area code from the telephone number) from which the number originates in Canada, or not depending on whether the inputted area code is from Canada/contains actual numbers and no letters.
//
// Algorithm: A combination of strings and functions of strings such as substr and .length and .at to check the validity of the string itself and to obtain the area code from the inputted string, and then if and else if statements to determine where the telephone number originates from. There are two loops, one which determines the validity of the inputted value and the other which determines if the user wants to continue processing telephone numbers.
//
// Major variables: continueLOOP, telephoneNUMBER, telephoneAREACODE
//
// Assumptions: That the user actually enters a area code coming from Canada or at least enters an area code that exists.
//
// Program limitations: Area codes out of Canada, or area codes that do not exist cannot be interpreted very well with this program.
//
//**************************************************************************


#include <iostream>
#include <string>
using namespace std;

bool ValidateInput(string telephone)  //this will check if the phone number is in a valid input. Will return either true or false depending on if they meet the requirements.

{
	if ((telephone.length() == 12) && (telephone[3] == '-') && (telephone[7] == '-') && (telephone[0] >= '0' && telephone[0] <= '9') && (telephone[1] >= '0' && telephone[1] <= '9') && (telephone[2] >= '0' && telephone[2] <= '9') && (telephone[4] >= '0' && telephone[4] <= '9') && (telephone[5] >= '0' && telephone[5] <= '9') && (telephone[6] >= '0' && telephone[6] <= '9') && (telephone[8] >= '0' && telephone[8] <= '9') && (telephone[9] >= '0' && telephone[9] <= '9') && (telephone[10] >= '0' && telephone[10] <= '9') && (telephone[11] >= '0' && telephone[11] <= '9'))  //the conditions that a correctly formatted telephone number would have. 
	{
		return true;  //if all of the above conditions are met, return true
	}
	else   //otherwise, return false since if not every condition is met we know we have an invalid input
	{
		return false;
	}
}


void PrintLocation(string telephone_number)  //this function will simply out the location from which the area code originates from
{
	string telephoneAREACODE = (telephone_number.substr(0, 3));  //obtain the substring of the area code

	if (telephoneAREACODE == "403" || telephoneAREACODE == "587" || telephoneAREACODE == "780")     //through a series of basic if and else if statements we can then determine where the phone number orginated from. I divided the if and else if statements by the area codes. Note that some provinces have multiple area codes, and Prince Edward Island and Nova Scotia have the exact same pair of area codes despite being two different provinces. I seperated them for clarity.
	{
		cout << "The phone number comes from the province of Alberta." << endl;
	}
	else if (telephoneAREACODE == "236" || telephoneAREACODE == "250" || telephoneAREACODE == "604")
	{
		cout << "The phone number comes from the province of British Columbia." << endl;
	}
	else if (telephoneAREACODE == "204" || telephoneAREACODE == "431")
	{
		cout << "The phone number comes from the province of Manitoba." << endl;
	}
	else if (telephoneAREACODE == "506")
	{
		cout << "The phone number comes from the province of New Brunswick." << endl;
	}
	else if (telephoneAREACODE == "709")
	{
		cout << "The phone number comes from the province of Newfoundland and Labrador." << endl;
	}
	else if (telephoneAREACODE == "782" || telephoneAREACODE == "902")
	{
		cout << "The phone number comes from the province of Nova Scotia or Prince Edward Island." << endl;
	}
	else if (telephoneAREACODE == "548" || telephoneAREACODE == "249" || telephoneAREACODE == "289" || telephoneAREACODE == "343" || telephoneAREACODE == "365" || telephoneAREACODE == "416" || telephoneAREACODE == "437" || telephoneAREACODE == "519" || telephoneAREACODE == "226" || telephoneAREACODE == "613" || telephoneAREACODE == "647" || telephoneAREACODE == "705" || telephoneAREACODE == "807" || telephoneAREACODE == "905")
	{
		cout << "The phone number comes from the province of Ontario." << endl;
	}
	else if (telephoneAREACODE == "782" || telephoneAREACODE == "902")
	{
		cout << "The phone number comes from the province of Prince Edward Island or Nova Scotia." << endl;
	}
	else if (telephoneAREACODE == "418" || telephoneAREACODE == "438" || telephoneAREACODE == "450" || telephoneAREACODE == "514" || telephoneAREACODE == "579" || telephoneAREACODE == "581" || telephoneAREACODE == "819" || telephoneAREACODE == "873")
	{
		cout << "The phone number comes from the province of Quebec." << endl;
	}
	else if (telephoneAREACODE == "306" || telephoneAREACODE == "639")
	{
		cout << "The phone number comes from the province of Saskatchewan." << endl;
	}
	else if (telephoneAREACODE == "867")   //unique area code in the fact that this one area code represents three different territories
	{
		cout << "The phone number comes from the territory of Yukon, Northwest Territories, or Nunavut." << endl;
	}
	else
	{
		cout << "Invalid phone number (area code does not exist) or the phone number does not come from Canada." << endl;  //obviously area codes from out of country are still valid, they just aren't in the country. The area code may also not exist in the world.
	}

}

int main()

{
	string telephoneNUMBER;    //declaration of all variables used in the main function
	int isTRUE;
	char control = 'Y';  //initialize loop at Y so the user enters the loop at least once
	while (control != 'q')   //if the user enters q, the loop will quit. Any other letter and the loop will continue.
	{
		cout << "Input a Canadian phone number in the format ddd-ddd-dddd where d is a digit." << endl;
		cin >> telephoneNUMBER;
		isTRUE = ValidateInput(telephoneNUMBER);
		while (isTRUE != 1)  //ie. if true is returned since 1= true, 0=false
		{
			cout << "The telephone number is in an invalid format. Try again." << endl;  //display user that invalidity of input. The user will be promted to enter another number and it will then be reevaluated.
			cin >> telephoneNUMBER;
			isTRUE = ValidateInput(telephoneNUMBER);
		}
		cout << "Valid format. " << endl;  //display valid format if the user gets through the loop
		PrintLocation(telephoneNUMBER);  //call the PrintLocation function to print the area code of the telephone if the entered telephone number is in a correct format.
		cout << "Do you want to continue processing telephone numbers? Enter any letter for yes and enter q to quit the program. " << endl;
		cin >> control;  //ask the user if they want to continue processing digits. If they don't, then the loop will exit and the program will exit.

	}
	cout << "Goodbye. " << endl; //display to the user goodbye signalling the end of the program

	return 0;
}

//end of program

