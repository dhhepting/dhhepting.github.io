//**************************************************************************
//
// Student name: Riley Peters
//
// Student number: 200 354 249
//
// Assignment number: #4 - Part 1
//
// Program name: Integer Analysis
//
// Date written: March 19th, 2015
//
// Problem statement: To have a program give the requested information on the number input by the user and repeat till a negative number is input
//
// Input: a number between 1-10000
//
// Output: # of digits, sum of digits, average of digits, product of digits
//
// Algorithm: input number -> while repeats while input is above zero -> check that the number is below 10000 -> call function to do calculations -> output reads digits, calculates sums from values of each digit, calculates average of digits, and reads product.
//
// Major variables: input number, number of digits, each place value (tenthousands, thousands, hundreds, tens, ones), sum, average, and product
//
// Assumptions: assuming decimals are not considered
//
// Program limitations: won't consider decimal points
//
//**************************************************************************


#include <iostream>
using namespace std;

void Calc(double&, int&, double&, double&, double&); /* Function Prototype */

int main()

{
    // Setting the Variables
    double number = 0;
    int digits;
    double product, sum, average;
    
    // Introduction and Input
    cout << "Welcome to assignment 1!" << endl;
    cout << "This program will analyze a number between 1-10000." << endl;
    cout << "It will continue till a negative number is input." << endl;
    
    // While statement to repeat until negative input
    while (number >= 0)
    {
        cout << "Input your number: ";
        cin >> number;
        cout << endl;
        
        // Check for negative to break the loop
        if(number < 0)
        {
            cout << "You entered a negative number to exit the program." << endl;
            break;
        }
        
        // Ensure number is 10000 or less
        while (number > 10000)
        {
            cout << "Enter a number between 0-10000" << endl;
            cin >> number;
        }
        
        cout << "Your number is: " << number << endl;
            
        // Call Fuction
        Calc(number, digits, sum, average, product);
            
        // Output of information
        cout << endl;
        cout << "Number of digits: " << digits << endl;
        cout << "Sum of digits: " << sum << endl;
        cout << "Average of digits: " << average << endl;
        cout << "Product of digits: " << product << endl;
        cout << endl;
        
    }
    return 0;
}

// Function making calculations
void Calc(double& num, int& dig, double& sum, double& av, double& prod)

{
    // Finding digits
    int tentho = num/10000;
    int tho = (static_cast<int>(num) % 10000) / 1000;
    int hund = (static_cast<int>(num) % 1000) / 100;
    int tens = (static_cast<int>(num) % 100) / 10;
    int ones = (static_cast<int>(num) % 10);
    
    // Setting digits and product
    if (num==10000)
        {dig = 5;
        prod = tentho*tho*hund*tens*ones;}
    else if (num >= 1000)
        {dig = 4;
        prod = tho*hund*tens*ones;}
    else if (num >= 100)
        {dig = 3;
        prod = hund*tens*ones;}
    else if (num >= 10)
        {dig = 2;
        prod = tens*ones;}
    else if (num >=0)
        {dig = 1;
        prod = ones;}
    
    //Sum
    sum = tentho + tho + hund + tens + ones;
    // Average
    av = (tentho+tho+hund+tens+ones)/static_cast<double>(dig);
    
}
