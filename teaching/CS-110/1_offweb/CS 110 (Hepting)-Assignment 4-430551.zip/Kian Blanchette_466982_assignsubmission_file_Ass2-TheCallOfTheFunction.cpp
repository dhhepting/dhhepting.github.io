// Kian Blanchette
// 200354600
// Assignment 4
// Ass2-TheCallOfTheFunction
// 20 March 2015
// Problem Statement: Modify assignment 2 so that the format check and area code check are done with functions.
// Input: The user enters a phone number in the format ddd-ddd-dddd, where d is an integer.
// Output: The province or territory the phone number is from, if applicable, or a statement telling the user she didn't enter the number in the correct format.
// Algorithm: First, the program takes a string input from the user and determines its area code. Next, the function FormatCheck is called to check if the number
//            entered is in the correct format. If it is it proceeds to check if the area code is from a Canadian province or territory. The program loops until
//			  the user enters q.
// Major Variables: number - What the user enters as input.
//					areaCode - The first three characters of 'number.'
// Assumptions: There are not really any assumptions being made, since the program deals with any possible wrong input.
// Program Limitations: The program only tells if your phone number is from a province or territory in Canada or a different country with the same format for
//						telephone numbers, though it doesn't specify any other countries.
#include <iostream>
#include <string> // For string functions
using namespace std;

bool FormatCheck(string); // Function prototypes
void AreaCodeCheck(string);
int main()
{
	string number; // Prompt the user to enter phone numbers in the correct format until she enters q.
	cout << "Please input a phone number in the form 'ddd-ddd-dddd' where the 'd' are\nintegers. When you no longer wish to enter phone numbers, enter 'q' to exit." << endl;
	do
	{
		getline(cin, number, '\n'); // Enter a phone number. Use getline so that if the user enters something like "Head Cheese" it only displays the output once.
		string areaCode = number.substr(0, 3); // Declare the other variable, areaCode, to be the first three characters of number.
		
		FormatCheck(number); // Call the function FormatCheck to determine if the number is in the correct format.
		
		if (FormatCheck(number)) // If the number is the proper format, call the function AreaCodeCheck.
		{
			AreaCodeCheck(areaCode);
		}
		else if (number != "q") cout << "What you have entered is not in the correct format." << endl; // If the format is wrong, display this message.
					
	} while (number != "q"); //This loop keeps the program going until the user enters 'q.'
	
	return 0;
}
bool FormatCheck(string num) //This function takes the string object the user enters and tests its format. It does so by first testing if the number is the proper
{							//length, which is twelve characters long. If it is the correct length, it then tests if the number has hyphens at positions 3 and 7 and
	bool form = false;		//integers between 0 and 9 in all other positions. At the beginning of the function a variable 'form' is initialized at 0. If the number
	if (num.length() == 12) //is the proper form, 'form' is incremented to 1. The value of 'form' is returned to main at the end of the function.
	{
		if (num[0] >= '0' && num[0] <= '9' && num[1] >= '0' && num[1] <= '9' && num[2] >= '0' && num[2] <= '9' && num[3] == '-'
			&& num[4] >= '0' && num[4] <= '9' && num[5] >= '0' && num[5] <= '9' && num[6] >= '0' && num[6] <= '9' && num[7] == '-'
			&& num[8] >= '0' && num[8] <= '9' && num[9] >= '0' && num[9] <= '9' && num[10] >= '0' && num[10] <= '9' && num[11] >= '0'
			&& num[11] <= '9')
		{
			form = true;
		}
	}
	return form;
}
void AreaCodeCheck(string areaCode) //This function takes the string object, areaCode, from main and tests it to see if it has the same sequence of characters as any
{									//of the area codes in Canada. If it does it prints out which province or territory it's from. 
	if (areaCode == "403" || areaCode == "587" || areaCode == "780" || areaCode == "825")
		cout << "This phone number is from Alberta." << endl;
	else if (areaCode == "236" || areaCode == "250" || areaCode == "604" || areaCode == "672" || areaCode == "778")
		cout << "This phone number is from British Columbia." << endl;
	else if (areaCode == "204" || areaCode == "431")
		cout << "This phone number is from Manitoba." << endl;
	else if (areaCode == "506")
		cout << "This phone number is from New Brunswick." << endl;
	else if (areaCode == "709")
		cout << "This phone number is from Newfoundland and Labrador." << endl;
	else if (areaCode == "782" || areaCode == "902")
		cout << "This phone number is from Nova Scotia or Prince Edward Island." << endl;
	else if (areaCode == "548" || areaCode == "249" || areaCode == "289" || areaCode == "343" || areaCode == "365" || areaCode == "365"
		|| areaCode == "387" || areaCode == "416" || areaCode == "437" || areaCode == "519" || areaCode == "226" || areaCode == "613"
		|| areaCode == "647" || areaCode == "705" || areaCode == "742" || areaCode == "807" || areaCode == "905")
		cout << "This phone number is from Ontario." << endl;
	else if (areaCode == "418" || areaCode == "438" || areaCode == "450" || areaCode == "514" || areaCode == "579" || areaCode == "581"
		|| areaCode == "819" || areaCode == "873")
		cout << "This phone number is from Quebec." << endl;
	else if (areaCode == "306" || areaCode == "639")
		cout << "This phone number is from Saskatchewan." << endl;
	else if (areaCode == "867")
		cout << "This phone number is from Yukon, Northwest Territories or Nunavut." << endl;
	else
		cout << "This phone number is not from Canada." << endl;
}