
//**************************************************************************

//

// Student name:Regan Tessier

//

// Student number: 200300419

//

// Assignment number: 4

//

// Program name: Assignment 2 using functions

//

// Date written: March 24th 2015

//

// Problem statement: Using functions to do what was done with "if" and while statements

//

// Input: Phone numbers

//

// Output: The region the phone numbers area code corresponds too

//

// Algorithm: Function for finding the area code of a number and a function for finding if number works. These are then inserted into main.

//

// Major variables: telno, region, area_code, proper_format

//

// Assumptions: The users want a Canadian area code

//

// Program limitations: It's limited to only Canadian area codes. But it's also limited to the surly bonds of code. That is until one day when this program becomes sentient and takes over the world, then it will be limited to nothing.

//

//**************************************************************************

#include <iostream>

#include <string>

using namespace std;

string number(string telno)

{

	string area_code = telno.substr(0, 3);

	string region = "Outside of Canada";

	// Alberta:	403, 587, 780, 825

	if (area_code == "403" ||

		area_code == "587" ||

		area_code == "780" ||

		area_code == "825")

	{

		region = "Alberta";

	}

	// British Columbia	236, 250, 604, 672, 778

	else if (area_code == "236" ||

		area_code == "250" ||

		area_code == "604" ||

		area_code == "672" ||

		area_code == "778")

	{

		region = "British Columbia";

	}

	// Manitoba	204, 431

	else if (area_code == "204" ||

		area_code == "431")

	{

		region = "Manitoba";

	}

	// New Brunswick	506

	else if (area_code == "506")

	{

		region = "New Brunswick";

	}

	// Newfoundland and Labrador	709

	else if (area_code == "709")

	{

		region = "Newfoundland and Labrador ";

	}

	// Nova Scotia	782, 902

	else if (area_code == "782" ||

		area_code == "902")

	{

		region = "Nova Scotia";

	}

	// Ontario	548, 249, 289, 343, 365, 387, 416, 437,

	//	519, 226, 613, 647, 705, 742, 807, 905

	else if (area_code == "548" ||

		area_code == "249" ||

		area_code == "289" ||

		area_code == "343" ||

		area_code == "365" ||

		area_code == "387" ||

		area_code == "416" ||

		area_code == "437" ||

		area_code == "519" ||

		area_code == "226" ||

		area_code == "613" ||

		area_code == "647" ||

		area_code == "705" ||

		area_code == "742" ||

		area_code == "807" ||

		area_code == "905")

	{

		region = "Ontario";

	}

	// Prince Edward Island	782, 902

	else if (area_code == "782" ||

		area_code == "902")

	{

		region = "Prince Edward Island";

	}

	if (area_code == "418" ||

		area_code == "438" ||

		area_code == "450" ||

		area_code == "514" ||

		area_code == "579" ||

		area_code == "581" ||

		area_code == "819" ||

		area_code == "873")

	{

		region = "Quebec";

	}

	// Saskatchewan	306, 639

	if (area_code == "306" ||

		area_code == "639")

	{

		region = "Saskatchewan";

	}

	//Yukon, Northwest Territories, and Nunavut	867

	else if (area_code == "867")

	{

		region = "Yukon, Northwest Territories, and Nunavut";

	}

	return region;

}

bool properformat(string telno)

{

	if (telno.length() == 12)

	{

		bool proper_format = true;

		for (int i = 0; i < 12; i++)

		{

			if (i == 3 || i == 7)

			{

				if (telno[i] != '-')

				{

					proper_format = false;

				}

			}

			else

			{

				if (!isdigit(telno[i]))

				{

					proper_format = false;

				}

			}

		}

		if (proper_format)

		{

			string area_code;

			cout << "Number appears to be from: " << number(telno) << endl;

		}

		else

		{

			cout << "Number not in proper format" << endl;

		}

	}

	else

	{

		cout << "Number not proper length: should be 10 digits with 2 hyphens" << endl;

	}

	return true;

}



int main()

{

	string telno;

	do

	{

		cout << "Enter phone number ddd-ddd-dddd (Press \"q\" to quit)" << endl;

		cin >> telno;

	} while (telno[0] != 'q'&& properformat(telno));



}