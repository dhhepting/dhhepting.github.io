/*********************************************************************************************************
 
 Student Name: Alexander Cameron
 
 Student Number: 200 246 288
 
 Assignment Number: 4.1
 
 Program Name: Diget Processor With Functions
 
 Date Written: 25 March, 2015
 
 Problem Statement: This program is created to accept 1-4 digit numbers,
 
 Output: number of digits, sum of digits, product of digits, and the average
 
 Algorithm: The user will be prompted to input a number between 0 and 10000, next the digits are counted using a modulus/division function which returns the number of digits and it is saved as an int variable, then a function sums the digits and the sum is saved as an int variable, a function calculates the product, finally the sum is divided by the amount of digits to calculate the average. The results are then printed out.
 
 Major Variables: int
 
 Assumptions: assums the user is only putting in 1-4 digit numbers
 
 Program Limitations: This program is limited to 1-4 digit positive numbers.
 
 
 ********************************************************************************************************/

#include <iostream>
using namespace std;

int extract_num(int);
int num_sum(int);
int product(int);

int main ()
{
    int number;
    
    do
    {
        cout << "Please enter a number between 0 and 10000, or a negative number to quit the program"
            << endl;
        
        cin >> number;
    
        if (number >= 0 && number <= 10000)
        {
            int numdig=extract_num(number); //save output of function for further calculations
            int numsum=num_sum(number);     //save output of function for further calculations
        cout <<"Number of digits is "<<numdig<<endl; //cout the results of each function and calculation
        cout << "The sum of digits is "<<numsum<<endl;
        cout << "The product of digits is "<<product(number)<<endl;
        cout << "Average for each single digit is "<<    numsum/static_cast<float>(numdig) << endl;
        }
        

        else
        {
            if (number<0)
                cout<<"Goodbye, thanks for playing!";
            else
            cout << "Number not between 0 & 10000, inclusive" << endl;
        }
        
    }while (number>0); //keep going as long as no negative number is input
    
    return 0;
        
}

int extract_num(int num)
{
    int digit1 = num % 10;       //find the first digit
    num /= 10;                   //divid by 10 to move to the next digit
    int digit2 = num % 10;
    num /= 10;
    int digit3  = num % 10;
    num /= 10;
    int digit4 = num % 10;
    num /= 10;
    int digit5 = num % 10;
    
    if (digit5 > 0)
    {
        return 5;
    }
    else if (digit4 > 0)
    {
        return 4;
    }
    else if (digit3 > 0)
    {
        return 3;
    }
    else if (digit2 > 0)
    {
        return 2;
    }
    else if (digit1 >0)
        return 1;
    else
        cout<< "Wrong that doesnt work";
    return -1;
    
   
}

int num_sum (int num)
{
    int digit1 = num % 10;         //find and save each digit
    num /= 10;
    int digit2 = num % 10;
    num /= 10;
    int digit3  = num % 10;
    num /= 10;
    int digit4 = num % 10;
    num /= 10;
    int digit5 = num % 10;
    int sum = digit1;
    int total_dig;
    
    if (digit5 > 0)               //depending on how many digits there are, use set total_dig to that number
    {
        total_dig=5;
    }
    else if (digit4 > 0)
    {
        total_dig=4;
    }
    else if (digit3 > 0)
    {
        total_dig=3;
    }
    else if (digit2 > 0)
    {
        total_dig= 2;
    }
    else if (digit1 >0)
        total_dig = 1;
    
    int current_digit = 1;
    if (current_digit <total_dig )  //keep adding digits together until all digits have been counted
    {
        sum += digit2;
        
        if (++current_digit < total_dig)
        {
            sum += digit3;
            
            if (++current_digit < total_dig)
            {
                sum += digit4;
                
                if (++current_digit < total_dig)
                {
                    sum += digit5;
                }
            }
        }
        
    }
    
    return sum;
        

}

int product (int num)
{
    int digit1 = num % 10;    //find and save each number
    num /= 10;
    int digit2 = num % 10;
    num /= 10;
    int digit3  = num % 10;
    num /= 10;
    int digit4 = num % 10;
    num /= 10;
    int digit5 = num % 10;
    int prod = digit1;
    int total_dig;
    
    if (digit5 > 0)  //calculate total digits
    {
        total_dig=5;
    }
    else if (digit4 > 0)
    {
        total_dig=4;
    }
    else if (digit3 > 0)
    {
        total_dig=3;
    }
    else if (digit2 > 0)
    {
        total_dig= 2;
    }
    else if (digit1 >0)
        total_dig = 1;
    
    int current_digit = 1;
    if (current_digit <total_dig )
        //continue multiplying the digits together until all have been acounted for
    {
        prod *= digit2;
        
        if (++current_digit < total_dig)
        {
            prod *= digit3;
            
            if (++current_digit < total_dig)
            {
                prod *= digit4;
                
                if (++current_digit < total_dig)
                {
                    prod *= digit5;
                }
            }
        }
        
    }
    
    return prod;
   
}


    

