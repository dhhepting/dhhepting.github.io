#include <iostream>

using namespace std;

// Prototype functions
int checkInput(int);
void generateData(int);

int main()
{

	int number = 0;
	bool loop = true;
	
	do
	{
		// Prompt the user for and acquire number
		cout << "Please enter a number between 0 and 10000, or a negative number to exit: ";
		cin >> number;
		
		// Determine what to do with the given number
		if(checkInput(number) == 0)
		{
			generateData(number);
		}
		else if (checkInput(number) == 1)
		{
			cout << "The inputted number is too large." << endl;
		}
		else
		{
			loop = false;
		}
	} while(loop);
	
	return 0;
}

void generateData(int num)
{
	
	int counter = 10, set = 1;
	int digits = 0 , current = 0;
	int sum = 0, average = 0, product = 1;
	
	bool flag = true;
	
	while (num / counter != 0 || set != 0)
	{
		digits++;
		sum += (num % counter) / (counter / 10);
		product *= (num % counter) / (counter / 10);
		
		if (num / counter == 0)
		{
			set--;
		}
		
		counter *= 10;
	}
	
	average = sum / digits;
	
	// Output data
	cout << endl <<  "The number of digits is: " << digits << endl;
	cout << "The sum of the digits is: " << sum << endl;
	cout << "The average of the digits is: " << average << endl;
	cout << "The product of the digits is: " << product << endl << endl;
}

int checkInput(int num)
{
	
	if (num > 10000) // Case the number is too large
	{
		return 1;
	}
	else if (num < 0) // Case the number is negative
	{
		return 2;
	}
	else
	{
		return 0; // Case the number is valid
	}
}


