/*****************************************
This is the solution of assignemnt number 4 part A

Student name: Nasser Alhamed

Student ID  : 200307983

Program name: Calculat (Number of digits, Products, Sum, and Average)

Date written: Mar 24, 2015

Problem statement:

Input: Numbers between 0- 10000

Output: 1-number of the digits, 2- products of the digits, 3- sum of the digits , and 4- average of the digits.

Algorithm: it takes the digits and count how many numbers entered and then calculate ave, pro, and sum.


Assumptions: To calculate the number of digits entered by user, products of digits and give two decimal points of the average.

Program limitations: any number less than 0 or greater than 10000 will not function
*****************************************************************/
#include <iostream>
using namespace std;


void calculations(int); //Function prototype, with one integer parameter
// main program
int main()
{
// if statement to ensure that number is between 0 and 10000
	int number;
	cout << "Please enter a number between 0 and 10000" << endl;
	cin >> number;

	if (number >= 0)
	{
		if (number <= 10000)
		{
			cout << "Correct Selection" << endl;
		}
		else
		{
			cout << "Bigger then 10000" << endl;
		}
	}
	else
	{
		cout << "Smaller than 0" << endl;
	}

	calculations(number); //Function call


	return 0;
}
// function calculation of how many digits.
void calculations(int number)
{

	int digit1 = 0;
	int digit2 = 0;
	int digit3 = 0;
	int digit4 = 0;
	int digit5 = 0;
	int digits;
	digit1 = (number / 1) % 10;
	digit2 = (number / 10) % 10;
	digit3 = (number / 100) % 10;
	digit4 = (number / 1000) % 10;
	digit5 = (number / 10000) % 10;
	if (digit1 >= 0)
	{
		digits = 1;
	}
	if (digit2 > 0)
	{
		digits = 2;
	}
	if (digit3 > 0)
	{
		digits = 3;
	}
	if (digit4 > 0)
	{
		digits = 4;
	}
	if (digit5 > 0)
	{
		digits = 5;
	}
	cout << "number of digits: " << digits << endl;
	// product calculation
	int prodDigits;

	if (digits == 1)
	{
		prodDigits = digit1;
	}
	if (digits == 2)
	{
		prodDigits = (digit1 * digit2);
	}
	if (digits == 3)
	{
		prodDigits = (digit1 * digit2 * digit3);
	}
	if (digits == 4)
	{
		prodDigits = (digit1 * digit2 * digit3 * digit4);
	}
	if (digits == 5)
	{
		prodDigits = (digit1 * digit2 * digit3 * digit4 * digit5);
	}
	cout << "Product of digits: " << prodDigits << endl;
	//sum calculation
	int sumDigits;

	if (digits == 1)
	{
		sumDigits = (digit1);
	}
	if (digits == 2)
	{
		sumDigits = (digit1 + digit2);
	}
	if (digits == 3)
	{
		sumDigits = (digit1 + digit2 + digit3);
	}
	if (digits == 4)
	{
		sumDigits = (digit1 + digit2 + digit3 + digit4);
	}
	if (digits == 5)
	{
		sumDigits = (digit1 + digit2 + digit3 + digit4 + digit5);
	}
	//average calculation
	cout << "The sum of digits: " << sumDigits << endl;
	double average = (double)sumDigits / digits;
	cout << "The average is:" << average << endl;

	cout << "Have a Nice Day! :)" << endl;
}

// end program