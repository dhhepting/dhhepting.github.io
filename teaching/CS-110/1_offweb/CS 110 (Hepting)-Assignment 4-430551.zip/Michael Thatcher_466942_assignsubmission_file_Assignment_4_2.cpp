/*
 Name: Michael Thatcher
 
 Student Number: 200 353 864
 
 Assignment 2: CS 110
 
 Program Name: Informational Area Code Calculator
 
 Date: February 25, 2015
 
 Problem statement:
 
 Write a program that prompts the user to enter a telephone number in the format ddd-ddd-dddd, where d is digit.
 This is the format for telephone numbers in North America. Test that the input is in the correct format and further check if the phone number has a Canadian area code (see the list of Canadian area codes).
 The program will report if the input is valid or not.
 If the input includes a Canadian area code, the program will display the name of the province or territory with that area code.
 The program will continue to process numbers until the user enters the letter q.
 
 Input: Phone number in format ddd-ddd-dddd
 
 Output: number of digits, sum of all digits, average of all digits, and product of all digits
 
 Algorithm: receive input for phone_number, convert phone_number to area_code, convert area_code to integer type, use switch statement to test for wether it is a Canadian area code, give option for user to repeat the operation by pressing any key, or terminating by pressing 'q'.
 
 Major variables: | option | phone_number | area_code | area_code_int |
 
 'option' stores as a char to accept the letter 'q' for the loop
 phone_number takes the input from the user
 area_code is the first 3 digits of the phone_number
 area_code_int is the first 3 digits of the phone_number converted to integer type
 
 
 Assumptions: User will properly format the phone number into the ddd-ddd-dddd format
 
 Program limitations: Doesn't ensure that user enters an all number phone number, only ensures it is the correct length (ie. abd-efg-hijk would be considered valid while aaaa-aaaa-aaaa would be considered invalid)
 
 */


#include <iostream>
#include <string>
#include <algorithm>
#include <stdlib.h>
using namespace std;




void GetData (string&);

void FormatData (string&, int&);

void CheckCase (int&);

int main()

{
    char option;
    do
    {
        
        string phone_number; // initializes phone_number string
        string area_code; // initializes area_code as string
        int area_code_int = 0; // initializes area_code_int for converting from string to integer
        
        GetData(phone_number); // Runs the GetData function from down below
        FormatData(phone_number, area_code_int); // Runs the FormatData function from down below
        // convert area code from string to integer to be used in the switch statement
        
        CheckCase(area_code_int); // Checks to see if input is a Canadian area code. Function down below
        
    }
    while (option != 'q');
    
    
    return 0;
}



void GetData (string& phone_number)
{
    
    // introduce phone_number variable and collect input information from user
    
    
    cout << "Please enter a phone number in the format ddd-ddd-dddd, where d is a digit, or enter q to quit: " << endl;
    
    cin >> phone_number;
    
    
}




void FormatData (string& phone_number, int& area_code_int)
{
    // tests to ensure that the input is in the format ddd-ddd-dddd by testing length
    
    
    
    
    if (phone_number == "q")
        cout << "exit code entered, goodbye" << endl;
    else if (phone_number.length()!=12)
    {
        cout << "Error, invalid code" << endl;
        
    }
    else
    {
        cout << "You have formatted the input correctly" << endl;
    }
    // remove the hyphens from the phone number for later formatting
    phone_number.erase (3,1);
    phone_number.erase (6,1);
    
    
    // used to preview the info stores in phone_number, placed in comment to properly format output for assignment
    // cout << phone_number << endl;
    
    
    string area_code = phone_number.substr (0,3);
    
    // used cout to preview area_code formatting while coding
    // cout << area_code << endl;
    
    area_code_int = atoi(area_code.c_str());
    
    
    
    
}



void CheckCase (int& area_code_int)
{
    switch(area_code_int)
    {
        case (403):
            cout << "Alberta area code" << endl;
            break;
        case (587):
            cout << "Alberta area code" << endl;
            break;
        case (780):
            cout << "Alberta area code" << endl;
            break;
        case (825):
            cout << "Alberta area code" << endl;
            break;
            
            
        case (236):
            cout << "British Columbia area code" << endl;
            break;
        case (250):
            cout << "British Columbia area code" << endl;
            break;
        case (604):
            cout << "British Columbia area code" << endl;
            break;
        case (672):
            cout << "British Columbia area code" << endl;
            break;
        case (778):
            cout << "British Columbia area code" << endl;
            break;
            
            
        case (204):
            cout << "Manitoba area code" << endl;
            break;
        case (431):
            cout << "Manitoba area code" << endl;
            break;
        case (506):
            cout << "New Brunswick area code" << endl;
            break;
        case (709):
            cout << "Newfoundland and Labrador area code" << endl;
            break;
            
        case (782):
            cout << "Nova Scotia or Prince Edward Island area code" << endl;
            break;
        case (902):
            cout << "Nova Scotia or Prince Edward Island area code" << endl;
            break;
            
        case (548):
            cout << "Ontario area code" << endl;
            break;
        case (249):
            cout << "Ontario area code" << endl;
            break;
        case (289):
            cout << "Ontario area code" << endl;
            break;
        case (343):
            cout << "Ontario area code" << endl;
            break;
        case (365):
            cout << "Ontario area code" << endl;
            break;
        case (387):
            cout << "Ontario area code" << endl;
            break;
        case (416):
            cout << "Ontario area code" << endl;
            break;
        case (437):
            cout << "Ontario area code" << endl;
            break;
        case (519):
            cout << "Ontario area code" << endl;
            break;
        case (226):
            cout << "Ontario area code" << endl;
            break;
        case (613):
            cout << "Ontario area code" << endl;
            break;
        case (647):
            cout << "Ontario area code" << endl;
            break;
        case (705):
            cout << "Ontario area code" << endl;
            break;
        case (742):
            cout << "Ontario area code" << endl;
            break;
        case (807):
            cout << "Ontario area code" << endl;
            break;
        case (905):
            cout << "Ontario area code" << endl;
            break;
        case (418):
            cout << "Quebec area code" << endl;
            break;
        case (438):
            cout << "Quebec area code" << endl;
            break;
        case (450):
            cout << "Quebec area code" << endl;
            break;
        case (514):
            cout << "Quebec area code" << endl;
            break;
        case (579):
            cout << "Quebec area code" << endl;
            break;
        case (581):
            cout << "Quebec area code" << endl;
            break;
        case (819):
            cout << "Quebec area code" << endl;
            break;
        case (873):
            cout << "Quebec area code" << endl;
            break;
            
        case (306):
            cout << "Saskatchewan area code" << endl;
            break;
        case (639):
            cout << "Saskatchewan area code" << endl;
            break;
            
        case (867):
            cout << "Yukon, Northwest Territories, or Nunavut area code" << endl;
            break;
            
        default:
            cout << "Not a Canadian area code." << endl;
    }
}