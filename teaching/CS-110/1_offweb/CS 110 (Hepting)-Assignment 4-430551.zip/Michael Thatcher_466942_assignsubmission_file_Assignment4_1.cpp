/*
 Name: Michael Thatcher
 
 Student Number: 200 353 864
 
 Assignment 4: CS 110
 
 Program Name: Informational Integer Calculator WITH FUNCTIONS
 
 Date: March 18, 2015
 
 Problem statement:
 Write a program that reads an integer between 0 and 10000 and then calculates and displays (from the integer that has been read):
 the number of digits
 the sum of all the digits
 the average of all the digits
 the product of all of the digits
 
 USE FUNCTIONS TO COMPLETE ABOVE
 
 Input: Integer between 0 and 10000 declared as number1
 
 Output: number of digits, sum of all digits, average of all digits, and product of all digits
 
 Algorithm: receive input for number1, determine number of digits using if statements, print out number of digits, use modulus command to determine sum
 of digits, use if statements to determine average of digits, use if statements to determine product of digits
 
 USE FUNCTIONS TO MAKE CODE IN int main() EASIER TO READ
 
 Major variables: | number1 | dig1 | dig2 | dig3 | dig4 | dig5 |
 ALL variables stored as integers except when calculating average where dig1-5 are stored as double
 
 Assumptions: User will only enter a number into the console between 0 and 10000
 
 Program limitations: Limited functionality for numbers other than those between 0 and 10000. Doesn't prevent user from entering non-number characters
 
 */

#include <iostream>
#include <stdlib.h>

using namespace std;



// 5 void statements below setup separate functions in program that are compiled outside of int main()



void GetData (int&);  // obtains data from user

void NumDigits (int&); // calculates number of digits

void SumDigits(int&); // calculates sum of digits

void AverageDigits(int&); // calculates average of digits

void ProductDigits(int&); // calculates product of digits



int main()
{
    int number1; // initializes the number1 variable
    
    do // loop so user can continually enter numbers, loop terminates when number entered is less than zero
    {
        
        GetData(number1);
        
        if (number1 < 0)
        {
            return 1;
        }
        
        // Below call the functions specified from down below
        
        NumDigits(number1);
        
        SumDigits(number1);
        
        AverageDigits(number1);
        
        ProductDigits(number1);
        
        
    }while (number1 >= 0);
    
    return 0; // end of int main() function
}


// BELOW ARE THE SEPARATE VOID FUNCTIONS

void GetData(int& number1) // Gets data from user, same process as assignment 1
{
    
    cout << "This is a program that reads an integer between 0 and 10000 and then calculates and displays:" << endl << "number of digits" << endl << "sum of all the digits" << endl << "average of all the digits" << endl << "product of all of the digits" << endl;
    cout << "Please enter a number between 0 and 10000, enter a number less than 0 to quit" << endl;
    cin >> number1;
    
    
    
    if (number1 >= 0)
        cout << "You have entered: " << number1 << endl;
    
    else if (number1 < 0)
    {
        cout << "You have entered a number less than zero, the program will now terminate." << endl;
        
    }
}




void NumDigits (int& number1) // Tests the number of digits
{
    cout << "Number of digits: ";
    if (number1 == 10000)
        cout << "5" << endl;
    
    if (number1 < 10000 && number1 >= 1000)
        cout << "4" << endl;
    
    if (number1 < 1000 && number1 >= 100)
        cout << "3" << endl;
    
    if (number1 < 100 && number1 >= 10)
        cout << "2" << endl;
    
    if (number1 < 10 && number1 >= 0)
        cout << "1" << endl;
}


void SumDigits (int& number1) // sums up the digits
{
    cout << "Sum of all digits: ";
    
    int dig1 = (number1 % 10);
    int dig2 = (number1 / 10 % 10);
    int dig3 = (number1 / 100 % 10);
    int dig4 = (number1 / 1000 % 10);
    int dig5 = (number1 / 10000 % 10);
    
    cout << dig1 + dig2 + dig3 + dig4 + dig5 << endl;
}


void AverageDigits (int& number1) // Computes the average of the digits
{
    // Determine average of all digits
    double dig1 = (number1 % 10);
    double dig2 = (number1 / 10 % 10);
    double dig3 = (number1 / 100 % 10);
    double dig4 = (number1 / 1000 % 10);
    double dig5 = (number1 / 10000 % 10);
    
    
    if (number1 == 10000)
        cout << "Average of all digits: " << (dig1 + dig2 + dig3 + dig4 + dig5) / 5.0;
    
    if (number1 < 10000 && number1 >= 1000)
        cout << "Average of all digits: " << (dig1 + dig2 + dig3 + dig4 + dig5) / 4.0;
    
    if (number1 < 1000 && number1 >= 100)
        cout << "Average of all digits: " << (dig1 + dig2 + dig3 + dig4 + dig5) / 3.0;
    
    if (number1 < 100 && number1 >= 10)
        cout << "Average of all digits: " << (dig1 + dig2 + dig3 + dig4 + dig5) / 2.0;
    
    if (number1 < 10 && number1 >= 0)
        cout << "Average of all digits: " << (dig1 + dig2 + dig3 + dig4 + dig5) / 1.0;
    cout << endl;
}


void ProductDigits (int& number1) // Computes the product of the digits
{
    
    int dig1 = (number1 % 10);
    int dig2 = (number1 / 10 % 10);
    int dig3 = (number1 / 100 % 10);
    int dig4 = (number1 / 1000 % 10);
    int dig5 = (number1 / 10000 % 10);
    // Determine product of all digits
    
    if (number1 == 10000)
        cout << "Product of all digits: " << dig1 * dig2 * dig3 * dig4 * dig5;
    
    if (number1 < 10000 && number1 >= 1000)
        cout << "Product of all digits: " << dig1 * dig2 * dig3 * dig4;
    
    if (number1 < 1000 && number1 >= 100)
        cout << "Product of all digits: " << dig1 * dig2 * dig3;
    
    if (number1 < 100 && number1 >= 10)
        cout << "Product of all digits: " << dig1 * dig2;
    
    if (number1 < 10 && number1 >= 0)
        cout << "Product of all digits: " << dig1;
    
    cout << endl;
    
}


// END OF CODE


