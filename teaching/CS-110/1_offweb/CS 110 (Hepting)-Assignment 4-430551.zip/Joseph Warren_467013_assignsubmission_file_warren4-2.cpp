//**************************************************************************
//
// Student name: Joseph Warren
//
// Student number: 200241391
//
// Assignment number: 4-2
//
// Program name: Area Codes
//
// Date written: March 25, 2015
//
// Problem statement:  Write a program that reads a phone number then performs several 
// operations with the number. The program will check
// that it is in the proper format, check that it is a Canadian phone number
// Modification: Rewrite the program so the operations are performed in distinct functions.
//
// Input: A phone number in the format ddd-ddd-dddd
//
// Output:
// 1. A message will be displayed telling the user to enter the phone number or enter "q" to 
// quit.
// 2. If the phone number is entered in the correct format, a message telling the user what  
// province the phone number is from will be displayed.  
// 3. If it is in the wrong format, a message will be displayed that tells the user their format 
// was incorrect, and to re-enter the number or enter q to quit.
// 4. If it is in the correct format but not a Canadian phone number, a message will be           
// displayed that tells the user their number was not Canadian,
// and to re-enter the number or enter "q" to quit.
//
//
// Algorithm:
// 1. Prompt user to enter a phone number in the format ddd-ddd-dddd or enter "q" to quit.
// 2. Check if the number is in the correct format.
// 3. Check which province the number is from, or if it is not a Canadian phone number at all.
// 4. Tell the user which province their number is from, or if it is in the incorrect format or not a Canadian number. 
// User should also be told to enter "q" to quit.
// 5. Repeat steps 1 through 4 until user enters "q."
//
// Major variables: phonenumber, correctlength, correcthyphens, correctdigits, areacode    
//
// Assumptions: User can follow directions given.
//
// Program limitations: Works only for Canadian phone numbers in the format ddd-ddd-dddd.
//
//
//**************************************************************************

#include <iostream>
#include <string>
using namespace std;
void format(string phonenumber);
void province(string phoneunmber);
int main()
{
	string phonenumber = "0";
	do
	{
		cout << "Please enter a phone number in the format ddd-ddd-dddd" << endl;
		cin >> phonenumber;
		format(phonenumber);

	} while (phonenumber != "q");
}
void format(string& phonenumber)
{
	bool correctlength = (phonenumber.length == 12);
	bool correcthyphens = (phonenumber.at(3) == '-' && phonenumber.at(7) == '-');
	bool correctdigits = (phonenumber.at(0) <= 9 && phonenumber.at(0) >= 0 && phonenumber.at(1) <= 9 && (phonenumber.at(1) >= 0
		&& phonenumber.at(2) <= 9 && phonenumber.at(2) >= 0
		&& phonenumber.at(4) <= 9 && phonenumber.at(4) >= 0
		&& phonenumber.at(5) <= 9 && phonenumber.at(5) >= 0
		&& phonenumber.at(6) <= 9 && phonenumber.at(6) >= 0
		&& phonenumber.at(8) <= 9 && phonenumber.at(8) >= 0
		&& phonenumber.at(9) <= 9 && phonenumber.at(9) >= 0
		&& phonenumber.at(10) <= 9 && phonenumber.at(10) >= 0
		&& phonenumber.at(11) <= 9 && phonenumber.at(11) >= 0));
	if (correctlength && correcthyphens && correctdigits)
	{
		province(phonenumber);
	}
	else
	{
		cout << "Incorrect format." << endl;

	}
	return;
}

void province(string& phonenumber)
{
	string areacode;
	
	areacode = (string substr.phonenumber(0, 3));
	if ((areacode == "403") || (areacode == "587") || (areacode == "780") || (areacode == "825"))
	{
		cout << "That phone number is from Alberta. Please enter another number or enter q to quit." << endl;
	}
	if ((areacode == "236") || (areacode == "250") || (areacode == "604") || (areacode == "672") || (areacode == "778"))
	{
		cout << "That phone number is from British Columbia. Please enter another number or enter q to quit." << endl;
	}
	if ((areacode == "204") || (areacode == "431"))
	{
		cout << "That phone number is from Manitoba. Please enter another number or enter q to quit." << endl;
	}
	if (areacode == "506")
	{
		cout << "That phone number is from New Brunswick. Please enter another number or enter q to quit." << endl;
	}
	if (areacode == "709")
	{
		cout << "That phone number is from Newfoundland and Laborador. Please enter another number or enter q to quit." << endl;
	}
	if ((areacode == "782") || (areacode == "902"))
	{
		cout << "That phone number is from Nova Scotia. Please enter another number or enter q to quit." << endl;
	}
	if ((areacode == "548") || (areacode == "249") || (areacode == "289") || (areacode == "343") || (areacode == "365") || (areacode == "387") ||
		(areacode == "416") || (areacode == "437") || (areacode == "519") || (areacode == "226") || (areacode == "613") || (areacode == "647") ||
		(areacode == "705") || (areacode == "742") || (areacode == "807") || (areacode == "905"))
	{
		cout << "That phone number is from Ontario. Please enter another number or enter q to quit." << endl;
	}
	if ((areacode == "782") || (areacode == "902"))
	{
		cout << "That phone number is from Prince Edward Island. Please enter another number or enter q to quit." << endl;
	}
	if ((areacode == "418") || (areacode == "438") || (areacode == "450") || (areacode == "514") || (areacode == "579") ||
		(areacode == "581") || (areacode == "819") || (areacode == "873"))
	{
		cout << "That phone number is from Quebec. Please enter another number or enter q to quit." << endl;
	}
	if ((areacode == "306") || (areacode == "639"))
	{
		cout << "That phone number is from Saskatchewan. Please enter another number or enter q to quit." << endl;
	}
	if (areacode == "867")
	{
		cout << "That phone number is from Yukon, Nunavut, or the Northwest Territories. Please enter another number or enter q to quit." << endl;
	}
	else
	{
		cout << "That is not a Canadian phone number.";
	}
	
	return;
}