// STUDENT NAME: Emily Chea

// STUDENT NUMBER: 200352055

// ASSIGNMENT NUMBER: 4

// PROGRAM NAME: C++ Visual Studio 2013

// DATE WRITTEN: March 18, 2015

// PROBLEM STATEMENT: Rewrite the Assignment 1 using functions

// INPUT: single integer between 0 and 10000 inclusive

// OUTPUT: number of digits, sum of digits, average of digits, products of digits

// ALGORITHM: Judge if the number is within range, determine the number of digits, determine the sum of the digits, determine the average of the digits, determine the product of the digits

// MAJOR VARIABLES: number, digit, digit1, digit2, digit3, digit4, digit5, sum, average, product, Range, Digits, Sum, Average, Product, printdigits

// ASSUMPTIONS: assume that participant will select a whole number,

// PROGRAM LIMITATIONS: only accurate when calculating with whole numbers, 

//***************************************************************************************************************

#include <iostream>
#include <cstdlib>
#include <string>
using namespace std;

// prototypes
string Range(int);
void printdigits(int&, int&, int&, int&, int&, int);
int Digits(int, int, int, int, int);
float Sum(int&, int&, int&, int&, int&);
float Average(int&, int&, int&, int&, int&, float&);
int Product(int&, int&, int&, int&, int&);
int main()
{
	string range;
	int digit;
	int number;
	int digit1;
	int digit2;
	int digit3;
	int digit4;
	int digit5;

	// asking the participant to pick a number
	cout << "Please pick a number between 0 and 10000." << endl;
	cin >> number;
	while (number >= 0)
	{
		//geting digits
		printdigits(digit1, digit2, digit3, digit4, digit5, number);

		//determine if the number is within the given range
		range = Range(number);

		//Determining the number of digits in the chosen number
		digit = Digits(digit1, digit2, digit3, digit4, digit5); //call the function

		//Determining the sum of the digits in the chosen number
		float sum;
		sum = Sum(digit1, digit2, digit3, digit4, digit5); //call the function

		//Determining the average of the digits in the chosen number
		float average;
		average = Average(digit1, digit2, digit3, digit4, digit5, sum);

		//Determining the product of the digits in the chosen number
		int product;
		product = Product(digit1, digit2, digit3, digit4, digit5);

		cout << "Please pick a number between 0 and 10000." << endl;
		cin >> number;
	}
	return 0;
}
string Range(int number)
{
	if (number >= 0 && number <= 10000)
	{
		cout << "The number is within the range." << endl;
	}
	else if (number > 10000)
	{
		cout << "This number is not within range." << endl;
		exit(1);
	}
}
void printdigits(int& digit1, int& digit2, int& digit3, int& digit4, int& digit5, int number)
{
	digit1 = number % 10;
	number /= 10;
	digit2 = number % 10;
	number /= 10;
	digit3 = number % 10;
	number /= 10;
	digit4 = number % 10;
	number /= 10;
	digit5 = number % 10;
}
int Digits(int digit1, int digit2, int digit3, int digit4, int digit5)
{
	//Determining the number of digits in the chosen number
	int digit;
	if (digit1 >= 0)
	{
		digit = 1;
	}
	if (digit2 > 0)
	{
		digit = 2;
	}
	if (digit3 > 0)
	{
		digit = 3;
	}
	if (digit4 > 0)
	{
		digit = 4;
	}
	if (digit5 > 0)
	{
		digit = 5;
	}
	cout << "Number of digits: " << digit << endl;
	return digit;
}
//Determining the sum of the digits in the chosen number
float Sum(int& digit1, int& digit2, int& digit3, int& digit4, int& digit5)
{
	float sum;
	sum = digit1 + digit2 + digit3 + digit4 + digit5;
	cout << "Sum of digits: " << sum << endl;
	return sum;
}
//Determining the average of the digits in the chosen number
float Average(int& digit1, int& digit2, int& digit3, int& digit4, int& digit5, float& sum)
{
	float average;
	if (digit1 > 0)
	{
		average = sum;
	}
	if (digit2 > 0)
	{
		average = sum / 2;
	}
	if (digit3 > 0)
	{
		average = sum / 3;
	}
	if (digit4 > 0)
	{
		average = sum / 4;
	}
	if (digit5 > 0)
	{
		average = sum / 5;
	}
	cout << "Average of digits: " << average << endl;
	return average;
}
//Determining the product of the digits in the chosen number
int Product(int& digit1, int& digit2, int& digit3, int& digit4, int& digit5)
{
	int product;
	if (digit1 > 0)
	{
		product = digit1;
	}
	if (digit2 > 0)
	{
		product = digit1 * digit2;
	}
	if (digit3 > 0)
	{
		product = digit1 * digit2 * digit3;
	}
	if (digit4 > 0)
	{
		product = digit1 * digit2 * digit3 * digit4;
	}
	if (digit5 > 0)
	{
		product = digit1 * digit2 * digit3 * digit4 * digit5;
	}
	cout << "Product of digits: " << product << endl;
	return product;
}
