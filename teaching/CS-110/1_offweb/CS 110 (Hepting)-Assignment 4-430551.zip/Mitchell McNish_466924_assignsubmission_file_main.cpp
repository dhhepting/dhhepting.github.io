//
///
//
//
////**************************************************************************
//
// Student name: Mitchell McNish
//
// Student number: 200 235 791
//
// Assignment number: #4
//
// Program name: X-code
//
// Date written:
//
// Problem statement:Run a multi function program check format, and area of a 12 integer imput
//
// Input: 12 digit phone number including "-" in the correct sting placement.
//
// Output: invlaid input or the correct province /territoy
//
// Algorithm:
//
// Major variables:
//
// Assumptions: create a string which has "if" and "else if" statement
//
// Program limitations: no limitations regarding the input vs output because there will always be either-or
//
//**************************************************************************
//  Created by Mitchell Mcnish on 2015-03-05.
//  Copyright (c) 2015 Mitchell Mcnish. All rights reserved.
//
//
//  Created by Mitchell Mcnish on 2015-03-25.
//  Copyright (c) 2015 Mitchell Mcnish. All rights reserved.
//

#include <iostream>
#include <cstdlib>
#include <string>
#include <fstream>
using namespace std;

int area_code, proper_format;
void printProv (int area_code);
void format (int telno);
string telno;





void printProv(string area_code = telno.substr(0,3));
{
  
 
    if (area_code == "403" ||
        area_code == "587" ||
        area_code == "780" ||
        area_code == "825")
    {
        cout << "Number appears to be from Alberta";
      
    }
    // British Columbia	236, 250, 604, 672, 778
    else if (area_code == "236" ||
             area_code == "250" ||
             area_code == "604" ||
             area_code == "672" ||
             area_code == "778")
    {
        cout << "Number appears to be from British Columbia";
    }
    // Manitoba	204, 431
    else if (area_code == "204" ||
             area_code == "431")
    {
        cout << "Number appears to be from Manitoba";
    }
    // New Brunswick	506
    else if (area_code == "506")
    {
         cout << "Number appears to be from New Brunswick";
    }
    // Newfoundland and Labrador	709
    else if (area_code == "709")
    {
        cout << "Number appears to be from Newfoundland and Labrador ";
    }
    // Nova Scotia	782, 902
    else if (area_code == "782" ||
             area_code == "902")
    {
        cout << "Number appears to be from Nova Scotia";
    }
    // Ontario	548, 249, 289, 343, 365, 387, 416, 437,
    //		519, 226, 613, 647, 705, 742, 807, 905
    else if (area_code == "548" ||
             area_code == "249" ||
             area_code == "289" ||
             area_code == "343" ||
             area_code == "365" ||
             area_code == "387" ||
             area_code == "416" ||
             area_code == "437" ||
             area_code == "519" ||
             area_code == "226" ||
             area_code == "613" ||
             area_code == "647" ||
             area_code == "705" ||
             area_code == "742" ||
             area_code == "807" ||
             area_code == "905")
    {
        cout << "Number appears to be from Ontario";
    }
    // Prince Edward Island	782, 902
    else if (area_code == "782" ||
             area_code == "902")
    {
         cout << "Number appears to be from Prince Edward Island";
    }
    // Quebec	418, 438, 450, 514, 579, 581, 819, 873
    if (area_code == "418" ||
        area_code == "438" ||
        area_code == "450" ||
        area_code == "514" ||
        area_code == "579" ||
        area_code == "581" ||
        area_code == "819" ||
        area_code == "873")
        
    {
        cout << "Number appears to be from Quebec";
    }
    // Saskatchewan	306, 639
    if (area_code == "306" ||
        area_code == "639")
    {
         cout << " Number appears to be from Saskatchewan";
    }
    //Yukon, Northwest Territories, and Nunavut	867
    else if (area_code == "867")
    {
        cout << "Number appears to be from Yukon, Northwest Territories, and Nunavut";
    }
        
return printProv();
    
}

int format()
{
   
    string telno;
 
    while (telno[0] != 'q')
    {
    if (telno.length() == 12) // proper length
    {
        // make use of loops here :-)
        bool proper_format = true;
        for (int i = 0;i < 12; i++)
        {
            if (i == 3 || i == 7)
            {
                if (telno[i] != '-')
                {
                    proper_format = false;
                }
            }
            else
            {
                if (!isdigit(telno[i]))
                {
                    proper_format = false;
                }
            }
        }
    }
    }
    return format();
}


int main()
{
    
    cout << "Enter phone number ddd-ddd-dddd" << endl;
    string telno;
    cin >> telno;
    printProv(area_code);
    
    return 0;
}

