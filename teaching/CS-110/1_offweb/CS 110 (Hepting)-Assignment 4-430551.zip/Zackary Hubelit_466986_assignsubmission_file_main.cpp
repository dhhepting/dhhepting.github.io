//**************************************************************************
//
// Student name: Zackary Hubelit
//
// Student number: 200351286 
//
// Assignment number: 2
//
// Program name: Phone Number and Area Code detector
//
// Date written: March 24th / 15
//
// Problem statement: Take a phone number input from the user and display the correct area code. continue to loop this process until the user inputs the letter 'q'
//
// Input: User will input a phone number in the format ddd-ddd-dddd where d is a digit.
//
// Output: The program will tell the user which province the area code of that phone number is from, and then ask for another one.
//
// Algorithm: uses if statements to decide which province the phone number is from
//
// Major variables: number - the phone number that the user inputs
//
// Assumptions: The user doesn't input any letters into the phone number, only integers.
//
// Program limitations: Can not handle letters where there are supposed to be numbers.
//
//**************************************************************************


#include <iostream>
#include <string>

using namespace std;

void GetProv(string);

int main()
{
	string number;
input:
	cout << "Please enter a phone number in the format (ddd-ddd-dddd), where d is a digit." << endl;
	cout << "Phone number: ";
	cin >> number;

	if (number[0] == 'q' || number[0] == 'Q')
	{
		cout << "Goodbye!" << endl;
		return 0;
	}

	if (number.length() > 12 || number.length() < 12 || number[3] != '-' || number[7] != '-')
	{
		cout << "That is an incorrect format, please try again." << endl;
		cout << " " << endl;
		goto input;
	}

	if (number.length() == 12)
	{
		cout << "That is a valid phone number." << endl;
	}

	GetProv(number.substr(0,3));

	goto input;

	return 0;
}

void GetProv(string x)
{
	if (x == "403" || x == "587" || x == "780" || x == "825")
		{
			cout << "That phone number has an Alberta area code!" << endl;
		}

		if (x == "236" || x == "250" || x == "604" || x == "672" || x == "778")
		{
			cout << "That phone number has a British columbia area code!" << endl;
		}

		if (x == "204" || x == "431")
		{
			cout << "That phone number has a Manitoba area code!" << endl;
		}

		if (x == "506")
		{
			cout << "That phone number has a New Brunswick area code!" << endl;
		}

		if (x == "709")
		{
			cout << "That phone number has a Newfoundland and Labrador area code!" << endl;
		}

		if (x == "782" || x == "902")
		{
			cout << "That phone number has a Nova Scotia area code!" << endl;
		}

		if (x == "548" || x == "249" || x == "289" || x == "343" || x == "365" || x == "387" ||  x == "416" ||  x == "437" ||  x == "519" ||  x == "226" ||  x == "613" || x == "647" || x == "705" || x == "742" || x == "807" ||  x == "905")
		{
			cout << "That phone number has an Ontario area code!" << endl;
		}

		if (x == "782" || x == "902")
		{
			cout << "That phone number has a Prince Edward Island area code!" << endl;
		}

		if (x == "418" || x == "438" || x == "450" || x == "514" || x == "579" || x == "581" || x == "819" || x == "873")
		{
			cout << "That phone number has a Quebec area code!" << endl;
		}

		if (x == "306" || x == "639")
		{
			cout << "That phone number has a Saskatchewan area code!" << endl;
		}

		if (x == "867")
		{
			cout << "That phone number has a Yukon, Northweast Territories, or Nunavut area code!" << endl;
		}
}