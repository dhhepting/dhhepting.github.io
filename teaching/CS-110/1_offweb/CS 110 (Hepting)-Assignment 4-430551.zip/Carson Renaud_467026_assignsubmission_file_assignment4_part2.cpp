

// Student name: Carson Renaud
//
// Student number: 200304106
//
// Assignment number:4
//
// Program name: Phone number areacode identifier
//
// Date written: March 25, 2015
//
// Problem statement: Write a program that prompts the user to enter a telephone number in the format
// ddd-ddd-dddd, where d is digits. This is the format for telephone numbers in North America. Test that
// the input is in the correct format and further check ifthe phone number has a Canadian area code.
// The program will report if the input is valid or not. If the input includes a Canadian area code,
// the program will display the name of the province or territory with that area code. The program
// will continue to process numbers until the user enters the letter q these steps will be done 1 by the
// validation in one function and the printing of the corresponding areacode in the other.
//
// Input: Phone Number from user keyboard input.
//
// Output: The areacode if its a canadian number will tell you which province the number came from, and
//  if valid but not canadian areacode will prompt user for a new number, and will exist if invalid input
// all these step being done in two fuctions.
//
// Algorithm:Takes the input and test the conditions if it's valid input in the form ddd-ddd-dddd and has
// hyphenses in the correct places,Then processes the input and checks if its a canadian areacode and if
// so details which one.
//
// Major variables: The phonenumber and while loops one controls the exit condition, other validates the
// user input and makes sure it in the proper form, next it takes a sub string of the strings first 3
// digits and tests to see if there
//    a canadian area code.
//
// Assumptions: This will only work for phone numbers in North American form.
//
// Program limitations: Can only handle phone numbers of North American form.

#include <iostream>
#include <string>
using namespace std;

    
    ////////// void first fuction test the input and validates it
bool formatcorrect(string& telno)
{
    while (telno[0] != 'q')
    {
        if (telno.length() == 12) // proper length
        {
            // make use of loops here :-)
            bool proper_format = true;
            for (int i = 0;i < 12; i++)
            {
                
                if (i == 3 || i == 7) // check hyphenes
                {
                    if (telno[i] != '-')
                    {
                        proper_format = false;
                    }
                }
                else
                {
                    if (!isdigit(telno[i])) // checks type
                    {
                        proper_format = false;
                    }
                }
                
            }
        }
    }
        /////////////// This will be the second call if bool proper_format is true
void printareacode(string telno) // funtion would return a string and would execute in the case bool was
                                   // true (proper_format).
{
            if (proper_format)
            {
                string area_code = telno.substr(0,3);
                string region = "Outside of Canada";
                // Alberta:	403, 587, 780, 825
                if (area_code == "403" ||
                    area_code == "587" ||
                    area_code == "780" ||
                    area_code == "825")
                {
                    region = "Alberta";
                }
                // British Columbia	236, 250, 604, 672, 778
                else if (area_code == "236" ||
                         area_code == "250" ||
                         area_code == "604" ||
                         area_code == "672" ||
                         area_code == "778")
                {
                    region = "British Columbia";
                }
                // Manitoba	204, 431
                else if (area_code == "204" ||
                         area_code == "431")
                {
                    region = "Manitoba";
                }
                // New Brunswick	506
                else if (area_code == "506")
                {
                    region = "New Brunswick";
                }
                // Newfoundland and Labrador	709
                else if (area_code == "709")
                {
                    region = "Newfoundland and Labrador ";
                }
                // Nova Scotia	782, 902
                else if (area_code == "782" ||
                         area_code == "902")
                {
                    region = "Nova Scotia";
                }
                // Ontario	548, 249, 289, 343, 365, 387, 416, 437,
                //		519, 226, 613, 647, 705, 742, 807, 905
                else if (area_code == "548" ||
                         area_code == "249" ||
                         area_code == "289" ||
                         area_code == "343" ||
                         area_code == "365" ||
                         area_code == "387" ||
                         area_code == "416" ||
                         area_code == "437" ||
                         area_code == "519" ||
                         area_code == "226" ||
                         area_code == "613" ||
                         area_code == "647" ||
                         area_code == "705" ||
                         area_code == "742" ||
                         area_code == "807" ||
                         area_code == "905")
                {
                    region = "Ontario";
                }
                // Prince Edward Island	782, 902
                else if (area_code == "782" || 
                         area_code == "902")
                {
                    region = "Prince Edward Island";
                }		
                // Quebec	418, 438, 450, 514, 579, 581, 819, 873
                if (area_code == "418" || 
                    area_code == "438" ||
                    area_code == "450" ||
                    area_code == "514" ||
                    area_code == "579" ||
                    area_code == "581" ||
                    area_code == "819" ||
                    area_code == "873")
                {
                    region = "Quebec";
                }		
                // Saskatchewan	306, 639
                if (area_code == "306" || 
                    area_code == "639")
                {
                    region = "Saskatchewan";
                }		
                //Yukon, Northwest Territories, and Nunavut	867
                else if (area_code == "867")
                {
                    region = "Yukon, Northwest Territories, and Nunavut";
                }		
                cout << "Number appears to be from: " << region << endl;
            }
            else
            {
                cout << "Number not in proper format" << endl;
                cout << "Number not proper length: should be 10 digits with 2 hyphens" << endl;
            }
    
}


            int main()
    {
                    bool proper_format;
                    cout << "Enter phone number ddd-ddd-dddd" << endl;
                    string telno;
                    cin >> telno;
                
                    while (telno[0] != 'q') // will execute until q detected
                    {
                       
                        formatcorrect(telno); // couldnt get the fuctions to work
                    
                   void printareacode(string); // fuction call returns the region
                        
                    cout << "Enter phone number ddd-ddd-dddd" << endl; // gets a new number
                    cin >> telno;

                    }
                    return 0;
    }
