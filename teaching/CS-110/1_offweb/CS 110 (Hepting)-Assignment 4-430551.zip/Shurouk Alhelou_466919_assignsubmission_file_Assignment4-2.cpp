/*NAME: SHUROUK ALHELOU
SID: 200336944
DATE: MARCH 25
*/


#include <iostream>
#include <string>
using namespace std;

int Formate(string, int, int );
int Areacode(int, string, string,string);

main()
{
	cout << "Enter phone number ddd-ddd-dddd" << endl;
	string tele;
	cin >> tele;

	//Formate(tele);
//	Areacode(tele);

	return 0;
}


int Formate(string telno, int i, int proper_format)
{
	while (telno[0] != 'q')
	{
		if (telno.length() == 12) // proper length
		{
			// make use of loops here :-)
			 proper_format = true;
			for (i = 0; i < 12; i++)
			{
				if (i == 3 || i == 7)
				{
					if (telno[i] != '-')
						proper_format = false;
				}
				else
				{
					if (!isdigit(telno[i]))
						proper_format = false;
				}
			}

		}
	}
	return i;
}

int Areacode(int proper_format, string area_code, string telno, string region)
{
	if (proper_format)
	{
		area_code = telno.substr(0, 3);
		region = "Outside of Canada";
		// Alberta:	403, 587, 780, 825
		if (area_code == "403" ||
			area_code == "587" ||
			area_code == "780" ||
			area_code == "825")
		{
			region = "Alberta";
		}
		// British Columbia	236, 250, 604, 672, 778
		else if (area_code == "236" ||
			area_code == "250" ||
			area_code == "604" ||
			area_code == "672" ||
			area_code == "778")
		{
			region = "British Columbia";
		}
		// Manitoba	204, 431
		else if (area_code == "204" ||
			area_code == "431")
		{
			region = "Manitoba";
		}
		// New Brunswick	506
		else if (area_code == "506")
		{
			region = "New Brunswick";
		}
		// Newfoundland and Labrador	709
		else if (area_code == "709")
		{
			region = "Newfoundland and Labrador ";
		}
		// Nova Scotia	782, 902
		else if (area_code == "782" ||
			area_code == "902")
		{
			region = "Nova Scotia";
		}
		// Ontario	548, 249, 289, 343, 365, 387, 416, 437, 
		//		519, 226, 613, 647, 705, 742, 807, 905
		else if (area_code == "548" ||
			area_code == "249" ||
			area_code == "289" ||
			area_code == "343" ||
			area_code == "365" ||
			area_code == "387" ||
			area_code == "416" ||
			area_code == "437" ||
			area_code == "519" ||
			area_code == "226" ||
			area_code == "613" ||
			area_code == "647" ||
			area_code == "705" ||
			area_code == "742" ||
			area_code == "807" ||
			area_code == "905")
		{
			region = "Ontario";
		}
		// Prince Edward Island	782, 902
		else if (area_code == "782" ||
			area_code == "902")
		{
			region = "Prince Edward Island";
		}
		// Quebec	418, 438, 450, 514, 579, 581, 819, 873
		if (area_code == "418" ||
			area_code == "438" ||
			area_code == "450" ||
			area_code == "514" ||
			area_code == "579" ||
			area_code == "581" ||
			area_code == "819" ||
			area_code == "873")
		{
			region = "Quebec";
		}
		// Saskatchewan	306, 639
		if (area_code == "306" ||
			area_code == "639")
		{
			region = "Saskatchewan";
		}
		//Yukon, Northwest Territories, and Nunavut	867
		else if (area_code == "867")
		{
			region = "Yukon, Northwest Territories, and Nunavut";
		}
		cout << "Number appears to be from: " << region << endl;
	}
	else {
		cout << "Number not in proper format" << endl;
	}

	return proper_format;
}



/* OR */
/*

int Telephone(int, string, int);
int Areacode(int, string, int, int, int, int, int, int, int, int, int, int, int, int, int);

int main()
{
	string tele, Region1, Region2, Region3, Region4, Region5, Region6, Region7, Region8, Region9, Region10, Region11;

	cout << "Enter phone number ddd-ddd-dddd" << endl;
	cin >> tele;

	string area_code = tele.substr(0, 3);
	string region = "Outside of Canada";
	

	Region1 = "Alberta";
	Region2 = "British Columbia";
	Region3 = "British Columbia";
	Region4 = "New Brunswick";
	Region5 = "Newfoundland and Labrador ";
	Region6 = "Nova Scotia";
	Region7 = "Ontario";
	Region8 = "Prince Edward Island";
	Region9 = "Quebec";
	Region10 = "Saskatchewan";
	Region11 = "Yukon, Northwest Territories, and Nunavut";

	//cout << "Number not in proper format" << endl;
	return 0;
}
	
int Telephone(int properformat, string telno, int third)
{

	while (telno[0] != 'q')
	{
		if (telno.length() == 12) // proper length
		{

			bool properformat = true;

			for (int i = 0; i < 12; i++)
			{
				if (i == 3 || i == 7)
				{
					if (telno[i] != '-')
						properformat = false;
				}

				else
				{
					if (!isdigit(telno[i]))
						properformat = false;
				}
			}

		}
	}
	return third;
}


int Areacode(int Properformat, string areacode, int region1, int region2, int region3, int region4, int region5, int region6,
		int region7, int region8, int region9, int region10, int region11, int Third)
{
	if (Properformat)
	{
		// Alberta:	403, 587, 780, 825
		if (areacode == "403" ||
			areacode == "587" ||
			areacode == "780" ||
			areacode == "825")
		{
			return region1;
		}

		// British Columbia	236, 250, 604, 672, 778
		else if (areacode == "236" ||
			areacode == "250" ||
			areacode == "604" ||
			areacode == "672" ||
			areacode == "778")
		{
			return region2;
		}

		// Manitoba	204, 431
		else if (areacode == "204" ||
			areacode == "431")
		{
			return region3;
		}

		// New Brunswick	506
		else if (areacode == "506")
		{
			return region4;
		}

		// Newfoundland and Labrador	709
		else if (areacode == "709")
		{
			return region5;
		}

		// Nova Scotia	782, 902
		else if (areacode == "782" ||
			areacode == "902")
		{
			return region6;
		}

		// Ontario	548, 249, 289, 343, 365, 387, 416, 437, 
		//		519, 226, 613, 647, 705, 742, 807, 905
		else if (areacode == "548" ||
			areacode == "249" ||
			areacode == "289" ||
			areacode == "343" ||
			areacode == "365" ||
			areacode == "387" ||
			areacode == "416" ||
			areacode == "437" ||
			areacode == "519" ||
			areacode == "226" ||
			areacode == "613" ||
			areacode == "647" ||
			areacode == "705" ||
			areacode == "742" ||
			areacode == "807" ||
			areacode == "905")
		{
			return region7;
		}

		// Prince Edward Island	782, 902
		else if (areacode == "782" ||
			areacode == "902")
		{
			return region8;
		}

		// Quebec	418, 438, 450, 514, 579, 581, 819, 873
		if (areacode == "418" ||
			areacode == "438" ||
			areacode == "450" ||
			areacode == "514" ||
			areacode == "579" ||
			areacode == "581" ||
			areacode == "819" ||
			areacode == "873")
		{
			return region9;
		}

		// Saskatchewan	306, 639
		if (areacode == "306" ||
			areacode == "639")
		{
			return region10;
		}

		//Yukon, Northwest Territories, and Nunavut	867
		else if (areacode == "867")
		{
			return region11;
		}

	}
	else
	return Third;
}

	*/