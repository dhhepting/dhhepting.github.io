#include <iostream>

using namespace std;

bool check format(string);

void check digits(string);

int main ()

{

	// get input

	cout << "Please enter a number between 0 and 10000" << endl;

	int number = 0;

	cin >> number;

	// check the format is good

	if (number >= 0 && number <= 10000)
	{

		int sum = 0;

		int prod = 1;
	
	int num_digits = 0;
	
	bool non_zero = false;
	
	int digit = 0;
		

		// 10000's place (1 or none)

		digit = number / 10000;
		
number -= (digit * 10000);

		if (digit > 0 || non_zero == true)

		{
			non_zero = true;

			sum += digit;
			
prod *= digit;

			num_digits++;

		}
			

		// 1000's place (0 - 9)
		
digit = number / 1000;

		number -= (digit * 1000);
	
	if (digit > 0 || non_zero == true)
	
	{
			
non_zero = true;
		
	sum += digit;
	
		prod *= digit;
	
		num_digits++;
	
	}
			
	
	// 100's place (0 - 9)
	
	digit = number / 100;
		
number -= (digit * 100);
	
	if (digit > 0 || non_zero == true)

		{
			
non_zero = true;
		
	sum += digit;
		
	prod *= digit;
		
	num_digits++;
		}
	
		
		// 10's place (0 - 9)
	
	digit = number / 10;
	
	number -= (digit * 10);
	
	if (digit > 0 || non_zero == true)
	
	{
			
non_zero = true;
	
		sum += digit;
	
		prod *= digit;
	
		num_digits++;
	
	}
	
		
		// 1's place (0 - 9)
	
	sum += number;

		prod *= number;
	
	num_digits++;
		
 
		cout << "Number of digits: " << num_digits << endl;

		cout << "Sum of digits: " << sum << endl;

		cout << "Product of digits: " << prod << endl;
	
	cout << "Average of digits: " << sum / static_cast<float>(num_digits) << endl;
	
}
	
else
	{
		cout << "Number not between 0 & 10000, inclusive" << endl;
	
}
	

	return 0;
}
