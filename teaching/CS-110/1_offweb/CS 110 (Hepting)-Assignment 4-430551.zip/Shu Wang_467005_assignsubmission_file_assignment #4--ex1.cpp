//********************************************************************
//Name: Shu Wang
//Student number: 200335170
//Assignment number: 4
//Program name: Write a program that reads an integer between 0 and 10000 and then calculates and displays
//Date written: Mar 25, 2015
//Problem statement: Modify Assignment 1 code so that the calculations it does are located within a function. The main() function that calls this function should let the user input any desired about of numbers, until a negative number is input.
//Input: A number between 0 and 10000
//Output: the number of digits
        //the sum of all the digits
        //the average of all the digits
        //the product of all of the digits
//Algorithm:
        //(1) Function: reads.  Calculate the above four questions
        //(2) do...while in main function: check if the number is between 0 and 10000
        //(3) do...while in reads function: same as above one
        // (3)for (int i=0; i<string_num.length()-1;i++): do further checking for every digit

//Major variables: number, product,sum,digit,average
//Assumptions: numbers should be between 0-10000
//Program limitations: cannot do any number outside the range of 0-10000
//**********************************************************************




#include <iostream>
#include <string>
using namespace std;


//Sorry! I didn't have enough time to figure out how to fix my problem.  I can just submit this not working one.  If it is easy to find the problem, could you please tell me?

void reads(int);

int main()
{
    int number;
   
    do
    {
        cout << "Please input an integer from 0-10,000" << endl;
        
        cin >> number;
       
        
        if(number >= 0 && number <= 10000)
            reads(number);
        else
            cout<< "Wrong input"<< endl;
        
    
    } while(1);
    
    return 0;
}


void reads (int number)
{
   
    double product=1;
  
    double sum=0;
   
    
    while (number >= 0 && number <= 10000)
    {
        string string_num;
        string_num=static_cast<char> (number);
        
        for (int i=0; i<string_num.length()-1;i++)
        {
            int dight=0;
            dight= string_num[i]+'0';
            sum += dight;
            product *= dight;
        }
        
        double average;
        average =sum/string_num.length();
       
        cout<< "The number of digits: "<< string_num.length()+1<< endl;
        cout<< "The sum of all the digits: " << sum<< endl;
        cout<< "The average of all the digits: " << average << endl;
        cout<< "The product of all the digits: " << product<< endl;
        return ;
    }
   
}
