//Shamneet Dhillon
//200333548
//Assignment#4 part b
//25th March,2015

//the program asks the user to input the phonenumber
//it checks for the correctness of the format of the  number entered
//then it checks the areacode and gives the name of the the province that this areacode is used in
//it includes function
//one function has checks for the validation of the phonenumber format
//and the other function checks for the areacode of theh number

#include<iostream>
#include<string>
using namespace std;




//declare function prototypes
void Process_Num(string PhoneNumb);
void test(string AreaCode, string PhoneNumb);

int main()
{
	//declare your Phone number to be PhoneNumb
	string PhoneNumb;


	//use a do-while loop to get the programe running continuosly 
	do{
		//Prompt the user to enter a Phone number
		cout << "Enter your Phone Number in the format DDD-DDD-DDDD : " << endl;
		cout << " " << endl;



		//using get line, get the input(Phone number) and display it to the user
		getline(cin, PhoneNumb);
		cout << "Your Phone Number is : " << PhoneNumb << endl;
		cout << "  " << endl;

		//check if the input is 12 characters long
		if ((PhoneNumb.length() == 12) && (PhoneNumb != "q"))


		{

			//check the values of the input if all are digits
			if ((PhoneNumb[0] >= '0' && PhoneNumb[0] <= '9')

				&&

				(PhoneNumb[1] >= '0' && PhoneNumb[1] <= '9')

				&&

				(PhoneNumb[2] >= '0' && PhoneNumb[2] <= '9')

				&&


				(PhoneNumb[4] >= '0' && PhoneNumb[4] <= '9')

				&&

				(PhoneNumb[5] >= '0' && PhoneNumb[5] <= '9')
				&&



				(PhoneNumb[6] >= '0' && PhoneNumb[6] <= '9')
				&&



				(PhoneNumb[8] >= '0' && PhoneNumb[8] <= '9')
				&&


				(PhoneNumb[9] >= '0' && PhoneNumb[9] <= '9')
				&&

				(PhoneNumb[10] >= '0' && PhoneNumb[10] <= '9')
				&&
				(PhoneNumb[11] >= '0' && PhoneNumb[11] <= '9'))

			{

				Process_Num(PhoneNumb);


			}
			//if the value of the input are not all digits within 0 to 9, display the error message below 
			else
			{
				cout << "Error, the values of your Phone Number are not all digits" << endl;

			}

		}
		//if the input are not 12 character long display the error message below
		else if (PhoneNumb.length() != 12 && PhoneNumb != "q")
		{
			cout << "Error, the Phone Number you entered is not 12 characters long" << endl;
			cout << " " << endl;

		}

	}
	//here is the closure of the do-while loop; when the user enters "q" the program stops running 
	//and prompt the user to "press any key to continue"
	while (PhoneNumb != "q");



	//return 0 which means "no error" from the compiling of the program
	return 0;
}
void test(string AreaCode, string PhoneNumb)
{

	//string AreaCode = PhoneNumb.substr(0, 3);
	if (AreaCode == "403" || AreaCode == "587" || AreaCode == "780" || AreaCode == "825")
	{
		cout << " the Phone Number is from  Alberta   " << endl;
	}
	// check if area Code is from British Columbia 
	else	if (AreaCode == "236" || AreaCode == "250" || AreaCode == "604" || AreaCode == "672" || AreaCode == "778")
	{
		cout << "  the Phone Number is from British Columbia  " << endl;

	}

	//check if the Area code is from Manitoba
	else	if (AreaCode == "204" || AreaCode == "431")
	{
		cout << "the Phone Number is from  Manitoba  " << endl;

	}
	//check if the Area code is from New Brunswick
	else	if (AreaCode == "506")
	{
		cout << " the Phone Number is from  New Brunswick  " << endl;
	}
	//check if the Area code is from Newfoundland and labrador
	else	if (AreaCode == "709")
	{
		cout << "the Phone Number is from  Newfoundland and Labrador  " << endl;
	}
	//check if the Area code if from Nova Scotia
	else	if (AreaCode == "782" || AreaCode == "902")
	{
		cout << "the Phone Number is from  Nova Scotia  " << endl;

	}

	//check if the Area Code is from Ontario
	else	if (AreaCode == "548" || AreaCode == "249" || AreaCode == "289" ||
		AreaCode == "343" || AreaCode == "365" || AreaCode == "387" || AreaCode == "416" ||
		AreaCode == "437" || AreaCode == "519" || AreaCode == "226" || AreaCode == "613" ||
		AreaCode == "647" || AreaCode == "705" || AreaCode == "742" || AreaCode == "807" || AreaCode == "905")
	{
		cout << " the Phone Number is from  Ontario  " << endl;

	}
	//check if the Area Code is from Edward Island
	else	if (AreaCode == "782" || AreaCode == "902")
	{
		cout << "the Phone Number is from  Prince Edward Island  " << endl;

	}
	//check if the Area Code is from Quebec
	else	if (AreaCode == "418" || AreaCode == "438" || AreaCode == "450" || AreaCode == "514" ||
		AreaCode == "579" || AreaCode == "581" || AreaCode == "819" || AreaCode == "873")
	{
		cout << "the Phone Number is from  Quebec " << endl;

	}
	//check if the Area Code is from Saskatchewan
	else	if (AreaCode == "306" || AreaCode == "639")
	{
		cout << "the Phone Number is from Saskatchewan  " << endl;

	}
	//check if the Area Code is from the terroritories:Yukon, Northwest Territories and Nunavut
	else	if (AreaCode == "867")

	{
		cout << " the Phone Number is from  Yukon, " << endl;
		cout << " Northwest Territories and Nunavut" << endl;
	}
	//If the Area Code is not from the above provinces and Territories listed 
	//above display the message below
	else
	{
		cout << " Area Code of the Phone Number you entered is not from Canada," << endl;
		cout << "although the Phone Number Is Correct" << endl;
		cout << " " << endl;
	}

}
void Process_Num(string PhoneNumb)
{


	if (PhoneNumb[3] == '-' && PhoneNumb[7] == '-')
	{
		cout << "The format of the Phone Number entered is correct ";
		//declare the first three values to be the Area Code(AreaCode) 
		string AreaCode = PhoneNumb.substr(0, 3);
		test(AreaCode, PhoneNumb);
		cout << "  " << endl;
		//Further check the Area Code of the input if the above conditions are met
		//check if the Area Code is from Alberta


	}
	else if (PhoneNumb[3] != '-' || PhoneNumb[7] != '-')
	{

		cout << "Error, the format of the Phone Number entered is incorrect, " << endl;

		cout << "Please make sure that the format Of your Phone Number is in DDD-DDD-DDDD format." << endl;
		cout << " " << endl;
	}

}
