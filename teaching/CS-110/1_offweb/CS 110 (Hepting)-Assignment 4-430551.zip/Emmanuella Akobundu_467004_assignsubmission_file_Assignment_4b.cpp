//Name: Emmanuella Akobundu
//
//Class: CS 110
//
//Assignment: 4b
//
//Student number: 200359057
//
// Program name: Program for determining Canadian area code using Functions
//
// Date written: 25th March, 2015
//
// Problem statement: This code is aimed at testing an inputed number to check if it has the correct format and
//					  then displaying the Canadian area code of the phone number.
//
// Input: The user is expected to input a phone number in the format, ddd-ddd-dddd
//
// Output: The output should display the area code of the phone number or an appropriate error message if the format is wrong
//
// Algorithm: The void function, testFormat, is used to test the format of the phone number entered by the user.
//			  The number should have the correct length with the dashes in the appropriate positions, 
//			  and should also have all the other characters as digits.		  
//			  Thereafter, a value-returning function, testAreaCode, is used to determine the province to which the area code 
//			  of the phone number entered belongs. This is done by defining the first three numbers in the string.
//			  The provinces are then assigned based on this set of numbers using logical operators.
//			  The program can be terminated when the user enters the letter q.
//
// Major variables: phone, code
//
// Limitations: The program cannot determine the locations to which any non-Canadian phone numbers entered belong

#include <iostream>
#include <string>
using namespace std;

// Function Prototype
void testFormat(string&, string&);
string testAreaCode(string&);


// Main Function
int main()
{
	//Ask user to enter a phone number in the format ddd-ddd-dddd
	cout << "Please enter a phone number in the format ddd-ddd-dddd." << endl;
	cout << "You can enter q to terminate program.\n" << endl;
	cout << "Phone number: ";

	string phone;
	string code;
	cin >> phone;
	
	if (phone == "q")
		return 0;

	else
	{
		testFormat(phone, code);
		cout << testAreaCode(code) << endl;
	}
	
	return 0;
}

//Function Definition
void testFormat(string& phone, string& code)
{
	//Define the first three numbers (area codes) in the phone number
	code = phone.substr(0, 3);

	//Check if phone number entered is in the correct format
	//Firstly, check that the phone number is 12 characters long
	//Then check if the phone number if the input matches ddd-ddd-dddd by checking if all the 
	//characters are digits except the dashes and if the dashes are in the correct positions.
	//Finally, check if the phone number has a Canadian area code. If it does, display what province it belongs to
	//If any of these are not followed, output the appropriate error message

	if (phone.length() == 12)
	{
		if (phone[3] == '-' && phone[7] == '-')
		{
			if ((phone[0] >= 0 && phone[0] <= 9) && (phone[1] >= 0 && phone[1] <= 9) && (phone[2] >= 0 && phone[2] <= 9)
				&& (phone[4] >= 0 && phone[4] <= 9) && (phone[5] >= 0 && phone[5] <= 9) && (phone[6] >= 0 && phone[6] <= 9) 
				&& (phone[8] >= 0 && phone[8] <= 9) && (phone[9] >= 0 && phone[9] <= 9) && (phone[10] >= 0 && phone[10] <= 9) 
				&& (phone[11] >= 0 && phone[11] <= 9))

				cout << "This is phone number has a valid format." << endl;
		}
	}

	else
		cout << "This is phone number has an invalid format! Please try again!" << endl;
}


string testAreaCode(string& code)
{

	if (code == "403" || code == "587" || code == "780" || code == "825")
		return "Area Code: Alberta";

	else if (code == "236" || code == "250" || code == "604" || code == "672" || code == "778")
		return "Area Code: British Columbia";

	else if (code == "204" || code == "431")
		return "Area Code: Manitoba";

	else if (code == "506")
		return "Area Code : New Brunswick";

	else if (code == "709")
		return "Area Code: Newfoundland and Labrador";

	else if (code == "782" || code == "902")
		return "Area Code: Nova Scotia and Prince Edward Island";

	else if (code == "548" || code == "249" || code == "289" || code == "343" || code == "365" || code == "387"
		|| code == "416" || code == "437" || code == "519" || code == "226" || code == "613" || code == "647"
		|| code == "705" || code == "742" || code == "807" || code == "905")
		return "Area Code: Ontario";

	else if (code == "418" || code == "438" || code == "450" || code == "514" || code == "579" || code == "581"
		|| code == "819" || code == "873")
		return "Area Code: Quebec";

	else if (code == "306" || code == "639")
		return "Area Code: Saskatchewan";

	else if (code == "867")
		return "Area Code: Yukon, Northwest Territories, and Nunavut";

	else
		return "This phone number does not have a valid Canadain area code! Please try again!";

}
