#include<iostream>
using namespace std;

//**************************************************************************
//
// Student name: Bright Nwanoruo
//
// Student number: 200337192
//
// Assignment number: #1
//
// Program name:   Bright4.cpp
//
// Date written: 23/3/2015
//
// Problem statement: A program that reads an integer between 0 and 10000
//and then calculates and displays (from the integer that has been read)
//The Sum of digits 
//The Average of digits
//The Product of digits
//Number of digits
//
// Input:  An integer between 0 and 10000
//
// Output: Number of digits:The Sum of digits 
//                          The Average of digits
//                          The Product of digits
//                          Number of digits
//
// Algorithm:
//Declare 5 number of digits, digits1 to digit5; 
//Prompt the user to enter an integer between 0 and 10000; 
//if the integer entered is between 0 and 10000 proceed and call the void function  process_number(int number) and from give process_number function
// call the functions cout number_digits(digit5, digit4, digit3, digit2) to get the number of digits;
// sum_digits(digit1, digit2, digit3, digit4, digit5) to get the sum of all the digits;
//prod_digits(digit1, digit2, digit3, digit4, digit5, numDigits) to get the product of the digits
// sum_digits(digit1, digit2, digit3, digit4, digit5) / static_cast<float>(number_digits(digit5, digit4, digit3, digit2)) to get the average of the digits
//sum of all the digits, average of all the digits, and product of digits. But, if the integer entered is less than 0 or greater than 10000, display
//"Number not between 0 & 10000, inclusive"
//
//
// Assumptions: The product is initialized to 1 to prevent giving the output 0 when less than 5digit integer is entered;
//
// Program limitations: 
//The program will proceed to give the outputs if the integer entered is between 0 and 10000. 
//If less than zero or greater 10000 the program will display an error message; 
//
//
//**************************************************************************



void process_number(int number);
int number_digits(int digit5, int digit4, int digit3, int digit2);
int sum_digits(int digit1, int digit2, int digit3, int digit4, int digit5);
int prod_digits(int digit1s, int digit10s, int digit100s, int digit1000s, int digit10000s, int number_digits);

int main()
{
	// get input
	cout << "Please enter a number between 0 and 10000" << endl;
	int number;
	cin >> number;

	while (number >= 0)
	{
		// if number is in the proper range
		if (number >= 0 && number <= 10000)
		{
			process_number(number);
		}
		else
		{
			cout << "Number not between 0 & 10000, inclusive" << endl;
		}
		// get input
		cout << "Please enter a number between 0 and 10000" << endl;
		cin >> number;
	}
	return 0;
}
void process_number(int number)
{
	// extract digits
	int digit1 = number % 10;
	number /= 10;
	int digit2 = number % 10;
	number /= 10;
	int digit3 = number % 10;
	number /= 10;
	int digit4 = number % 10;
	number /= 10;
	int digit5 = number % 10;

	// perform computations -- there is at least 1 digit,
	// so initialize variables with it, even if it is 0
	
	int numDigits = number_digits(digit5, digit4, digit3, digit2);

	cout << "Number of digits: " << number_digits(digit5, digit4, digit3, digit2) << endl;
	cout << "Sum of digits: " << sum_digits(digit1, digit2, digit3, digit4, digit5) << endl;
	cout << "Product of digits: " << prod_digits(digit1, digit2, digit3, digit4, digit5, numDigits) << endl;
	cout << "Average of digits: " << sum_digits(digit1, digit2, digit3, digit4, digit5) / static_cast<float>(number_digits(digit5, digit4, digit3, digit2)) << endl;
}
//function for the number of digits
int number_digits(int digit5, int digit4, int digit3, int digit2)
{
	int count_digits = 1;
	if (digit5 > 0)
	{
		count_digits = 5;
	}
	else if (digit4 > 0)
	{
		count_digits = 4;
	}
	else if (digit3 > 0)
	{
		count_digits = 3;
	}
	else if (digit2 > 0)
	{
		count_digits = 2;
	}
	return count_digits;
}

//function for the sum of digits
int sum_digits(int digit1, int digit2, int digit3, int digit4, int digit5)
{
	return digit1 + digit2 + digit3 + digit4 + digit5;
}
//functions for product of digits
int prod_digits(int digit1s, int digit10s, int digit100s, int digit1000s, int digit10000s, int number_digits)
{
	// handle case for at least 1 digit
	int prod = digit1s;
	// handle case for at least 2 digits
	if (number_digits >= 2)
	{
		prod = prod * digit10s;
	}
	// handle case for at least 3 digits
	if (number_digits >= 3)
	{
		prod = prod * digit100s;
	}
	// handle case for at least 4 digits
	if (number_digits >= 4)
	{
		prod = prod * digit1000s;
	}
	if (number_digits >= 5)
	{
		prod = prod * digit10000s;
	}
	// if number_digits == 5, the digit can only be 1, so it won't affect product
	return prod;
}

