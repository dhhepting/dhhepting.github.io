/*-----------------------------------------------------------------------------
 
 NAME: Aidan (Clark) McMaster     SID: 200354844       WRITTEN: March 20, 2015
                    
                    ASSIGNMENT 4: Integer Analyzer (PART 2)
        
        Input any integer between 0 and 10000, and the program will analyze 
and output how many digits the interger has, the sum of the digits, the average 
of the digits, and the product of the digits. 

        The main variables used were:
       
            integer1: Stores main inputted integer
            countInt: Stores the number of digits
            sum:      Stores the sum of the digits
            avgInt:   Stores the average of the digits
            prod:     Stores the product of the digits
        
-----------------------------------------------------------------------------*/
        

#include <iostream>
#include <iomanip>
using namespace std;

int numdigits(int&, int&);

int sumdigits(int&, int&);

float avgdigits(int&, int&);

int prodigits(int&, int&);

int main()
{
    
   cout << "Hello! Please enter an integer between 0 and 10000" << endl;
   double integer1;
   cin >> integer1;
    
   while((integer1 > 10000) || (integer1 < 0))    
    {
       cout << "Error! That integer is not in the allowed range. Try again" << endl;
       cin >> integer1;
    }
   
   int integer = integer1;
   int countInt = 0;                    //First we find the number of digits:
   countInt = numdigits(integer, countInt);
   

   int sumInt = integer1;               //Now we find the sum of all digits:
   int sum = 0;
   sumdigits(sumInt, sum) == sum;

   double avgInt;
   avgInt = avgdigits(sum, countInt);  /*Finding the average is easy! Since we have
                                    both the sum of the digits and the number of
                                   digits, we just have to divide the sum by the
                                    number of digits!*/
    
    int prodInt = integer1;        //All that's left is to find the product.
    int prod = 1;
	prod = prodigits(prodInt, prod);
	
   
   //Now that all the math is done, we can output the values.
   
   cout << "Your integer was: " << integer1 << endl;
   cout << "The number of digits was: " << countInt << endl;
   cout << "The sum of the digits was: " << sum << endl;
   cout << "The average was: " << fixed << setprecision(1) << avgInt << endl;
   cout << "The product of the digits was: " << prod << endl;
   
   return 0;
}

int numdigits(int& integer, int& countInt)
{
	while (integer > 0)
	{
		countInt++;
		integer /= 10;
	}
	return countInt;
}

int sumdigits(int& sumInt, int& sum)
{
	while (sumInt > 0)
	{
		sum += sumInt % 10;
		sumInt /= 10;
	}
	return sum;

}

float avgdigits(int& sum, int& countInt)
{
	double avgInt = sum / countInt;
	return avgInt;

}

int prodigits(int& prodInt, int& prod)
{
	while (prodInt > 0)
	{
		prod *= prodInt % 10;
		prodInt /= 10;
	}
	return prod;

}