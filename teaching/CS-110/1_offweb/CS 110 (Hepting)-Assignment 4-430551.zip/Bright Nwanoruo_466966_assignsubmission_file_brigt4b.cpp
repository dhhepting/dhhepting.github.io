#include<iostream>
#include<string>
using namespace std;

//**************************************************************************
//
// Student name: Bright Nwanoruo
//
// Student number: 200337192
//
// Assignment number: #4b
//
// Program name: bright4b.cpp
//
// Date written: 23/3/2015
//
// Problem statement:

//Modify Assignment 2 so that the validation of the telephone format is done in one function and the test to see if the area code is
//from Canada is done in another function.

// Input: Enter a telephone number in the formte ddd-ddd-dddd
//
// Output: Run the program and display "if the area code is from North America, but not canada "
// or display "the province at which the phone number is, within canada(if at all the phone number is from canada" 
//if not display "errors that prevented such outputs";beside all mentioned, the program will continue to process
// numbers until the user enters q.
//.
//
//
// Algorithm: 
//( 1.) check if phone number is 12 long and continue if condition is met; if not display the error message.
// But if the condition is met then call the function Process_Num(PhoneNumb) to process the number
//
//( 2.)  check if the values that make up the 12 long input are all digits within 0-9 and continue if condition is met;
//     if not display the error message.  
//
//
//( 3.) check the format of the phone number entered and condition is met; if not display the error message.
//
//( 4.) From the void funtion Process_Num(PhoneNumb) check the area code of the phone number entered, whether it is from canada or not.
//If it is from canada display the province with the area code, but if not from canada output "The Area Code of the Phone Number you entered 
// is not from Canada, although the Phone Number Is Correct." 
//
// Major variables: PhoneNumb; AreaCode.
//
// Assumptions:your phone number is from north america.
//
// Program limitations:Your input must be only be digits from 0 to 9;no letters; input must be 12 digits long;input must be
//in the format ddd-ddd-dddd;the phone number must be from north America.
//
//**************************************************************************



void Process_Num(string PhoneNumb);//void function
void test(string AreaCode, string PhoneNumb);//void function

int main()
{
	//declare your Phone number to be PhoneNumb
	string PhoneNumb;


	//use a do-while loop to get the programe running continuosly 
	do{
		//Prompt the user to enter a Phone number
		cout << "Enter your Phone Number in the format DDD-DDD-DDDD : " << endl;
		cout << " " << endl;



		//using get line, get the input(Phone number) and display it to the user
		getline(cin, PhoneNumb);
		cout << "Your Phone Number is : " << PhoneNumb << endl;
		cout << "  " << endl;

		//check if the input is 12 characters long
		if ((PhoneNumb.length() == 12) && (PhoneNumb != "q"))


		{

			//check the values of the input if all are digits
			if ((PhoneNumb[0] >= '0' && PhoneNumb[0] <= '9')

				&&

				(PhoneNumb[1] >= '0' && PhoneNumb[1] <= '9')

				&&

				(PhoneNumb[2] >= '0' && PhoneNumb[2] <= '9')

				&&


				(PhoneNumb[4] >= '0' && PhoneNumb[4] <= '9')

				&&

				(PhoneNumb[5] >= '0' && PhoneNumb[5] <= '9')
				&&



				(PhoneNumb[6] >= '0' && PhoneNumb[6] <= '9')
				&&



				(PhoneNumb[8] >= '0' && PhoneNumb[8] <= '9')
				&&


				(PhoneNumb[9] >= '0' && PhoneNumb[9] <= '9')
				&&

				(PhoneNumb[10] >= '0' && PhoneNumb[10] <= '9')
				&&
				(PhoneNumb[11] >= '0' && PhoneNumb[11] <= '9'))

			{

				Process_Num(PhoneNumb);

				
			}
			//if the value of the input are not all digits within 0 to 9, display the error message below 
			else
			{
				cout << "Error, the values of your Phone Number are not all digits" << endl;

			}

		}
		//if the input are not 12 character long display the error message below
		else if (PhoneNumb.length() != 12 && PhoneNumb != "q")
		{
			cout << "Error, the Phone Phone Number you entered is not 12 characters long" << endl;
			cout << " " << endl;

		}

	}
	//here is the closure of the do-while loop; when the user enters "q" the program stops running 
	//and prompt the user to "press any key to continue"
	while (PhoneNumb != "q");



	//return 0 which means "no error" from the compiling of the program
	return 0;
}
//function to test the area code of the phone number
void test(string AreaCode, string PhoneNumb)
{

	//string AreaCode = PhoneNumb.substr(0, 3);
	if (AreaCode == "403" || AreaCode == "587" || AreaCode == "780" || AreaCode == "825")
	{
		cout << "and the Phone Number is from a province in canada called Alberta   " << endl;
	}
	// check if area Code is from British Columbia 
	else	if (AreaCode == "236" || AreaCode == "250" || AreaCode == "604" || AreaCode == "672" || AreaCode == "778")
	{
		cout << " and the Phone Number is from a province in canada called British Columbia  " << endl;

	}

	//check if the Area code is from Manitoba
	else	if (AreaCode == "204" || AreaCode == "431")
	{
		cout << "and the Phone Number is from a province in canada called Manitoba  " << endl;

	}
	//check if the Area code is from New Brunswick
	else	if (AreaCode == "506")
	{
		cout << "and the Phone Number is from a province in canada called New Brunswick  " << endl;
	}
	//check if the Area code is from Newfoundland and labrador
	else	if (AreaCode == "709")
	{
		cout << "and the Phone Number is from a province in canada called Newfoundland and Labrador  " << endl;
	}
	//check if the Area code if from Nova Scotia
	else	if (AreaCode == "782" || AreaCode == "902")
	{
		cout << "and the Phone Number is from a province in canada called Nova Scotia  " << endl;

	}

	//check if the Area Code is from Ontario
	else	if (AreaCode == "548" || AreaCode == "249" || AreaCode == "289" ||
		AreaCode == "343" || AreaCode == "365" || AreaCode == "387" || AreaCode == "416" ||
		AreaCode == "437" || AreaCode == "519" || AreaCode == "226" || AreaCode == "613" ||
		AreaCode == "647" || AreaCode == "705" || AreaCode == "742" || AreaCode == "807" || AreaCode == "905")
	{
		cout << "and the Phone Number is from a province in canada called Ontario  " << endl;

	}
	//check if the Area Code is from Edward Island
	else	if (AreaCode == "782" || AreaCode == "902")
	{
		cout << "and the Phone Number is from a province in canada called Prince Edward Island  " << endl;

	}
	//check if the Area Code is from Quebec
	else	if (AreaCode == "418" || AreaCode == "438" || AreaCode == "450" || AreaCode == "514" ||
		AreaCode == "579" || AreaCode == "581" || AreaCode == "819" || AreaCode == "873")
	{
		cout << "and the Phone Number is from a province in canada called  Quebec " << endl;

	}
	//check if the Area Code is from Saskatchewan
	else	if (AreaCode == "306" || AreaCode == "639")
	{
		cout << "and the Phone Number is from a province in canada called Saskatchewan  " << endl;

	}
	//check if the Area Code is from the terroritories:Yukon, Northwest Territories and Nunavut
	else	if (AreaCode == "867")

	{
		cout << "and the Phone Number is from one of the terroritories in Canada called Yukon, " << endl;
		cout << " Northwest Territories and Nunavut" << endl;
	}
	//If the Area Code is not from the above provinces and Territories listed 
	//above display the message below
	else
	{
		cout << "but Area Code of the Phone Number you entered is not from Canada," << endl;
		cout << "although the Phone Number Is Correct" << endl;
		cout << " " << endl;
	}

}
//function to process the phone number to check the format
void Process_Num(string PhoneNumb)
{


	if (PhoneNumb[3] == '-' && PhoneNumb[7] == '-')
	{
		cout << "The format of the Phone Number entered is correct ";
		//declare the first three values to be the Area Code(AreaCode) 
		string AreaCode = PhoneNumb.substr(0, 3);
		test(AreaCode, PhoneNumb);
		cout << "  " << endl;
		//Further check the Area Code of the input if the above conditions are met
		//check if the Area Code is from Alberta


	}
	else if (PhoneNumb[3] != '-' || PhoneNumb[7] != '-')
	{

		cout << "Error, the format of the Phone Number entered is incorrect, " << endl;

		cout << "Please make sure that the format Of your Phone Number is in DDD-DDD-DDDD format." << endl;
		cout << " " << endl;
	}

}
