/*
Name: Naizhao Tan
Student number: 200353140
Assignment number: 4
Program Name: Assignment 1
Program Due: Mar 26 2015
Date: Mar 23 2015
problem statement:
Modify Assignment 1 code so that the calculations it does are located within a function. 
The main() function that calls this function should let the user input any desired about of numbers,
until a negative number is input.
input:  1.  2468  2.  5070   3.  42   4.  23451
output:
1.  (4, 20, 5, 384)
2.  (4, 12, 3, 0)
3.  (2, 6, 3, 8)
algorithm:
Step 1. Read in variables
Step 2. Set the conditions for the number that user enters
Step 3. Obtain digits and do the compute
major variables: There are 6 variables in the code
program limitations:
It could only compute with integer

*/




#include <iostream>
#include <iomanip>

using namespace std;

void Cal(int);

int main(){
	//Ask user to input the number
	int number = 0;
	while (number != -1){
		cout << "Please enter a number" << endl;
		cin >> number;
		//Call the calculation function
		Cal(number);
		
	} 

	return 0;
}
//Write the function
void Cal(int number){
	int sum, product, amount;
	double average;
	int digit1 = 0, digit2 = 0, digit3 = 0, digit4 = 0, digit5 = 0;
	//Limit the range of the input number
	if (0 <= number && number <= 10000){
		//Obtain digits from input number, and calculate the sum, product and average
		if (0 <= number && number < 10){
			digit1 = number;
			amount = 1;
			sum = digit1;
			product = digit1;
			average = static_cast<double>(digit1);
		}
		else if (10 <= number && number < 100){
			digit1 = number / 10;
			digit2 = number % 10;
			amount = 2;
			sum = digit1 + digit2;
			product = digit1 * digit2;
			average = static_cast<double>((sum)) / 2.0;
		}
		else if (100 <= number && number < 1000){
			digit1 = number / 100;
			digit2 = (number % 100) / 10;
			digit3 = (number % 100) % 10;
			amount = 3;
			sum = digit1 + digit2 + digit3;
			product = digit1 * digit2 * digit3;
			average = static_cast<double>((sum)) / 3.0;
		}
		else if (1000 <= number && number < 10000){
			digit1 = number / 1000;
			digit2 = (number % 1000) / 100;
			digit3 = ((number % 1000) % 100) / 10;
			digit4 = (number % 1000) % 10;
			amount = 4;
			sum = digit1 + digit2 + digit3 + digit4;
			product = digit1 * digit2 * digit3 * digit4;
			average = static_cast<double>((sum)) / 4.0;
		}
		else{
			amount = 5;
			sum = 1;
			product = 0;
			average = static_cast<double>((sum)) / 5.0;
		}
		//Output the result
		cout << "The number of the dight is: " << amount << endl;
		cout << "The sum of dights is: " << sum << endl;
		cout << "The average of dights is: " << average << endl;
		cout << "The product of dights is: " << product << endl;
	}
	else if(number == -1){
		cout << "Thanks for using" << endl; 
		
	}

}