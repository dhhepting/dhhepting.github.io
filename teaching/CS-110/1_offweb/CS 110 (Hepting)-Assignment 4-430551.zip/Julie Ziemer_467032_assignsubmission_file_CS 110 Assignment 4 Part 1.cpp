//**************************************************************************
//
// Student name: Julie Ziemer
//
// Student number: 200342432
//
// Assignment number: Assignment 4
//
// Program name: CS 110 Assignment 4 Part 1.cpp
//
// Date written: March 25, 2015
//
// Problem statement:  Modify Assignment 1 code so that the calculations it does are located within a function.The main() function that calls this function 
//					   should let the user input any desired about of numbers, until a negative number is input
//
// Input: User enters a number from 0 to 10000.
//
// Output: "To quit the program, please enter a negative number.", "Please enter a number between 0 and 10000.", "Number does not follow constraints",
//			"Average of digits:", "Sum of digits:", "Product of digits:", "Number of digits:"
//
// Algorithm: A void prototype is used for storing the number the user inputs.  The user is prompted to enter the number in the main, a while statement is initiated. 
//			  The while loop continues until the user enters a negative number, or one beyond the constraints of 0 to 10000.  Within the while
//			  loop, the call statements are made for the calculated number. Outide of the main, the definitions for this function is declared.
//			  The calculated number function outputs the number of digits, the sum, the product, and the average of digits.
//
// Major variables: int num_calc, number, sum, prod, num_digits, digit; bool non_zero = true;
//
// Assumptions:  The user will enter a number between 0 and 10000.
//
// Program limitations: The number entered must be between 0 and 10000, and the user must enter a negative to end the program.
//
//**************************************************************************
#include <iostream>
using namespace std;

// Prototype void function
void digit_calculations(int num_calc);

int main()
{
	// get input
	cout << "To quit the program, please enter a negative number." << endl;
	cout << "Please enter a number between 0 and 10000." << endl;
	int number = 0;
	cin >> number;

	// call function if the digit is between 0 and 10000
	while (number >= 0 && number <= 10000)
	{
		digit_calculations(number);

		cout << "Please enter a number between 0 and 10000." << endl;
		cin >> number;
	}
	
	cout << "Number does not follow constraints" << endl; // end program when a number outside of 0 - 10000 is entered

	return 0;
}
// Function Definition for calculations

void digit_calculations(int num_calc)
{
	// extract digits
	int sum = 0;
	int prod = 1;
	int num_digits = 0;
	bool non_zero = false;
	int digit = 0;

	// 10000's place (1 or none)
	digit = num_calc / 10000;
	num_calc -= (digit * 10000);
	if (digit > 0 || non_zero == true)
	{
		non_zero = true;
		sum += digit;
		prod *= digit;
		num_digits++;
	}

	// 1000's place (0 - 9)
	digit = num_calc / 1000;
	num_calc -= (digit * 1000);
	if (digit > 0 || non_zero == true)
	{
		non_zero = true;
		sum += digit;
		prod *= digit;
		num_digits++;
	}

	// 100's place (0 - 9)
	digit = num_calc / 100;
	num_calc -= (digit * 100);
	if (digit > 0 || non_zero == true)
	{
		non_zero = true;
		sum += digit;
		prod *= digit;
		num_digits++;
	}

	// 10's place (0 - 9)
	digit = num_calc / 10;
	num_calc -= (digit * 10);
	if (digit > 0 || non_zero == true)
	{
		non_zero = true;
		sum += digit;
		prod *= digit;
		num_digits++;
	}

	// 1's place (0 - 9)
	sum += num_calc;
	prod *= num_calc;
	num_digits++;

	cout << "Number of digits: " << num_digits << endl;
	cout << "Sum of digits: " << sum << endl;
	cout << "Product of digits: " << prod << endl;
	cout << "Average of digits: " << sum / static_cast<float>(num_digits) << endl;
}
