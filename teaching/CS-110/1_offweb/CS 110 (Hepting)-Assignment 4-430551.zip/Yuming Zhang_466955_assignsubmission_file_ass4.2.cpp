
//********************************************************************
//Name: Yuming Zhang
//Student number: 200338416
//Assignment number: 2
//Program name: Testing and check if the phone number has a Canadian area code
//Date written: Mar 24th, 2015
//Problem statement: Write a program that prompts the user to enter a telephone number in the format ddd-ddd-dddd, where d is digit. This is the format for telephone numbers in North America. Test that the input is in the correct format and further check if the phone number has a Canadian area code (see the list of Canadian area codes). The program will report if the input is valid or not. If the input includes a Canadian area code, the program will display the name of the province or territory with that area code. The program will continue to process numbers until the user enters the letter q.
//Input: A valid 12 digits telephone number
//Output: Correct area code from a province from Canada
//Algorithm 1: Input a telephonenumber as a string.
//Algorithm 2: If the input telephonenumber is letter "q", "Exit the program" will display and the program is over.
//Algorithm 3: If the input telephonenumber'length is 12, the program will check if the first three digits are from Canada'area code or not.
//Algorithm 4: If the first three digits are from Canada's area code, the program should tell which area does the number belong to.
//Algorithm 5: If the first three digits are not from Canada's area code, the number is invalid.
//Algorithm 6: If the input telphonenumber's length is not 12, the program will display "the length is wrong" and it will not run the next step to check the area code.
//Major variables: telephonenumber, areacode
//Assumptions:  The program helps users to test the telephonenumbers. Any international telephone number or number from other areas outside Canada will be invalid.
//Program limitations:The telephone number should only come from Canada area.
//**********************************************************************


#include <iostream>
#include <string>
using namespace std;

void format(string t, string a);
void tele(string telephonenumber, string areacode);
int main()

{

	string t = "0";
	string a;
	format(t, a);
}
void tele(string telephonenumber, string areacode)
{
	if (areacode == "403" || areacode == "587" || areacode == "780" || areacode == "825")
		cout << "This number's area code is from Alberta." << endl;
	else if (areacode == "236" || areacode == "250" || areacode == "604" || areacode == "672" || areacode == "778")
		cout << "This number's area code is from British Columbia." << endl;
	else if (areacode == "204" || areacode == "431")
		cout << "This number's area code is from Manitoba." << endl;
	else if (areacode == "236" || areacode == "250" || areacode == "604" || areacode == "672" || areacode == "778")
		cout << "This number's area code is from New Brunswick." << endl;
	else if (areacode == "709")
		cout << "This number's area code is from Newfoundland and Labrador." << endl;
	else if (areacode == "782" || areacode == "902")
		cout << "This number's area code is from Nova Scotia." << endl;
	else if (areacode == "548" || areacode == "249" || areacode == "289" || areacode == "343" || areacode == "365" || areacode == "387" || areacode == "416" || areacode == "437" || areacode == "519" || areacode == "226" || areacode == "613" || areacode == "647" || areacode == "705" || areacode == "742" || areacode == "807" || areacode == "905")
		cout << "This number's area code is from New Brunswick." << endl;
	else if (areacode == "782" || areacode == "902")
		cout << "This number's area code is from Prince Edward Island." << endl;
	else if (areacode == "418" || areacode == "438" || areacode == "450" || areacode == "514" || areacode == "579" || areacode == "581" || areacode == "819" || areacode == "873")
		cout << "This number's area code is from Quebec." << endl;
	else if (areacode == "306" || areacode == "639")
		cout << "TThis number's area code is from Saskatchewan." << endl;
	else if (areacode == "867")
		cout << "This number's area code is from Yukon, Northwest Territories, and Nunavut." << endl;
	else
		cout << "This number's area code is not from Canada." << endl;
	cout << endl;
	format(telephonenumber, areacode);
}
void format(string t, string a)
{
	while (t != "q")
	{
		cout << "Please enter a telephone number in the format ddd-ddd-dddd, where d is digit." << endl;
		cin >> t;
		if (t.length() == 12)
		{
			if (t.length() == 12 && t.at(0) >= '0' && t.at(0) <= '9' && t.at(1) >= '0' && t.at(1) <= '9' && t.at(2) >= '0' && t.at(2) <= '9' && t.at(3) == '-' && t.at(4) >= '0' && t.at(4) <= '9' && t.at(5) >= '0' && t.at(5) <= '9' && t.at(6) >= '0' && t.at(6) <= '9' && t.at(7) == '-' && t.at(8) >= '0' && t.at(8) <= '9' && t.at(9) >= '0' && t.at(9) <= '9' && t.at(10) >= '0' && t.at(10) <= '9' && t.at(11) >= '0' && t.at(11) <= '9')
			{
				string a = t.substr(0, 3);
				cout << "The area code is " << a << endl;
				tele(t, a);
			}
			else
				cout << "error input is invalid " << endl;
		}
		else if (t == "q")
		{
			cout << "Exist the program" << endl;
			exit(0);
		}
		else
			cout << "the length is wrong" << endl;
		cout << endl;
	}

}
