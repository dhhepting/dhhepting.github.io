/*********************************************************************************************************
 
 Student Name: Alexander Cameron
 
 Student Number: 200 246 288
 
 Assignment Number: 4.2
 
 Program Name: Telephone Area Code Finder Using Functions
 
 Date Written: 25 March, 2015
 
 Problem Statement: This program is created to identify a phone number by its Canadian area code.
 
 Input: 10 digit hyphenated phone number.
 
 Output: Location attached to the phone number's Area Code.
 
 Algorithm: The user will be prompted to input a phone number, once this is don the program will check to ensure the correct fromat has been used, and if so it will then check to see if the first three digits (the area code) match that of one of the ten Canadian provinces or three territories. If it matches the name of the corresponding province or territory will be out put, if not it will indicate that it is not a canadian area code. Whichever the case the program will continue to ask for input until the user inputs 'q'
 
 Major Variables: string
 
 Assumptions: This program assumes that the user is inputting a regular phone number
 
 Program Limitations: This program is limited to Canadian phone numbers, only in the format "ddd-ddd-dddd".
 
 
 ********************************************************************************************************/
#include <iostream>
#include <string>
using namespace std;
int phonegood(string);
void area_code (string);
int main()
{
    string telno;
    do
    {
    cout << "Enter phone number ddd-ddd-dddd" << endl; //original input
    
    cin >> telno;
    
    //set the function equal to a variable to save it, put string "telno" into phonegood function
    int proper_format= phonegood(telno);
        
    //if phonegood returns 1, activate the areacode function
        if (proper_format==1)
        {
            area_code(telno);
        }
    //if phonegood returns 0, either quit program or prompt the user to input correctly
        else if (proper_format==0)
        {
            if(telno[0] != 'q')
                cout << "Number not proper length: should be 10 digits with 2 hyphens" << endl;
            else
                cout<<"I will miss you, goodbye!";
        }
            
        
    }while (telno[0] != 'q'); //continue program unless 'q' is entered
    return 0;
}



int phonegood(string telno)     //function to ensure phone number has been input correctly
{
    if (telno.length() == 12) // proper length
    {
        for (int i = 0;i < 12; i++)
        {
            
            if (i == 3 || i == 7)   // ensure hyphens in right spot
            {
                if (telno[i] != '-')
                {
                    return 0;
                    
                }
            }
          
            else if (!isdigit(telno[i])) //ensure digits in correct spot
            {
                return 0;
                
            }
            
            
        }
        return 1;//Added this to return if it makes it through the loop.
        
    }
    return 0;
    
}




void area_code(string telno)    //check the area code for which the phone is from
{
    string area_code = telno.substr(0,3); //take the first three digits and check with each area
    string region = "Outside of Canada";
    // Alberta:	403, 587, 780, 825
    if (area_code == "403" ||
        area_code == "587" ||
        area_code == "780" ||
        area_code == "825")
    {
        region = "Alberta";
    }
    // British Columbia	236, 250, 604, 672, 778
    else if (area_code == "236" ||
             area_code == "250" ||
             area_code == "604" ||
             area_code == "672" ||
             area_code == "778")
    {
        region = "British Columbia";
    }
    // Manitoba	204, 431
    else if (area_code == "204" ||
             area_code == "431")
    {
        region = "Manitoba";
    }
    // New Brunswick	506
    else if (area_code == "506")
    {
        region = "New Brunswick";
    }
    // Newfoundland and Labrador	709
    else if (area_code == "709")
    {
        region = "Newfoundland and Labrador ";
    }
    // Nova Scotia	782, 902
    else if (area_code == "782" ||
             area_code == "902")
    {
        region = "Nova Scotia";
    }
    // Ontario	548, 249, 289, 343, 365, 387, 416, 437,
    //		519, 226, 613, 647, 705, 742, 807, 905
    else if (area_code == "548" ||
             area_code == "249" ||
             area_code == "289" ||
             area_code == "343" ||
             area_code == "365" ||
             area_code == "387" ||
             area_code == "416" ||
             area_code == "437" ||
             area_code == "519" ||
             area_code == "226" ||
             area_code == "613" ||
             area_code == "647" ||
             area_code == "705" ||
             area_code == "742" ||
             area_code == "807" ||
             area_code == "905")
    {
        region = "Ontario";
    }
    // Prince Edward Island	782, 902
    else if (area_code == "782" ||
             area_code == "902")
    {
        region = "Prince Edward Island";
    }
    // Quebec	418, 438, 450, 514, 579, 581, 819, 873
    if (area_code == "418" ||
        area_code == "438" ||
        area_code == "450" ||
        area_code == "514" ||
        area_code == "579" ||
        area_code == "581" ||
        area_code == "819" ||
        area_code == "873")
    {
        region = "Quebec";
    }
    // Saskatchewan	306, 639
    if (area_code == "306" ||
        area_code == "639")
    {
        region = "Saskatchewan";
    }
    //Yukon, Northwest Territories, and Nunavut	867
    else if (area_code == "867")
    {
        region = "Yukon, Northwest Territories, and Nunavut";
    }
    cout << "Number appears to be from: " << region << endl;
}





