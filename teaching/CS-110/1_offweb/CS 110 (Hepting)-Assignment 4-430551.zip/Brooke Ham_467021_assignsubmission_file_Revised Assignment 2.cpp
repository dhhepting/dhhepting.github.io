/*
Student name: Brooke Ham
Student number: 200353759
Assignment number: 4
Program name: Area Coding.... With Functions!
Date: written for Mar. 25, 2015
Problem Statement: Modify Assignment 2 so that the validation of the telephone format is done in one function and the test to see 
	if the area code is from Canada is done in another function. The problem statement for Assignment 1 is as follows: Write a 
	program that prompts the user to enter a telephone number in the format ddd-ddd-dddd, where d is digit. This is the format for
	telephone numbers in North America. Test that the input is in the correct format and further check if the phone number has a 
	Canadian area code (see the list of Canadian area codes). The program will report if the input is valid or not. If the input 
	includes a Canadian area code, the program will display the name of the province or territory with that area code. The program 
	will continue to process numbers until the user enters the letter q.
Input: A number preferably in the form ddd-ddd-dddd (where d is a digit), although other inputs will give an output on this program.
Output: The correctness of the format of the input and whether the area code is Canadian are the outputs of this program.
Algorithm: The user will enter a number string in the correct format (after being prompted to do so) and the format will be tested in a function 
	(using boolean operators to test each section of the phone number and its total length) and if/else statments in a different function to 
	show if the area code the user inputted corresponds to a Canadian province or is in the correct format.
Major variables: pNum, areaCode
Assumptions: The program will compile and run correctly, no syntax or logic or runtime errors are present in the code.
Program Limitations: A number in the form of ddd-ddd-dddd must be inputted to obtain a result.
*/

#include <iostream>																													// This is the preprocessor directive that is used to support input and output.
#include <string>																													// This preprocessor directive allows stings to be used in the code.

using namespace std;																												// Standard namespace is used in this code.

void NUMBER(string, string&);																										// Function prototypes allow the functions to be used later. They are void becuase no values are returned.
void ACODE(string);

int main()																															// The main funciton intitates the program by creating an integer and an argument (which is the code below).
{
	while (true)																													// The code will repeat until "Q" or "q" is entered by the user (which will be expressed below).
	{
		cout << endl;																												// This simply spaces the output each time the code repeats.
		cout << "Please enter a phone number in the form ddd-ddd-dddd," << endl;													// This message is relayed to the user and prompts the user to enter a phone number in a specific format.
		cout << "where d is a digit. For example, 123-456-7890 is a viable entry." << endl;
		cout << "Or press Q or q to exit." << endl;																					// This lets the user know that they can exit the program by entering "Q" or "q."
		string pNum;																												// The string "pNum" is declared for the phone number that will be inputteed by the user.
		cin >> pNum;																												// The computer can now recognize the phone number that the user inputted, and the input is assigned to the string "pNum."

		string format;																												// A string that will be used to evaluate the format of the function is declared.
		string areaCode(pNum, 0, 3);																								// The area code is separated from the phone number and assigned to the string areaCode. 

		NUMBER(pNum, format);																										// The NUMBER function is called.
		
		if (format == "correct")																									// The NUMBER function has manipulated the string format based on its format, and what it was changed to determines what
			ACODE(areaCode);																										// happens next (using if statements). The area code only has to be tested if the format is correct, the program will quit if 
																																	// "Q" or  "q" was entered, and if the input was correct, then the user has the opportunity to try entering another input.
																					
		else if (format == "quit")											 
			return 0;														

		else
			cout << "This is not the correct format. Try again." << endl;															
	}

}

void NUMBER(string phone, string& form)																								// Function definition for NUMBER
{
	if (phone.length() == 12 &&																										// This tests the length of the input (which should be 12 characters including dashes if its a phone number), as well as the values (which should be between "0" 
		phone[0] >= '0' && phone[0] <= '9' && phone[1] >= '0' && phone[1] <= '9' && phone[2] >= '0' && phone[2] <= '9' &&			// and "9" for each individual character. For the format to be correct, the first three digits must have values between "0" and "9", followed by a dash, followed 
		phone[3] == '-' &&																											// by three characters with values between "0" and "9", followed by a dash, and followed by four characters with values between "0" and "9".
		phone[4] >= '0' && phone[4] <= '9' && phone[5] >= '0' && phone[5] <= '9' && phone[6] >= '0' && phone[6] <= '9' &&			
		phone[7] == '-' &&																											
		phone[8] >= '0' && phone[8] <= '9' && phone[9] >= '0' && phone[9] <= '9' && phone[10] >= '0' && phone[10] <= '9' &&	
		phone[11] >= '0' && phone[11] <= '9')
	{
		cout << "The format of the phone number that you entered was correct. Good work!" << endl;
		form = "correct";
	}

	else if (phone == "Q" || phone == "q")																							// This is used if the phone number length is not the correct length or if the characters aren't either numbers or dashes in the correct order. If the user wants
		form = "quit";																												// to quit the loop, then entering "Q" or "q" will quit the code.
	
	else																															// If "Q" or "q" or a correct phone number wasn't entered, then the format for the phone number wasn't correct.
		form = "incorrect";
}

void ACODE (string area)
{
	if (area == "403" || area == "587" || area == "780" || area == "825")															// Each if statement has a set of area codes that correspond to a province or territory in Canada. If the statement is true, then the following cout statement will be displayed. If the 
		cout << "This area code is used in Alberta." << endl;																		// statement is not true, then the next if statement will be tested. If none of the if statemtents are true, then the area code that was typed in by the user is not used in Canada. This
																																	// is covered by the else statement.
	else if (area== "236" || area == "250" || area == "604" || area == "672" || area == "778")
		cout << "This area code is used in British Columbia." << endl;

	else if (area == "204" || area == "431")
		cout << "This area code is used in Manitoba." << endl;

	else if (area == "506")
		cout << "This area code is used in New Brunswick." << endl;

	else if (area == "709")
		cout << "This area code is used in Newfoundland and Labrador." << endl;

	else if (area == "782" || area == "902")
		cout << "This area code is used in Nova Scotia and Prince Edward Island." << endl;

	else if (area == "548" || area == "249" || area == "289" || area == "343" || area == "365" 
		|| area == "387" || area == "416" || area == "437" || area == "519" || area == "226" 
		|| area == "613" || area == "647" || area == "705" || area == "742" || area == "807" || area == "905")
		cout << "This area code is used in Ontario." << endl;

	else if (area == "418" || area == "438" || area == "450" || area == "514" || area == "579" || area == "581" || area == "819" || area == "873")
		cout << "This area code is used in Quebec." << endl;

	else if (area == "306" || area == "639")
		cout << "This area code is used in Saskatchewan." << endl;

	else if (area == "867")
		cout << "This area code is used in the Yukon, Northwest Territories, and Nunavut." << endl;

	else
		cout << "This is not a Canadian area code." << endl;
}