/******************************
student name : Lei Nie
student number : 200304372
assignment number : 1
program name : get number, sum, average, product of the digits
date written : Jan 29
problem statement:write a program that reads an integer between 0 and 10000 and then calculates and displays
input: 2468, 5070, 42 23451.
output:4,20,5,384; 4,12,3,0; 2,6,3,8; uninvalid number.
algorithm: slection control
majoy variables: number, one two three four
assumptions: i can diffenert way
program limitations:no
******************************/

#include <iostream>
#include <math.h>
using namespace std;

void getnumber(int&);
void sele(int, int, int, int, int, int);

void getnumber(int& number)
{

	cout << "please enter number: ";
	cin >> number;//input number
}

void sele(int number,int one, int two, int three, int four, int five)
{
	if (number >= 0 && number<10)//if number >=0 and <10
	{
		one = number;//7, 7 is one
		cout << "the number of digits: 1" << endl;
		cout << "the sum of digits: " << one << endl;
		cout << "the avg of digits: " << one << endl;
		cout << "the product of digits: " << one << endl;
	}

	else if (number >= 10 && number<100)//if number >= 10 and <100
	{
		one = number / 10;//43, one is 4
		two = number % 10;// two is 3
		cout << "the number of digits: 2" << endl;
		cout << "the sum of digits: " << one + two << endl;
		cout << "the avg of digits: " << (one + two) / 2 << endl;
		cout << "the product of digits: " << one*two << endl;
	}

	else if (number >= 100 && number<1000)//if number>=100 and <1000
	{
		one = number / 100;//345, one is 3
		number = number - (one * 100);// 345 change to 45
		two = number / 10;//two is 4
		number = number - (two * 10);// 45 change to 5
		three = number;//three is 5
		cout << "the number of digits: 3" << endl;
		cout << "the sum of digits: " << one + two + three << endl;
		cout << "the avg of digits: " << (one + two + three) / 3 << endl;
		cout << "the product of digits: " << one*two*three << endl;
	}

	else if (number >= 1000 && number<10000)//if number>=1000 and <10000
	{
		one = number / 1000;//3456, one is 3
		number = number - (one * 1000);//456
		two = number / 100;//two is 4
		number = number - (two * 100);//56
		three = number / 10;// three is 5
		number = number - (three * 10);//6
		four = number;
		cout << "the number of digits: 4" << endl;
		cout << "the sum of digits: " << one + two + three + four << endl;
		cout << "the avg of digits: " << (one + two + three + four) / 4 << endl;
		cout << "the product of digits: " << one*two*three*four << endl;
	}

	else if (number == 10000)//if number = 10000
	{
		cout << "the number of digits: 5" << endl;
		cout << "the sum of digits: 1" <<  endl;
		cout << "the avg of digits: 1" << endl;
		cout << "the product of digits: 0" << endl;
	}

	else
		cout << "please enter number from 0 to 10000" << endl;//if number >10000 or <0
}

int main()
{
	int number;
	int d1=0, d2=0, d3=0, d4=0, d5=0;
	getnumber(number);
    sele(number, d1, d2, d3, d4, d5);
}