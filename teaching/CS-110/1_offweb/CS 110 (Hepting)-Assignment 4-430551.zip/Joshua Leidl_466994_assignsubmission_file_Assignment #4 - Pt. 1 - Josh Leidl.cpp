#include <iostream>
#include <string>

using namespace std;

// Prototype necessary functions
string checkProvince (string);
bool checkValid(string);

int main()
{
	// Declare the needed strings
	string phoneNumber;
	string areaCode;
	
	
	// Ensure valid input
	do
	{
		cout << "Please enter a phone number with the format XXX-XXX-XXXX: ";
		cin >> phoneNumber;
	} while(checkValid(phoneNumber));
	
	// Extract the area code
	areaCode = phoneNumber.substr(0, 3);
	
	// Output results
	cout << endl << "The phone number is from " << checkProvince(areaCode) << ".";
	
	// End the program
	return 0;
}

bool checkValid(string phoneNumber)
{
	// Ensure the hyphens are in the correct positions
	if (phoneNumber[3] != '-' || phoneNumber[7] != '-')
	{
		return true;
	}
	else
	{
		return false;
	}
}

string checkProvince (string areaCode)
{
	// Determine the area from which the code is from
	if (areaCode == "403" || areaCode == "587" || areaCode == "780" || areaCode == "825")
	{
		return("Alberta");
	}
	else if(areaCode == "236" || areaCode == "250" || areaCode == "604" || areaCode == "778" || areaCode == "672")
	{
		return("British Columbia");
	}
	else if(areaCode == "204" || areaCode == "431")
	{
		return("Manitoba");
	}
	else if(areaCode == "506")
	{
		return("New Brunswick");
	}
	else if(areaCode == "709")
	{
		return("Newfoundland and Labrador");
	}
	else if(areaCode == "782" || areaCode == "902")
	{
		return("Nova Scotia");
	}
	else if(areaCode == "548" || areaCode == "249" || areaCode == "289" || areaCode == "343" || areaCode == "365" || areaCode == "416" || areaCode == "437" || areaCode == "519" || areaCode == "226" || areaCode == "613" || areaCode == "647" || areaCode == "705" || areaCode == "807" || areaCode == "905" || areaCode == "387" || areaCode == "742")
	{
		return("Ontario");
	}
	else if(areaCode == "782" || areaCode == "902")
	{
		return("Prince Edward Island");
	}
	else if(areaCode == "418" || areaCode == "438" || areaCode == "450" || areaCode == "514" || areaCode == "579" || areaCode == "581" || areaCode == "819" || areaCode == "873")
	{
		return("Quebec");
	}
	else if(areaCode == "306" || areaCode == "639")
	{
		return("Saskatchewan");
	}
	else if(areaCode == "867")
	{
		return("the Yukon, Northwest Territories, or Nunavut");
	}
	else
	{
		return("1");
	}

}
