/*
Student name: Brooke Ham
Student number: 200353759
Assignment number: 4
Program name: Functional Code
Date: written for Mar. 25, 2015
Problem Statement: Modify Assignment 1 code so that the calculations it does are located within a function. The main() function that
	calls this function should let the user input any desired amout of numbers, until a negative number is input. The problem statement
	for Assignment 1 is as follows: Write a program that reads an integer between 0 and 10000 and then calculates and displays (from
	the integer that has been read):
		the number of digits
		the sum of all the digits
		the average of all the digits
		the product of all of the digits
Input: A series of numbers, preferably between 0 and 10000 (inclusive), although other integers will work on this program, amd a negative
	number to quit the code
Output: The number of digits, the sum of all the digits, the average of all the digits, and the product of all the digits
Algorithm: The user will enter a number between 0 and 10000 (after being prompted to do so) and the respective quantities will be computed 
	(using if/else statements, while statements, and simple math operations) and then listed
Major variables: input, NumDigit, SumDigit, AvgDigit, ProdDigit, totalsum, totalproduct
Assumptions: The program will compile and run correctly, no syntax or logic or runtime errors are present in the code, an integer is entered
Program Limitations: A whole number must be inputted to obtain a result, and a negative number must be imputted to exit the code
*/

#include <iostream>																							// This is the library that is used to support input and output. It is the only library necessary for this code to run.
using namespace std;																						// Standard namespace is used in this program.

int NUMDIG(int);																							// Functions for each computation are prototyped.
int SUMDIG(int);
int PRODIG(int);
double AVGDIG(int, int);

int main()
{
	cout << "Hallo, I'll provide you with some cool information on any numbers you enter " << endl;			// This statement is displayed for the user. It describes the purpose of the code and lets the user know that 
	cout << "between 0 and 10000 (inclusive). I'll keep doing this until you enter a " << endl;				// they can enter a negative number to quit the program.
	cout << "negative number. Here goes!" << endl;
	cout << endl;

	while (true)																							// The code will loop unless a "return 0" is used within the loop.
	{
		cout << "Please enter an integer between 0 and 10000: ";											// This prompts the user to enter a number.
		int input;																							// A variable for the input that the user has given is now declared.
		cin >> input;																						// The computer can now recognize that the input is assigned to the variable input.

		while (input > 10000)																				// If the input was higher than the parameters given, then this code will run.
		{
			cout << "That number was't within the parameters that I gave you! Try again." << endl;
			cin >> input;																					// A new value is assigned to the variable input when the user enters it.
		}

		if (input < 0)																						// The code quits if a negative number is entered.
			return 0;
		
		int Numdigits = NUMDIG(input);																		// This variable represents the number of digits that the integer the user inputted has. Its value will be computed using the function NUMDIG (which was just called).
		int Sumdigit = SUMDIG(input);																		// This variable represents the sum of the digits that the user inputted. Its value will be computed using the function SUMDIG (which was just called).
		int Prodigit = PRODIG(input);																		// This variable represents the product of the digits that the user inputted. Its value will be computed using the function PRODIG (which was just called).
		double Avgdigit = AVGDIG(Sumdigit, Numdigits);														// This variable represents the average of the digits that the user inputted. Its value will be computed using the function AVGDIG (which was just called).

		cout << "Number of digits: " << Numdigits << endl;													// These cout statements display the values that have been computed using its respective function and assigned to specific variables.
		cout << "Sum of digits: " << Sumdigit << endl;
		cout << "Average of digits: " << Avgdigit << endl;
		cout << "Product of digits: " << Prodigit << endl;
		cout << endl;
	}
}

int NUMDIG(int userinput1)																					// Function definition
{
	if (userinput1 < 10)																					// If/else statements are used to evaluate how many digits the number inputted has. If the number is found to be within the condition, the value that is returned will
		return 1;																							// be the number of digits.

	else if (userinput1 >= 10 && userinput1 < 100)
		return 2;

	else if (userinput1 >= 100 && userinput1 < 1000)
		return 3;

	else if (userinput1 >= 1000 && userinput1 < 10000)
		return 4;

	else
		return 5;
}

int SUMDIG(int userinput2)																					// Function definition
{
	int totalsum = 0;																						// The integer totalsum is declared and assigned the value zero.
	
	while (userinput2 > 0)																					// The sum of the digits can be found by adding the value of the last digit (found using modulus 10) to the sum of the digits (which was originally 0). Then, the
	{																										// user's input is divided by 10 to move the digits to the right. As this process is repeated, the values of the all the digits in the input are added to find the total sum.
		totalsum += userinput2 % 10;
		userinput2 /= 10;
	}

	return totalsum;																						// The sum of all the digits in the input (stored in totalsum) is returned to the main function.
}

double AVGDIG(int sumdig, int numdig)																		// Function definition
{
	return sumdig / (static_cast<double>(numdig));															// The average is determined by dividing the sum by the number of digits. the integer numdig is casted into a double so that the average includes decimal digits.
}

int PRODIG(int userinput3)																					// The product of the digits can be found by multiplying the value of the last digit (found using modulus 10) to the product of the digits (which was originally 1). Then, the
{																											// user's input is divided by 10 to move the digits to the right and get a new last digit. As this process is repeated, the values of the all the digits in the input are 
	int totalproduct = 1;																					// multiplied together to get the final product.

	while (userinput3 > 0)
	{
		totalproduct *= userinput3 % 10;
		userinput3 /= 10;
	}

	return totalproduct;																					// The product of all the digits (stored in totalproduct) is returned to the main function. 
}