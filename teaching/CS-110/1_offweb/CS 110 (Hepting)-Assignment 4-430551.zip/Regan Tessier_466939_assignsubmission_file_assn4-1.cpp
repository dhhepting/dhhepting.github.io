
#include <iostream>
using namespace std;



int numberofdigits(int number)

{

	int digit1 = number % 10;

	number /= 10;

	int digit2 = number % 10;

	number /= 10;

	int digit3 = number % 10;

	number /= 10;

	int digit4 = number % 10;

	number /= 10;

	int digit5 = number % 10;





	int number_digits = 1;





	if (digit5 > 0)

	{

		number_digits = 5;

	}

	else if (digit4 > 0)

	{

		number_digits = 4;

	}

	else if (digit3 > 0)

	{

		number_digits = 3;

	}

	else if (digit2 > 0)

	{

		number_digits = 2;

	}





	return number_digits;







}

int sum(int number)

{

	int digit1 = number % 10;

	number /= 10;

	int digit2 = number % 10;

	number /= 10;

	int digit3 = number % 10;

	number /= 10;

	int digit4 = number % 10;

	number /= 10;

	int digit5 = number % 10;





	int sum = digit1;







	int number_digits;

	if (digit5 > 0)

	{

		number_digits = 5;

	}

	else if (digit4 > 0)

	{

		number_digits = 4;

	}

	else if (digit3 > 0)

	{

		number_digits = 3;

	}

	else if (digit2 > 0)

	{

		number_digits = 2;

	}

	int current_digit = 1;

	if (current_digit < number_digits)

	{

		sum += digit2;

		if (++current_digit < number_digits)

		{

			sum += digit3;

			if (++current_digit < number_digits)

			{

				sum += digit4;

				if (++current_digit < number_digits)

				{

					sum += digit5;

				}

			}

		}

	}

	return sum;





}

int product(int number)

{

	int digit1 = number % 10;

	number /= 10;

	int digit2 = number % 10;

	number /= 10;

	int digit3 = number % 10;

	number /= 10;

	int digit4 = number % 10;

	number /= 10;

	int digit5 = number % 10;







	int prod = digit1;

	int number_digits;





	if (digit5 > 0)

	{

		number_digits = 5;

	}

	else if (digit4 > 0)

	{

		number_digits = 4;

	}

	else if (digit3 > 0)

	{

		number_digits = 3;

	}

	else if (digit2 > 0)

	{

		number_digits = 2;

	}

	int current_digit = 1;

	if (current_digit < number_digits)

	{

		prod *= digit2;

		if (++current_digit < number_digits)

		{

			prod *= digit3;

		}

		if (++current_digit < number_digits)

		{

			prod *= digit4;

		}

		if (++current_digit < number_digits)

		{

			prod *= digit5;

		}

	}





	return prod;







}







int main()

{

	int number;

	do

	{

		cout << "Please enter a number between 0 and 10000... If you enter a letter or a negative number the program will end " << endl;

		cin >> number;

		if (0 > number || number > 10000)

		{

			cout << "9 out of 10 doctors say the leading cause of death is not following instructions" << endl;

			
			return 0;
		}
		
		cout << "Number of digits: " << numberofdigits(number) << endl;

		cout << "Sum of digits: " << sum(number) << endl;

		cout << "Product of digits: " << product(number) << endl;

		cout << "Average of digits: " << sum(number) / static_cast<float>(numberofdigits(number)) << endl;

	} while (number >0);

	return 0;

}