/**********************************************************************
//
// Student name: Joshua Ajakaiye
//
// Student number: 200348270
//
// Assignment number: 1
//
// Programe name: Digitcalc
//
// Date written: 1st of February 2015
//
// Problem statement: the program determines the amount of digits in a
//                    given integer and calculate the sum, average, and
//                    product.
//
// Input: an integer between 0 and 10000 is inputted
//
// output: the program outputs the number of digits, the sum of the
//         digits, the product of the digits and the digits average
//
// Main Algorithm: prompt the user to enter an integer value between
//                 0 and 10000. error check the input of the user to
//                 make sure the rules are obeyed. assign each to a
//                 variable meaningfully qualified, digit1, digit2 etc.
//                 use if-else statement to check for the number of
//                 digits inputed by the user and assign the value and
//                 print to screen.calculae sum print it out, calculate
//                 average print it out, use the if statement to check
//                 for the number of digits and calculate the product
//                 respectively.
//
// Major variables:  digit1
//               	 digit2
//                   digit3
//                   digit4
//               	 digit5
//                   sum
//              	 average
//              	 product
//                   numofdig
//                   number
//
// Assumptions: the user wont input a number with 1 digit or 5 digits
//
// Program limitations: can only work for numbers between 0 and 10000
**********************************************************************/
#include<iostream>
using namespace std;

// function prototype
void IsoDig(int&, int&, int&, int&, int&, int&);

// function prototype
int SUM(int, int, int, int, int);

// function prototype
int AVG(int, int);

// function prototype
int PROD(int, int, int, int, int, int);

int main()
{
	int digit1 = 0;  // declared and initialized digit1
	int digit2 = 0;  // declared and initialized digit2
	int digit3 = 0;  // declared and initialized digit3
	int digit4 = 0;  // declared and initialized digit4
	int digit5 = 0;  // declared and initialized digit5

	int sum = 0;  // declared and initialized sum
	int average = 0;  // declared and initialized average
	int product = 0;  // declared and initialized product
	int numofdig = 0;  // declared and initialized numofdig (number of digit(s))

	int number = 0;  // declared and initialized number

	// prompt the user to enter an interger between 0 and 10000
	cout << "Please enter an integer between 0 and 10000: " << endl;
	cin >> number;

	// error check entry
	if (number >= 0)
	{
		if (number <= 10000)
		{
			cout << "correct integer input range" << endl;
			cout << endl;

			// function call
			IsoDig(digit1, digit2, digit3, digit4, digit5, number);

			// determine the number of digits 
			if (digit5 > 0)
			{
				numofdig = 5;  // if the number of digits is 5 print out 5
				cout << "The number of digits is: " << numofdig << endl;
			}
			else if (digit4 > 0)
			{
				numofdig = 4;   // if the number of digits is 4 print out 4
				cout << "The number of digits are: " << numofdig << endl;
			}
			else if (digit3 > 0)
			{
				numofdig = 3;  // if the number of digits is 3 print 3
				cout << "The number of digits are: " << numofdig << endl;
			}
			else if (digit2 > 0)
			{
				numofdig = 2;  // if the number of digits is 2 print 2
				cout << "The number of digits are: " << numofdig << endl;
			}
			else if (digit1 > 0)
			{
				numofdig = 1;  // if the number of digits is 1 print 1
				cout << "The number of digits are: " << numofdig << endl;
			}

			// funtion call
			sum = SUM(digit1, digit2, digit3, digit4, digit5);

			cout << "The sum of the digit is: " << sum << endl;

			// function call
			average = AVG(sum, numofdig);

			cout << "The average of the digits is: " << average << endl;

			// funtion call
			product = PROD(digit1, digit2, digit3, digit4, digit5, numofdig);

			cout << "The product of the digits are: " << product << endl;

		}
		else
		{
			cout << "number is too big, hence beyond 10000" << endl;
			cout << endl;
		}
	}
	else
	{
		cout << "number is negative, below zero" << endl;
		cout << endl;
	}

	return 0;

}

//**************************************
// purpose: to isolate them digits
//**************************************
void IsoDig(int& digit1, int& digit2, int& digit3, int& digit4, int& digit5, int& number)
{
	// assign each digit in its respective location
	digit5 = (number / 10000) % 10;
	digit4 = (number / 1000) % 10;
	digit3 = (number / 100) % 10;
	digit2 = (number / 10) % 10;
	digit1 = (number / 1) % 10;
}
//***********************************************
// Purpose: to calculate the sum of the function
//***********************************************
int SUM(int digit1, int digit2, int digit3, int digit4, int digit5)
{

	// calculate the sum and print out the sum
	int sum = digit1 + digit2 + digit3 + digit4 + digit5;

	return sum;
}
//*************************************************
// purpose: to calculate the average of the digits
//*************************************************
int AVG(int sum, int numofdig)
{
	// calculate the average and print out the average
	int average = sum / numofdig;

	return average;
}
//***********************************************************
// purpose: to get the product of the digits under conditions
//***********************************************************
int PROD(int digit1, int digit2, int digit3, int digit4, int digit5, int numofdig)
{
	int product = 0;
	// determine the number of digits  then calculate the product of them respectively
	if (numofdig == 2)
	{
		 product = digit1 * digit2;

	}
	if (numofdig == 3)
	{
		 product = digit1 * digit2 * digit3;

	}
	if (numofdig == 4)
	{
		 product = digit1 * digit2 * digit3 * digit4;

	}
	if (numofdig == 5)
	{
		 product = digit1 * digit2 * digit3 * digit4 * digit5;

	}

	return product;
}