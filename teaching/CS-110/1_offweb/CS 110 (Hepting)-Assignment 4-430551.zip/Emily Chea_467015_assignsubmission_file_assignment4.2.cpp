// STUDENT NAME: Emily Chea

// STUDENT NUMBER: 200352055

// ASSIGNMENT NUMBER: 4

// PROGRAM NAME: C++ Visual Studio 2013

// DATE WRITTEN: March 18, 2015

// PROBLEM STATEMENT: Rewrite Assignment 2 using one function to verify if the number is in the correct format and another to determine the province where it is from

// INPUT: a telephone number in the form of ddd-ddd-dddd (where d is a digit)

// OUTPUT: if the number is in the correct format. If yes, is the number has a canadian area code and if yes, which provice and territory

// ALGORITHM: prompt participant to input a phone number in the format xxx-xxx-xxxx, check to see if phone number is in the correct format (does it contain 12 characters? Are the numbers between 0 and 9?), determine if the phone number is from Canada and if it is from which province, allow the participant to continue to enter phone numbers until they enter "q"

// MAJOR VARIABLES: phone, letter, area, Format, Type, format, place

// ASSUMPTIONS: none

// PROGRAM LIMITATIONS: will only state the specific province/ territory if area code is found in Canada,  

//**************************************************************************************************************************************************************

#include <iostream>
#include <string>
using namespace std;
//function prototype
string Format(string);
string Type(string);

int main()
{
	string phone;
	char letter;
	// Ask participant to enter a phone number in the form ddd-ddd-dddd
	cout << "Please enter a phone number in the form xxx-xxx-xxxx." << endl;
	cin >> phone;
	//Test if input is in correct formula
	string format = Format(phone); // function call
	cout << format << endl;
	//Determine where in Canada the phone number is from 
	string place = Type(phone); // function call
	cout << place << endl;
	//Ask the participant if they want to quit the program. If q is not entered, program will loop.
	cout << "Would you like to quit? If so, enter q ." << endl;
	cin >> letter;
	while (letter != 'q')
	{
		cout << "Please enter a phone number in the form xxx-xxx-xxxx." << endl;
		cin >> phone;
		//Test if input is in correct formula
		string format = Format(phone);
		cout << format << endl;
		//Determine where in Canada the phone number is from 
		string place = Type(phone);
		cout << place << endl;
		//Ask the participant if they want to quit the program. If q is not entered, program will loop.
		cout << "Would you like to quit? If so, enter q ." << endl;
		cin >> letter;
	}
}
//functions
string Format(string phone)
{
	string format;
	if (phone.length() != 12) // does the phone number contain 12 characters (10 digits and 2 hyphens)?
	{
		format = "Error. Incorrect number of characters.";
	}
	else //are the digits of the phone number in the range of 0-9? Are the hyphens in the correct position?
	{
		if (phone[0] >= '0' && phone[0] <= '9')
		{
			if (phone[1] >= '0' && phone[1] <= '9')
			{
				if (phone[2] >= '0' && phone[2] <= '9')
				{
					if (phone[3] == '-')
					{
						if (phone[4] >= '0' && phone[4] <= '9')
						{
							if (phone[5] >= '0' && phone[5] <= '9')
							{
								if (phone[6] >= '0' && phone[6] <= '9')
								{
									if (phone[7] == '-')
									{
										if (phone[8] >= '0' && phone[8] <= '9')
										{
											if (phone[9] >= '0' && phone[9] <= '9')
											{
												if (phone[10] >= '0' && phone[10] <= '9')
												{
													if (phone[11] >= '0' && phone[11] <= '9')
													{
														format =  "The phone number is in the correct format.";
													}
													else
													{
														format = "Error with 10th number";
													}
												}
												else
												{
													format = "Error with 9th number";
												}
											}
											else
											{
												format = "Error with 8th number";
											}
										}
										else
										{
											format = "Error with 7th number";
										}
									}
									else
									{
										format = "Error. Missing hyphen.";
									}
								}
								else
								{
									format = "Error with 6th number";
								}
							}
							else
							{
								format = "Error with 5th number";
							}
						}
						else
						{
							format = "Error with 4th number";
						}
					}
					else
					{
						format = "Error. Missing hyphen.";
					}
				}
				else
				{
					format = "Error with 3rd number";
				}
			}
			else
			{
				format = "Error with 2nd number";
			}
		}
		else
		{
			format = "Error with 1st number";
		}

	}
	return format;
}
string Type(string phone)
{
	string area = phone.substr(0, 3);
	//test if phone number has Canadian area code. If it is a canadian area code number, display the province or territory it is from
	string place;
	if (area == "403" || area == "587" || area == "780" || area == "825")
	{
		place = "Alberta";
	}
	else if (area == "236" || area == "250" || area == "604" || area == "672" || area == "778")
	{
		place = "British Columbia";
	}
	else if (area == "204" || area == "431")
	{
		place = "Manitoba";
	}
	else if (area == "506")
	{
		place = "New Brunswick";
	}
	else if (area == "709")
	{
		place = "Newfoundland and Labrador";
	}
	else if (area == "782" || area == "902")
	{
		place = "Nova Scotia or Prince Edward Island";
	}
	else if (area == "548" || area == "249" || area == "289" || area == "343" || area == "365" || area == "387" || area == "416" || area == "437" || area == "519" || area == "226" || area == "613" || area == "647" || area == "705" || area == "742" || area == "807" || area == "905")
	{
		place =  "Ontario";
	}
	else if (area == "418" || area == "438" || area == "450" || area == "514" || area == "579" || area == "581" || area == "819" || area == "873")
	{
		place = "Quebec";
	}
	else if (area == "306" || area == "639")
	{
		place =  "Saskatchewan";
	}
	else if (area == "867")
	{
		place =  "Yukon, Northwest Territories, or Nunavut";
	}
	else
	{
		place = "This is not a number with a Canadian area code. ";
	}
	return place;
}
