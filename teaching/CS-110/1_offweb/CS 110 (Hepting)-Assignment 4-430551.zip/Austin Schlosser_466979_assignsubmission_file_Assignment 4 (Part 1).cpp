/*Name: Austin Schlosser
Student ID: 200352214
Assignent: 4 Part 1
Program: Integer reader
Date wrote: March 23, 2015
Problem: Determines number of digits, average, product and sum of the digits
Input: User unputs integer between 0 and 10000
Output: Program outputs sum, product, average and number of digit in the integer
Algorithm: modulus, addition, multiplication and division
Major Variables:
Assumptions: User only inputs integer, not letters, symbols nor decimals
Limitations: Can only calculate numbers from 0 to 10000
*/

#include <iostream>
using namespace std;

int amount(int &num, int &numDigits, int &a, int &b, int &c, int &d, int &e)

{
a=num%10;
num=num/10;
b=num%10;
num=num/10;
c=num%10;
num=num/10;
d=num%10;
num=num/10;
e=num&10;

//Finding values of the digits

if (a>0)
{
numDigits=1;
}
if (b>0)
{
numDigits=2;
}
if (c>0)
{
numDigits=3;
}
if (d>0)
{
numDigits=4;
}
if (e>0)
{
numDigits=5;
}
return numDigits;
    
}
//Finding amount of digits in integer

int multiply(int &productCalc,int &numDigits,int &a,int &b,int &c,int &d,int &e)
{
if (numDigits==1)
{
productCalc=a;
}
if (numDigits==2)
{
productCalc=a*b;
}
if (numDigits==3)
{
productCalc=a*b*c;
}
if (numDigits==4)
{
productCalc=a*b*c*d;
}
if (numDigits==5)
{
productCalc=a*b*c*d*e;
}
return productCalc;
    
}
//Finding product of digits

int add(int &sumCalc, int &a, int &b, int &c, int &d, int &e)
{
sumCalc=a+b+c+d+e;

    return sumCalc;
}
//Finding sum of digits

float avg(float &averageCalc, int&sumCalc,int &numDigits)
{
averageCalc=sumCalc/numDigits;

    return averageCalc;
}
//Finding average of digits


int main()
{
int sum;
int d1,d2,d3,d4,d5;
float average;
int product;
int digits;
int integer;

cout << "Please enter integer between 0 and 10000." << endl;
cin >> integer;

cout << "Your input is " << integer << "." <<endl;

digits=amount(integer, digits,d1,d2,d3,d4,d5);
sum=add(integer,d1,d2,d3,d4,d5);
average=avg(average,sum,digits);
product=multiply(integer,digits,d1,d2,d3,d4,d5);
//Calls back variables calculated in functions

cout << "The number of integers is " <<digits<< ", the sum is " <<sum<< ", the average is " <<setprecision(2)<<average<< ", and the product is " <<product<< "." <<endl;

return 0;
}
//End of program