//**************************************************************************
//
// Student name: Callum Jacobson
//
// Student number: 200234874
//
// Assignment number: 4 Part 1
//
// Program name: Digit Reader and Calculator (using functions)
//
// Date written: 24 March 2015
//
// Problem statement: 
//		The problems that need to be solved by this program are:
//		1) The separation of an integer between 1 and 10000 into its constituent digits;
//		2) Counting the number of digits in the inputted integer;
//		3) Obtaining a sum for the digit values added together;
//		4) Obtaining the average of the digit values;
//		4) Obtaining a product for the digit values multiplied together.
//
// Input:
//		The user will input an integer between 0 and 10000 (range inclusive of 0 and 10000).
//
// Output:
//		After computation, the program will output:
//		1) A value for the number of digits in the inputted integer;
//		2) A value for the sum of the inputted digits;
//		3) A value for the average of the inputted digits;
//		4) A value for the product of the inputted digits.
//
// Algorithm: 
//		1) Instruct user to enter an integer between 1 and 10000;
//			-If the inputted integer is negative the program will close;
//		2) Using a function, the program calculates an integer value for each digit in the integer using the modulus operator;
//		3) Using a function, the program calculates an integer value for the sum of the digits;
//		4) Using a function, the program calculates an integer value for the average value of the digits;
//		5) Using a function, the program calculates an integer value for the product of the digits;
//		6) The program invokes the above 4 functions and outputs their values
//		7) Program gives user the option of running the program again for a different number.
//
// Major variables: 
//		1) User-inputted integer between 1 and 10000.
//
// Assumptions:
//		Assumes user will follow the instruction to enter integer between 1 and 10000.
//
// Program limitations:
//		No limitations, so long as the inputted integer is within the specified parameters.
//
//**************************************************************************

#include <iostream>
using namespace std;

// Obtaining a value for the number of digits in the inputted integer
	int number_of_digits(int number)
	{
		int d1;
		d1 = number % 10;
		int d2;
		d2 = (number / 10) % 10;
		int d3;
		d3 = ((number / 10) / 10) % 10;
		int d4;
		d4 = (((number / 10) / 10) / 10) % 10;
		int d5;
		d5 = ((((number / 10) / 10) / 10) / 10) % 10;

		// Counting the number of digits in the integer:

		if (d5 > 0)
		{
			return 5;
		}
		else if (d4 > 0)
		{
			return 4;
		}
		else if (d3 > 0)
		{
			return 3;
		}
		else if (d2 > 0)
		{
			return 2;
		}
		else if (d1 > 0)
		{
			return 1;
		}
	}

// Sum of the digits:

	int sum_of_digits(int number)
	{
		int d1;
		d1 = number % 10;
		int d2;
		d2 = (number / 10) % 10;
		int d3;
		d3 = ((number / 10) / 10) % 10;
		int d4;
		d4 = (((number / 10) / 10) / 10) % 10;
		int d5;
		d5 = ((((number / 10) / 10) / 10) / 10) % 10;
		return (d1 + d2 + d3 + d4 + d5);
	}


// Average of the digits:

	int average_of_digits(int number)
	{
		int d1;
		d1 = number % 10;
		int d2;
		d2 = (number / 10) % 10;
		int d3;
		d3 = ((number / 10) / 10) % 10;
		int d4;
		d4 = (((number / 10) / 10) / 10) % 10;
		int d5;
		d5 = ((((number / 10) / 10) / 10) / 10) % 10;
		return ((d1 + d2 + d3 + d4 + d5) / number_of_digits(number));
	}
// Product of the digits:

	int product_of_digits(int number)
	{
		int product_of_digits;
		int d1;
		d1 = number % 10;
		int d2;
		d2 = (number / 10) % 10;
		int d3;
		d3 = ((number / 10) / 10) % 10;
		int d4;
		d4 = (((number / 10) / 10) / 10) % 10;
		int d5;
		d5 = ((((number / 10) / 10) / 10) / 10) % 10;
		
			if (number_of_digits(number) == 5)

				product_of_digits = (d1 * d2 * d3 * d4 * d5);

			else if (number_of_digits(number) == 4)

				product_of_digits = (d1 * d2 * d3 * d4);

			else if (number_of_digits(number) == 3)

				product_of_digits = (d1 * d2 * d3);

			else if (number_of_digits(number) == 2)

				product_of_digits = (d1 * d2);

			else if (number_of_digits(number) == 1)
				product_of_digits = (d1 * 1);
		
		return product_of_digits;
	}
	

	int main()
	{

		// User inputs integer between 0 and 10000

		int number;
		char ans;
		do
		{
		cout << "Please enter a number between 0 and 10000 " << endl;
		cin >> number;

			if (number < 0)
			{
				cout << "The number is not between 0 and 10000.";
				cout << endl;
				return 0;
			}
			else
			{
				cout << "Thanks." << endl;
				cout << "The number of digits in the number is " << number_of_digits(number) << endl;
				cout << "The sum of the digits in the number is " << sum_of_digits(number) << endl;
				cout << "The average of the digits in the number is " << average_of_digits(number) << endl;
				cout << "The product of the digits in the number is " << product_of_digits(number) << endl;
				cout << "Enter y to repeat" << endl;
				cin >> ans;
			}
		} while (number >= 0 && number <= 10000 && ans == 'y');

		return 0;
	}

