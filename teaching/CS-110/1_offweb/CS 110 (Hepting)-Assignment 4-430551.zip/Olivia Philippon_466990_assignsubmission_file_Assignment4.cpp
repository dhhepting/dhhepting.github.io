//**************************************************************************
//
// Student name: Olivia Philippon
//
// Student number: 200294151
//
// Assignment number: 4
//
// Program name: Assignment4
//
// Date written: Mar. 24, 2015
//
// Problem statement: Allow the user to enter a number, ranging from 0 to 10000. From here, write a program that 
//                    will use a function to find the number of digits in that number, as well as the sum, product and average of those digits. 
//                    The user must be able to continue entering numbers until they enter a negative number to quit the program. 
//                    
// Input: A number between the range of 0 and 10000 is expected from the user. A negative numebr can be entered to quit the program.
//
// Output: If the user enters a number that is out of the correct range, the user will be told that the number is not within the range. 
//         If the number is entered within the correct range, the number of digits in the number, as well as the sum, product and average of 
//         those digits will be expected as output. 
//
// Algorithm: I will instruct the computer to make sure that the user enters a number from 0 to 10000. If it is not
//			  within this range, they will be told to change their number or the program will end if the number is negative. When the number is entered correctly, the computer
//            will find the value of each digit in the number by using the modulus operator in the first function. Continuing to divide the original 
//            number by 10 will allow each digit to be found in its correct decimal place in the number. The calculations to 
//            find the sum is presented in a separate function. There is also a function that finds the product of the digits. Within each function, 
//            depending on the number of digits, the corresponding if statements are employed. In the main function, the correct sum and product will be 
//            presented based on the calculations from the separate functions. Also in the main function, the average is calculated based on the sum and
//            number of digits as indicated by previous functions.  
//            
// Major variables: The major variables that I will use in my code are the variables that represent the digits. These variables 
//                  allow the program to be directed to the correct if statement and present the correct output for that set
//                  of digits. Also, the variables that represent the sum, product and average are important. The variables that 
//                  create each function in this program are important too in order for the calcualtions to occur. 
//                 
// Assumptions: The assumptions I need to make in order for the solution to work are that the user wants to find the 
//              number of digits, sum, product and average of those digits simultaneously. 
//
// Program limitations: There are limitations. The program is long. Each function checks the number in order to correspond with an if statement. 
//  As in, there is a function that checks the user's input to indicate how many digits are present, a function that rechecks the input in order 
//  to find the sum, and finally a function that checks the number once again in order to find the product of the input.
//               
//**************************************************************************

#include <iostream>
using namespace std;

//This function finds the number of digits in the number that the user has entered in the main function. 
int numberofdigits(int number)
{
	//The following calculations find the digits within the number.
	int digit1 = number % 10;
	number /= 10;
	int digit2 = number % 10;
	number /= 10;
	int digit3 = number % 10;
	number /= 10;
	int digit4 = number % 10;
	number /= 10;
	int digit5 = number % 10;

	// get number of digits
	int number_digits = 1;
	if (digit5 > 0)
	{
		number_digits = 5;
	}
	else if (digit4 > 0)
	{
		number_digits = 4;
	}
	else if (digit3 > 0)
	{
		number_digits = 3;
	}
	else if (digit2 > 0)
	{
		number_digits = 2;
	}

	//This returns the number of digits to the main function. 
	return number_digits;
}

//This function finds the sum of the digits of the number that the user has entered in the main function. 
double sum(int number)
{
	int digit1 = number % 10;
	number /= 10;
	int digit2 = number % 10;
	number /= 10;
	int digit3 = number % 10;
	number /= 10;
	int digit4 = number % 10;
	number /= 10;
	int digit5 = number % 10;

	// get number of digits
	int number_digits = 1;
	if (digit5 > 0)
	{
		number_digits = 5;
	}
	else if (digit4 > 0)
	{
		number_digits = 4;
	}
	else if (digit3 > 0)
	{
		number_digits = 3;
	}
	else if (digit2 > 0)
	{
		number_digits = 2;
	}

	int sum = digit1;

	//sum calculations depending on number of digits
	int current_digit = 1;
	if (current_digit < number_digits)
	{
		sum += digit2;
		if (++current_digit < number_digits)
		{
			sum += digit3;
			if (++current_digit < number_digits)
			{
				sum += digit4;
				if (++current_digit < number_digits)
				{
					sum += digit5;
				}
			}
		}
	}
	//This returns the sum of the digits to the main function. 
	return sum;
}

//This function finds the product of the digits. 
double prod(int number)
{
	int digit1 = number % 10;
	number /= 10;
	int digit2 = number % 10;
	number /= 10;
	int digit3 = number % 10;
	number /= 10;
	int digit4 = number % 10;
	number /= 10;
	int digit5 = number % 10;

	// get number of digits
	int number_digits = 1;
	if (digit5 > 0)
	{
		number_digits = 5;
	}
	else if (digit4 > 0)
	{
		number_digits = 4;
	}
	else if (digit3 > 0)
	{
		number_digits = 3;
	}
	else if (digit2 > 0)
	{
		number_digits = 2;
	}

	int prod = digit1;
	int current_digit = 1;
	if (current_digit < number_digits)
	{
		prod *= digit2;
		if (++current_digit < number_digits)
		{
			prod *= digit3;
			if (++current_digit < number_digits)
			{
				prod *= digit4;
				if (++current_digit < number_digits)
				{
					prod *= digit5;
				}
			}
		}
	}
	//This returns the value of the product to the main function. 
	return prod;
}

int main()
{
	int number = 0;

	do
	{
		//Ask the user for a number between 0 and 10000.
		cout << "Please enter a number between 0 and 10000" << endl;
		cout << "If you wish to quit this program, please enter a negative number." << endl;

		cin >> number;
		int number_digits = 0;
		//This if statement checks the input number from the user. If the number is not within the correct range, the program will end or tell the
		// user that number is not within the correct range.
		if (number >= 0 && number <= 10000)
		{
			cout << "Thank you for correctly entering a number within the specified range." << endl;
			//The output comes from the functions that have done the calulations. Here we are able to call those functions and put the values in the output.
			cout << "Number of digits: " << numberofdigits(number) << endl;
			cout << "Sum of digits: " << sum(number) << endl;
			cout << "Product of digits: " << prod(number) << endl;
			cout << "Average of digits: " << sum(number) / static_cast<float>(numberofdigits(number)) << endl;
		}
		else
		{
			cout << "Number not between 0 & 10000, inclusive" << endl;
		}
	} while (number >= 0);

	return 0;
}