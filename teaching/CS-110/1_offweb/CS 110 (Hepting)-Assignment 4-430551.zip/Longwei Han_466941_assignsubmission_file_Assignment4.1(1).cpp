//**************************************************************************
//
// Student name: Longwei Han
//
// Student number: 200313136	
//
// Assignment number: Assignment 4.1
//
// Program name: CS 110
//
// Date written: March 24th, 2015
//
// Problem statement: Modify Assignment 1 code so that the calculations it does are located within a function. The main() function that calls this function should let the user input any desired about of numbers, until a negative number is input.
//
// Input: A numebr between 0 and 10000
//
// Output:the number of digits, the sum of all the digits, the average of all the digits and the product of all of the digits
//
// Algorithm 1: Set up a function prototype: void cal (int x)
// Algorithm 2: Use the "Do While"loop and bool to test if the input is a valid or not.
// Algorithm 3: Use "While" loop to check the lengh of the input.
// Algorithm 4: Calculate the sum, product and the average.
//
// Major variables: x, num,lengh, sum, product,average, 
//
// Assumptions: the integer number between 0 and 10000
//
// Program limitations: Any number is not in the range of 0 to 10000
//
// Comment: The code I created can run succefully 
//**************************************************************************

#include <iostream>
using namespace std;

void cal(int x);

int main()
{
	int num;
	do{
	  cout << "Please input an integer from 0-10000" << endl;
	  cin >> num;
	  if (num >= 0 && num <=10000) 
	    cal(num);
	  else{
	    cout << "The number you entered is invalid." << endl;
	    return 0;
      }
    }while (1);
    return 0;
}

void cal(int x)
{
	int length=0,sum=0,product=1;
	double average,n;
	int a[4];
	while (x > 0)
	{
		a[length]=x % 10;
		x/=10;
		length++;
	}
	cout << "This integer has " << length << " digits " << endl;
	for (int i=0;i<length;i++)
	{
		sum+=a[i];
		product*=a[i];
	}
	n=length;
	average=sum / n;
	cout << "The sum of these digits is: " << sum << endl;
	cout << "The average of these digits is:" << average << endl;
	cout << "The product of these digits is:" << product << endl <<endl;
}
