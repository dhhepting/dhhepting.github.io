//your name, your student number, assignment number, program name, date written, problem statement, input, output, algorithm, major variables, assumptions, and program limitations
// Renee Lavoy
// 200336240
// Assignment #2
// Area Codes of the Provinces and Territories
// Febuary 24, 2015
// 


#include <iostream>
#include <string>
using namespace std;

//function
void ValidateTelephone(string);
void CheckCanadian(string);

int main()
{
	string telephone;
	string q;

	do
	{
		cout << "Please enter a Canadian phone number in the form ddd-ddd-dddd. Press 'q' when you want to terminate the program." << endl;
		cin >> telephone;
		ValidateTelephone(telephone);
		CheckCanadian(telephone);

	} while (telephone != "q");

	cout << "The program has been terminated." << endl;
	
	return 0;
}

void ValidateTelephone(string telephone)
{
	if (telephone.length() != 12)
	{
		cout << "Error, your phone number is not the correct length." << endl;

	}
	if (telephone.at(3) != '-' && telephone.at(7) != '-')
	{
		cout << "Error, you did not input the correct format." << endl;
		
	}
}

void CheckCanadian(string telephone)
{
	if (telephone.length() == 12 && telephone.at(3) == '-' && telephone.at(7) == '-')
	{

		while (telephone != "q")
		{
			if (telephone.at(0) == '3' && telephone.at(1) == '0' && telephone.at(2) == '6')
				cout << "This is an area code for Saskatchewan. Please enter another phone number!" << endl;

			if (telephone.at(0) == '2' && telephone.at(1) == '5' && telephone.at(2) == '0')
				cout << "This is an area code for British Columbia. Please enter another phone number!" << endl;
			if (telephone.at(0) == '7' && telephone.at(1) == '7' && telephone.at(2) == '8')
				cout << "This is an area code for British Columbia. Please enter another phone number!" << endl;
			if (telephone.at(0) == '6' && telephone.at(1) == '0' && telephone.at(2) == '4')
				cout << "This is an area code for British Columbia. Please enter another phone number!" << endl;

			if (telephone.at(0) == '7' && telephone.at(1) == '8' && telephone.at(2) == '0')
				cout << "This is an area code for Alberta. Please enter another phone number!" << endl;
			if (telephone.at(0) == '4' && telephone.at(1) == '0' && telephone.at(2) == '3')
				cout << "This is an area code for Alberta. Please enter another phone number!" << endl;

			if (telephone.at(0) == '8' && telephone.at(1) == '6' && telephone.at(2) == '7')
				cout << "This is an area code for Northwest Territories, Nunavut, and the Yukon. Please enter another phone number!" << endl;

			if (telephone.at(0) == '2' && telephone.at(1) == '0' && telephone.at(2) == '4')
				cout << "This is an area code for Manitoba. Please enter another phone number!" << endl;

			if (telephone.at(0) == '8' && telephone.at(1) == '0' && telephone.at(2) == '7')
				cout << "This is an area code for Ontario. Please enter another phone number!" << endl;
			if (telephone.at(0) == '7' && telephone.at(1) == '0' && telephone.at(2) == '5')
				cout << "This is an area code for Ontario. Please enter another phone number!" << endl;
			if (telephone.at(0) == '5' && telephone.at(1) == '1' && telephone.at(2) == '9')
				cout << "This is an area code for Ontario. Please enter another phone number!" << endl;
			if (telephone.at(0) == '2' && telephone.at(1) == '8' && telephone.at(2) == '9')
				cout << "This is an area code for Ontario. Please enter another phone number!" << endl;
			if (telephone.at(0) == '9' && telephone.at(1) == '0' && telephone.at(2) == '5')
				cout << "This is an area code for Ontario. Please enter another phone number!" << endl;
			if (telephone.at(0) == '4' && telephone.at(1) == '1' && telephone.at(2) == '6')
				cout << "This is an area code for Ontario. Please enter another phone number!" << endl;
			if (telephone.at(0) == '6' && telephone.at(1) == '4' && telephone.at(2) == '7')
				cout << "This is an area code for Ontario. Please enter another phone number!" << endl;
			if (telephone.at(0) == '6' && telephone.at(1) == '1' && telephone.at(2) == '3')
				cout << "This is an area code for Ontario. Please enter another phone number!" << endl;

			if (telephone.at(0) == '4' && telephone.at(1) == '5' && telephone.at(2) == '0')
				cout << "This is an area code for Quebec. Please enter another phone number!" << endl;
			if (telephone.at(0) == '5' && telephone.at(1) == '1' && telephone.at(2) == '4')
				cout << "This is an area code for Quebec. Please enter another phone number!" << endl;
			if (telephone.at(0) == '8' && telephone.at(1) == '1' && telephone.at(2) == '9')
				cout << "This is an area code for Quebec. Please enter another phone number!" << endl;
			if (telephone.at(0) == '4' && telephone.at(1) == '1' && telephone.at(2) == '8')
				cout << "This is an area code for Quebec. Please enter another phone number!" << endl;

			if (telephone.at(0) == '5' && telephone.at(1) == '0' && telephone.at(2) == '6')
				cout << "This is an area code for New Brunswick. Please enter another phone number!" << endl;

			if (telephone.at(0) == '9' && telephone.at(1) == '0' && telephone.at(2) == '2')
				cout << "This is an area code for Nova Scotia and Prince Edward Island. Please enter another phone number!" << endl;


			if (telephone.at(0) == '7' && telephone.at(1) == '0' && telephone.at(2) == '9')
				cout << "This is the area code for Newfoundland and Labrador. Please enter another phone number!" << endl;

			cin >> telephone;
		}
	}
}