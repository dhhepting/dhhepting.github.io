//**************************************************************************
//
// Student name: Olivia Philippon
//
// Student number: 200294151
//
// Assignment number: 4
//
// Program name: Assignment 4.2 
//
// Date written: Mar. 24, 2015
//
// Problem statement:  Write a code that checks the phone number with functions. The user must enter a phone number in
// the format ddd-ddd-dddd. The program must check by using a function to make sure that what the user has entered it in this correct format;
// the number must contain hyphens and digits in the correct places. Based on the phone number entered by the user, the program
// must find the area code location if the phone number is from Canada by using a function. The program must continue looping by allowing the user to enter 
// phone numbers and find their Canadian area code location until the user no longer wishes to do so. In this case, the user has been 
// notified that they may enter q at any time during the program in order to exit. 
//
// Input: A phone number, containing digits and hyphens, in the format ddd-ddd-dddd.
//
// Output: The program will indicate if the phone number is in the correct format and the region of the area code in Canada. 
//
// Algorithm: I will instruct the user to enter a phone number in the correct format. I will provide an example of the format so the user 
// understands. A loop is created so that if the user enters q at any time, the program will stop. If they do not enter q, the 
// program will continue to check the input that is entered. A function begins by checking length of the phone number. If the number length is incorrect
// the program will notify the user that the number is invalid. If the length is correct, the program will check each digit to make sure 
// that they are within the rango of 0 to 9; this eliminates the possbility of the input being another character. Each number is 
// checked for hyphens and correct placement. If these conditions are true, then the function with the if statements containing all of the Canadian 
// area codes will be executed. The first three digits of the phone number will be assessed for their area code location. If the
// area code is not contained in the listed Canadian ones, it will tell the user that the area code is not from Canada.
//
// Major variables: The phone number is a major variable. This contains the main digits that will be assessed within the program. The variables that make 
// the function prototypes and names are important. 
// 
// Assumptions: That the user doesn't enter an international number with a 1 in front. We also assume that the user is looking for a Canadian
// phone number area code. 
//
// Program limitations: If the phone number entered is too long or too short, it does not tell the user this specific problem. It only notifies
// the user that there is a problem within the input format. The program does not tell the user where the problem is in their number that they have entered. As in,
// it does not tell them if they have entered an invilid digit such as a letter, or have misplaced or forgotten a dash. 
// The area codes do not tell the user where in each province or territory that the number originates. The area codes for Prince Edward Island and 
// Nova Scotia are the same; the program cannot indicate exactly which province the number is from in this case. If the user enters an area code that 
// does not classify as being from Canada, the program does not tell the user where the area code is from. It is also possible that the user entered a 
// nonexistant area code but the program does not notify the user of this. It only says that the area code is not from Canada. 
//
//**************************************************************************

#include <iostream>
#include <string>
using namespace std;

//This checks the format. This bool conditions can either be true or false. If it return true, the program continues to check the number.
//If this function returns false, the user will be notified that the number is not correct. 
bool proper_format(string & telnum)
{
	if (telnum.length() == 12) //This checks the length of the input.
	{
		//The program checks each hyphen and digit at all locations of the input.
		bool proper_format = true;
		for (int i = 0; i < 12; i++)
		{
			if (i == 3 || i == 7)
			{
				if (telnum[i] != '-')
				{
					return false;
				}
			}
			else
			{
				if (!isdigit(telnum[i]))
				{
					return false;
				}
			}
		}
	}
	else
	{
		cout << "Number not proper length: should be 10 digits with 2 hyphens" << endl;
	}
}
//This function tests the area code of the number if the number is in the correct format. 
string TestAreaCode(string & telnum)
{
	//This substring allows the program to check only part of the phone number. We are able to check the first three digits of the number,
	// the area code, and indicate where the phone number is in Canada based on this. 
	string area_code = telnum.substr(0, 3);
	string region = "Outside of Canada";
	// Alberta:	403, 587, 780, 825
	if (area_code == "403" ||
		area_code == "587" ||
		area_code == "780" ||
		area_code == "825")
	{
		region = "Alberta";
	}
	// British Columbia	236, 250, 604, 672, 778
	else if (area_code == "236" ||
		area_code == "250" ||
		area_code == "604" ||
		area_code == "672" ||
		area_code == "778")
	{
		region = "British Columbia";
	}
	// Manitoba	204, 431
	else if (area_code == "204" ||
		area_code == "431")
	{
		region = "Manitoba";
	}
	// New Brunswick	506
	else if (area_code == "506")
	{
		region = "New Brunswick";
	}
	// Newfoundland and Labrador	709
	else if (area_code == "709")
	{
		region = "Newfoundland and Labrador ";
	}
	// Nova Scotia	782, 902
	else if (area_code == "782" ||
		area_code == "902")
	{
		region = "Nova Scotia";
	}
	// Ontario	548, 249, 289, 343, 365, 387, 416, 437, 
	//		519, 226, 613, 647, 705, 742, 807, 905
	else if (area_code == "548" ||
		area_code == "249" ||
		area_code == "289" ||
		area_code == "343" ||
		area_code == "365" ||
		area_code == "387" ||
		area_code == "416" ||
		area_code == "437" ||
		area_code == "519" ||
		area_code == "226" ||
		area_code == "613" ||
		area_code == "647" ||
		area_code == "705" ||
		area_code == "742" ||
		area_code == "807" ||
		area_code == "905")
	{
		region = "Ontario";
	}
	// Prince Edward Island	782, 902
	else if (area_code == "782" ||
		area_code == "902")
	{
		region = "Prince Edward Island";
	}
	// Quebec	418, 438, 450, 514, 579, 581, 819, 873
	if (area_code == "418" ||
		area_code == "438" ||
		area_code == "450" ||
		area_code == "514" ||
		area_code == "579" ||
		area_code == "581" ||
		area_code == "819" ||
		area_code == "873")
	{
		region = "Quebec";
	}
	// Saskatchewan	306, 639
	if (area_code == "306" ||
		area_code == "639")
	{
		region = "Saskatchewan";
	}
	//Yukon, Northwest Territories, and Nunavut	867
	else if (area_code == "867")
	{
		region = "Yukon, Northwest Territories, and Nunavut";
	}
	else
	{
		region = "Not Canadian";
	}
	//This returns the region of the area code to the main function. 
	return region;
}
int main()
{
	//We need to create the phone number as a string variable so that it can include both digits and dashes.
	string telnum;
	//This is the beginning of the loop. If the user does not enter q, the loop will continue and check the number.
	do
	{
		cout << "Enter phone number ddd-ddd-dddd" << endl;
		cin >> telnum;
		//The loop will end if the user enters q instead of a phone number.
		if (telnum[0] == 'q')
		{
			return 0;
		}
		//If the length is good, the program will check the phone number in a function. 
		if (proper_format (telnum))
		{
			//If all of the previous conditions are true (the length is good, all digits and hyphens are correct) then the program will continue 
			// to check the area code of the number to see where it originates in Canada by using a function. 
			cout << "Number appears to be from: " << TestAreaCode(telnum) << endl;
		}

		else
		{
			//There is something wrong in the phone number entered.
			cout << "Number not in proper format" << endl;
		}
	
	}while (telnum[0] != 'q');

	return 0;
}
