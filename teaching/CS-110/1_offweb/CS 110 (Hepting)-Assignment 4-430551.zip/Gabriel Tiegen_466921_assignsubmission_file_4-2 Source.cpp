/*
Gabriel Tiegen
200351654
Assignment 4-1

January 28, 2015
Problem: To take a phone number input and determine if it has a Canadian area code

Input:
Phone number in the format:
xxx-xxx-xxxx

Output:
-A string saying whether or not the phone number has a Canadian area code

Algorithm:
	Input Stage:
	-Takes user's input, closes program if input is 'q'
	-If not 'q' it will call the function that checks if the input is in a valid format

	Validating:
	-Checks if the length is 12, if not, 0 will be returned
	-While loop to increment the place in the string each loop, checking the next digit in the phone number each time
	-Checks if the 4th and 8th digits are '-', if not, 0 will be returned
	-Checks if all places that are not the 4th and 8th have a value of '0'-'9', if not, 0 is returned
	-Once the loop has iterated 12 times with no 0's returned, 1 will be returned to tell the program that the number is in a valid format

	Finding Area Code:
	-User's area code placed in a substring, from the first three digits in their input
	-Function is called to check if the number is from Canada
	-If the number is from Canada, the function will return the region that the area code is assigned to
	-If the numbersi not from Canada, the function will return that it is not a valid Canadian phone number


Variables:
numin: contains user's raw input
acode: contains the first three digits of the user's phone number
valid: used to determine whether or not to exit the loop that takes the user's input
region: holds the name of the region that the phone number is from
quit: will close the program when set to 1

Assumptions:

Program Limitations:
-inflexible in the format, could be made to be more lenient

*/

#include <iostream>
#include <string>
using namespace std;

//Variable and function declaration
string numin;
string acode;
int verify(string);
string acheck(string);
int valid = 0;
string region;
int quit = 0;



int main()
{
	while (!quit){
		while ((!valid) && (!quit))
		{

			//Take user's input
			cout << "Please input your number in the format 'xxx-xxx-xxxx' or enter 'q' to exit" << endl;
			cin >> numin;

			//Sets quit to 1 if user entered 'q' so the program will exit
			if (numin == "q")
			{
				valid = 0;
				quit = 1;
			}

			//Call the function to verify the format of the input
			valid = verify(numin);

			//If the verify function returned 0, an error message will be displayed and the user will have to enter another input
			if (!valid)
			{
				cout << "Error. Please enter the correct format." << endl;
			}


		}
		if (valid && !quit)
		{
			//Take the area code out of the user's input (first three digits) and call the function to check the area code against Canadian provinces' area codes
			acode = numin.substr(0, 3);
			region = acheck(acode);
			//Outputs the result to the user
			cout << "The region that this number is from is " << region << "." << endl << endl << endl;
			valid = 0;
		}
		else
		{
			return 0;
		}
	}
}



int verify(string numin)
{
	int verified = 1;
	int i = 0;
	char currentchar;

	//Returns 0 if the input is an incorrect length
	if (numin.length() != 12)
	{
		return 0;
	}
	//Loops until the whole number is checked
	while (i < 11){
		currentchar = numin[i];
		//Checks if the 4th and 8th digits are '-', if not, verified will be set to 0
		if (((i == 3) || (i == 7)) && (currentchar != '-'))
		{
			verified = 0;
			break;
		}
		//If any place within the input that is not the 4th or 8th place is not equal to '0'-'9, 'verified' will be set to 0
		if (((i != 3) && (i != 7)) && ((currentchar != '0') && (currentchar != '1') && (currentchar != '2') && (currentchar != '3') && (currentchar != '4') && (currentchar != '5') && (currentchar != '6') && (currentchar != '7') && (currentchar != '8') && (currentchar != '9')))
		{
			verified = 0;
			break;
		}
		i = i + 1;
	}
	//Function will return 0 if it failed verification
	if (!verified)
	{
		return 0;
	}
	//Function will return 1 if it passed verification
	else
	{
		return 1;
	}
}

string acheck(string ac)
{
	string region;

	//This section checks the area code against every area code in Canada. It will return the region name if it is found, if not, it will return 'outside of Canada'
	if ((ac == "403") || (ac == "587") || (ac == "780") || (ac == "825"))
	{
		region = "Alberta";
	}
	else if ((ac == "236") || (ac == "250") || (ac == "604") || (ac == "672") || (ac == "778"))
	{
		region = "British Columbia";
	}
	else if ((ac == "204") || (ac == "431"))
	{
		region = "Manitoba";
	}
	else if (ac == "506")
	{
		region = "New Brunswick";
	}
	else if (ac == "709")
	{
		region = "Newfoundland and Labrador";
	}
	else if ((ac == "782") || (ac == "902"))
	{
		region = "Nova Scotia or PEI";
	}
	else if ((ac == "548") || (ac == "289") || (ac == "249") || (ac == "343") || (ac == "365") || (ac == "387") || (ac == "416") || (ac == "437") || (ac == "519") || (ac == "226") || (ac == "613") || (ac == "647") || (ac == "705") || (ac == "742") || (ac == "807") || (ac == "905"))
	{
		region = "Ontario";
	}
	else if ((ac == "418") || (ac == "438") || (ac == "450") || (ac == "514") || (ac == "579") || (ac == "581") || (ac == "819") || (ac == "873"))
	{
		region = "Quebec";
	}
	else if ((ac == "306") || (ac == "639"))
	{
		region = "Saskatchewan";
	}
	else if (ac == "867")
	{
		region = "Yukon, Northwest Territories and Nunavut";
	}
	else
	{
		region = "Outside of Canada";
	}
	return region;
}