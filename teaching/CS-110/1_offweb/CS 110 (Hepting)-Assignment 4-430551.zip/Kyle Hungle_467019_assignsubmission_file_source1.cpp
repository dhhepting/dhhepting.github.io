/*

Name: Kyle HUngle
Student #: 200354270
Assignment #4
Program Name: Assignment#4-1
March 25/15
Problem Question
Modify Assignment one so that the calculations it does are done within function. The main function
should let the user input as many values as they desire until a negative integer is is the input
Write a program that reads an integer between 0 and 10000 and then calculates and displays (from the integer that has been read): 
�the number of digits
�the sum of all the digits
�the average of all the digits
�the product of all of the digits



*/
#include <iostream>
using namespace std;

int NumberofDigits(int); //declare the number of digits function

int SUM(int); // declares the sum function
 
void AVERAGE(int, int); // declare the average function

void PRODUCT(int); // declares the product function

int main()
{
	int num = 0; //Variable for integer that is being inputted
	int numdig;
	int sum;

		while (num >=0) // whill loop to check that the input is not a negative value which would end the program
		{
			// Asks user for integer and assigns it to variable num
		cout << "Enter an integer between 0 and 100000 enter a negative integer to end the program: " << endl;
		cin >> num;
		
		if (num>=0)
		{
		numdig = NumberofDigits(num); //calls the number of digits function
		sum = SUM(num); // calls the sum function
		AVERAGE (numdig, sum); // calls the average function
		PRODUCT(num); // calls the product function
		}

		}

		cout << "End of program" << endl;
		
 return 0;

}

int NumberofDigits (int n1)
{
	
	int numdigits=0;
		
			//While statement to find the number of digits
			// adds 1 to variable numdigits each time the while statement initiates
			while(n1>0)
			{
				numdigits=numdigits+1;
				n1=n1/10 ;
			}
		//displays the number of digits
		cout << "Number of digits: " << numdigits << endl;

		return (numdigits);
		
		
}

int SUM(int n2)
{
		
		int sum=0;
		int digit;
			
			//While statement to find the sum of digits
			// adds the digit that is calculated to variable sum each time the while statement initiates
			while(n2>0)
			{
				digit=n2 %10;
				n2=n2/10 ;
				sum=sum+digit;
			}
		//displays the sum
		cout << "Sum of digits: " << sum << endl;

		return (sum);
}

void AVERAGE ( int digit, int sum)
{
	int average;
			average = sum/digit;
		cout << "Average of digits: " << average << endl; 
}

void PRODUCT(int n3)
{
		int product = 1;
		int digit;
		

			//While statement to find the products of digits
			// multiplies the digit that is calculated to variable product which initially equals 1 each time the while statement initiates
			while(n3>0)
			{
				digit = n3%10;
				n3=n3/10;
				product=product*digit;

			}
		//displays the product
		cout << "Product of digits: " << product << endl;
}

