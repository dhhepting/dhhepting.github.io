//**************************************************************************
//
// Student name: Yue Wang
//
// Student number: 200350793
//
// Assignment number: 4
//
// Program name: assigment4b
//
// Date written: 25th March, 2015
//
// Problem statement: Modify Assignment 2 so that the validation of the telephone format is done in one function and the test to see if the area code is from Canada is done in another function.
//

//                             Assignment 2 asked you to check phone numbers until 'q' was entered.For a phone number to be valid,
//                             it had to be in the form ddd - ddd - dddd(10 digits and 2 hyphens or dashes).I am asking you to put 
//                             this format check into a function.If the phone number was valid, I asked you to check if the area code came from a Canadian province or territory.I am asking that you put the test for a Canadian area code into a second function.
//
// Input: phone number
//
// Output: The output should display the area code if the number is a canandian number. 
//		   
//
// Algorithm: 
//
// Major variables: number, num(int i, string telno)
// Assumptions: The only assumption noted is that the user inputs a proper phone number ranging 
//
// Program limitations:	The program does not assign a result for any input that is not proper phone number
//
//**************************************************************************
#include <iostream>
#include <string>
using namespace std;


int num(int i, string telno)//test if the number is in proper format
{
	bool proper_format = true;
	{
		for (int i = 0; i < 12; i++)
		{
			if (i == 3 || i == 7)
			{
				if (telno[i] != '-')
				{

				}
			}
			else
			{
				if (!isdigit(telno[i]))
				{
					proper_format = false;
				}
			}
		}
		return i;
		
	}
}

double num2(int i, string telno)//if it is test the orgin of the number

{
	while (telno[0] != 'q')
	{
		if (telno.length() == 12) // proper length
		{
			// make use of loops here :-)

			if (i == 3 || i == 7 || telno[i] != '-')
			{
				string area_code = telno.substr(0, 3);
				string region = "Outside of Canada";
				// Alberta:	403, 587, 780, 825
				if (area_code == "403" ||
					area_code == "587" ||
					area_code == "780" ||
					area_code == "825")
				{
					region = "Alberta";
				}
				// British Columbia	236, 250, 604, 672, 778
				else if (area_code == "236" ||
					area_code == "250" ||
					area_code == "604" ||
					area_code == "672" ||
					area_code == "778")
				{
					region = "British Columbia";
				}
				// Manitoba	204, 431
				else if (area_code == "204" ||
					area_code == "431")
				{
					region = "Manitoba";
				}
				// New Brunswick	506
				else if (area_code == "506")
				{
					region = "New Brunswick";
				}
				// Newfoundland and Labrador	709
				else if (area_code == "709")
				{
					region = "Newfoundland and Labrador ";
				}
				// Nova Scotia	782, 902
				else if (area_code == "782" ||
					area_code == "902")
				{
					region = "Nova Scotia";
				}
				// Ontario	548, 249, 289, 343, 365, 387, 416, 437, 
				//		519, 226, 613, 647, 705, 742, 807, 905
				else if (area_code == "548" ||
					area_code == "249" ||
					area_code == "289" ||
					area_code == "343" ||
					area_code == "365" ||
					area_code == "387" ||
					area_code == "416" ||
					area_code == "437" ||
					area_code == "519" ||
					area_code == "226" ||
					area_code == "613" ||
					area_code == "647" ||
					area_code == "705" ||
					area_code == "742" ||
					area_code == "807" ||
					area_code == "905")
				{
					region = "Ontario";
				}
				// Prince Edward Island	782, 902
				else if (area_code == "782" ||
					area_code == "902")
				{
					region = "Prince Edward Island";
				}
				// Quebec	418, 438, 450, 514, 579, 581, 819, 873
				if (area_code == "418" ||
					area_code == "438" ||
					area_code == "450" ||
					area_code == "514" ||
					area_code == "579" ||
					area_code == "581" ||
					area_code == "819" ||
					area_code == "873")
				{
					region = "Quebec";
				}
				// Saskatchewan	306, 639
				if (area_code == "306" ||
					area_code == "639")
				{
					region = "Saskatchewan";
				}
				//Yukon, Northwest Territories, and Nunavut	867
				else if (area_code == "867")
				{
					region = "Yukon, Northwest Territories, and Nunavut";
				}
				cout << "Number appears to be from: " << region << endl;


			}

		}

	}
	return i;
}
int main(int i, string telno)
{

	cout << "Enter phone number ddd-ddd-dddd" << endl;
	cin >> telno;



	return 0;
}

