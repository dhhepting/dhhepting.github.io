// Student Name : Cole Sanderson
//
// Student Number: 200355179
//
// Assignment Number: 4
//
// Program Name: Modification to Assignment #2 code
//
// Date Written: March 24, 2015
//
// Problem Statement: Manipulate Assignment #2 so that the validation of the telephone format is done in one function and then test to see if the area code is from Canada is done in another function.
//
// Input: The user will input a phone number to the computer and the computer will validate the number
//
// Output: The computer will output to the user if it is a valid or invalid number along with ending the program if "q" is entered 
//
// Major Variables: string valid, string validation, string code, string number 
//
// Assumptions: I assume that the user will have a rough understanding of area codes based in Canada. 
//
// Program Limitations: This program is limited only to the user entering a Canadian area code and none other.  
//

#include <iostream>
#include <string>
using namespace std;

// Using the string function to validate the number
string validation(string);

// Utilizing the void function
void area(string);

int main()
{
	// Utilizing the string approach to accomplish assignment two's requirements
	string code;
	string number;
	string valid ;

	// Prompt the user to enter a phone number to begin the program
	cout << "Please enter a phonenumber in the form ddd-ddd-dddd or q to end the program: ";
	cin >> number;

	// Utilizing the while loop in case if the user types the letter q into the program 
	while (number[0] != 'q')
	{
		do
		{
			valid = validation(number);
			if (valid == "check")
			{
				cout << "Invalid number/format please try again" << endl;
				cout << "Please enter a phonenumber in the form ddd-ddd-dddd or q to end the program: ";
				cin >> number;
			}
			
		} while (valid == "check");

			code = valid.substr(0, 3);

			area(code);

		

		// Allows the user to try again and enter a proper phone number that is acceptable in Canada
		cout << "Please enter a phone number in the form ddd-ddd-dddd or q to quit: ";
		cin >> number;
	}

	return 0;
}

// Utilizing string function to relay back the information to the void function
string validation(string phonenumber)
{
	if (phonenumber.length() == 12 && phonenumber[3] == '-' && phonenumber[7] == '-' && phonenumber[0] >= '0' && phonenumber[0] <= '9' && phonenumber[1] >= '0' &&
		phonenumber[1] <= '9' && phonenumber[2] >= '0' && phonenumber[2] <= '9' && phonenumber[4] >= '0' && phonenumber[4] <= '9' && phonenumber[5] >= '0' && phonenumber[5] <= '9'
		&& phonenumber[6] >= '0' && phonenumber[6] <= '9' && phonenumber[8] >= '0' && phonenumber[8] <= '9' && phonenumber[9] >= '0' && phonenumber[9] <= '9'
		&& phonenumber[10] >= '0' && phonenumber[10] <= '9' && phonenumber[11] >= '0' && phonenumber[11] <= '9')
	{ 
		return (phonenumber);
	}
	else
	{
		phonenumber = "check";
		return (phonenumber);
	}
}

void area(string areacode)
{
	// Utilizing the if statement to seperate each provinces area codes 
	if (areacode == "403" || areacode == "507" || areacode == "780" || areacode == "825")
	{
		cout << "The number that you input is a Canadian phone number from the Province Alberta" << endl;
	}
	if (areacode == "236" || areacode == "250" || areacode == "604" || areacode == "627" || areacode == "778")
	{
		cout << "The number that you input is a Canadian phone number from the Province British Columbia" << endl;
	}
	if (areacode == "204" || areacode == "431")
	{
		cout << "The number that you input is a Canadian phone number from the Province Manitoba" << endl;
	}
	if (areacode == "506")
	{
		cout << "The number that you input is a Canadian phone number from the Province New Brunswick" << endl;
	}
	if (areacode == "709")
	{
		cout << "The number that you input is a Canadian phone number from the Province Newfoundland and Labrador" << endl;
	}
	if (areacode == "782" || areacode == "903")
	{
		cout << "The number that you input is a Canadian phone number from the Province Nova Scotia or Prince Edward Island" << endl;
	}
	if (areacode == "548" || areacode == "249" || areacode == "289" || areacode == "343" || areacode == "365" || areacode == "387" || areacode == "416" || areacode == "437" || areacode == "519" || areacode == "226" || areacode == "613" || areacode == "647" || areacode == "705" || areacode == "742" || areacode == "807" || areacode == "905")
	{
		cout << "The number that you input is a Canadian phone number from the Province Ontario" << endl;
	}
	if (areacode == "418" || areacode == "438" || areacode == "450" | areacode == "514" || areacode == "579" || areacode == "581" || areacode == "819" || areacode == "873")
	{
		cout << "The number that you input is a Canadian phone number from the Province Quebec" << endl;
	}
	if (areacode == "306" || areacode == "639")
	{
		cout << "The number that you input is a Canadian phone number from the Province Saskatchewan" << endl;
	}
	if (areacode == "867")
	{
		cout << "The number that you input is a Canadian phone number from the Northwest Territories, the Yukon, or Nunavut" << endl;
	}
}