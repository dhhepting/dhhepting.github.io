/*
Name: Trisha Campbell
Student ID: 200321297
Assignment #: 4 part 1
Due Date: March 25, 2015
*/

//Step 1. Modify Assignment 1 code so that the calculations it does are located within a function. 
// The main() function that calls this function should let the user input any desired about of numbers, until a negative number is input.

#include <iostream>
#include <iomanip>
using namespace std;

void GetData(int&);
void NumOfDigits(int&);
void SumOfDigits(int&);
void AvgOfDigits(int&);
void ProdOfDigits(int&);

int main()
{
	int num;
	
	GetData(num);
	while (num >= 0)
	{
		NumOfDigits(num);
		SumOfDigits(num);
		AvgOfDigits(num);
		ProdOfDigits(num);
		GetData(num);
	}
	return 0;
}
	// This program first uses a function to prompt the user to enter an integer between 0 and 10000
void GetData(int& number)
{
	cout << "Please enter an integer between 0 and 10000:" << endl;
	cin >> number;

	if (number >= 0 && number <= 10000)
	cout << endl;
}

	// The program then uses a function to calculate the number of digits in the integer entered
void NumOfDigits(int& digits)
{
	cout << "Number of digits:";

	if (digits < 10)
	{
		cout << "1" << endl;
	}
	if (digits >= 10 && digits <= 99)
	{
		cout << "2" << endl;
	}
	if (digits >= 100 && digits <= 999)
	{
		cout << "3" << endl;
	}
	if (digits >= 1000 && digits <= 9999)
	{
		cout << "4" << endl;
	}
	if (digits == 10000 && digits > 9999)
	{
		cout << "5" << endl;
	}
}

    //The program then uses a function to calculate the sum of all the digits
void SumOfDigits(int& sum)
{
	cout << "Sum of all the digits:";

	int temp = sum;
	int digit5 = temp % 10;
	int digit4 = temp / 10 % 10;
	int digit3 = temp / 100 % 10;
	int digit2 = temp / 1000 % 10;
	int digit1 = temp / 10000 % 10;

	if (sum < 10)
	{
		cout << (digit5) << endl;
	}

	if (sum >= 10 && sum <= 99)
	{
		cout << (digit5 + digit4) << endl;
	}
	if (sum >= 100 && sum <= 999)
	{
		cout << (digit5 + digit4 + digit3) << endl;
	}
	if (sum >= 1000 && sum <= 9999)
	{
		cout << (digit5 + digit4 + digit3 + digit2) << endl;
	}
	if (sum == 10000 && sum > 9999)
	{
		cout << (digit5 + digit4 + digit3 + digit2 + digit1) << endl;
	}
}
    // The program then uses a function to calculate the average of all the digits
void AvgOfDigits(int& avg)
{
	cout << "Average of all the digits:";

	int temp = avg;
	int digit5 = temp % 10;
	int digit4 = temp / 10 % 10;
	int digit3 = temp / 100 % 10;
	int digit2 = temp / 1000 % 10;
	int digit1 = temp / 10000 % 10;

	if (avg < 10)
	{
		cout << (digit5) / 1 << endl;
	}
	if (avg >= 10 && avg <= 99)
	{
		cout << (digit5 + digit4) / 2 << endl;
	}
	if (avg >= 100 && avg <= 999)
	{
		cout << (digit5 + digit4 + digit3) / 3 << endl;
	}
	if (avg >= 1000 && avg <= 9999)
	{
		cout << (digit5 + digit4 + digit3 + digit2) / 4 << endl;
	}
	if (avg == 10000 && avg > 9999)
	{
		cout << (digit5 + digit4 + digit3 + digit2 + digit1) / 5 << endl;
	}
}
    //The program then uses a function to calculate the product of all the digits
void ProdOfDigits(int& prod)
{
	cout << "Product of all the digits:";

	int temp = prod;
	int digit5 = temp % 10;
	int digit4 = temp / 10 % 10;
	int digit3 = temp / 100 % 10;
	int digit2 = temp / 1000 % 10;
	int digit1 = temp / 10000 % 10;

	if (prod < 10)
	{
		cout << (digit5) << endl;
	}
	if (prod >= 10 && prod <= 99)
	{
		cout << (digit5 * digit4) << endl;
	}
	if (prod >= 100 && prod <= 999)
	{
		cout << (digit5 * digit4 * digit3) << endl;
	}
	if (prod >= 1000 && prod <= 9999)
	{
		cout << (digit5 * digit4 * digit3 * digit2) << endl;
	}
	if (prod == 10000 && prod > 9999)
	{
		cout << (digit5 * digit4 * digit3 * digit2 * digit1) << endl;
	}
}
