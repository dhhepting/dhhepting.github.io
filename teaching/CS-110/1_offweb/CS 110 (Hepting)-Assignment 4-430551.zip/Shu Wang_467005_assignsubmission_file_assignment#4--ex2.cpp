//********************************************************************
//Name: Shu Wang
//Student number: 200335170
//Assignment number: 4
//Program name: Checking Canadian Area Code of A Telephone Number
//Date written: Mar 25, 2015
//Problem statement: Write a program that prompts the user to enter a telephone number in the format ddd-ddd-dddd, where d is digit. This is the format for telephone numbers in North America. Test that the input is in the correct format and further check if the phone number has a Canadian area code (see the list of Canadian area codes). The program will report if the input is valid or not. If the input includes a Canadian area code, the program will display the name of the province or territory with that area code. The program will continue to process numbers until the user enters the letter q.
//Input: A 12 digits telephone number
//Output: Validation of telephone number, area code, and the province
//Algorithm:
//(1) int check1(string) : check if the phone number is in correct format
//(2) void check2(string): check the area that the phone number belongs to
//(3) while: exit while input is "q", otherwise check the number by calling funtion
//Major variables: num,area
//Assumptions:  Helping to check if telephone numbers are valid, and more spicificly, the program will tell user the area for the telephone number.
//Program limitations: We can only check if the telephone number is for province of Canada
//**********************************************************************

#include <iostream>
#include <string>
using namespace std;

int check1(string);
void check2(string);

int main()
{
    string num;
    string area;
    
    while (num != "q")
    {
        cout << "Enter phone number ddd-ddd-dddd" << endl;
        cin >> num;
        
        if (num == "q")
        {
            cout << "Exit the program." << endl;
            return 0;
        }
        
        if (check1(num))
        {
           
            area = num.substr(0, 3);
            check2(area);
        }
        else
            cout << "Number not in proper format" << endl;
        
        cout <<endl;
    }
    
    return 0;
}

int check1(string num)
{
    if (num.length() != 12)
        return 0;
    if (num[3] != '-' ||num[7] != '-')
        return 0;
    
    if (!(num[0] >= '0' && num[0] <= '9') ||!(num[1] >= '0' && num[1] <= '9') || !(num[2] >= '0' && num[2] <= '9') ||!(num[4] >= '0' && num[4] <= '9') || !(num[5] >= '0' && num[5] <= '9') || !(num[6] >= '0' && num[6] <= '9') || !(num[8] >= '0' && num[8] <= '9')|| !(num[9] >= '0' && num[9] <= '9') || !(num[10] >= '0' && num[10] <= '9') || !(num[11] >= '0' && num[11] <= '9'))
        return 0;
 
    return 1;
}


void check2(string area)
{
    cout << "The area code is: " << area << endl;
    if (area == "403" || area == "587" || area == "780" || area == "825")
        cout << "Number appears to be from: Alberta." << endl;
    else if (area == "236" || area == "250" || area == "604" || area == "672" || area == "778")
        cout << "Number appears to be from: British Columbia." << endl;
    else if (area == "204" || area == "431")
        cout << "Number appears to be from:  Manitoba." << endl;
    else if (area == "236" || area == "250" || area == "604" || area == "672" || area == "778")
        cout << "Number appears to be from:  New Brunswick." << endl;
    else if (area == "709")
        cout << "Number appears to be from:  Newfoundland and Labrador." << endl;
    else if (area == "782" || area == "902")
        cout << "Number appears to be from:  Nova Scotia." << endl;
    else if (area == "548" || area == "249" || area == "289" || area == "343" || area == "365" || area == "387" || area == "416" || area == "437" || area == "519" || area == "226" || area == "613" || area == "647" || area == "705" || area == "742" || area == "807" || area == "905")
        cout << "Number appears to be from:  New Brunswick." << endl;
    else if (area == "782" || area == "902")
        cout << "Number appears to be from:  Prince Edward Island." << endl;
    else if (area == "418" || area == "438" || area == "450" || area == "514" || area == "579" || area == "581" || area == "819" || area == "873")
        cout << "Number appears to be from:  Quebec." << endl;
    else if (area == "306" || area == "639")
        cout << "Number appears to be from:  Saskatchewan." << endl;
    else if (area == "867")
        cout << "Number appears to be from:  Yukon, Northwest Territories, and Nunavut." << endl;
    else
        cout << "Number appears to be from: Not Canada." << endl;
}














