#include <iostream>
using namespace std;

void GetNumber(double);
double ComputeNumbers(double);
void PrintAnswers(double);
int main()
{

void GetNumber(double & number);
	{
	int number;
	int sum = 0;
	int digits = 0;
	int average = 0;
	int count = 0;
	int product = 1;

	cout << endl; 	// using this to make a space so output is easier to see.
	cout << "Hello, please enter any whole number between 0 and 10,000." << 
endl;
	cout << endl;
	cin >> number; 	// input number to program.
	}
double ComputeNumbers(double);
	{
// formula for sum and product.

	while ( number > 0 ) {	
	{product *= number % 10;}
	sum += number % 10;
	number /= 10;

// formula for number of digits.
	
	if ( number < 10 ) { count += 1; }	
	else
	if ( number < 100 ) { count += 2 - 1; }
	else
	if ( number < 1000 ) { count += 3 - 2; }
	else
	if ( number < 10000 ) { count += 4 - 3; }
	else
	if ( number = 10000 ) { count += 5; }
	
// formula for the average of the digits.

	average = sum/count;

	}
	}
void PrintAnswers(double);
	{
// output of the required information.

	cout << endl; 
	cout << "The number of digits is: " << count << endl;
	cout << endl;
	cout << "The sum of the digits is: " << sum << endl;
	cout << endl;
	cout << "The average of the digits is: " << average << endl;
	cout << endl;
	cout << "The product of the digits is: " << product << endl;
	cout << endl;
	cout << "Thank you for trying the program." << endl;
	cout << endl;
	}
	return 0;
}

