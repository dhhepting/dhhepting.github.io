// 
//**************************************************************************
//
// Student name: Sheena-Lee Gaetz
//
// Student number: 200317727
//
// Assignment Number: 4
//
// Program Name: 1 to 10000
//
// Date written: March 21, 2015
//
// Problem statement: Get an input of an integer in between 0 and 10000 and calculate
// the number of digits, sum, average, and product using a separate function. The main function that calls
// the function asks the user to contine to input numbers until a negative number is entered.
//
// Input: An integer between 0 and 10000
//
// Output: The number of digits, sum, averagem and produt
//
// Algorithm: using if statements will determine the number of digits.
// Using modulus and division will determine what number each digit is.
// Simple math calculations will be done from there to find sum and, average, and product.
// 4 Functions are used to calculate each component separately.
// A do-while loop is used to continue asking for input until a negative number is entered.
//
// Major variables: int num, int d1-d5, int sum, int product, int ave.
//
// Assumptions: The program will work with any number that is inputed.
// If the number is not in the range the user will be informed and program will end when a negative number and will
// ask for a new number if it is above 10000.
//
// Program limitations: None
//
//**************************************************************************
#include <iostream>
using namespace std;

int ComputeDigits(int num); //function prototypes
int ComputeSum(int num);
double ComputeAverage(int num);
int ComputeProduct(int num);

int main()
{
	
	int num;
	int digits;
	int sum;
	double ave;
	int product;

	do //while loop to continue to ask for input if conditions are true
	{
		cout << "Please enter an integer between 0 and 10000: " << endl;
		cin >> num;

		if (num >= 0 && num <= 10000)
		{

			digits = ComputeDigits(num); //function call
			cout << "Number of digits: " << digits << endl;

			sum = ComputeSum(num); //function call
			cout << "Sum of digits: " << sum << endl;

			ave = ComputeAverage(num); //function call
			cout << "Average of digits: " << ave << endl;

			product = ComputeProduct(num); //function call
			cout << "Product of the digits: " << product << endl;
		}

		else if (num > 10000)
		{
			cout << "This number is out of range!" << endl;
			continue;
		}

		else
		{
			cout << "This number is out of range!" << endl;
			return 0;
		}
		
	} while (num >= 0);

	return 0;
}

int ComputeDigits(int num) //function definition with one parameter
{
	if (num < 10)
	{
		return 1;
	}
	else

		if (num < 100)
		{
			return 2;
		}
		else

			if (num < 1000)
			{
				return 3;
			}
			else

				if (num < 10000)
				{
					return 4;
				}	
				else	

						if (num == 10000)
						{
								return 5;
						}
	return 0;
}

int ComputeSum(int num) //function definition with one parameter
{
	if (num < 10)
	{
		return num;
	}
	else

		if (num < 100)
		{
			int d1; 
			int d2; 
			d1 = num % 10; 
			num /= 10;
			d2 = num % 10;
			int sum; 
			sum = (d1 + d2);
			return sum;
		}
		else

			if (num < 1000)
			{
				int d1;
				int d2;
				int d3;
				d1 = num % 10;
				num /= 10;
				d2 = num % 10;
				num /= 10;
				d3 = num % 10;
				int sum;
				sum = (d1 + d2 + d3);
				return sum;
			}
			else

				if (num < 10000)
				{
					int d1;
					int d2;
					int d3;
					int d4;
					d1 = num % 10;
					num /= 10;
					d2 = num % 10;
					num /= 10;
					d3 = num % 10;
					num /= 10;
					d4 = num % 10;
					int sum;
					sum = (d1 + d2 + d3 + d4);
					return sum;
				}
				else

					if (num == 10000)
					{
						int d1;
						int d2;
						int d3;
						int d4;
						int d5;
						d1 = num % 10;
						num /= 10;
						d2 = num % 10;
						num /= 10;
						d3 = num % 10;
						num /= 10;
						d4 = num % 10;
						num /= 10;
						d5 = num % 10;
						int sum;
						sum = (d1 + d2 + d3 + d4 + d5);
						return sum;
					}
	return 0;
}

double ComputeAverage(int num) //function definition with one parameter
{
	if (num < 10)
	{
		return num;
	}
	else

		if (num < 100)
		{
			int d1;
			int d2;
			d1 = num % 10;
			num /= 10;
			d2 = num % 10;
			int sum;
			sum = (d1 + d2);
			double ave;
			ave = sum/2;
			return ave;
		}
		else

			if (num < 1000)
			{
				int d1;
				int d2;
				int d3;
				d1 = num % 10;
				num /= 10;
				d2 = num % 10;
				num /= 10;
				d3 = num % 10;
				int sum;
				sum = (d1 + d2 + d3);
				double ave;
				ave = sum/3;
				return ave;
			}
			else

				if (num < 10000)
				{
					int d1;
					int d2;
					int d3;
					int d4;
					d1 = num % 10;
					num /= 10;
					d2 = num % 10;
					num /= 10;
					d3 = num % 10;
					num /= 10;
					d4 = num % 10;
					int sum;
					sum = (d1 + d2 + d3 + d4);
					double ave;
					ave = sum/4;
					return ave; return sum;
				}
				else

					if (num == 10000)
					{
						int d1;
						int d2;
						int d3;
						int d4;
						int d5;
						d1 = num % 10;
						num /= 10;
						d2 = num % 10;
						num /= 10;
						d3 = num % 10;
						num /= 10;
						d4 = num % 10;
						num /= 10;
						d5 = num % 10;
						int sum;
						sum = (d1 + d2 + d3 + d4 + d5);
						double ave;
						ave = sum/5;
						return ave;
					}
	return 0;
}

int ComputeProduct(int num) //function definition with one parameter
{
	if (num < 10)
	{
		return num;
	}
	else

		if (num < 100)
		{
			int d1;
			int d2;
			d1 = num % 10;
			num /= 10;
			d2 = num % 10;
			int product;
			product = (d1 * d2);
			return product;
		}
		else

			if (num < 1000)
			{
				int d1;
				int d2;
				int d3;
				d1 = num % 10;
				num /= 10;
				d2 = num % 10;
				num /= 10;
				d3 = num % 10;
				int product;
				product = (d1 * d2 * d3);
				return product;
			}
			else

				if (num < 10000)
				{
					int d1;
					int d2;
					int d3;
					int d4;
					d1 = num % 10;
					num /= 10;
					d2 = num % 10;
					num /= 10;
					d3 = num % 10;
					num /= 10;
					d4 = num % 10;
					int product;
					product = (d1 * d2 * d3 * d4);
					return product;
				}
				else

					if (num == 10000)
					{
						int d1;
						int d2;
						int d3;
						int d4;
						int d5;
						d1 = num % 10;
						num /= 10;
						d2 = num % 10;
						num /= 10;
						d3 = num % 10;
						num /= 10;
						d4 = num % 10;
						num /= 10;
						d5 = num % 10;
						int product;
						product = (d1 * d2 * d3 * d4 * d5);
						return product;
					}
	return 0;
}
