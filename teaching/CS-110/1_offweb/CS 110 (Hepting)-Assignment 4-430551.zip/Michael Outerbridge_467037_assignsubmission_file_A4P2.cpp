//**************************************************************************
//
// Student name: Michael Outerbridge
//
// Student number:  200352016
//
// Assignment number: 4 part 2
//
// Program name: Canadian Phone Number Finder w/ functions
//
// Date written: 25/03/2015
//
//	Modify Assignment 2 so that the validation of the telephone format
//	is done in one function and the test to see if the area code is from
//	Canada is done in another function.
//
//*****************************************************************

#include <iostream>
#include <string> 
using namespace std;

string valid(string&); //Declares the function for checking if the phone# is a valid #
void area(string&); //Declares the function to check the area code of the #


int main()
{


	string phone;
	while (phone != "q") //Tells the program to run until "q" is entered as a #
	{
		string areacode;
		areacode = valid(phone);
		if (phone != "q")
			area(areacode);
	}

}

string valid(string& phone) //Checking the # for format
{
	cout << "Please enter a ten digit phone number in the ddd-ddd-dddd format. Include the dashes. Press 'q' to close the program" << endl;
	cin >> phone;
	if (phone.length() != 12) //Lets the program know if the # is the proper length
		if (phone != "q")
			cout << "This is an invalid number" << endl; //Tells the user the phone# was not a valid length
	string areacode = phone.substr(0, 3); //Tells the code which portion of the # is the area code
	return phone, areacode; //Returns the phone# and the first 3 digits (areacode) to seperate variables in the main()
}

void area(string& a) //Checking for area code
{
	if (a == "306" || a == "639")
	{
		cout << "This is a Saskatchewan based number" << endl; //Each if statement contains the area codes for the provinces and territories and then tells the user where the area code is from
	}
	else if (a == "867")
	{
		cout << "This is a number for the Yukon, Northwest Territories and Nunavut." << endl;
	}
	else if (a == "403" || a == "587" || a == "780" || a == "825")
	{
		cout << "This is a Alberta based number" << endl;
	}
	else if (a == "236" || a == "250" || a == "604" || a == "672" || a == "778")
	{
		cout << "This is a number for British Columbia" << endl;
	}
	else if (a == "204" || a == "431")
	{
		cout << "This is a number for Manitoba" << endl;
	}
	else if (a == "506")
	{
		cout << "This is a number for New Brunswick" << endl;
	}
	else if (a == "709")
	{
		cout << "This is a number for Newfoundland and Labrador" << endl;
	}
	else if (a == "782" || a == "902")
	{
		cout << "This is a number for Nova Scotia" << endl;
	}
	else if (a == "548" || a == "249" || a == "289" || a == "343" || a == "365" || a == "387" || a == "416" || a == "437" || a == "519" || a == "226" || a == "613" || a == "647" || a == "705" || a == "742" || a == "807" || a == "905")
	{
		cout << "This is a number for Ontario" << endl;
	}
	else if (a == "782" || a == "902")
	{
		cout << "This is a number for Prince Edward Island" << endl;
	}
	else if (a == "418" || a == "438" || a == "450" || a == "514" || a == "579" || a == "581" || a == "819" || a == "873")
	{
		cout << "This is a number for Qu�bec" << endl;
	}
	else
	{
		cout << "This is not a Canadian number, try again" << endl; //If the area code does not match any of the above, it tells the user that the # is not Canadian.
	}
	cout << endl;
}