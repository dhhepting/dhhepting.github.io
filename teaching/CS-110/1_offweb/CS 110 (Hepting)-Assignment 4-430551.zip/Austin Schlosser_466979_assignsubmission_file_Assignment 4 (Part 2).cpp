/*
Name: Austin Schlosser
Student ID: 200352214
Assignment number: 4 Part 2
Program Name: Canadian area code validation
Date wrote: March 23, 2015
Problem: Determines if area code is Canadian and region of area code
Input of user: User inputs phone number
Output: Program tells user if it is a Canadian area code and which province it is from
Algorithm: Functions and if statements
Major variables: phone, place, province
Assumptions: User only inputs area code
Limitations: Cannot handle fulll phone number
*/

#include <iostream>

#include <string>

using namespace std;




int phone(int &number, int &code)
{
cout << "Please input a Canadian area code as ddd. To exit the program press q." << endl;

cin >> code;



return code;
}
//Prompts user to enter area code



string province (int &area, string &place)

{

if (area == 867)

{

place = "the territories";

}


else if (area == 403 || area == 587 || area == 780 || area == 825)

{

place = "Alberta";

}


else if (area == 236 || area == 250 || area == 604 || area == 672 || area == 778)

{

place = "British Colombia";

}


else if (area == 204 || area == 231)

{

place = "Manitoba";

}


else if (area == 506)
{
place = "New Brunswick";

}


else if (area == 709)

{

place = "Newfoundland";

}


else if (area == 782 || area == 902)

{

place = "Nova Scotia";

}

else if (area == 548 || area == 249 || area == 289 || area == 343 || area == 365
 || area == 387|| area == 416 
	|| area == 437 || area == 519 || area == 226 || area == 613 || area == 647 || area == 705 || area == 742 
	|| area == 807 || area == 905)

{

place = "Ontario";

}


else if (area == 782 || area == 902)

{

place = "Prince Edward Island";

}


else if (area == 418 || area == 438 || area == 450 || area == 514|| area == 579 || area == 581 || area == 819
 
	|| area == 873)

{

place = "Quebec";

}


else if (area == 306 || area == 639)

{

place = "Saskatchewan";

}


else

{

place = "not Canada";

}


return place;

}


//Determines region where area code is located

int main ()

{

int number;


int region;

string place;



number = phone (number, region);
place = province(region, place);



cout << "The number is from "<< place << "." << endl;


//Calls back variable calculated in funtions before main program


return 0;

}
//End of program