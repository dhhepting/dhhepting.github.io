//**************************************************************************
//
// Student name:Juan Echavarria	
//
// Student number: 200360759
//
// Assignment number: 4
//
// Program name:
//
// Date written: 25-03-2015
//
// Problem statement: Change assignment 1 with return functions
//
// Input: 
//
// Output: 
//
// Algorithm: 
//
// Major variables: n, a, b, c, m, d, p, e, i, x;
//
// Assumptions:
//
// Program limitations:
//
//**************************************************************************
#include<iostream>

using namespace std;
void fun(int, int, int, int, int);
int n, a, b, c, m, d, p, e, i, x;

int main()
{
        while (1){
                cout << "Please type an integer between 0 and 10000:\n";

                cin >> n;
                if (n < 0)break;
                a = (n / 10000) % 10;
                b = (n / 1000) % 10;
                c = (n / 100) % 10;
                d = (n / 10) % 10;
                e = (n / 1) % 10;
                fun(a, b, c, d, e);
                a = 0, b = 0, c = 0, d = 0, e = 0;
         }
        }
        void fun(int a, int b, int c, int d, int e){
                if (a == 0)
                        i = 4;
                if (b == 0 && a == 0)
                        i == 3;
                if (c == 0 && b == 0 && a == 0)
                        i = 2;
                if (a == 0 && b == 0 && c == 0 && d == 0)
                        i = 1;

                if (i == 0)
                        x = (a + b + c + d + e) / 5;
                else
                        x = (a + b + c + d + e) / i;

                if (i == 0)
                {
                        cout << a << "\n" << b << "\n" << c << "\n" << d << "\n" << e << "\n";
                        p = a*b*c*d*e;
                }
                else
                        if (i == 4)
                        {
                                cout << b << "\n" << c << "\n" << d << "\n" << e << "\n";
                                p = b*c*d*e;

                        }
                        else
                                if (i == 3)
                                {
                                        cout << c << "\n" << d << "\n" << e << "\n";

                                        p = c*d*e;
                                }
                                else
                                        if (i == 2)
                                        {
                                                cout << d << "\n" << e << "\n";
                                                p = d*e;
                                        }
                                        else
                                        {
                                                cout << e << endl;
                                                p = e;
                                        }

                if (i == 0)
                        cout << "The number of digits are: " << " " << 5 << "\n";
                else
                        cout << "The number of digits are: " << " " << i << "\n";
                cout << "The sum of the digits is:" << " " << a + b + c + d + e << "\n";
                cout << "The average of all digits is:" << " " << x << /* (a + b + c
+ d + e) / i << */ "\n";
                cout << "The product of all digits is:" << " " << p << "\n";

        }
