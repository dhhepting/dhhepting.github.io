//**************************************************************************
//
// Student name: Riley Peters
//
// Student number: 200 354 249
//
// Assignment number: #4 - Part 2
//
// Program name: Phone Number Analysis
//
// Date written: March 19th, 2015
//
// Problem statement: To have a program read a phone number, check for proper format, and display the area
//                      code's location and repeat until the user inputs q
//
// Input: phone number in format ddd-ddd-dddd
//
// Output: location of area code
//
// Algorithm: input phone number -> check if the phone number is in the proper format using a function -> take the first
//            three digits out for the area code -> check the area code to Canadian area codes -> output
//            the location of the area code or output not from Canada -> loop again until the while loop
//            is false (user inputs q).
//
// Major variables: phone number, area code
//
// Assumptions: non-Canadian numbers must follow similar format
//
// Program limitations: will not display location of non-Canadian area codes, phone number must be input
//                      in proper format
//
//**************************************************************************

#include <iostream>
#include <string>  /* for string use */
using namespace std;

bool CheckFormat(string); /* Function Prototype */

void FindAreaCode(string);  /* Function Prototype */

int main()
{
    cout << "Enter phone number ddd-ddd-dddd" << endl;
    string number;
    cin >> number;
    while (number[0] != 'q')
    {
        bool proper_format = CheckFormat(number); /* Call Function to check format */
        
        if (proper_format) /* Test if proper format is true */
        {
            string area_code = number.substr(0,3);
            FindAreaCode(area_code);
        }
        
        else
            cout << "Number not in proper format" << endl;
    
        cout << "Enter phone number ddd-ddd-dddd" << endl; /* Recieve input for next number */
        cin >> number;
    }
    
    return 0;
}

// Function Definition

bool CheckFormat(string num)
{
    if (num.length() != 12) /* Check if length is correct */
        return false;
    else
    {
        for (int i = 0;i < 12; i++)
        {
            if (i == 3 || i == 7)
            {
                if (num[i] != '-')  /* Check if 3rd and 7th digits are hyphens */
                    return false;
            }
            else
            {
                if (!isdigit(num[i])) /* Check if each digit is a number */
                    return false;
            }
        }
    }
    
    return true;
}

//Function that prints the location of the area code
void FindAreaCode(string acode)
{
    string region = "Not from Canada";
    
    // Alberta
    if (acode == "403" || acode == "587" || acode == "780" || acode == "825")
        region = "Alberta";
    
    // British Columbia
    else if (acode == "236" || acode == "250" || acode == "604" || acode == "672" || acode == "778")
        region = "British Columbia";
    
    // Manitoba
    else if (acode == "204" || acode == "431")
        region = "Manitoba";
    
    // New Brunswick
    else if (acode == "506")
        region = "New Brunswick";
    
    // Newfoundland and Labrador
    else if (acode == "709")
        region = "Newfoundland and Labrador ";
    
    // Nova Scotia and PEI
    else if (acode == "782" || acode == "902")
        region = "Nova Scotia or Prince Edward Island";
    
    // Ontario
    else if (acode == "548" || acode == "249" || acode == "289" || acode == "343" ||
             acode == "365" || acode == "387" || acode == "416" || acode == "437" ||
             acode == "519" || acode == "226" || acode == "613" || acode == "647" ||
             acode == "705" || acode == "742" || acode == "807" || acode == "905")
        region = "Ontario";
    
    // Quebec
    else if (acode == "418" || acode == "438" || acode == "450" || acode == "514" ||
             acode == "579" || acode == "581" || acode == "819" || acode == "873")
        region = "Quebec";
    
    // Saskatchewan
    else if (acode == "306" || acode == "639")
        region = "Saskatchewan";
    
    //Yukon, Northwest Territories, and Nunavut
    else if (acode == "867")
        region = "Yukon, Northwest Territories, and Nunavut";
    
    cout << "This phone number is from: " << region << endl;
}