// Joseph Egyir
// 200357099
// 25/03/2015
#include <iostream>
using namespace std;

void Calculations(int &);


int main()
{
	int number;	
	Calculations(number);
	
		
	return 0;
}

void Calculations(int& a)
{
	cout << "Please enter a number between 0 and 1000." << endl;
	cin >> a;

	if (a >= 0 && a <= 10000)
	{
		int digit1 = a % 10;
		a /= 10;
		int digit2 = a % 10;
		a /= 10;
		int digit3 = a % 10;
		a /= 10;
		int digit4 = a % 10;
		a /= 10;
		int digit5 = a % 10;


		int number_digits = 1;
		if (digit5 > 0)
		{
			number_digits = 5;
		}
		else if (digit4 > 0)
		{
			number_digits = 4;
		}
		else if (digit3 > 0)
		{
			number_digits = 3;
		}
		else if (digit2 > 0)
		{
			number_digits = 2;
		}

		int sum = digit1;
		int prod = digit1;

		int current_digit = 1;
		if (current_digit < number_digits)
		{
			sum += digit2;
			prod *= digit2;
			if (++current_digit < number_digits)
			{
				sum += digit3;
				prod *= digit3;
				if (++current_digit < number_digits)
				{
					sum += digit4;
					prod *= digit4;
					if (++current_digit < number_digits)
					{
						sum += digit5;
						prod *= digit5;
					}
				}
			}
		}
		cout << "The number of digits is " << number_digits << endl;
		cout << "The sum of digits is " << sum << endl;
		cout << "The product of digits is " << prod << endl;
		cout << "The average of digits is " << sum / static_cast<float>(number_digits) << endl;
	}
	else
	{
		cout << "The number is not between 0 and 10000. Please eneter a valid number." << endl;
	}
}