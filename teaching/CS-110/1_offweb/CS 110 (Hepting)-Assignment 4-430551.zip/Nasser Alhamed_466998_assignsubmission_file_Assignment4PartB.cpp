/*************************************************



This is the solution of assignemnt number 4 Part B

Student name: Nasser Alhamed

Student ID  : 200307983

Program name: Identifiy the Area Code

Date written: Mar 24, 2015

Problem statement: 

Input: A phone number that contains 10 digits

Output: The name of the province entered

Algorithm: enter a number in a certine fromat, test the valdiation then check which aree code is from. 

Major variables: the number 306-444-1234, 33-345-1234, 236-444-1234

Assumptions:

Program limitations: Any number not in the format like qqq-qqq-qqq will diplay an invalid number



*************************************************/
#include <iostream>
#include <string>
using namespace std;
// prototype function needed so c++ does not freak out about the coming integers.
void validation(string);
void test(string);

int main()
{
	// to declare to the computer the input
	string  number;
	cout << "please enter a phone number with the fromat like: 333-444-2222 " << endl;
	cin >> number;

	cout << " The number your entered is: " << number << endl;
	//call function
	validation(number);



	return 0;
}
// function in which check the validation of the number entered.
void validation(string digit)
{

	// Here to declare the area code
	string areacodeofcanada = digit.substr(0, 3);
	// the length of the number including the hyphen is 12 characters
	// if the number length is more or less 12 and the third and seventh input not hephen the
	// will not run and will diplay "Invalid number!"
	if ((digit.length() < 12) || (digit.length() > 12) || (digit.at(3) != '-') || (digit.at(7) != '-'))
	{
		cout << " Invalid number! " << endl;
		string number;
		cout << "please enter other number including the hyhen if you wish or q to end " << endl;
		cin >> number;

		if (number == "q")
		{
			cout << " Thnak you!" << endl;
		}
		else
		{
			// call the number to the second function
			validation(number);
		}

	}
	else
	{
		test(areacodeofcanada);
	}


}

void test(string areaCode)
{
	// here we define every code to it's number
	// there are many area codes for Alberta so. there are declaration for each case
	if (areaCode == "403" || areaCode == "587" || areaCode == "780" || areaCode == "825")
	{

		cout << " This number is from Alberta " << endl;
	}
	// same in BC
	else if (areaCode == "236" || areaCode == "250" || areaCode == "604" || areaCode == "778")
	{

		cout << " This number is from British Columbia " << endl;
	}
	// area code for Ontario (Very long list of codes)
	else if (areaCode == "548" || areaCode == "249"
		|| areaCode == "289" || areaCode == "343" ||
		areaCode == "365" || areaCode == "387" || areaCode == "416" ||
		areaCode == "437" || areaCode == "519" || areaCode == "226"
		|| areaCode == "613" || areaCode == "647" || areaCode == "705"
		|| areaCode == "742" || areaCode == "807" || areaCode == "905")
	{

		cout << " This number is from Ontario " << endl;

	}
	// for Prince Edward Island
	else if (areaCode == "782" || areaCode == "902")
	{

		cout << " The number is from Prince Edward Island " << endl;

	}
	// For Saskatchewan
	else if (areaCode == "306" || areaCode == "639")
	{

		cout << " This number is from Saskatchewan " << endl;

	}
	// For Quebec
	else if (areaCode == "418" || areaCode == "438" ||
		areaCode == "450" || areaCode == "514" ||
		areaCode == "579" || areaCode == "581" ||
		areaCode == "819" || areaCode == "873")
	{

		cout << " This number is from Quebec " << endl;

	}
	// For Brunswick
	else if (areaCode == "506")
	{

		cout << " The number is from New Brunswick " << endl;

	}
	// For Manitoba
	else if (areaCode == "204" || areaCode == "431")
	{

		cout << " This number is from Manitoba " << endl;

	}
	// For Nova Scotia
	else if (areaCode == "782" || areaCode == "902")
	{

		cout << " This number is from Nova Scotia " << endl;

	}
	// For Newfoundland and Labrador
	else if (areaCode == "709")
	{

		cout << " The number is from Newfoundland and Labrador " << endl;

	}
	// For three provinces
	else if (areaCode == "867" || areaCode == "902")
	{

		cout << " The number is from Yukon, Northwest, and Nunavut " << endl;

	}
	else
	{
		cout << " The number your entered is not a Canadian number " << endl;
	}
	// Here after the program dispalys the output
	// the user will have a choise weather to continue entering a new number or pressing 
	// "q" to end the program
	string number;
	cout << "please enter other number including the hyhen if you wish or press q to end " << endl;
	cin >> number;

	if (number == "q")
	{
		cout << " Thnak you!" << endl;
	}
	else
	{
		validation(number);
	}
}