// Name: Renee Lavoy
// SID: 200336240
// Assignment: #1
// Program Name: Calculating the number of digits, the sum of digits, the average of digits, and the product of the digits in a number [0, 10000]
// Date Written: January 29, 2015
/* Problem Statement: this code will count the digits, sum the digits, average the digits, and take the product of the digits of any number
from [0,10000] inputed by the user*/
// Input: an integer with range [0,10000]
// Output: the number of digits, the sum of digits, the average of digits, and the product of the digits in the integer
// Algorithm: the computer will be calculating in terms of addition, subtraction, multiplication, and division
// Major variables: number, a, b, c, d, sum, average, product
// Assumptions: the user will follow instructions and only enter a integer in the range [0,10000]
/* Program limitations: the program will only calculate the number of digits, the sum, the average, and the product for numbers that
are 0 to 10000, inclusive. If the user enters a number greater than 10000 or less than 0, the user will be prompted to enter a number that
is in the range required*/

#include <iostream>
using namespace std;

// function
int GetTheNumber(int &);

int main()
{
	int number;
	do
	{
	cout << "Please enter a number between 0 and 10000." << endl;					// prompting the user to enter an integer
	cin >> number;
	GetTheNumber(number);
	cout << endl;
	} while (number > 0);

	return 0;
}

int GetTheNumber(int&x)
{
	int sum;
	int average;
	int product;
	if (x < 10)																		/* this section of the code will be performed if the
																					integer entered by the user is < 10*/
	{
		cout << "Number of digits: 1" << endl;
		sum = x;
		cout << "The sum of the digits is: " << sum << endl;
		average = x;
		cout << "The average of the digits is: " << average << endl;
		product = x;
		cout << "The product of the digits is: " << product << endl;

		return sum;
		return average;
		return product;
	}
	else if (x < 100 && x > 9)															/* this section of the code will be performed if the
																					integer entered by the user is < 100*/
	{
		cout << "Number of digits: 2" << endl;
		int a = x / 10;
		int b = x - (a * 10);
		sum = (a + b);
		cout << "The sum of the digits is: " << sum << endl;
		average = (a + b) / 2;
		cout << "The average of the digits is: " << average << endl;
		product = (a * b);
		cout << "The product of the digits is: " << product << endl;

		return sum;
		return average;
		return product;
	}
	else if (x < 1000 && x > 99)															/* this section of the code will be performed if the
																					integer entered by the user is < 1000*/
	{
		cout << "Number of digits: 3" << endl;
		int a = x / 100;
		int b = (x / 10) - (a * 10);
		int c = x - (b * 10) - (a * 100);
		sum = (a + b + c);
		cout << "The sum of the digits is: " << sum << endl;
		average = (a + b + c) / 3;
		cout << "The average of the digits is: " << average << endl;
		product = (a * b * c);
		cout << "The product of the digits is: " << product << endl;

		return sum;
		return average;
		return product;
	}
	else if (x < 10000 && x > 999)														/* this section of the code will be performed if the
																					integer entered by the user is < 10000*/
	{
		cout << "Number of digits: 4" << endl;
		int a = x / 1000;
		int b = (x / 100) - (a * 10);
		int c = (x / 10) - (b * 10) - (a * 100);
		int d = x - (c * 10) - (b * 100) - (a * 1000);
		sum = (a + b + c + d);
		cout << "The sum of the digits is: " << sum << endl;
		average = (a + b + c + d) / 4;
		cout << "The average of the digits is: " << average << endl;
		product = (a * b * c * d);
		cout << "The product of the digits is: " << product << endl;

		return sum;
		return average;
		return product;
	}
	else if (x == 10000)														/* this section of the code will be performed if the
																					integer entered by the user is == 10000*/
	{
		cout << "Number of digits: 5" << endl;
		sum = 1;
		cout << "The sum of the digits is: " << sum << endl;
		average = 0;
		cout << "The average of the digits is: " << average << endl;
		product = 0;
		cout << "The product of the digits is: " << product << endl;

		return sum;
		return average;
		return product;
	}
	
}