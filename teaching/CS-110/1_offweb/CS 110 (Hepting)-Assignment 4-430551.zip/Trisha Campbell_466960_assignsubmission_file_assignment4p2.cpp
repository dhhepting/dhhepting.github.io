/*
Name: Trisha Campbell
Student ID: 200321297
Assignment #: 4 part 2
Due Date: March 25, 2015
*/

#include <iostream>
#include <string>
using namespace std;

void GetNum(string&);
void TestNum(string&);
void AreaNum(string);


int main()
{
	string tel;
	GetNum(tel);
    TestNum(tel);
	string areac = tel.substr(0, 3); // To determine whether the first three digits represent a Canadian area code.
	AreaNum(areac);



	return 0;
}
// Step 1: Prompts the user to enter a phone number in the format ddd-ddd-dddd, where d is a digit.
void GetNum(string& t)
{
	cout << "Please enter a telephone number in the format: ddd-ddd-dddd, where d represents digits:\n";
	getline(cin, t);
	cout << endl;
}
// Step 2: This program then tests whether the input is in the correct format for North America.
void TestNum(string& tele)
{
	if (tele.length() == 12 && tele.at(3) == '-' && tele.at(7) == '-')
		cout << "\nThank you.\n" << endl;
	else while (tele.length() != 12 && tele.at(3) != '-' && tele.at(7) != '-') // Used to repeatedly ask the user to enter phone numbers until it is finally in the correct format.
	{
		cout << "Please try again with correct format:\n";
		getline(cin, tele);
		cout << "\nThank you.\n" << endl;
	}
}
// Step 3: If the input contains a Canadian area code the program will output the province or territory with that area code.
void AreaNum(string areacode)
{

	if (areacode == "403" || areacode == "587" || areacode == "780")
	{
		cout << "This is an Alberta area code.\n";
	}
	else if (areacode == "236" || areacode == "250" || areacode == "604" || areacode == "778")
	{
		cout << "This is a British Columbia area code.\n";
	}
	else if (areacode == "204" || areacode == "431")
	{
		cout << "This is a Manitoba area code.\n";
	}
	else if (areacode == "506")
	{
		cout << "This is a New Brunswick area code.\n";
	}
	else if (areacode == "709")
	{
		cout << "This is a Newfoundland and Labrador area code.\n";
	}
	else if (areacode == "782" || areacode == "902")
	{
		cout << "This is a Nova Scotia or Prince Edward Island area code.\n";
	}
	else if (areacode == "548" || areacode == "249" || areacode == "289" || areacode == "343" || areacode == "365" || areacode == "416" || areacode == "437" || areacode == "519" || areacode == "226" || areacode == "613" || areacode == "647" || areacode == "705" || areacode == "807" || areacode == "905")
	{
		cout << "This is an Ontario area code.\n";
	}
	else if (areacode == "418" || areacode == "438" || areacode == "450" || areacode == "514" || areacode == "579" || areacode == "581" || areacode == "819" || areacode == "873")
	{
		cout << "This is a Quebec area code.\n";
	}
	else if (areacode == "306" || areacode == "639")
	{
		cout << "This is a Saskatchewan area code.\n";
	}
	else if (areacode == "867")
	{
		cout << "This is a Yukon, Northwest Territories, or Nunavut area code.\n";
	}
	else
	{
		cout << "This is not a Canadian area code.\n";
	}
}



