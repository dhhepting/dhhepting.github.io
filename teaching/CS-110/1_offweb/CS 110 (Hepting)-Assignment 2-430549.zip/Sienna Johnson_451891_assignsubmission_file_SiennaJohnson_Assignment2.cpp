//
//  Assignment2.cpp
//  Assignment 2
//
//  Created by Sienna Johnson on 2015-02-25.
//  Copyright (c) 2015 Sienna Johnson. All rights reserved.
//

#include <iostream>
#include <string>
using namespace std;
int main()
{
	string phonenumber;  //Declare the variables: phonenumber, string length, areacode
	string::size_type len;
	len = phonenumber.length();

	string areacode = phonenumber.substr(0, 3);

	//Loop if the user doesn't enter 12 digits
	while (len != 12)
	{
		cout << "Please enter a telephone number in the format ddd-ddd-dddd, where d is your phone number digit." << endl;
		cin >> phonenumber;
		len = phonenumber.length();
		cout << "The phonenumber has " << len << " numbers in it." << endl;

		// Test if the dashes are correctly placed in [3] and [7].
		if (len == 12 && phonenumber[3] != '-' && phonenumber[7] != '-')
		{
			cout << "Even though you entered the right amount of digits, you did not enter the dashes. This program will not proceed." << endl;
		}
		// End program if this is not fulfilled.
		// If dashes requirement is filled, continue to if-else statements to test areacode province/terrotory.
		else if (len == 12 && phonenumber[3] == '-' && phonenumber[7] == '-')
		{
			cout << "Thank you. The areacode is:" << phonenumber.substr(0, 3) << endl;
			areacode = phonenumber.substr(0, 3);
			if (areacode == "306" || areacode == "639")
			{
				cout << "The area code is a Saskatchewan area code." << endl;
			}
			else if (areacode == "403" || areacode == "587" || areacode == "780" || areacode == "825")
			{
				cout << "The area code is an Alberta area code." << endl;
			}
			else if (areacode == "403" || areacode == "587" || areacode == "780" || areacode == "825")
			{
				cout << "The area code is an Alberta area code." << endl;
			}
			else if (areacode == "236" || areacode == "250" || areacode == "604" || areacode == "672" || areacode == "778")
			{
				cout << "The area code is an British Columbia area code." << endl;
			}
			else if (areacode == "204" || areacode == "431")
			{
				cout << "The area code is a Manitoba area code." << endl;
			}
			else if (areacode == "506")
			{
				cout << "The area code is a New Brunswick area code." << endl;
			}
			else if (areacode == "709")
			{
				cout << "The area code is a Newfoundland & Laborador area code." << endl;
			}
			else if (areacode == "782" || areacode == "902")
			{
				cout << "The area code is a Nova Scotia area code." << endl;
			}
			else if (areacode == "548" || areacode == "249" || areacode == "289" || areacode == "343" || areacode == "365" || areacode == "387" || areacode == "416" || areacode == "437" || areacode == "519" || areacode == "226" || areacode == "226" || areacode == "613" || areacode == "647" || areacode == "705" || areacode == "742" || areacode == "807" || areacode == "905")
			{
				cout << "The area code is an Ontario area code." << endl;
			}
			else if (areacode == "782" || areacode == "902")
			{
				cout << "The area code is a Prince Edward Island area code." << endl;
			}
			else if (areacode == "418" || areacode == "438" || areacode == "450" || areacode == "514" || areacode == "579" || areacode == "581" || areacode == "819" || areacode == "873")
			{
				cout << "The area code is a Quebec area code." << endl;
			}
			else if (areacode == "867")
			{
				cout << "The area coe is either a Yukon, Northwest Territories, or Nunavut area code." << endl;
			}
			else
			{
				cout << "The number you have entered is not a Canadian area code." << endl;
			}
		}
	}
	return 0;
}

