#include <iostream>
#include <string>
#include <sstream>
using namespace std; 
void checklength(string&);
void checkformat(string&);
void checkareacode(string&);																	// function prototype
int main()
{
	string phonenumber;																			// declearing variables
	char input;
	do
	{
		cout << "enter a phone number with a format of (ddd-ddd-dddd)" << endl;					// askin user to enter a phone number as a string in a specific format
		getline(cin, phonenumber);																// user enter their phone number as a string 
		checklength(phonenumber);																// call the function to check the lenght if the lenght is correct then it will call other function
		cout << "enter q to quit the program  if  not press any keys" << endl;					// asking user to enter q or Q to quit the program
		cin >> input;																			// user enter a character anything beside q or Q it will continious the program using a do while loop
	} while (input != 'q' && input != 'Q');												
	return 0;
}
void checklength(string& phonenumber)															// this funtion is use to check the lenght of the phone number
{
	if (phonenumber.length() != 12)																// check the lenght of the phone numbers   
	{
		cout << "invalid phone numbers" << endl;												// if the length is less then 12 or greatr then 12 character it will output this code
	}
	else
	{
		checkformat(phonenumber);																// if the lenght is 12 character it will call the funtion to check the format of the string
	}
}
void checkformat(string& phonenumber)
{
	if (phonenumber.at(3) == '-' && phonenumber.at(7) == '-')
	{
		checkareacode(phonenumber);																// if the format is correct call another function to check the area code
	}
	else
	{
		cout << "bad format" << endl;															// if the format of the string is wrong output this massage to the user 
	}
}
void checkareacode(string& phonenumber)															// using swtching statment to checck all the areacode in canada and output where it belong 
{
	string areacode;
	areacode = phonenumber.substr(0, 3);														// using sub string to find the first 3 character of the string and convert them into a int and use swtching statment 
	int Areacode;
	istringstream convert(areacode);		
	convert >> Areacode;																		// convert the sub string to a int so i can use swtich statment to find the areacode
	switch (Areacode)
	{
	case 403:
	case 587:
	case 780:
	case 825:
		cout << "the area code is from Alberta." << endl;
		break;
	case 236:
	case 250:
	case 604:
	case 672:
	case 778:
		cout << "the area code is from British Columbia." << endl;
		break;
	case 204:
	case 431:
		cout << "the area code is from Manitoba." << endl;
		break;
	case 506:
		cout << "the area code is from New brunswick." << endl;
		break;
	case 709:
		cout << "the area code is from Newfoundland and Labrador." << endl;
		break;
	case 782:
	case 902:
		cout << "the area code is from Nova Scotia or Prince Edward Island." << endl;
		break;
	case 867:
		cout << "the area code is from Yukon, Northwest Territories and Nunavut." << endl;
		break;
	case 418:
		cout << "the area code is from Quebec" << endl;
		break;
	case 438:
	case 450:
	case 514:
	case 579:
	case 581:
	case 819:
	case 873:
		cout << "the area code is from Quebec" << endl;
		break;
	case 306:
	case 639:
		cout << "the area code is from Saskatchewan" << endl;
		break;
	case 548:
	case 249:
	case 289:
	case 343:
	case 365:
	case 387:
	case 416:
	case 437:
	case 519:
	case 226:
	case 613:
	case 647:
	case 705:
	case 742:
	case 807:
	case 905:
		cout << "the area code is from Ontario" << endl;
		break;
	default:
		cout << "the area code is invalid " << endl;
	}

}


