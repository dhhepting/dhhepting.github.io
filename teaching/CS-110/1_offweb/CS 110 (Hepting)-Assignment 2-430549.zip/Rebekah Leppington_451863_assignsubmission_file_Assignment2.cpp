// *********************************************************
//
// Student name: Rebekah Leppington
// Studnet number: 200 343 095
// Assignment number: 2
// Program name: Assignment2.cpp
// Date written: February 25, 2015
// Problem statement: This program will find the Province or Territory the phone number belongs to.
// Input: Canadian phone number.
// Output: Province or Territory the number belongs to.
// Algorithm: The computer will use if and else statements as well as loops to gather the required results.
// Major variables: q, areacode, d1, d2, d3, code, A1 to 4, BC1 to 5, M1, M2, NB, NFL, NS1, NS2, O1 to 16, PEI1, PEI2, Q1 to 8, SK1, SK2, YNTN.
// Assumptions: None
// Program limitations: None
//
//****************************************************************

#include <iostream>
#include <iomanip>
#include <stdlib.h>
#include <string>

using namespace std;

int main()
{

	char q;
	
	string areacode;
	string d1;
	string d2;
	string d3;
	string code;

	do
	{

		cout << "Please enter a phone number in the form ddd-ddd-dddd" << endl;
		cin >> areacode;

		if (areacode.length() == 12)
		{
			d1 = (areacode.at(0));
			d2 = (areacode.at(1));
			d3 = (areacode.at(2));
			code = d1 + d2 + d3;

			cout << "The area code of this phone number is: " << code << endl;

			string A1 = "403";
			string A2 = "587";
			string A3 = "780";
			string A4 = "825";
			string BC1 = "236";
			string BC2 = "250";
			string BC3 = "604";
			string BC4 = "672";
			string BC5 = "778";
			string M1 = "204";
			string M2 = "431";
			string NB = "506";
			string NFL = "709";
			string NS1 = "782";
			string NS2 = "902";
			string O1 = "548";
			string O2 = "249";
			string O3 = "289";
			string O4 = "343";
			string O5 = "365";
			string O6 = "387";
			string O7 = "416";
			string O8 = "437";
			string O9 = "519";
			string O10 = "226";
			string O11 = "613";
			string O12 = "647";
			string O13 = "705";
			string O14 = "742";
			string O15 = "807";
			string O16 = "905";
			string PEI1 = "782";
			string PEI2 = "902";
			string Q1 = "418";
			string Q2 = "438";
			string Q3 = "450";
			string Q4 = "514";
			string Q5 = "579";
			string Q6 = "581";
			string Q7 = "819";
			string Q8 = "873";
			string SK1 = "306";
			string SK2 = "639";
			string YNTN = "867";

			if ((((((((((((((((((((((((((((((((((((((((((((code == A1)
				|| (code == A2))
				|| (code == A3))
				|| (code == A4))
				|| (code == BC1))
				|| (code == BC2))
				|| (code == BC3))
				|| (code == BC4))
				|| (code == BC5))
				|| (code == M1))
				|| (code == M2))
				|| (code == NB))
				|| (code == NFL))
				|| (code == NS1))
				|| (code == NS2))
				|| (code == O1))
				|| (code == O2))
				|| (code == O3))
				|| (code == O4))
				|| (code == O5))
				|| (code == O6))
				|| (code == O7))
				|| (code == O8))
				|| (code == O9))
				|| (code == O10))
				|| (code == O11))
				|| (code == O12))
				|| (code == O13))
				|| (code == O14))
				|| (code == O15))
				|| (code == O16))
				|| (code == PEI1))
				|| (code == PEI2))
				|| (code == Q1))
				|| (code == Q2))
				|| (code == Q3))
				|| (code == Q4))
				|| (code == Q5))
				|| (code == Q6))
				|| (code == Q7))
				|| (code == Q8))
				|| (code == SK1))
				|| (code == SK2))
				|| (code == YNTN))
			{
				if ((((code == A1)
					|| (code == A2))
					|| (code == A3))
					|| (code == A4))
				{
					cout << "Alberta" << endl;
				}

				if (((((code == BC1)
					|| (code == BC2))
					|| (code == BC3))
					|| (code == BC4))
					|| (code == BC5))
				{
					cout << "British Columbia" << endl;
				}
				if ((code == M1) || (code == M2))
				{
					cout << "Manitoba" << endl;
				}
				if (code == NB)
				{
					cout << "New Brunswick" << endl;
				}
				if (code == NFL)
				{
					cout << "Newfoundland and Labrador" << endl;
				}
				if ((code == NS1) || (code == NS2))
				{
					cout << "Nova Scotia" << endl;
				}
				if ((((((((((((((((code == O1)
					|| (code == O2))
					|| (code == O3))
					|| (code == O4))
					|| (code == O5))
					|| (code == O6))
					|| (code == O7))
					|| (code == O8))
					|| (code == O9))
					|| (code == O10))
					|| (code == O11))
					|| (code == O12))
					|| (code == O13))
					|| (code == O14))
					|| (code == O15))
					|| (code == O16))
				{
					cout << "Ontario" << endl;
				}
				if ((code == PEI1) || (code == PEI2))
				{
					cout << "Prince Edward Island" << endl;
				}
				if ((((((((code == Q1)
					|| (code == Q2))
					|| (code == Q3))
					|| (code == Q4))
					|| (code == Q5))
					|| (code == Q6))
					|| (code == Q7))
					|| (code == Q8))
				{
					cout << "Quebec" << endl;
				}
				if ((code == SK1) || (code == SK2))
				{
					cout << "Saskatchewan" << endl;
				}
				if (code == YNTN)
				{
					cout << "Yukon, Northwest Territories, and Nunavut" << endl;
				}
			}
			else
			{
				cout << "This is not a Canadian phone number." << endl;
			}

		}
		else if (areacode.length() == 10)
		{
			cout << "Please include dashes in your phone number." << endl;
		}
		cout << "Enter q to quit or another key to continue. " << endl;
		cin >> q; 
	}
	while ((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((q == 'A')
		|| (q == 'a'))
		|| (q == 'B'))
		|| (q == 'b'))
		|| (q == 'C'))
		|| (q == 'c'))
		|| (q == 'D'))
		|| (q == 'd'))
		|| (q == 'E'))
		|| (q == 'e'))
		|| (q == 'F'))
		|| (q == 'f'))
		|| (q == 'G'))
		|| (q == 'g'))
		|| (q == 'H'))
		|| (q == 'h'))
		|| (q == 'I'))
		|| (q == 'i'))
		|| (q == 'J'))
		|| (q == 'j'))
		|| (q == 'K'))
		|| (q == 'k'))
		|| (q == 'L'))
		|| (q == 'l'))
		|| (q == 'M'))
		|| (q == 'm'))
		|| (q == 'N'))
		|| (q == 'n'))
		|| (q == 'O'))
		|| (q == 'o'))
		|| (q == 'P'))
		|| (q == 'p'))
		|| (q == 'R'))
		|| (q == 'r'))
		|| (q == 'S'))
		|| (q == 's'))
		|| (q == 'T'))
		|| (q == 't'))
		|| (q == 'U'))
		|| (q == 'u'))
		|| (q == 'V'))
		|| (q == 'v'))
		|| (q == 'W'))
		|| (q == 'w'))
		|| (q == 'X'))
		|| (q == 'x'))
		|| (q == 'Y'))
		|| (q == 'y'))
		|| (q == 'Z'))
		|| (q == 'z'))
		|| (q == '1'))
		|| (q == '2'))
		|| (q == '3'))
		|| (q == '4'))
		|| (q == '5'))
		|| (q == '6'))
		|| (q == '7'))
		|| (q == '8'))
		|| (q == '9'))
		|| (q == '0'));
		

	return 0;
}