
//
//Student Name: Caleigh Ritson
//Student ID: 200253359
//Program Create Date: Feb. 25, 2015
//Assignment #: 2
//Program Name: Canadian phone number
//Problem Statement: User enters a phone number in the format ddd-ddd-dddd, and the program will 
//					determine if the phone number is Canadian.  If it is Canadian, what province 
//					it comes from. If the user enters an invaild phone number, it will loop unitil 
//					the user enters the letter 'q'.
//input: a phone number
//output: The phone number written; whether or not it is Canadian; if Canadian, what province it is from
//Algorithm: The user is prompt to enter a phone number or lowercase letter 'q'. If 'q' is entered, the program will
//			finish. Othersiwse the program will read if it follows the format ddd-ddd-dddd. If the format is invail
//			the program will ask the user to enter in another phone number or the letter 'q'. Otherwise, the program 
//			will see if the phone number is Canadian, and if it is, the program will output what province or territory.
//			Program will continue to loop until user enters in the letter 'q'.
//Major variables: number, ac, dash, dast, mid, last
//Assumptions: The program will identify whether the number is vaild. If valid, The program will determine whether
//				the phone number entered is Canadian or not. If it is, it will output what province and finish.
//				If invalid, the program will loop back and ask the user to enter in another phone number until a 
//				valid one can be reached.
//Program limitations: The program will only end when the user enters 'q'.
//

#include <iostream>
#include <string>
using namespace std;
int main()
{
	string number;
	cout << "Please enter a phone number in the format ddd-ddd-dddd. Or the lowercase q to terminate program." << endl;
	getline(cin, number);

	cout << "The phone number you entered is: " << number << endl;

	while (number != "q")
	{
		string dash;
		dash = number.at(3);
		string dast;
		dast = number.at(7);
		string ac;
		ac = number.substr(0, 3);
		string mid, last;
		mid = number.substr(4, 7);
		last = number.substr(8, 11);

		if (number.length() == 12 && dash == "-" && dast == "-" && ac >= "000" && ac <= "999" && mid >= "000" && mid <= "999" && last >= "0000" && last <= "9999")
		{

			if (ac == "204" || ac == "226" || ac == "236" || ac == "249" || ac == "250" || ac == "289" || ac == "306" || ac == "343" || ac == "365" || ac == "387" || ac == "403" || ac == "416" || ac == "418" || ac == "431" || ac == "437" || ac == "438" || ac == "450" || ac == "506" || ac == "514" || ac == "519" || ac == "579" || ac == "581" || ac == "587" || ac == "604" || ac == "613" || ac == "639" || ac == "647" || ac == "672" || ac == "705" || ac == "709" || ac == "742" || ac == "778" || ac == "780" || ac == "782" || ac == "807" || ac == "819" || ac == "825" || ac == "867" || ac == "873" || ac == "902" || ac == "905")
			{
				cout << "This is a Canadian phone number!" << endl;
			}
			else
			{
				cout << "This is not a Canadian phone number!" << endl;
			}


			if (ac == "403" || ac == "587" || ac == "780" || ac == "825")
			{
				cout << "This number is from Alberta." << endl;
			}
			else
			{
				//This is not an Alberta phone number
			}
			if (ac == "236" || ac == "250" || ac == "604" || ac == "672" || ac == "778")
			{
				cout << "This number is from British Columbia." << endl;
			}
			else
			{
				//This is not a British Columbia phone number
			}
			if (ac == "226" || ac == "249" || ac == "289" || ac == "343" || ac == "365" || ac == "387" || ac == "416" || ac == "437" || ac == "519" || ac == "613" || ac == "647" || ac == "705" || ac == "742" || ac == "807" || ac == "905")
			{
				cout << "This number is from Ontario." << endl;
			}
			else
			{
				//This is not an Ontario phone number
			}
			if (ac == "418" || ac == "438" || ac == "450" || ac == "514" || ac == "579" || ac == "581" || ac == "819" || ac == "875")
			{
				cout << "This number is from Quebec." << endl;
			}
			else
			{
				//This is not a Quebec phone number
			}
			if (ac == "782" || ac == "902")
			{
				cout << "This number is either from Nova Scotia or Prince Edward Island" << endl;
			}
			else
			{
				//This is not a Nova Scotia or PEI phone number
			}
			if (ac == "306" || ac == "639")
			{
				cout << "This number is from Saskatchewan." << endl;
			}
			else
			{
				//This is not a Saskatchewan phone number
			}
			if (ac == "204" || ac == "431")
			{
				cout << "This number is from Manitoba." << endl;
			}
			else
			{
				//This is not a Manitoba phone number
			}
			if (ac == "506")
			{
				cout << "This number is from New Brunswick." << endl;
			}
			else
			{
				//This is not a New Brunswick phone number
			}
			if (ac == "709")
			{
				cout << "This number is from Newfounland and Labradour." << endl;
			}
			else
			{
				//This is not a Newfoundland and Labradout phone number
			}
			if (ac == "867")
			{
				cout << "This number is from either the Yukon, Northwest Territores or Nunavut." << endl;
			}
			else
			{
				//This is not a Territories phone number
			}
		}
		else
		{
			cout << "The phone number you enter is invaild. Makes sure to include dashes. Letters are not numbers. Make sure to put in the format ddd-ddd-dddd." << endl;
		}
		
		cout << "Please enter a phone number in the format ddd-ddd-dddd. Or the lowercase q to terminate program." << endl;
		getline(cin, number);

		cout << "The phone number you entered is: " << number << endl;
	}

	cout << "Thank You!" << endl;
	return 0;
}
														
									