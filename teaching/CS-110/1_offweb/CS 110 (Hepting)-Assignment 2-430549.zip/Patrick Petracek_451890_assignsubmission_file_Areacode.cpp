// Patrick Petracek
// student#: 200266402
// Section: CS 110
//
//Algorithm: Step 1: Acquire the number from the user and turn it into a string. 
//           Step 2: Make sure format is in proper phone number structure. 
//           Step 3: Compare the first 3 digits to area codes of canada and display which area.
//Limitations: The program will not show anything is wrong if the user types in letter instead of numbers in this format "xxx-xxx-xxxx" but it will say the area code is not a Canadian one.


#include <iostream>
#include <string>
#include <fstream>
using namespace std;

int main()
{
	string Code;

	cout << "Enter a Complete phone number with the format: xxx-xxx-xxxx. " << endl;
	cin >> Code;

	if ((Code[3] == '-') && (Code[7] == '-') && (Code.length()== 12))
	{
		string area = Code.substr(0, 3);
		if (area == "403" || area == "587" || area == "780" || area == "825")
		{
			cout << " The area code belongs to Alberta. ";
		}
		else if (area == "236" || area == "250" || area == "604" || area == "672" || area == "778")
		{
			cout << " The area code belongs to British Columbia. ";
		}
		else if (area == "204" || area == "431")
		{
			cout << " The area code belongs to Manitoba. ";
		}
		else if (area == "506")
		{
			cout << " The area code belongs to New Brunswick. ";
		}
		else if (area == "709")
		{
			cout << " The area code belongs to Nefoundland and Labrador. ";
		}
		else if (area == "782" || area == "902")
		{
			cout << " The area code belongs to Nova Scotia. ";
		}
		else if (area == "548" || area == "249" || area == "289" || area == "343" || area == "365" || area == "387" || area == "416" || area == "437" || area == "519" || area == "226" || area == "613" || area == "647" || area == "705" || area == "742" || area == "807" || area == "905")
		{
			cout << " The area code belongs to Ontario which has WAY too many area codes.";
		}
		else if (area == "782" || area == "902")
		{
			cout << " The area code belongs to Prince Edward Island. ";
		}
		else if (area == "418" || area == "438" || area == "450" || area == "514" || area == "579" || area == "581" || area == "819" || area == "873")
		{
			cout << " The area code belongs to Quebec. ";
		}
		else if (area == "306" || area == "639")
		{
			cout << " The area code belongs to Saskatchewan. ";
		}
		else if (area == "867")
		{
			cout << " The area code belongs to Yukon, Northwest Territories and Nunavut. ";
		}	
		
		else
		{
			cout << "The area code is not a Canadian one. ";
		}
	}
	else
	{
		cout << "You have entered an invalid number. " << endl;
	}



return 0;
}
