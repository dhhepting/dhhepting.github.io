
//Gerard Domingo
//Student Id 200356051
//Assignment 2
//Telephone Inqiury
//February 25, 2015

//Problem Statement
//Prompt the use to input a telephone number in the format ddd-ddd-dddd, and check if the area 
//is a Canadian province or terrritory. Once the user inputs a telephone number the program 
//if the area code is either a Canadian area code or not. Keep asking the user to input a 
//telephone number unless the user enters the letter q then the program will show a message 
//and stops the program.

//Input values
//Telephone numbers

//Ouput values
//Area code of the entered program
//Invalid value if the area code does not exist

//Major variables 
//string phone = represents the number in ddd-ddd-dddd format this value is entered by the 
//user. 
//string areacode = the values for this string comes from the area code numbes from the 
//in the string phone variable.

//Algorithm 
//Using if statements to determine what area code value was entered depending on the value 
//the program will decide the are code that value represents.

//Limitations
//The program will only determine area codes in North America Spefically area codes in Canada
//if area codes in America needs to be determine extra codes will be needed to the program.
//The other thing is that each country has a different format of telephone numbers. 
//because of that a different program must be made for each country and area code.

#include <iostream>
#include <string> // This function will allow the program to recognize string values
using namespace std; 

int main()
{
string phone; // This string value will be the telephone number the user will enter

cout << "Please enter a telephone in the format ddd-ddd-dddd. Please include the dash lines" 
<< " in the input. If you want to exit the program please enter 'q'. Thank you" << endl;
cin >> phone;

string areacode = phone.substr(0,3); 
//In this section, the progam will look at the first three numbers the use enters.
//the three numbers will determine what area code it belongs to. if the user wants
//to exit the program the use will enter the letter u



//Once the area code is dtermined the fi statements will check which numbers match the right
//if statement

if (areacode == "306" || areacode == "639")
cout << "The area code is Saskatchewan" << endl;

else if (areacode == "403" || areacode == "587" || areacode == "780" || areacode == "825")
cout << "The area code is Alberta" << endl;

else if (areacode == "236" || areacode == "250" || areacode == "604" || areacode == "672" || 
areacode == "678")
cout << "The areacode is British Columbia" << endl;

else if (areacode == "204" || areacode == "431")
cout << "The area code is Manitoba" << endl;

else if (areacode == "506") 
cout << "The area code is New Brunswick" << endl;

else if (areacode == "709")
cout << "The area code is Newfoundland and Labrador" << endl;

else if (areacode == "782" || areacode == "902")
cout << "The area code is Nova Scotia" << endl;

else if (areacode == "782" || areacode == "902")
cout << "The area code is Prince Edward Islands" << endl;

else if (areacode == "548" || areacode == "249" || areacode == "289" || 
areacode == "343" || areacode == "365" || areacode =="387" || areacode == 
"416" || areacode == "437" || areacode == "519" || areacode == "226" || 
areacode == "613" || areacode == "647" || areacode == "705" || areacode == 
"742" || areacode == "807" || areacode == "905")
cout << "The area code is Ontario" << endl;

else if (areacode == "418" || areacode == "438" || areacode == "450" || 
areacode == "514" || areacode == "579" || areacode == "581" || areacode == 
"819" || areacode == "873")
cout << "The area code is Quebec" << endl; 

else if (areacode == "867")
cout << "The area code is Yukon, Nunavut, and Northwest Territories" << endl;

else if (phone == "q")
cout << "Thank You for Participating" << endl;

else 
cout << "Try again" << endl;
//If the user entered a number not present in the statements the program will ask the use to 
//try again and enter another number.


return 0;
}
