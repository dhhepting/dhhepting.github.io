// Nandha Kishore Bijmon
// 200355253
// Feb 24th, 2015
// Assignment
#include <iostream>
using namespace std;

int main()
{
	int areacode;
	int number1;
	int number2;

	cout << "Enter a telephone number in the format ddd-ddd-dddd. " << endl;
	cin >> areacode >> number1 >> number2;

	if (areacode == 403 || areacode == 587 || areacode == 780 || areacode == 825)
		cout << " The telephone number " << areacode << "-" << number1 << "-" << number2 << " is from Alberta" << endl;

	else if (areacode == 236 || areacode == 250 || areacode == 604 || areacode == 672 || areacode == 778)
		cout << "The telephone number " << areacode << "-" << number1 << "-" << number2 << " is from British Columbia" << endl;

	else if (areacode == 204 || areacode == 431)
		cout << "The telephone number " << areacode << "-" << number1 << "-" << number2 << " is from Manitoba" << endl;

	else if (areacode == 506)
		cout << "The telephone number " << areacode << "-" << number1 << "-" << number2 << " is from Newfoundland and Labrador" << endl;

	else if (areacode == 548 || areacode == 249 || areacode == 289 || areacode == 343 || areacode == 365 || areacode == 387 || areacode == 416 || areacode == 437 || areacode == 519 || areacode == 226 || areacode == 613 || areacode == 705 || areacode == 742 || areacode == 807 || areacode == 905)
		cout << "The telephone number " << areacode << "-" << number1 << "-" << number2 << " is from Ontario" << endl;

	else if (areacode == 782 || areacode == 902)
		cout << "The telephone number " << areacode << "-" << number1 << "-" << number2 << " is from Nova Scotia or PEI" << endl;

	else if (areacode == 418 || areacode == 438 || areacode == 450 || areacode == 514 || areacode == 579 || areacode == 581 || areacode == 819 || areacode == 873)
		cout << "The telephone number " << areacode << "-" << number1 << "-" << number2 << " is from Quebec" << endl;

	else if (areacode == 306 || areacode == 639)
		cout << "The telephone number " << areacode << "-" << number1 << "-" << number2 << " is from Saskactchewan" << endl;

	else if (areacode == 867)
		cout << "The telephone number " << areacode << "-" << number1 << "-" << number2 << " is from Northwest Territories,Yukon, or Nunavut" << endl;
	else
		cout << "Invalid telephone. Please try again." << endl;


	return 0;
}