/*
Student name: Nicole Bohlken
Student number: 200273089
Assignment number: 2
Program name: Programming phone nmbers 
Date: written for Feb. 25, 2015
Problem Statement: Write a program that prompts the user to enter a telephone number in the format (ddd-ddd-dddd), where d is a digit, and then varify that it's a Canadian area code.  
Input: Preferably a tweleve digit telephone number with dashs between. 
Output: The region that corrseponds with the telephone number that was inputed. 
Algorithm: The user will enter tweleve digits (after being promted to do so) and the prespective quanities will be proccessed and tested to determine if they are a vaild telephone number and whether it's a Canadian area code. 
Major variables: phNum, areacode
Assumptions: The program will compile and run correctly, no syntax or logic or runtime errors are present in the code
Program Limitations: A whole number must be inputted to obtain a result.
*/

#include <iostream>
// This is the library that is used to support input and output.
#include <string>
//This library allows string to be used in the code.
using namespace std;
//Standard namespace is used in this program.

int main()
//The main funciton intitates the program by creating an integer and an argument(which is the code below).
{
	while (true)
	{
		cout << endl;
		cout << "Hello, please enter a phone number that is in the form ddd-ddd-dddd." << endl;
        // This message is relayed to the user and prompts the user to enter a phone number in a specific format.
		cout << "where d is a digit, for example 123-456-7891" << endl;
		cout << "Or you can press Q or q to exit" << endl;
		// This lets the user know that they can exit the program by entering "Q" or "q."
		string phNum;
		// The string "pNum" is declared for the phone number that will be inputteed by the user.
		cin >> phNum;
		// The computer can now recognize the phone number that the user inputted, and the input is assigned to the string "pNum".

		if (phNum.length() == 12 &&
			// The correct length of the phone number is 12 characters (this includes the dashes). This tests the lenght of the input to see if the input length is correct.
			phNum[0] >= '0' && phNum[0] <= '9' && phNum[1] >= '0' && phNum[1] <= '9' && phNum[2] >= '0' && phNum[2] <= '9' &&
			// The area code is being tested here. The first three characters must have values between the values for "0" and "9" (inclusive) for the area code to be correct.
			phNum[3] == '-' &&
			// The fourth character from the left in the phone number must be a dash if the format is correct.
			phNum[4] >= '0' && phNum[4] <= '9' && phNum[5] >= '0' && phNum[5] <= '9' && phNum[6] >= '0' && phNum[6] <= '9' &&
			// The set of three characters in the phone number is tested here. Each character must have a value between the values for "0" and "9" (inclusive).
			phNum[7] == '-' &&
			// The eighth character from the left in the phone number must be a dash.
			phNum[8] >= '0' && phNum[8] <= '9' && phNum[9] >= '0' && phNum[9] <= '9' && phNum[10] >= '0' && phNum[10] <= '9' && phNum[11] >= '0' && phNum[11] <= '9')
			// The last set of characters in the phone number are being tested here. Each character must have a value between the values for "0" and "9" (inclusive).
		{
			string areacode(phNum, 0, 3);
			// A substring, composed of the first three characters of the phone number, is created.
			// If the phone number is correct, then the outputted statement will be determined by which if statement it matches.
			// Each if statement has a set of area codes that correspond to a province or territory in Canada. If the statement is true, then the following cout statement will be displayed.
			// If the statement is not true, then the next if statement will be tested. If none of the if statemtents are true, then the area code that was typed in by the user is not used in Canada.
			// This is covered by the else statement.
			
			if (areacode == "403" || areacode == "587" || areacode == "780" || areacode == "825")
				cout << "This area code is used within Alberta." << endl;
			else if (areacode == "236" || areacode == "250" || areacode == "604" || areacode == "672" || areacode == "778")
				cout << "This area code is used within British Columbia." << endl;
			else if (areacode == "204" || areacode == "431")
				cout << "This area code is used within Manitoba." << endl;
			else if (areacode == "506")
				cout << "This area code is used within New Brunswick." << endl;
			else if (areacode == "709")
				cout << "This area code is used within Newfoundland and Labrador." << endl;
			else if (areacode == "782" || areacode == "902")
				cout << "This area code is used within Nova Scotia and Prince Edward Island." << endl;
			else if (areacode == "548" || areacode == "249" || areacode == "289" || areacode == "343" || areacode == "365" || areacode == "387" || areacode == "416" || areacode == "437" || areacode == "519" || areacode == "226" || areacode == "613" || areacode == "647" || areacode == "705" || areacode == "742" || areacode == "807" || areacode == "905")
				cout << "This area code is used within Ontario." << endl;
			else if (areacode == "418" || areacode == "438" || areacode == "450" || areacode == "514" || areacode == "579" || areacode == "581" || areacode == "819" || areacode == "873")
				cout << "This area code is used within Quebec." << endl;
			else if (areacode == "306" || areacode == "639")
				cout << "This area code is used within Saskatchewan." << endl;
			else if (areacode == "867")
				cout << "This area code is used withinthe Yukon, Northwest Territories, and Nunavut." << endl;
			else
				cout << "This area code is not Canadian." << endl;
		}
		else
		// This is tested if the phone number length is not the correct length.
		{
			if (phNum == "Q" || phNum == "q")
			// If the user wants to quit the loop, then entering "Q" or "q" will quit the code.
			// If "Q" or "q" wasn't entered, then the format for the phone number wasn't correct.
				return 0;
			// The main function returns the value zero and finishes the code.
			cout << "This is not the correct form.Please try again." << endl;
			// This message is relayed to the user if the phone number fails the parameters in the if statements above.
		}
	}
	return 0;
	// The main function returns the value zero and finishes the code.
}