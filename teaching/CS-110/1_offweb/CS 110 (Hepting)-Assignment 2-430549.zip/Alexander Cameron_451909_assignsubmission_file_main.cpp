/*********************************************************************************************************
 
 Student Name: Alexander Cameron
 
 Student Number: 200 246 288
 
 Assignment Number: 2
 
 Program Name: Telephone Area Code Finder
 
 Date Written: 23 February, 2015
 
 Problem Statement: This program is created to identify a phone number by its Canadian area code.
 
 Input: 10 digit hyphenated phone number.
 
 Output: Location attached to the phone number's Area Code.
 
 Algorithm: The user will be prompted to input a phone number, once this is don the program will check to ensure the correct fromat has been used, and if so it will then check to see if the first three digits (the area code) match that of one of the ten Canadian provinces or three territories. If it matches the name of the corresponding province or territory will be out put, if not it will indicate that it is not a canadian area code. Whichever the case the program will continue to ask for input until the user inputs 'q'
 
 Major Variables: bool and string
 
 Assumptions: This program assumes that the user is inputting a regular
 
 Program Limitations: This program is limited to Canadian phone numbers, only in the format "ddd-ddd-dddd".
 

 ********************************************************************************************************/

#include <iostream>
#include <string>
using namespace std;

int main ()

{
    cout<< "Please input a phone number using the format 'ddd-ddd-dddd' or enter 'q' to quit."<<endl;
    string phone; // string variable used so that i can use the substr function to match the area code
    cin>> phone;   //allows user to input the number
    bool notdone=true; //sets the bool expression to true so it will run unless told otherwise
    
    
    
    while (notdone)
    {
        bool digitGood=false;        //setting bool initially as false so that unless it is later satisfied, the program will know the
                                     //format is incorrect

        bool hyphenGood=false;
        
        bool lengthGood= (phone.length()==12);
        
       if (lengthGood)
       {
           digitGood= (phone.at(0)>='0'&& phone.at(0)<='9'          //ensring each digit falls between 0 and 9
                         && phone.at(1)>='0' && phone.at(1)<='9'
                         && phone.at(2)>='0' && phone.at(2)<='9'
                         && phone.at(4)>='0' && phone.at(4)<='9'
                         && phone.at(5)>='0' && phone.at(5)<='9'
                         && phone.at(6)>='0' && phone.at(6)<='9'
                         && phone.at(8)>='0' && phone.at(8)<='9'
                         && phone.at(9)>='0' && phone.at(9)<='9'
                         && phone.at(10)>='0' && phone.at(10)<='9'
                         && phone.at(11)>='0' && phone.at(11)<='9');
        
           hyphenGood= (phone.at(7)=='-' && phone.at(3)=='-');     //ensuring that the hyphens are added in the correct spots
       }
       
        
        if (lengthGood && digitGood && hyphenGood)
        {
            string areaCode = phone.substr(0,3);
            
            if(areaCode == "403" || areaCode == "587" || areaCode == "780")
                cout<<"This is an Alberta Area Code"<<endl<<endl;
            
            
            else if(areaCode == "236"|| areaCode == "250" ||areaCode == "604"||areaCode == "778")
                cout<<"This is a British Columbia Area Code"<<endl<<endl;
            
            
            else if(areaCode == "204" || areaCode == "431")
                cout<<"This is a Manitoba Area Code"<<endl<<endl;
            
            
            else if(areaCode == "506")
                cout<<"This is a New Brunswick Area Code"<<endl<<endl;
            
            
            else if(areaCode == "709")
                cout<<"This is a Newfoundland and Labrador Area Code"<<endl<<endl;
            
           
            else if(areaCode == "782" ||areaCode=="902")
                cout<<"This is a Prince Edward Island and Nova Scotia Area Code"<<endl<<endl;
            
            
            
            else if(areaCode == "548"||areaCode == "249" || areaCode == "289"|| areaCode == "343"
                    || areaCode == "365"|| areaCode == "416"|| areaCode == "437"|| areaCode == "519"
                    || areaCode == "226"|| areaCode == "613"|| areaCode == "647"|| areaCode == "705"
                    || areaCode == "807"|| areaCode == "905")
                cout<<"This is an Ontario Area Code"<<endl<<endl;
          
        
            
            else if(areaCode == "418"|| areaCode == "438"|| areaCode == "450"|| areaCode == "514"
                    || areaCode == "579"|| areaCode == "581"|| areaCode == "819"|| areaCode == "873")
                cout<<"This is a Quebec Area Code"<<endl<<endl;
            
            
            else if(areaCode == "306"|| areaCode == "639")
                cout<<"This is a Saskatchewan Area Code"<<endl<<endl;
           
            
            else if(areaCode == "867")
                cout<<"This is the Area Code for The Yukon, Northwest Territories, and Nunavut"<<endl<<endl;
            
            
            
            else
                cout<<"Not a canadian area code"<<endl<<endl;
            
            
        }
        
        else if (phone == "q"||phone=="Q")  //ensuring that if the user inputs q or Q it will quit
        {
            notdone= false;                 //if q is entered, notdone becomes false and the loop is broken
            cout << "Thank you for using Telephone Area Code Finder. Good bye."; //program end message
        }

        else
        {
            cout << "** Invalid format ** ";   //if user has not input q, and has not input a valid number, they will be told it is invalid.
        }
       
        
        if (notdone==true)                     //if q has not been entered, it will restart the program regardless of prior input (ie if the
        {                                      //the prior input was invalid, it will still run)
            cout<< "Please input a phone number using the format 'ddd-ddd-dddd' or enter 'q' to quit." //prompt user to input info, it will loop
            <<endl;                                                                                    //back to the beginning and start over
            cin>> phone;
        }
    }
    return 0;
}
