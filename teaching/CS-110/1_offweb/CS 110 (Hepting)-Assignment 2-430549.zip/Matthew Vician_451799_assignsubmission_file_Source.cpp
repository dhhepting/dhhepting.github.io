//*******************************************************
//Student Name: Matthew Vician
//
//Student Number: 200344933
//
//Assignment Number: 2
//
//Program Name: Area Code Determinor 
//
//Date Written: February 25, 2015
//
//Problem Statement: The user must enter in an area code in Canada, when the correct area code is entered into the 
//					 compiler, compiler will then tell the user which province or terrorie the area is from and whether or not its correct.
//Input: Entering numbers from 0-9 for area code and then following the compilers instructions of formating the numbers in the form of ddd-ddd-dddd
//
//Output: area code and random numbers the user has entered for a telephone number
//		  587-234-5678	
//        306-985-3343
//        548-999-7777
//Algorithm: Prompt the user to enter in a valid area code in Canada and follow the format of ddd-ddd-dddd
//			 The compiler will then tell the user if the area code entered is correct and will display the number if correct 
//			 If the area code is not correct then the compiler will then tell the user that he/she entered an invalid area code.
// 
// Major Variables: main() and iostream library.
//
//Assumptions: We are assuming that the user follows the instructions indicated on screen.
//Program limitations: This program can display if the user has entered in the proper area code and will also display the number he/she entered.
//*******************************************************
#include <iostream>
using namespace std;

int main()
{
	int areacode;
	int number1;
	int number2;
	//Telling user to enter the numbers in that particular form
	cout << "Enter a telephone number in the format of ddd-ddd-dddd. " << endl;
	cin >> areacode >> number1 >> number2;
	// The area code for Alberta
	if (areacode == 403 || areacode == 587 || areacode == 780 || areacode == 825)
		cout << " The telephone number " << areacode << "-" << number1 << "-" << number2 << " is from Alberta" << endl;
	//The area code for British Columbia
	else if (areacode == 236 || areacode == 250 || areacode == 684 || areacode == 672|| areacode == 778)
		cout << " The telephone number " << areacode << "-" << number1 << "-" << number2 << " is from British Columbia " << endl;
	//The area code for Manitoba
	else if (areacode == 204 || areacode == 431 )
		cout << " The telephone number " << areacode << "-" << number1 << "-" << number2 << " is from Manitoba " << endl;
	//The area code for New Brunswick
	else if (areacode == 506 )
		cout << " The telephone number " << areacode << "-" << number1 << "-" << number2 << " is from New Brunswick " << endl;
	//The area code for Ontario
	else if (areacode == 548 || areacode == 249 || areacode == 289 || areacode == 343 || areacode == 365 || areacode == 387 || areacode == 416
		|| areacode == 437 || areacode == 519 || areacode == 226 || areacode == 613 || areacode == 647 || areacode == 705 || areacode == 742 
		|| areacode == 807 || areacode == 905)
		cout << " The telephone number " << areacode << "-" << number1 << "-" << number2 << " is from Ontario " << endl;
	//The area code for Newfoundland and Labrador
	else if (areacode == 709)
		cout << " The telephone number " << areacode << "-" << number1 << "-" << number2 << " is from Newfoundland and Labrador " << endl;
	//The area code for Nova Scotia
	else if (areacode == 782||areacode ==902 )
		cout << " The telephone number " << areacode << "-" << number1 << "-" << number2 << " is from Nova Scotia  " << endl;
	//The area code for Quebec
	else if (areacode == 418 || areacode == 438 || areacode == 450 || areacode == 514 || areacode == 579 || areacode == 581 || areacode == 819
		|| areacode == 873)
		cout << " The telephone number " << areacode << "-" << number1 << "-" << number2 << " is from Quebec" << endl;
	//The area code for Saskatchewan 
	else if (areacode == 306 || areacode == 639)
		cout << " The telephone number " << areacode << "-" << number1 << "-" << number2 << " Saskatchewan " << endl;
	//The area code for Northwest Terrories
	else if (areacode == 867)
		cout << " The telephone number " << areacode << "-" << number1 << "-" << number2 << " Northwest Terroties  " << endl;
	//Telling the User that he/she entered the wrong area code and is invalid
	else
		cout << "Invalid Area code. Please Try Again " << endl;

	return 0;
}