/*

Name: Quinn Bast

SID: 200352973

Program: Will determine the area code of a telephone number that the user is asked to input

*/

#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

int main()
{
string input1;
char cont = 'v';
do
{
int i=0;
cout << "Please insert a telephone number." << endl << endl;
ws(cin);
getline(cin, input1);

string input[12] = {};
// display the input
cout << endl << "You entered: ";
for (i=0; i<12; i++)
	{
	input[i] = input1.substr(i, 1);
	cout << input[i];
	}
//check the format
bool fail=false;
if (input[3] == "-" && input[7] == "-")
{
	if (input[0] <= "9" && input[0] >= "0" &&
		input[1] <= "9" && input[1] >= "0" &&
		input[2] <= "9" && input[2] >= "0" &&
		input[4] <= "9" && input[4] >= "0" &&
		input[5] <= "9" && input[5] >= "0" &&
		input[6] <= "9" && input[6] >= "0" &&
		input[8] <= "9" && input[8] >= "0" &&
		input[9] <= "9" && input[9] >= "0" &&
		input[10] <= "9" && input[10] >= "0" &&
		input[11] <= "9" && input[11] >= "0"
		)
	{
		cout << endl << "You have entered a correct format." << endl;
	}
}
else
	{
	cout << endl << "You have entered an incorrect format." << endl;
	fail = true;
	}
// Put something here to cause a loop prompting a number //
if (fail == false)
{
//check area code//
string acode;
acode += input[0];
acode += input[1];
acode += input[2];

cout << endl << "The area code is: " << acode << endl;

// Check area code //

string code[11][16] = { };

// code[n][m] = Area code

code[0][0] = "403" ;
code[0][1] = "587" ;
code[0][2] = "780" ;
code[0][3] = "825" ;
code[1][0] = "236" ; 
code[1][1] = "250" ;
code[1][2] = "604" ;
code[1][3] = "672" ;
code[1][4] = "778" ;
code[2][0] = "204" ;
code[2][1] = "431" ;
code[3][0] = "506" ;
code[4][0] = "709" ;
code[5][0] = "782" ;
code[5][1] = "902" ;
code[6][0] = "548" ;
code[6][1] = "249" ;
code[6][2] = "289" ;
code[6][3] = "343" ;
code[6][4] = "365" ;
code[6][5] = "387" ;
code[6][6] = "416" ;
code[6][7] = "437" ;
code[6][8] = "519" ;
code[6][9] = "226" ;
code[6][10] = "613" ;
code[6][11] = "647" ;
code[6][12] = "750" ;
code[6][13] = "742" ;
code[6][14] = "807" ;
code[6][15] = "905" ;
code[7][0] = "782" ;
code[7][1] = "902" ;
code[8][0] = "418" ;
code[8][1] = "438" ;
code[8][2] = "450" ;
code[8][3] = "514" ;
code[8][4] = "579" ;
code[8][5] = "581" ;
code[8][6] = "819" ;
code[8][7] = "873" ;
code[9][0] = "306" ;
code[9][1] = "639" ;
code[10][0] = "867" ;

int n=0;
int m=0;
string province = "N.A.";
/////////////////////////
/////////////////////////
/////////////////////////
/////////////////////////

for (n=0; n<10; n++)
	{
	for (m=0; m<16; m++)
		{
		if (acode == code[n][m])
			{
			if (n==0)			
				province = "Alberta";
			if (n==1)
				province = "British Columbia";
			if (n==2)
				province = "Manitoba";
			if (n==3)
				province = "NewBrunswick";
			if (n==4)
				province = "Newfoundland and Labrador";
			if (n==5)
				province = "Nova Scotia";
			if (n==6)
				province = "Ontario";
			if (n==7)
				province = "Prince Edward Island";
			if (n==8)
				province = "Quebec";
			if (n==9)
				province = "Saskatchewan";
			if (n==10)
				province = "Yukon, Nothwest Territories or Nunavut";
			
			n=20;
			m=20;
			}
		
		}
		
	}

if (province != "N.A.")
	{
	cout <<	"Your area code is from: " << province << endl;
	}
else
	cout << "You do not have a Canadian area code.";
}
cout << endl << endl << "Press q to quit. Or enter another letter to try again.";
cin >> cont ;

}
while (cont!='q');

return 0;
}
