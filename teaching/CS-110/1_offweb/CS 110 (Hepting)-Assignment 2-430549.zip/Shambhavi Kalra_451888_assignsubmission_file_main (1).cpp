/*************************************
//
// Student name: Shambhavi Kalra
//
// Student number:200336705
//
// Assignment number:2
//
// Program name: Telephone Area Code Identifier (For Canada)
//
// Date written: 2.25.2015
//
// Problem statement: To identify what provinces and territories a telephone number belongs to.
//
// Input: Phone number
//
// Output: The province or territory it belongs to. 
         - or if the number is invalid
        - or if it is not a canadian number
//
// Algorithm:
Initialize a string, because the telephone number will have '-'
Then, prompt user to enter a string.
user enters the phone number string.
Then we will have to check the first 3 digits of the string. 
    we will intialize a string to be called areacode. to match with the first three digits of the phone number string
Once match is found, print the province or territory the first 3 digits belong to.
If not a canadian area code ->> print this is not a canadian area code
If invalid phone number, -->> print, their format is wrong and let them start over (use loop)
Continue this process for as many numbers they like.

To quit:
Tell the user to quit they can enter the letter q.
If they enter the letter q, then the program will print Thank you, bye. and then the program will terminate.



//
// Major variables: the telephone number string, the area code
//
// Assumptions: the user will not enter a different amount of numbers then the format asked. 
//
// Program limitations: can only calculate the area codes using the format. Is limited to Canadian numbers.
//








***************************************/




#include <iostream>
#include <string> // to be able to use strings.

using namespace std;

int main()

{
    string number; //the variable for the phone number

    cout << "Welcome! Please enter a phone number in the format ddd-ddd-dddd" << endl; //prompt user to enter a canadian phone number.
    cout << "To quit this program please enter the letter  Q." << endl;

    cin >> number; //user enters number
    string areacode = "";
    while ((number != "q") || (number != "Q"))
    {
        if (number[0] >= '0' && number[0] <= '9' && 
		    number[1] >= '0' && number[1] <= '9' && 
		    number[2] >= '0' && number[2] <= '9' &&	
	 	    number[3] == '-' && 
		    number[4] >= '0' && number[4] <= '9' && 
		    number[5] >= '0' && number[5] <= '9' && 
		    number[6] >= '0' && number[6] <= '9' &&	
		    number[7] == '-' && 
		    number[8] >= '0' && number[8] <= '9' && 
		    number[9] >= '0' && number[9] <= '9' && 
		    number[10] >= '0' && number[10] <= '9' && 
		    number[11] >= '0' && number[11] <= '9' )
        
                                                

                                                {
                                                    {
                                                        areacode = number.substr(0, 3);
                                                        if (areacode == "403" || areacode == "587" || areacode == "780" || areacode == "825") //If the first 3 digits of the string, or the area code of the phone number are as follows
                                                            cout << "Your phone number is of from Alberta" << endl; //Then your number is from Alberta

                                                        else if (areacode == "236" || areacode == "250" || areacode == "604" || areacode == "672" || areacode == "778") //if the first 3 digits of the string, or the area code of the phone number are as follows
                                                            cout << "Your number is from British Columbia." << endl; // then your number is from BC

                                                        else if (areacode == "204" || areacode == "431")//if the first 3 digits of the string, or the area code of the phone number are as follows
                                                            cout << "Your number is from Manitoba." << endl; // then your number is from Manitoba

                                                        else if (areacode == "506")//if the first 3 digits of the string, or the area code of the phone number are as follows
                                                            cout << "Your number is from New Brunswick." << endl; // then your number is from New Brunswick

                                                        else if (areacode == "709")//if the first 3 digits of the string, or the area code of the phone number are as follows
                                                            cout << "Your number is from Newfoundland and Labrador." << endl; // then your number is from Newfoundland and Labrador

                                                        else if (areacode == "782" || areacode == "902")//if the first 3 digits of the string, or the area code of the phone number are as follows
                                                            cout << "Your number is from Novia Scotia or Prince Edward Island." << endl; // then your number is from Novia Scotia

                                                        else if (areacode == "548" || areacode == "249" || areacode == "289" || areacode == "343" || areacode == "365" || areacode == "387" || areacode == "416" || areacode == "437" || areacode == "519" || areacode == "226" || areacode == "613" || areacode == "647" || areacode == "705" || areacode == "742" || areacode == "807" || areacode == "905") //if the first 3 digits of the string, or the area code of the phone number are as follows
                                                            cout << "Your number is from Onatario." << endl; // then your number is from Ontario

                                                        else if (areacode == "418" || areacode == "438" || areacode == "450" || areacode == "514" || areacode == "579" || areacode == "581" || areacode == "819" || areacode == "873") //if the first 3 digits of the string, or the area code of the phone number are as follows
                                                            cout << "Your number is from Quebec." << endl; // then your number is from Quebec

                                                        else if (areacode == "306" || areacode == "639")//if the first 3 digits of the string, or the area code of the phone number are as follows
                                                            cout << "Your number is from Saskatchewan." << endl; // then your number is from Saskatchewan

                                                        else if (areacode == "867")//if the first 3 digits of the string, or the area code of the phone number are as follows
                                                            cout << "Your number is from Yukon, Northwest Territories, or Nunavut." << endl; // then your number is from Yukon, Northwest Territories, or Nunavut


                                                        else
                                                        {
                                                            cout << "This is not a Canadian phone number." << endl;
                                                        }
                                                    }

            cout << "Enter another number to continue, or type q to quit." << endl;
            cin >> number;
                                                }
        cout << "Please enter a valid telephone number." << endl;
        cin >> number; //user enters number
    }

    cout << "Thanks, bye." << endl;
    return 0;
}