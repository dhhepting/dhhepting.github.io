//**************************************************************************
//
// Student name: Jinze Xue
//
// Student number: 200353480
//
// Assignment number: #2
//
// Program name: Check telephone number
//
// Date written: February 24/2015
//
// Problem statement: Input telephone and check the formate of phone number, if the format is right and number is Canada, show the procince.the process continue check until check q.
//
// Input: telephone number or q
//
// Output: format is right, format is wrong and province
//
// Algorithm: q<---telephone number----->number--->format is right---->province----->continue
//                                        |___format is wrong----->continue
//
// Major variables: telephone number and q
//
// Assumptions:the process can continue
//
// Program limitations:No.
//
//**************************************************************************





#include <iostream>
#include<string>

using namespace std;

int main()
{


	string a = "The format is wrong";
	string b = "The format is right";
	
	string phone;
	
	cout << "enter q cancel" << endl;
		cout << "Please enter a telephone number in the format ddd-ddd-dddd:";
		cin >> phone;
while (phone[0]!='q')
	{
		if (phone[3] != '-' || phone[7] != '-' || phone.length() != 12)
		{
			cout << a << endl << endl;

		}

		if (phone[3] == '-' && phone[7] == '-'&&phone.length() == 12)

		{
			cout << b << endl;
			if (phone[0] =='4 '&&phone[1] =='0' &&phone[2]=='3')
				cout << "Alberta" << endl;
			if (phone[0] == '5 '&&phone[1] == '8' &&phone[2] == ' 7')
				cout << "Alberta" << endl;
			if (phone[0] =='7' &&phone[1] =='8 '&&phone[2] =='0' )
				cout << "Alberta" << endl;
			if (phone[0] =='8' &&phone[1] =='2' &&phone[2] =='5' )
				cout << "Alberta" << endl;
			if (phone[0] =='2' &&phone[1] =='3' &&phone[2] =='6' )
				cout << "British Columbia" << endl;
			if (phone[0] =='2' &&phone[1] =='5' &&phone[2] =='0' )
				cout << "British Columbia" << endl;
			if (phone[0] =='6' &&phone[1] =='0' &&phone[2] =='4' )
				cout << "British Columbia" << endl;
			if (phone[0] == '6'&&phone[1] =='7' &&phone[2] =='2' )
				cout << "British Columbia" << endl;
			if (phone[0] =='7' &&phone[1] =='7' &&phone[2] =='8' )
				cout << "British Columbia" << endl;
			if (phone[0] =='2' &&phone[1] =='0' &&phone[2] =='4' )
				cout << "Manitoba" << endl;
			if (phone[0] =='4' &&phone[1] =='3' &&phone[2] =='1' )
				cout << "Manitoba" << endl;
			if (phone[0] =='5' &&phone[1] =='0' &&phone[2] =='6' )
				cout << "New Brunswick" << endl;
			if (phone[0] == '7'&&phone[1] =='0' &&phone[2] =='9' )
				cout << "Newfoundland and Labrador" << endl;
			if (phone[0] =='7' &&phone[1] =='8' &&phone[2] =='2' )
				cout << "Nova Scotia" << endl;
			if (phone[0] =='9' &&phone[1] == '0'&&phone[2] == '2')
				cout << "Nova Scotia" << endl;
			if (phone[0] =='5' &&phone[1] =='4' &&phone[2] =='8' )
				cout << "Ontario" << endl;
			if (phone[0] =='2' &&phone[1] =='4' &&phone[2] =='9' )
				cout << "Ontario" << endl;
			if (phone[0] == '2'&&phone[1] =='8' &&phone[2] =='9' )
				cout << "Ontario" << endl;
			if (phone[0] =='3' &&phone[1] =='4' &&phone[2] =='3' )
				cout << "Ontario" << endl;
			if (phone[0] =='3' &&phone[1] =='6' &&phone[2] =='5' )
				cout << "Ontario" << endl;
			if (phone[0] =='3' &&phone[1] =='8' &&phone[2] =='7' )
				cout << "Ontario" << endl;
			if (phone[0] =='4' &&phone[1] =='1' &&phone[2] == '6')
				cout << "Ontario" << endl;
			if (phone[0] =='4' &&phone[1] =='3' &&phone[2] =='7' )
				cout << "Ontario" << endl;
			if (phone[0] =='5' &&phone[1] =='1' &&phone[2] =='9' )
				cout << "Ontario" << endl;
			if (phone[0] =='2' &&phone[1] =='2' &&phone[2] =='6' )
				cout << "Ontario" << endl;
			if (phone[0] =='6' &&phone[1] =='1' &&phone[2] =='3' )
				cout << "Ontario" << endl;
			if (phone[0] =='6' &&phone[1] =='4' &&phone[2] =='7' )
				cout << "Ontario" << endl;
			if (phone[0] =='7' &&phone[1] =='0' &&phone[2] == '5')
				cout << "Ontario" << endl;
			if (phone[0] =='7' &&phone[1] =='4' &&phone[2] =='2' )
				cout << "Ontario" << endl;
			if (phone[0] =='8' &&phone[1] =='0' &&phone[2] =='7' )
				cout << "Ontario" << endl;
			if (phone[0] =='9' &&phone[1] =='0' &&phone[2] =='5' )
				cout << "Ontario" << endl;
			if (phone[0] =='7' &&phone[1] =='8' &&phone[2] =='2' )
				cout << "Prince Edward Island" << endl;
			if (phone[0] =='9' &&phone[1] =='0' &&phone[2] =='2' )
				cout << "Prince Edward Island" << endl;
			if (phone[0] =='4' &&phone[1] =='1' &&phone[2] =='8' )
				cout << "Quebec" << endl;
			if (phone[0] =='4' &&phone[1] =='3' &&phone[2] =='8' )
				cout << "Quebec" << endl;
			if (phone[0] =='4' &&phone[1] =='5' &&phone[2] =='0' )
				cout << "Quebec" << endl;
			if (phone[0] =='5' &&phone[1] =='1' &&phone[2] =='4' )
				cout << "Quebec" << endl;
			if (phone[0] =='5' &&phone[1] =='7' &&phone[2] =='9' )
				cout << "Quebec" << endl;
			if (phone[0] =='5' &&phone[1] =='8' &&phone[2] =='1' )
				cout << "Quebec" << endl;
			if (phone[0] =='8' &&phone[1] =='1' &&phone[2] =='9' )
				cout << "Quebec" << endl;
			if (phone[0] =='8' &&phone[1] =='7' &&phone[2] =='3' )
				cout << "Quebec" << endl;
			if (phone[0] =='3' &&phone[1] =='0' &&phone[2] =='6' )
				cout << "Saskatchewan" << endl;
			if (phone[0] =='6' &&phone[1] =='3' &&phone[2] =='9' )
				cout << "Saskatchewan" << endl;
			if (phone[0] =='8' &&phone[1] =='6' &&phone[2] =='7' )
				cout << "Yukon, Northwest Territoties, andNunavut" << endl;
			else
				cout << endl;
		}
		
		cout << "Please enter a telephone number in the format ddd-ddd-dddd:";
		cin >> phone;
	}
	 
	
  
	 if(phone[0] == 'q')
			cout << endl;
	


	
	return 0;
}