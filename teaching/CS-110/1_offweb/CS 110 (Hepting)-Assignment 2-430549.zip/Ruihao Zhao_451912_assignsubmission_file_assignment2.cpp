//**************************************************************************
//
// Student name:Ruihao Zhao    
//
// Student number: 200338484    
//
// Assignment number: #2
//
// Program name: Assignment2.cpp
//
// Date written: 2/17/2015
//
// Problem statement: Ask the user to input phone numbers until "q" is entered. Assess each phone number to see if it is valid
// and check if the area code (first 3 digits) is canadian and if it is canadian which province/territory it belongs to
//
// Input: string pnum (phone number)
//
// Output: phone number valid or not, checking if each digit is valid, the area code if the number is valid, and
// where in canada it is from or if it is not from canada
//
// Algorithm1:stringinput:input pnum as a string
//
// Algorithm2:lengthcheck:checking if pnum is 12 characters long
//
// Algorithm3:digitcheck:checking if digits are numbers or hyphens (in the correct spaces)
//
// Algorithm4:boolassignedtodigitcheck:if the digits checks are assigned to boolean variables
//
// Algorithm5:areacodecheck: use pnum.substr(0,3) to isolate the first three digits/characters(area code) and matches it with canadian area codes or to place it in incorrect category
//
// Algorithm6: Termination:if "q" is inputted the loop will end and the code will ask your to close the output window
//
// Major variables: pnum (string) , length (bool), pnum1(bool), pnum2(bool),pnum3(bool),pnum4(bool),pnum5(bool),pnum6(bool),pnum7(bool),
//pnum8(bool),pnum9(bool),pnum10(bool),pnum11(bool),pnum12(bool), acode(string)
//
// Assumptions:no international numbers, should be given to canadian phone users, and they have to use dashes for the input of phone numbers.
//
// Program limitations:the area code could be non-canadian that exist or non-canadian that do not exist. The code cannot tell them apart
// and cannot list non-canadian existing ones.
//
//**************************************************************************
#include <iostream>
#include <string>
using namespace std;

int main()
{

	string pnum;
	while (pnum != "q")
	{
		cout << "Please enter a valid 10 digit phone number(in the format of ddd-ddd-dddd) or q to terminate the program: " << endl;
		cin >> pnum;																					//algorithm1 start & algorithm1 end

		if (pnum.length() == 12)																		//algorithm2 start & algorithm2 end 
		{
			cout << "This phone number is a valid length" << endl;										//alrogithm3 start
			if (pnum[0] >= '0' && pnum[0] <= '9')
				cout << "first digit is valid" << endl;
			else
				cout << "error first digit is invalid" << endl;
			if (pnum[1] >= '0' && pnum[1] <= '9')
				cout << "second digit is valid" << endl;
			else
				cout << "error second digit is invalid" << endl;
			if (pnum[2] >= '0' && pnum[2] <= '9')
				cout << "third digit is valid" << endl;
			else
				cout << "error third digit is invalid" << endl;
			if (pnum[3] == '-')
				cout << "fourth digit is valid" << endl;
			else
				cout << "error fourth digit is invalid" << endl;
			if (pnum[4] >= '0' && pnum[4] <= '9')
				cout << "fifth digit is valid" << endl;
			else
				cout << "error fifth digit is invalid" << endl;
			if (pnum[5] >= '0' && pnum[5] <= '9')
				cout << "sixth digit is valid" << endl;
			else
				cout << "error sixth digit is invalid" << endl;
			if (pnum[6] >= '0' && pnum[6] <= '9')
				cout << "seventh digit is valid" << endl;
			else
				cout << "error seventh digit is invalid" << endl;
			if (pnum[7] == '-')
				cout << "eighth digit is valid" << endl;
			else
				cout << "error eighth digit is invalid" << endl;
			if (pnum[8] >= '0' && pnum[8] <= '9')
				cout << "ninth digit is valid" << endl;
			else
				cout << "error ninth digit is invalid" << endl;
			if (pnum[9] >= '0' && pnum[9] <= '9')
				cout << "tenth digit is valid" << endl;
			else
				cout << "error tenth digit is invalid" << endl;
			if (pnum[10] >= '0' && pnum[10] <= '9')
				cout << "eleventh digit is valid" << endl;
			else
				cout << "error eleventh digit is invalid" << endl;
			if (pnum[11] >= '0' && pnum[11] <= '9')
				cout << "twelfth digit is valid" << endl;
			else
				cout << "error twelfth digit is invalid" << endl;										//algorithm3 end

			bool length = pnum.length() == 12;															//algorithm4 start
			bool pnum1 = pnum[0] >= '0' && pnum[0] <= '9';
			bool pnum2 = pnum[1] >= '0' && pnum[1] <= '9';
			bool pnum3 = pnum[2] >= '0' && pnum[2] <= '9';
			bool pnum4 = pnum[3] == '-' && pnum[3] == '-';
			bool pnum5 = pnum[4] >= '0' && pnum[4] <= '9';
			bool pnum6 = pnum[5] >= '0' && pnum[5] <= '9';
			bool pnum7 = pnum[6] >= '0' && pnum[6] <= '9';
			bool pnum8 = pnum[7] == '-' && pnum[7] == '-';
			bool pnum9 = pnum[8] >= '0' && pnum[8] <= '9';
			bool pnum10 = pnum[9] >= '0' && pnum[9] <= '9';
			bool pnum11 = pnum[10] >= '0' && pnum[10] <= '9';
			bool pnum12 = pnum[11] >= '0' &&pnum[11] <= '9';


			if (length&&pnum1&&pnum2&&pnum3&&pnum4&&pnum5&&pnum6&&pnum7&&pnum8&&pnum9&&pnum10&&pnum11&&pnum12) //algorithm4 end
			{
				string acode = pnum.substr(0, 3);															   //algorithm5 start
				cout << "The area code is " << acode << endl;
				if (acode == "403" || acode == "587" || acode == "780" || acode == "825")
					cout << "This phone number's area code is from Alberta" << endl;
				else if (acode == "236" || acode == "250" || acode == "604" || acode == "672" || acode == "778")
					cout << "This phone number's area code is from British Columbia" << endl;
				else if (acode == "204" || acode == "431")
					cout << "This phone number's area code is from Manitoba" << endl;
				else if (acode == "506")
					cout << "This phone number's area code is from New Brunswick" << endl;
				else if (acode == "709")
					cout << "This phone number's area code is from Newfoundland and Labrador" << endl;
				else if (acode == "782" || acode == "902")
					cout << "This phone number's area code is from Nova Scotia" << endl;
				else if (acode == "548" || acode == "249" || acode == "289" || acode == "343" || acode == "365" || acode == "387" || acode == "416" || acode == "437" || acode == "519" || acode == "226" || acode == "613" || acode == "647" || acode == "705" || acode == "742" || acode == "807" || acode == "905")
					cout << "This phone number's area code is from Ontario" << endl;
				else if (acode == "782" || acode == "902")
					cout << "This phone number's area code is from Prince Edward Island" << endl;
				else if (acode == "418" || acode == "438" || acode == "450" || acode == "514" || acode == "579" || acode == "581" || acode == "819" || acode == "873")
					cout << "This phone number's area code is from Quebec" << endl;
				else if (acode == "306" || acode == "639")
					cout << "This phone number's area code is from Saskatchewan" << endl;
				else if (acode == "867")
					cout << "This phone number's area code is from Yukon, Northwest Territories, and/or Nunavut" << endl;
				else
					cout << "This phone number's area code is not from Canada" << endl;
				cout << endl;
			}

			else
			{
				cout << "Error invalid phone number" << endl;
				cout << endl;																	//algorithm5 end
			}
		}
		else
		{
			cout << "Error invalid phone number" << endl;
			cout << endl;
		}
		if (pnum == "q")																		//algorithm6 start
		{
			cout << "Program has been terminated" << endl;
			return 0;
		}																						//algorithm6 end

	}
}

