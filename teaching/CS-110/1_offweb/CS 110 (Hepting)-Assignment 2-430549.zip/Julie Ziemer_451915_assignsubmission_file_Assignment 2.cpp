//**************************************************************************
//
// Student name: Julie Ziemer
//
// Student number: 200342432
//
// Assignment number: Assignment 2
//
// Program name: Assignment 2.cpp
//
// Date written: February 25, 2015
//
// Problem statement: Develop a program that prompts user to enter a North American phone number using the format  ddd-ddd-dddd. Check if the
//					  number matches a Canadian area code, if so display the province/territory.  The user ends the program by entering 'q'.
//
// Input: User enters a North American phone number (ddd-ddd-dddd) and ends the program by entering 'q'.
//
// Output: "Please enter a valid North American phone number using the format ddd-ddd-dddd.", "Sorry, that phone number does not follow the format."
//			"You have entered an area code for Alberta.", "You have entered an area code for British Columbia.", "You have entered an area code for Manitoba.",
//			"You have entered an area code for New Brunswick.", "You have entered an area code for Newfoundland and Labrador.", "You have entered an area code for Nova Scotia.",
//			"You have entered an area code for Ontario.", "You have entered an area code for Quebec.", "You have entered an area code for Prince Edward Island.",
//			"You have entered an area code for Saskatchewan.", "You have entered an area code for Yukon, Northwest Territories, and Nunavut.", 
//			"To end this program, please enter the letter 'q'.";
//
// Algorithm: User enters a North American phone number (ddd-ddd-dddd) and a string function checks if the format and the phone number are valid.
//			  If the phone number entered meets the requirements of the if statements the program outputs the name of the province/territory.  The 
//            program continues to run allowing the user to enter phone numbers until entering 'q' to end the program.
//
// Major variables: string quit, phoneNum; bool goodNumber;
//
// Assumptions:  The user will follow the instructions and will enter a phone number that corresponds to the Canadian area codes.
//
// Program limitations: The user must enter the number using the proper format (ddd-ddd-dddd) including the dashes and no parenthesis. 
//
//**************************************************************************
#include <iostream>
#include <string>
using namespace std;

int main()

{
	string quit;
	while (quit != "q")
	{
		string phoneNum;
		cout << "Please enter a valid Canadian phone number using the format  ddd-ddd-dddd." << endl;
		cin >> phoneNum;

		// check that the input is 12 characters long
		// the program ends if the length of the string is not equal to 12 characters

		if (phoneNum.length() != 12)
		{
			cout << "Sorry, that phone number does not follow the format." << endl;
			return -1;
		}

		// check that only numbers between 0 and 9 or dashes were used
		// declare a bool variable to check the if statements
		// when the if statement is false, the program should end limiting the input 
		// for the phone number to digits and dashes.

		bool goodNumber;
		bool(goodNumber = true)
		{
			if ((phoneNum[0] >= '0') && (phoneNum[0] <= '9'))
			{
				goodNumber = true;
			}
			if ((phoneNum[1] >= '0') && (phoneNum[1] <= '9'))
			{
				goodNumber = true;
			}
			if ((phoneNum[2] >= '0') && (phoneNum[2] <= '9'))
			{
				goodNumber = true;
			}
			if ((phoneNum[3] == '-'))
			{
				goodNumber = true;
			}
			if ((phoneNum[4] >= '0') && (phoneNum[4] <= '9'))
			{
				goodNumber = true;
			}
			if ((phoneNum[5] >= '0') && (phoneNum[5] <= '9'))
			{
				goodNumber = true;
			}
			if ((phoneNum[6] >= '0') && (phoneNum[6] <= '9'))
			{
				goodNumber = true;
			}
			if ((phoneNum[7] == '-'))
			{
				goodNumber = true;
			}
			if ((phoneNum[8] >= '0') && (phoneNum[8] <= '9'))
			{
				goodNumber = true;
			}
			if ((phoneNum[9] >= '0') && (phoneNum[9] <= '9'))
			{
				goodNumber = true;
			}
			if ((phoneNum[10] >= '0') && (phoneNum[10] <= '9'))
			{
				goodNumber = true;

			}
			if ((phoneNum[11] >= '0') && (phoneNum[11] <= '9'))
			{
				goodNumber = true;
			}
			else
			{
				goodNumber = false;
				cout << "Sorry, that phone number does not follow the proper format." << endl;
				return 0;
			}
		}
																					
		// check the area code
		// if statements are used to test the string starting at the beginning and using three characters
		// if the input is true, the province corresponding to the area code is displayed.

		if (phoneNum.substr(0, 3) == "403" || phoneNum.substr(0, 3) == "587" || phoneNum.substr(0, 3) == "780")
		{
			cout << "You have entered an area code for Alberta." << endl;
		}
		if (phoneNum.substr(0, 3) == "236" || phoneNum.substr(0, 3) == "250" || phoneNum.substr(0, 3) == "604" || phoneNum.substr(0, 3) == "778")
		{
			cout << "You have entered an area code for British Columbia." << endl;
		}
		if (phoneNum.substr(0, 3) == "204" || phoneNum.substr(0, 3) == "431")
		{
			cout << "You have entered an area code for Manitoba." << endl;
		}
		if (phoneNum.substr(0, 3) == "506")
		{
			cout << "You have entered an area code for New Brunswick." << endl;
		}
		if (phoneNum.substr(0, 3) == "709")
		{
			cout << "You have entered an area code for Newfoundland and Labrador." << endl;
		}
		if (phoneNum.substr(0, 3) == "782" || phoneNum.substr(0, 3) == "902")
		{
			cout << "You have entered an area code for Nova Scotia." << endl;
		}
		if (phoneNum.substr(0, 3) == "548" || phoneNum.substr(0, 3) == "249" || phoneNum.substr(0, 3) == "289" || phoneNum.substr(0, 3) == "343" || phoneNum.substr(0, 3) == "365" || phoneNum.substr(0, 3) == "416" || phoneNum.substr(0, 3) == "437" || phoneNum.substr(0, 3) == "519" || phoneNum.substr(0, 3) == "226" || phoneNum.substr(0, 3) == "613" || phoneNum.substr(0, 3) == "705" || phoneNum.substr(0, 3) == "807" || phoneNum.substr(0, 3) == "905")
		{
			cout << "You have entered an area code for Ontario." << endl;
		}
		if (phoneNum.substr(0, 3) == "782" || phoneNum.substr(0, 3) == "902")
		{
			cout << "You have entered an area code for Prince Edward Island." << endl;
		}
		if (phoneNum.substr(0, 3) == "418" || phoneNum.substr(0, 3) == "438" || phoneNum.substr(0, 3) == "450" || phoneNum.substr(0, 3) == "514" || phoneNum.substr(0, 3) == "579" || phoneNum.substr(0, 3) == "581" || phoneNum.substr(0, 3) == "819" || phoneNum.substr(0, 3) == "873")
		{
			cout << "You have entered an area code for Quebec." << endl;
		}
		if (phoneNum.substr(0, 3) == "306" || phoneNum.substr(0, 3) == "639")
		{
			cout << "You have entered an area code for Saskatchewan." << endl;
		}
		if (phoneNum.substr(0, 3) == "867")
		{
			cout << "You have entered an area code for the Yukon, Northwest Territories, and Nunavut." << endl;
		}

		// User chooses whether or not to continue the program
		// entering 'q' and return ends the loop by making the while statement false
		// entering alternatives allows the while statement to keep running because it is true.

		cout << "To end this program, please enter the letter 'q' and then return." << endl;
		cin >> quit;
	}
	return 0;
}