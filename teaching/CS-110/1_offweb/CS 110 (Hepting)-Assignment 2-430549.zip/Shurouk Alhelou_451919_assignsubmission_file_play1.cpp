/*Write a program that prompts the user to enter a telephone number in the format ddd-ddd-dddd, where d is digit.
This is the format for telephone numbers in North America. Test that the input is in the correct format and further
check if the phone number has a Canadian area code (see the list of Canadian area codes). The program will report 
if the input is valid or not. If the input includes a Canadian area code, the program will display the name of the
province or territory with that area code. The program will continue to process numbers until the user enters the letter q.*/

#include <iostream>
#include <string>
using namespace std;

int main()
{
	string phone1;
	char q='0';
	while (q != 'q')
	{
		cout << "Please enter a phone number in this format:(ddd-ddd-dddd)" << endl;
		cin >> phone1;
		cout << endl;

		while (phone1.length() == 12)
		{
			string areacode(phone1, 0, 3);
			if (phone1[3] != '-' && phone1[7] != '-')
			{
				cout << "Error, Please enter the number in the correct formate (ddd-ddd-dddd)" << endl;
				//return 1;
			}
			while (areacode == "306" || areacode == "639" || areacode == "418" || areacode == "438" || areacode == "450" || areacode == "514" ||
				areacode == "579" || areacode == "581" || areacode == "819" || areacode == "873" || areacode == "548" || areacode == "249" ||
				areacode == "289" || areacode == "343" || areacode == "365" || areacode == "387" || areacode == "416" || areacode == "437" ||
				areacode == "519" || areacode == "226" || areacode == "613" || areacode == "647" || areacode == "705" || areacode == "742" ||
				areacode == "807" || areacode == "905" || areacode == "782" || areacode == "902" || areacode == "709" || areacode == "506" ||
				areacode == "867" || areacode == "204" || areacode == "431" || areacode == "780" || areacode == "403" || areacode == "587" ||
				areacode == "825" || areacode == "236" || areacode == "250" || areacode == "604" || areacode == "672" || areacode == "778")
			{
				if (areacode == "780" || areacode == "403" || areacode == "587" || areacode == "825")
					cout << "This Area code is for Alberta" << endl;

				else if (areacode == "236" || areacode == "250" || areacode == "604" || areacode == "672" || areacode == "778")
					cout << "This Area code is for British Columbia" << endl;
					
	
				else if (areacode == "204" || areacode == "431")
					cout << "This Area code is for Manitoba" << endl;

				else if (areacode == "506")
					cout << "This Area code is for New Brunswick" << endl;

				else if (areacode == "709")
					cout << "This Area code is for Newfoundland and Labrador" << endl;
				
				else if (areacode == "782" || areacode == "902")
					cout << "This Area code is for Nova Scotia and Prince Edward Island" << endl;

				else if (areacode == "548" || areacode == "249" || areacode == "289" || areacode == "343" || areacode == "365" ||
					areacode == "387" || areacode == "416" || areacode == "437" || areacode == "519" || areacode == "226" ||
					areacode == "613" || areacode == "647" || areacode == "705" || areacode == "742" || areacode == "807" || areacode == "905")
					cout << "This Area code is for Ontario" << endl;
	
				else if (areacode == "418" || areacode == "438" || areacode == "450" || areacode == "514" || areacode == "579" ||
					areacode == "581" || areacode == "819" || areacode == "873")
					cout << "This Area code is for Quebec" << endl;

				else if (areacode == "306" || areacode == "639")
					cout << "This Area code is for Saskatchewan" << endl;

				else if (areacode == "867")
					cout << "This Area code is for Yukon, Northwest Territories, and Nunavut" << endl;
				else
					cout << "enter Letter 'q' to quit" << endl;
				cin >> q;

				if (q == 'q')
					return 0;
			}


			cout << "This is either not a Canadian phone number or not a number but a letter" << endl;
			return -1;
		}
		cout << "Error, Please enter the number in the correct formate (ddd-ddd-dddd)" << endl;
		return -1;
	}
	
	return -1;
}



