//**************************************************************************
//
// Student name: Riley Peters
//
// Student number: 200 354 249
//
// Assignment number: #2
//
// Program name: Phone Number Reading
//
// Date written: February 25th, 2015
//
// Problem statement: To have a program read a phone number, check for proper format, and display the area
//                      code's location and repeat until the user inputs q
//
// Input: phone number in format ddd-ddd-dddd
//
// Output: location of area code
//
// Algorithm: input phone number -> check if the phone number is in the proper format -> take the first
//            three digits out for the area code -> check the area code to Canadian area codes -> output
//            the location of the area code or output not from Canada -> loop again until the while loop
//            is false (user inputs q).
//
// Major variables: phone number, area code
//
// Assumptions: to display not Canadian, non-Canadian phone numbers follow similar format
//
// Program limitations: will not display location of non-Canadian area codes, phone number must be input
//                      in proper format
//
//**************************************************************************

#include <iostream>
using namespace std;
int main()

{
    string phone = "a";
    string acode;
    
while (phone != "q")
{
    cout << "Input a 10 digit Canadian Phone number: " << endl;
    cin >> phone;
    
    if (phone == "q")
    { cout << "Good-bye" << endl;
        break;}
    if (phone.length() != 12)
    { cout << "Inproper format" << endl;
        continue;}
    if (phone[3] != '-' || phone[7] != '-')
    { cout << "Inproper format" << endl;
        continue;}
    
    acode = phone.substr(0,3);
    
    cout << "Area code location: ";
    
    if (acode=="403" || acode=="587" || acode=="780" || acode=="825")
        cout << "Alberta" << endl;
    
    else if (acode=="236" || acode=="250" || acode=="604" || acode=="672" || acode=="778")
        cout << "British Columbia" << endl;
    
    else if (acode=="204" || acode=="431")
        cout << "Manitoba" << endl;

    else if (acode=="506")
        cout << "New Brunswick" << endl;

    else if (acode=="709")
        cout << "Newfoundland and Labrador" << endl;
    
    else if (acode=="204" || acode=="431")
        cout << "Nova Scotia or Prince Edward Island" << endl;

    else if (acode=="548" || acode=="249" || acode=="289" || acode=="343" || acode=="365" || acode=="387" || acode=="416" || acode=="437" || acode=="519" || acode=="226" || acode=="613" || acode=="647" || acode=="705" || acode=="742" || acode=="807" || acode=="905")
        cout << "Ontario" << endl;
    
    else if (acode=="418" || acode=="438" || acode=="450" || acode=="514" || acode=="579" || acode=="581" || acode=="819" || acode=="873")
        cout << "Quebec" << endl;

    else if (acode=="306" || acode=="639")
        cout << "Saskatchewan" << endl;
    
    else if (acode=="867")
        cout << "from Yukon, Northwest Territories, or Nunavut" << endl;
            
    else
        cout << "not from Canada" << endl;
}
    return 0;
}
