//
//
// Student Name: Cole Sanderson
//
// Student Number: 200355179
//
// Assignment Number: 2
//
// Program Name: Determining area codes for Canadian provinces
//
// Date Written: February 23, 2015
//
// Problem Statement: Enter Canadian province area codes and detrmine the correct match for that area code to the specific province.
//
// Input: I expect the user to first enter a proper phone number first off. If neither of these is accomplished then the program will reroute the user until he/she follows the guidelines.
//
// Output: This computer program should output to the user the correct Canadian Province that coincides with the phone number entered or too display a message to the user that the phone number is not from Canada or that the number entered os invalid.
//
// Algorithm: I will instruct the computer to take input from the user in the form of a phone number and relay to the user that the input they entered is of a certain Canadian Provinces area code. However, if the user does not follow this, the computer will be expected to give the user more explanation on how to fix there problem or end the program immidiatley if the phone number is invalid or q is typed in.
//
// Major Variables: string areacode and string phonenumber.
//
// Assumptions: The programmer must assume that the user has a basic understanding of Canadian area codes to fully take advantage of what the prgram has to offer. 
//
// Program Limitations: The limit to this program is that it will only provide you with area codes in Canada and not in other parts of the world. 
//

#include <iostream>
#include <string>
using namespace std;
int main()
{
	// Utilizing the string approach to accomplish assignment two's requirements
	string areacode;
	string phonenumber;
	
	// Prompt the user to enter a phone number to begin the program
	cout << "Please enter a phonenumber in the form ddd-ddd-dddd or q to end the program: ";
	cin >> phonenumber;
	
	// Utilizing the while loop in case if the user types the letter q into the program 
	while (phonenumber[0] != 'q')
	{
		// In this section I used the >= '0' and <= '9' to single out the fact that a phone number's greatest digit can be 9 and to also not allow for letters to be typed in.
		if (phonenumber.length() == 12 && phonenumber[3] == '-' && phonenumber[7] == '-' && phonenumber[0] >= '0' && phonenumber[0] <= '9' && phonenumber[1] >= '0' &&
			phonenumber[1] <= '9' && phonenumber[2] >= '0' && phonenumber[2] <= '9' && phonenumber[4] >= '0' && phonenumber[4] <= '9' && phonenumber[5] >= '0' && phonenumber[5] <= '9'
			&& phonenumber[6] >= '0' && phonenumber[6] <= '9' && phonenumber[8] >= '0' && phonenumber[8] <= '9' && phonenumber[9] >= '0' && phonenumber[9] <= '9'
			&& phonenumber[10] >= '0' && phonenumber[10] <= '9' && phonenumber[11] >= '0' && phonenumber[11] <= '9')
		{
			areacode = phonenumber.substr(0, 3);

			// Utilizing the if statement to seperate each provinces area codes 
			if (areacode == "403" || areacode == "507" || areacode == "780" || areacode == "825")
			{
				cout << "The number that you input is a Canadian phone number from the Province Alberta" << endl;
			}
			if (areacode == "236" || areacode == "250" || areacode == "604" || areacode == "627" || areacode == "778")
			{
				cout << "The number that you input is a Canadian phone number from the Province British Columbia" << endl;
			}
			if (areacode == "204" || areacode == "431")
			{
				cout << "The number that you input is a Canadian phone number from the Province Manitoba" << endl;
			}
			if (areacode == "506")
			{
				cout << "The number that you input is a Canadian phone number from the Province New Brunswick" << endl;
			}
			if (areacode == "709")
			{
				cout << "The number that you input is a Canadian phone number from the Province Newfoundland and Labrador" << endl;
			}
			if (areacode == "782" || areacode == "903")
			{
				cout << "The number that you input is a Canadian phone number from the Province Nova Scotia or Prince Edward Island" << endl;
			}
			if (areacode == "548" || areacode == "249" || areacode == "289" || areacode == "343" || areacode == "365" || areacode == "387" || areacode == "416" || areacode == "437" || areacode == "519" || areacode == "226" || areacode == "613" || areacode == "647" || areacode == "705" || areacode == "742" || areacode == "807" || areacode == "905")
			{
				cout << "The number that you input is a Canadian phone number from the Province Ontario" << endl;
			}
			if (areacode == "418" || areacode == "438" || areacode == "450" | areacode == "514" || areacode == "579" || areacode == "581" || areacode == "819" || areacode == "873")
			{
				cout << "The number that you input is a Canadian phone number from the Province Quebec" << endl;
			}
			if (areacode == "306" || areacode == "639")
			{
				cout << "The number that you input is a Canadian phone number from the Province Saskatchewan" << endl;
			}
			if (areacode == "867")
			{
				cout << "The number that you input is a Canadian phone number from the Northwest Territories, the Yukon, or Nunavut" << endl;
			}
		}
		
		// Providing a sentence to the user to let them know that the phone nmber they entered is invalid and will cause the program to not run properly
		else
			cout << "You entered a Non-Canadian phone number or an invalid phone number please try again" << endl;
		// Allows the user to try again and enter a proper phone number that is acceptable in Canada
		cout << "Please enter a phone number in the form ddd-ddd-dddd or q to quit: ";
		cin >> phonenumber;
	}
	
	return 0;
}