//**************************************************************************
//
// Student name: Brayden Tang
//
// Student number: 200350623
//
// Assignment number: 2 
//
// Program name: Determining where a phone number orginates from in Canada after inputted in the format "ddd-ddd-dddd" where d is a digit
//
// Date written: Feb 15, 2015
//
// Problem statement: Write a program that prompts the user to enter a telephone number in the format ddd-ddd-dddd, where d is digit. This is the format for telephone numbers in North America. Test that the input is in the correct format and further check if the phone number has a Canadian area code (see the list of Canadian area codes). The program will report if the input is valid or not. If the input includes a Canadian area code, the program will display the name of the province or territory with that area code. The program will continue to process numbers until the user enters the letter q.
//
// Input: A telephone number in the format ddd-ddd-dddd where d is a digit, and char C or q (though q can be any value) to reenter or discontinue the loop respectively.
//
// Output: The validity of the inputted telephone number format, and if valid, the area (based on the area code from the telephone number) from which the number originates in Canada, or not depending on whether the inputted area code is from Canada/contains actual numbers and no letters.
//
// Algorithm: A combination of strings and functions of strings such as substr and .length and .at to check the validity of the string itself and to obtain the area code from the inputted string, and then if and else if statements to determine where the telephone number originates from. There are two loops, one which determines the validity of the inputted value and the other which determines if the user wants to continue processing telephone numbers.
//
// Major variables: continueLOOP, telephoneNUMBER, telephoneAREACODE
//
// Assumptions: That the user actually enters a area code coming from Canada or at least enters an area code that exists.
//
// Program limitations: Area codes out of Canada, or area codes that do not exist cannot be interpreted very well with this program.
//
//**************************************************************************
#include <iostream>
#include <string>
using namespace std;
int main()

{  
char continueLOOP;                                  //declaring the variable for the user to input if they want to continue to process numbers (ie. reenter the loop). C is to reenter the loop, q is to exit the loop, though technically they could enter any letter and have it exit the loop.
    continueLOOP = 'C';
   
   while (continueLOOP == 'C')                            //if the user enters 'C' (for continue) as an input they will reenter the loop.
{
    string telephoneNUMBER;                                   
    cout << "Input a Canadian telephone number in the format ddd-ddd-dddd where d is a digit." << endl;         //promting the user to enter a Canadian telephone number in the specified format.
        cin >> telephoneNUMBER;
         while (!(telephoneNUMBER.length() == 12) || !(telephoneNUMBER.at(3) == '-') || !(telephoneNUMBER.at(7) == '-') || !(telephoneNUMBER[0] >= '0' && telephoneNUMBER[0] <='9') || !(telephoneNUMBER[1] >= '0' && telephoneNUMBER[1] <='9') || !(telephoneNUMBER[2] >= '0' && telephoneNUMBER[2] <= '9') || !(telephoneNUMBER[4] >= '0' && telephoneNUMBER[4] <= '9') || !(telephoneNUMBER[5] >= '0' && telephoneNUMBER[5] <= '9') || !(telephoneNUMBER[6] >= '0' && telephoneNUMBER[6] <= '9') || !(telephoneNUMBER[8] >= '0' && telephoneNUMBER[8] <= '9') || !(telephoneNUMBER[9] >= '0' && telephoneNUMBER[9] <= '9') || !(telephoneNUMBER[10] >= '0' && telephoneNUMBER[10] <= '9') || !(telephoneNUMBER[11] >= '0' && telephoneNUMBER[11] <= '9'))    //first loop that checks for a correctly formatted telephone number. If the value is invalid, ie. the length does not equal 12 and no "-" at positions 3 and 7, as well as intergers in each position of the string in which an interger should be in the string then the user will continue to enter the loop until they enter a correctly formatted value.
        {
            if ((telephoneNUMBER.length() == 12) && (telephoneNUMBER.at(3) == '-') && (telephoneNUMBER.at(7) == '-') && (telephoneNUMBER[0] >= '0' && telephoneNUMBER[0] <= '9') && (telephoneNUMBER[1] >= '0' && telephoneNUMBER[1] <= '9') && (telephoneNUMBER[2] >= '0' && telephoneNUMBER[2] <= '9') && (telephoneNUMBER[4] >= '0' && telephoneNUMBER[4] <= '9') && (telephoneNUMBER[5] >= '0' && telephoneNUMBER[5] <= '9') && (telephoneNUMBER[6] >= '0' && telephoneNUMBER[6] <= '9') && (telephoneNUMBER[8] >= '0' && telephoneNUMBER[8] <= '9') && (telephoneNUMBER[9] >= '0' && telephoneNUMBER[9] <= '9') && (telephoneNUMBER[10] >= '0' && telephoneNUMBER[10] <= '9') && (telephoneNUMBER[11] >= '0' && telephoneNUMBER[11] <= '9'))  //the conditions that a correctly formatted telephone number would have. Essentially the same thing as the while conditions but instead we want verification of the phone number being correct to exit the loop rather than verification to stay in the loop (essentially it's opposite of the while conditions)
            {
                break; //break immediately out of this loop if correct
            }
            else 
            {
                cout << "Invalid format. Try again." << endl;    //reenter a telephone number until format is correct
                cin >> telephoneNUMBER;  //user reenters a telephone number
            }
        }
       
        
    string telephoneAREACODE = (telephoneNUMBER.substr(0, 3));  //obtain the area code from the string, (or the substring of the string from 0,3) which should be the first three digits of the telephone number in any correctly formatted telephone number. 
    
        
    
	cout << "Valid format." << endl;             //after exiting the loop, this message will be displayed indicating a a valid format
		if (telephoneAREACODE == "403" || telephoneAREACODE == "587" || telephoneAREACODE == "780")     //through a series of basic if and else if statements we can then determine where the phone number orginated from. I divided the if and else if statements by the area codes. Note that some provinces have multiple area codes, and Prince Edward Island and Nova Scotia have the exact same pair of area codes despite being two different provinces. I seperated them for clarity.
		{
			cout << "The phone number comes from the province of Alberta." << endl;
            cout << "Enter C to continue and q to quit:" << endl;      //promting the user to enter C to continue which will force the user to reenter the loop (and thus reenter a telephone number to check if its format is correct)
            cin >> continueLOOP;
		}
		else if (telephoneAREACODE == "236" || telephoneAREACODE == "250" || telephoneAREACODE == "604")
		{
			cout << "The phone number comes from the province of British Columbia." << endl;
             cout << "Enter C to continue and q to quit:" << endl;
            cin >> continueLOOP;
		}
		else if (telephoneAREACODE == "204" || telephoneAREACODE == "431")
		{
			cout << "The phone number comes from the province of Manitoba." << endl;
             cout << "Enter C to continue and q to quit:" << endl;
            cin >> continueLOOP;
		}
		else if (telephoneAREACODE == "506")
		{
			cout << "The phone number comes from the province of New Brunswick." << endl;
             cout << "Enter C to continue and q to quit:" << endl;
            cin >> continueLOOP;
		}
		else if (telephoneAREACODE == "709")
		{
			cout << "The phone number comes from the province of Newfoundland and Labrador." << endl;
             cout << "Enter C to continue and q to quit:" << endl;
            cin >> continueLOOP;
		}
		else if (telephoneAREACODE == "782" || telephoneAREACODE == "902")
		{
			cout << "The phone number comes from the province of Nova Scotia or Prince Edward Island." << endl;
             cout << "Enter C to continue and q to quit:" << endl;
            cin >> continueLOOP;
		}
		else if (telephoneAREACODE == "548" || telephoneAREACODE == "249" || telephoneAREACODE == "289" || telephoneAREACODE == "343" || telephoneAREACODE == "365" || telephoneAREACODE == "416" || telephoneAREACODE == "437" || telephoneAREACODE == "519" || telephoneAREACODE == "226" || telephoneAREACODE == "613" || telephoneAREACODE == "647" || telephoneAREACODE == "705" || telephoneAREACODE ==  "807" || telephoneAREACODE == "905")
		{
			cout << "The phone number comes from the province of Ontario." << endl;
             cout << "Enter C to continue and q to quit:" << endl;
            cin >> continueLOOP;
		}
		else if (telephoneAREACODE == "782" || telephoneAREACODE == "902")
		{
			cout << "The phone number comes from the province of Prince Edward Island or Nova Scotia." << endl;
             cout << "Enter C to continue and q to quit:" << endl;
            cin >> continueLOOP;
		}
		else if (telephoneAREACODE == "418" || telephoneAREACODE == "438" || telephoneAREACODE == "450" || telephoneAREACODE == "514" || telephoneAREACODE == "579" || telephoneAREACODE == "581" || telephoneAREACODE == "819" || telephoneAREACODE == "873")
		{
			cout << "The phone number comes from the province of Quebec." << endl;
             cout << "Enter C to continue and q to quit:" << endl;
            cin >> continueLOOP;
		}
		else if (telephoneAREACODE == "306" || telephoneAREACODE == "639")
		{
			cout << "The phone number comes from the province of Saskatchewan." << endl;
            cout << "Enter C to continue and q to quit:" << endl;
            cin >> continueLOOP;
		}
		else if (telephoneAREACODE == "867")   //unique area code in the fact that this one area code represents three different territories
		{
			cout << "The phone number comes from the territory of Yukon, Northwest Territories, or Nunavut." << endl;
            cout << "Enter C to continue and q to quit:" << endl;
            cin >> continueLOOP;
		}
		else
		{
			cout << "Invalid phone number (area code does not exist) or the phone number does not come from Canada." << endl;  //obviously area codes from out of country are still valid, they just aren't in the country. The area code may also not exist in the world.
            cout << "Enter C to continue and q to quit:" << endl;
            cin >> continueLOOP;
		}
    }
		return 0;
}
