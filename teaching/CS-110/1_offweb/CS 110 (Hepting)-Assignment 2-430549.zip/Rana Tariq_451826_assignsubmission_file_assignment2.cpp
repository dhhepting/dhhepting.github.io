// Name: Rana Mujahid Tariq
// Student ID: 200 321 914 
// Assignment # 2 
// Program Name: North America Phone Number Locator
// Feb 22, 2015 
// Problem Statement: Problem is that we have to ask user to enter a phone number in the format 'ddd-ddd-dddd' where d is a number. 
//                    Then we have to take th area code and find from where in Canada the person is calling from. 
//					  Also, when the person enters 'q', the program should terminate.
//input: Repeatly asks the user for phone numbers untill he or she enter the letter 'q'.
//output: Displays the area code and where the person is calling from
// algorithm
//major variables: Areacode, phonenumber, count;
// assumptions: I will assume the person enters a correct phone number with 10 digits only
//program limitations: The program can only locate phone numbers within Canada
//inline documentation:



#include < iostream >
#include < string > // to use strings
using namespace std;
int main() // defined main
{
	string phonenumber; // declared string phonenumber
	string areacode; // declared string areacode 
int count; // declared int count
	string number1;  // declared string
	string number2;  // declared string
	string number3;  // declared string
	string number4;  // declared string
	string number5;  // declared string
	string number6;  // declared string
	string number7;  // declared string
	string number8;  // declared string
	string number9;  // declared string
	string number10;  // declared string

	cout << "Please enter a phone number in the format 'ddd-ddd-dddd' where 'd' is a digit, when you enter the letter 'q' the program will terminate" << endl; // tells user what to do on screen
	cin >> phonenumber;  // gets phone number from user

	
	areacode = phonenumber.substr( 0, 3 ); // using the subtract function to get the first three digits from the string phonenumber
	
	while (areacode == "q") // checking to see if user enterd letter q
	{ 
		return 1;  // if user enterd letter q then progrm will quit
	} 

	count =0; // setting counter to equal 0

	number1 = phonenumber.substr( 0, 1 ); // getting first digit from phonenumber string
	number2 = phonenumber.substr( 1, 1 );// getting second digit from phonenumber string
	number3 = phonenumber.substr( 2, 2 );// getting third digit from phonenumber string
	
	cout << "you entered " << phonenumber << endl; // shows user what phone number he entered
	
	cout << "The area code being " << areacode << endl; // shows user the area code of the phone number entered



		if (number1 !=  "1" && number1 != "2" && number1 != "3" && number1 != "0" && number1 != "4" && number1 != "5" && number1 != "6" && number1 != "7" && number1 != "8" && number1 != "9" && number1 != "10") // check the first digit to see if its not from from 1 to 10
		{
			cout << "you entered a invalid number " << endl;// tells user that he or she entered a invalid number
		}
		if (number2 != "0" && number2 !=  "1" && number2 != "2" && number2 != "3" && number2 != "4" && number2 != "5" && number2 != "6" && number2 != "7" && number2 != "8" && number2 != "9" && number2 != "10")// check the second digit to see if its not from from 1 to 10
		{
			cout << "you entered a invalid number " << endl;// tells user that he or she entered a invalid number
		}
		if (number3 != "0" && number3 !=  "1" && number3 != "2" && number3 != "3" && number3 != "4" && number3 != "5" && number3 != "6" && number3 != "7" && number3 != "8" && number3 != "9" && number3 != "10")// check the third digit to see if its not from from 1 to 10
		{
			cout << "you entered a invalid number " << endl;// tells user that he or she entered a invalid number
		}
	

	
		while (areacode == "548" || areacode == "249" || areacode == "289" || areacode == "343" || areacode == "365" || areacode == "387" || areacode == "416" || areacode == "437"|| areacode == "519" || areacode == "226" || areacode == "387" || areacode == "416" || areacode == "437"|| areacode == "519" || areacode == "226" || areacode == "613" || areacode == "647" || areacode == "705" || areacode == "742" || areacode == "807" || areacode == "905") // checking area codes
	{
		cout << "The area code you entered is " << areacode << " and belongs to the province Ontario " << endl << endl; // tells user the area code of the phone number and the ontario is the province the call came from
		cout << "Please enter a phone number in the format 'ddd-ddd-dddd' where 'd' is a digit, when you enter the letter 'q' the program will terminate" << endl;// asks user again to enter phone number
		cin >> phonenumber; // user inputs phone number
		areacode = phonenumber.substr( 0, 3 ); // gets first three digits of phone number from string phonenumber
		count++; // counter varirable initialized 
	}

	while (areacode == "639" || areacode == "306") // checking area codes
	{
		cout << "The area code you entered is " << areacode << " and belongs to the province Saskatchewan " << endl << endl; // tells user the area code of the phone number and the Saskatchewan is the province the call came from
		cout << "Please enter a phone number in the format 'ddd-ddd-dddd' where 'd' is a digit, when you enter the letter 'q' the program will terminate" << endl; // asks user again to enter phone number
		cin >> phonenumber;  // user inputs phone number
		areacode = phonenumber.substr( 0, 3 );// gets first three digits of phone number from string phonenumber
		count++; // counter varirable initialized 
	}


	while (areacode == "403" || areacode == "587" || areacode == "780" || areacode == "825")
	{
		cout << "The area code you entered is " << areacode << " and belongs to the province Alberta " << endl << endl;
		cout << "Please enter a phone number in the format 'ddd-ddd-dddd' where 'd' is a digit, when you enter the letter 'q' the program will terminate" << endl;
		cin >> phonenumber; 
		areacode = phonenumber.substr( 0, 3 );
		count++;
	}


	while (areacode == "236" || areacode == "250" || areacode == "604" || areacode == "742" || areacode == "778")
	{
		cout << "The area code you entered is " << areacode << " and belongs to the province British Columbia " << endl << endl;
		cout << "Please enter a phone number in the format 'ddd-ddd-dddd' where 'd' is a digit, when you enter the letter 'q' the program will terminate" << endl;
		cin >> phonenumber; 
		areacode = phonenumber.substr( 0, 3 );
		count++;
	}

	while (areacode == "204" || areacode == "431")
	{
		cout << "The area code you entered is " << areacode << " and belongs to the province Manitoba " << endl << endl;
		cout << "Please enter a phone number in the format 'ddd-ddd-dddd' where 'd' is a digit, when you enter the letter 'q' the program will terminate" << endl;
		cin >> phonenumber; 
		areacode = phonenumber.substr( 0, 3 );
		count++;
	}

	while (areacode == "506")
	{
		cout << "The area code you entered is " << areacode << " and belongs to the province New Brunswick " << endl << endl;
		cout << "Please enter a phone number in the format 'ddd-ddd-dddd' where 'd' is a digit, when you enter the letter 'q' the program will terminate" << endl;
		cin >> phonenumber; 
		areacode = phonenumber.substr( 0, 3 );
		count++;
	}

	while (areacode == "709")
	{
		cout << "The area code you entered is " << areacode << " and belongs to the province New Foundland and Labrador " << endl << endl;
		cout << "Please enter a phone number in the format 'ddd-ddd-dddd' where 'd' is a digit, when you enter the letter 'q' the program will terminate" << endl;
		cin >> phonenumber; 
		areacode = phonenumber.substr( 0, 3 );
		count++;
	}

	while (areacode == "782" || areacode == "902")
	{
		cout << "The area code you entered is " << areacode << " and belongs to the province Nova Scotia " << endl << endl;
		cout << "Please enter a phone number in the format 'ddd-ddd-dddd' where 'd' is a digit, when you enter the letter 'q' the program will terminate" << endl;
		cin >> phonenumber; 
		areacode = phonenumber.substr( 0, 3 );
		count++;
	}

	while (areacode == "782" || areacode == "902")
	{
		cout << "The area code you entered is " << areacode << " and belongs to the province Prince Edward Island " << endl << endl;
		cout << "Please enter a phone number in the format 'ddd-ddd-dddd' where 'd' is a digit, when you enter the letter 'q' the program will terminate" << endl;
		cin >> phonenumber; 
		areacode = phonenumber.substr( 0, 3 );
		count++;
	}

	while (areacode == "418" || areacode == "438" || areacode == "450" || areacode == "514" || areacode == "579" || areacode == "581" || areacode == "819" || areacode == "873")
	{
		cout << "The area code you entered is " << areacode << " and belongs to the province Quebec " << endl << endl;
		cout << "Please enter a phone number in the format 'ddd-ddd-dddd' where 'd' is a digit, when you enter the letter 'q' the program will terminate" << endl;
		cin >> phonenumber; 
		areacode = phonenumber.substr( 0, 3 );
		count++;
	}

	while (areacode == "867")
	{
		cout << "The area code you entered is " << areacode << " and belongs to the Yukon or Northwest Territories, or Nunavut " << endl << endl;
		cout << "Please enter a phone number in the format 'ddd-ddd-dddd' where 'd' is a digit, when you enter the letter 'q' the program will terminate" << endl;
		cin >> phonenumber; 
		areacode = phonenumber.substr( 0, 3 );
		count++;
	}

	return 0; // end of program
}

	