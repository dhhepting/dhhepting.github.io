//**************************************************************************
//
// Student name: Zackary Hubelit
//
// Student number: 200351286 
//
// Assignment number: 2
//
// Program name: Phone Number and Area Code detector
//
// Date written: Feb. 18th / 15
//
// Problem statement: Take a phone number input from the user and display the correct area code. continue to loop this process until the user inputs the letter 'q'
//
// Input: User will input a phone number in the format ddd-ddd-dddd where d is a digit.
//
// Output: The program will tell the user which province the area code of that phone number is from, and then ask for another one.
//
// Algorithm: uses if statements to decide which province the phone number is from
//
// Major variables: number - the phone number that the user inputs
//
// Assumptions: The user doesn't input any letters into the phone number, only integers.
//
// Program limitations: Can not handle letters where there are supposed to be numbers.
//
//**************************************************************************


#include <iostream>
#include <string>

using namespace std;

string number;

int main()
{
input:
	cout << "Please enter a phone number in the format (ddd-ddd-dddd), where d is a digit." << endl;
	cout << "Phone number: ";
	cin >> number;

	if (number.substr(0,1) == "q")
	{
		cout << "Goodbye!" << endl;
		return 0;
	}

	if (number.length() > 12 || number.length() < 12 || number.substr(2,3) != "-" || number.substr(6,7) != "-")
	{
		cout << "That is an incorrect format, please try again." << endl;
		cout << " " << endl;
		goto input;
	}

	if (number.length() == 12)
	{
		cout << "That is a valid phone number." << endl;

		if (number.substr(0, 3) == "403" || number.substr(0, 3) == "587" || number.substr(0, 3) == "780" || number.substr(0, 3) == "825")
		{
			cout << "That phone number has an Alberta area code!" << endl;
		}

		if (number.substr(0, 3) == "236" || number.substr(0, 3) == "250" || number.substr(0, 3) == "604" || number.substr(0, 3) == "672" || number.substr(0, 3) == "778")
		{
			cout << "That phone number has a British columbia area code!" << endl;
		}

		if (number.substr(0, 3) == "204" || number.substr(0, 3) == "431")
		{
			cout << "That phone number has a Manitoba area code!" << endl;
		}

		if (number.substr(0, 3) == "506")
		{
			cout << "That phone number has a New Brunswick area code!" << endl;
		}

		if (number.substr(0, 3) == "709")
		{
			cout << "That phone number has a Newfoundland and Labrador area code!" << endl;
		}

		if (number.substr(0, 3) == "782" || number.substr(0, 3) == "902")
		{
			cout << "That phone number has a Nova Scotia area code!" << endl;
		}

		if (number.substr(0, 3) == "548" || number.substr(0, 3) == "249" || number.substr(0, 3) == "289" || number.substr(0, 3) == "343" || number.substr(0, 3) == "365" || number.substr(0, 3) == "387" ||  number.substr(0, 3) == "416" ||  number.substr(0, 3) == "437" ||  number.substr(0, 3) == "519" ||  number.substr(0, 3) == "226" ||  number.substr(0, 3) == "613" || number.substr(0, 3) == "647" || number.substr(0, 3) == "705" || number.substr(0, 3) == "742" || number.substr(0, 3) == "807" ||  number.substr(0, 3) == "905")
		{
			cout << "That phone number has an Ontario area code!" << endl;
		}

		if (number.substr(0, 3) == "782" || number.substr(0, 3) == "902")
		{
			cout << "That phone number has a Prince Edward Island area code!" << endl;
		}

		if (number.substr(0, 3) == "418" || number.substr(0, 3) == "438" || number.substr(0, 3) == "450" || number.substr(0, 3) == "514" || number.substr(0, 3) == "579" || number.substr(0, 3) == "581" || number.substr(0, 3) == "819" || number.substr(0, 3) == "873")
		{
			cout << "That phone number has a Quebec area code!" << endl;
		}

		if (number.substr(0, 3) == "306" || number.substr(0, 3) == "639")
		{
			cout << "That phone number has a Saskatchewan area code!" << endl;
		}

		if (number.substr(0, 3) == "867")
		{
			cout << "That phone number has a Yukon, Northweast Territories, or Nunavut area code!" << endl;
		}

		goto input;
	}
	return 0;
}