// Shyla Christie
// SID: 200337036
// Assignment #2
// phonenumber
// Date: FEburary 24th, 2015

#include <iostream>
#include <string>
using namespace std;

int main()
{
	string phoneNum;

	cout << "Please enter a phone number in the form ddd-ddd-dddd: " << endl;
	cin >> phoneNum;

	while (phoneNum.length() == 12 || phoneNum[3] == '-' || phoneNum[7] == '-')
	{
		if (phoneNum.at(0) == '3' && phoneNum.at(1) == '0' && phoneNum.at(2) == '6')
		{
			cout << "That area code is from Saskatchewan" << endl;
		}
		else if (phoneNum.at(0) == '6' && phoneNum.at(1) == '3' && phoneNum.at(2) == '9')
		{
			cout << "That area code is from Saskatchewan" << endl;
		}
		else if (phoneNum.at(0) == '8' && phoneNum.at(1) == '6' && phoneNum.at(2) == '7')
		{
			cout << "That area code is from Nunavut/ Yukon/ Northwest Territories" << endl;
		}
		else if (phoneNum.at(0) == '4' && phoneNum.at(1) == '0' && phoneNum.at(2) == '3')
		{
			cout << "That area code is from Alberta" << endl;
		}
		else if (phoneNum.at(0) == '5' && phoneNum.at(1) == '8' && phoneNum.at(2) == '7')
		{
			cout << "That area code is from Alberta" << endl;
		}
		else if (phoneNum.at(0) == '7' && phoneNum.at(1) == '8' && phoneNum.at(2) == '0')
		{
			cout << "That area code is from Alberta" << endl;
		}
		else if (phoneNum.at(0) == '8' && phoneNum.at(1) == '2' && phoneNum.at(2) == '5')
		{
			cout << "That area code is from Alberta" << endl;
		}
		else if (phoneNum.at(0) == '2' && phoneNum.at(1) == '3' && phoneNum.at(2) == '6')
		{
			cout << "That area code is from British Columbia" << endl;
		}
		else if (phoneNum.at(0) == '2' && phoneNum.at(1) == '5' && phoneNum.at(2) == '0')
		{
			cout << "That area code is from British Columbia" << endl;
		}
		else if (phoneNum.at(0) == '6' && phoneNum.at(1) == '0' && phoneNum.at(2) == '4')
		{
			cout << "That area code is from British Columbia" << endl;
		}
		else if (phoneNum.at(0) == '6' && phoneNum.at(1) == '7' && phoneNum.at(2) == '2')
		{
			cout << "That area code is from British Columbia" << endl;
		}
		else if (phoneNum.at(0) == '7' && phoneNum.at(1) == '7' && phoneNum.at(2) == '8')
		{
			cout << "That area code is from British Columbia" << endl;
		}
		else if (phoneNum.at(0) == '2' && phoneNum.at(1) == '0' && phoneNum.at(2) == '4')
		{
			cout << "That area code is from Manitoba" << endl;
		}
		else if (phoneNum.at(0) == '4' && phoneNum.at(1) == '3' && phoneNum.at(2) == '1')
		{
			cout << "That area code is from Manitoba" << endl;
		}
		else if (phoneNum.at(0) == '5' && phoneNum.at(1) == '0' && phoneNum.at(2) == '6')
		{
			cout << "That area code is from New Brunswick" << endl;
		}
		else if (phoneNum.at(0) == '7' && phoneNum.at(1) == '0' && phoneNum.at(2) == '9')
		{
			cout << "That area code is from Newfoundland and Labrador" << endl;
		}
		else if (phoneNum.at(0) == '7' && phoneNum.at(1) == '8' && phoneNum.at(2) == '2')
		{
			cout << "That area code is from Nova Scotia/ Prince Edward Island" << endl;
		}
		else if (phoneNum.at(0) == '9' && phoneNum.at(1) == '0' && phoneNum.at(2) == '2')
		{
			cout << "That area code is from Nova Scotia/ Prince Edward Island" << endl;
		}
		else if (phoneNum.at(0) == '4' && phoneNum.at(1) == '1' && phoneNum.at(2) == '8')
		{
			cout << "That area code is from Quebec" << endl;
		}
		else if (phoneNum.at(0) == '4' && phoneNum.at(1) == '3' && phoneNum.at(2) == '8')
		{
			cout << "That area code is from Quebec" << endl;
		}
		else if (phoneNum.at(0) == '4' && phoneNum.at(1) == '5' && phoneNum.at(2) == '0')
		{
			cout << "That area code is from Quebec" << endl;
		}
		else if (phoneNum.at(0) == '5' && phoneNum.at(1) == '1' && phoneNum.at(2) == '4')
		{
			cout << "That area code is from Quebec" << endl;
		}
		else if (phoneNum.at(0) == '5' && phoneNum.at(1) == '7' && phoneNum.at(2) == '9')
		{
			cout << "That area code is from Quebec" << endl;
		}
		else if (phoneNum.at(0) == '5' && phoneNum.at(1) == '8' && phoneNum.at(2) == '1')
		{
			cout << "That area code is from Quebec" << endl;
		}
		else if (phoneNum.at(0) == '8' && phoneNum.at(1) == '1' && phoneNum.at(2) == '9')
		{
			cout << "That area code is from Quebec" << endl;
		}
		else if (phoneNum.at(0) == '8' && phoneNum.at(1) == '7' && phoneNum.at(2) == '3')
		{
			cout << "That area code is from Quebec" << endl;
		}
		else if (phoneNum.at(0) == '5' && phoneNum.at(1) == '4' && phoneNum.at(2) == '8')
		{
			cout << "That area code is from Ontario" << endl;
		}
		else if (phoneNum.at(0) == '2' && phoneNum.at(1) == '4' && phoneNum.at(2) == '9')
		{
			cout << "That area code is from Ontario" << endl;
		}
		else if (phoneNum.at(0) == '2' && phoneNum.at(1) == '8' && phoneNum.at(2) == '9')
		{
			cout << "That area code is from Ontario" << endl;
		}
		else if (phoneNum.at(0) == '3' && phoneNum.at(1) == '4' && phoneNum.at(2) == '3')
		{
			cout << "That area code is from Ontario" << endl;
		}
		else if (phoneNum.at(0) == '3' && phoneNum.at(1) == '6' && phoneNum.at(2) == '5')
		{
			cout << "That area code is from Ontario" << endl;
		}
		else if (phoneNum.at(0) == '3' && phoneNum.at(1) == '8' && phoneNum.at(2) == '7')
		{
			cout << "That area code is from Ontario" << endl;
		}
		else if (phoneNum.at(0) == '4' && phoneNum.at(1) == '1' && phoneNum.at(2) == '6')
		{
			cout << "That area code is from Ontario" << endl;
		}
		else if (phoneNum.at(0) == '4' && phoneNum.at(1) == '3' && phoneNum.at(2) == '7')
		{
			cout << "That area code is from Ontario" << endl;
		}
		else if (phoneNum.at(0) == '5' && phoneNum.at(1) == '1' && phoneNum.at(2) == '9')
		{
			cout << "That area code is from Ontario" << endl;
		}
		else if (phoneNum.at(0) == '2' && phoneNum.at(1) == '2' && phoneNum.at(2) == '6')
		{
			cout << "That area code is from Ontario" << endl;
		}
		else if (phoneNum.at(0) == '6' && phoneNum.at(1) == '1' && phoneNum.at(2) == '3')
		{
			cout << "That area code is from Ontario" << endl;
		}
		else if (phoneNum.at(0) == '6' && phoneNum.at(1) == '4' && phoneNum.at(2) == '7')
		{
			cout << "That area code is from Ontario" << endl;
		}
		else if (phoneNum.at(0) == '7' && phoneNum.at(1) == '0' && phoneNum.at(2) == '5')
		{
			cout << "That area code is from Ontario" << endl;
		}
		else if (phoneNum.at(0) == '7' && phoneNum.at(1) == '4' && phoneNum.at(2) == '2')
		{
			cout << "That area code is from Ontario" << endl;
		}
		else if (phoneNum.at(0) == '8' && phoneNum.at(1) == '0' && phoneNum.at(2) == '7')
		{
			cout << "That area code is from Ontario" << endl;
		}
		else if (phoneNum.at(0) == '9' && phoneNum.at(1) == '0' && phoneNum.at(2) == '5')
		{
			cout << "That area code is from Ontario" << endl;
		}
		else
		{
			cout << "That area code is not from Canada!" << endl;
		}
		
		cout << "Please enter a phone number in the form ddd-ddd-dddd: " << endl;
		cin >> phoneNum;

	}

	return 0;

}