//**********************************************************************************************
//Mohammed Alzughaibi
// ID : 200289053
// *********************************************************************************************
// Name of the File : Assignment 2
// *********************************************************************************************
// This program will let the user to enter a telephone number in North American Format
// And then will test if the number is in correct format or not and if it is in Canadian format
// Then , the program will display the number and the province name .
//***********************************************************************************************


#include <iostream>
#include <cmath>
#include <cmath>
#include <iomanip>

using namespace std ;

// Program Starts

int main()

{
	
	
	string  PhoneNumber;
    
	cout << " please enter ten digit numbers with the sign (-) , for exampme , ddd-ddd-dddd  " << endl ;
    
	cin  >> PhoneNumber ;
	
	cout << " The number you entered is  :  " << PhoneNumber << endl ;
    
    
	while(PhoneNumber!= "q")
        
        
	{
        
		string area_code =  PhoneNumber.substr(0,3);
        
		
        if(PhoneNumber.length( )< 12 | PhoneNumber.length()>12 | PhoneNumber.at(3)!='-' | PhoneNumber.at(7)!='-')
            
            
			cout << " This is not correct number , please try again  " << endl;
        
		else
            
		{
			
			
			
            if (area_code == "306" ||area_code == "639"  )

			{
				
				cout << " This is Saskatchewan number " << endl;
				
			}
            
			else if ( area_code == "236" || area_code == "250" || area_code == "604"|| area_code == "778" )
                
			{
				
				cout << " This is British Columbia number " << endl;
			}
            
			else if (area_code == "548" ||area_code == "249" || area_code == "289"||area_code == "343"||area_code == "365" ||area_code == "387"|| area_code == "416"||area_code == "437" ||area_code == "519"||area_code == "226"||area_code == "613" ||area_code == "647"||area_code == "705"||area_code == "742" ||area_code == "807"||area_code == "905")
                
			{
				
				cout << " This is Ontario number " << endl;
				
			}
			
			else if (area_code == "418" ||area_code == "438" ||area_code == "450"||area_code == "514"||area_code == "579" ||area_code == "581"||area_code == "819"||area_code == "873")
                
			{
				
				cout << " This is Quebec number " << endl;
				
			}
			
			else if (area_code == "204" ||area_code == "431")
                
			{
				
				cout << " This is  Manitoba number " << endl;
				
			}
			
			
            else if (area_code == "867" ||area_code == "902")

			{
				
				cout << "  This Yukon or Northwest Territories, or  Nunavut number   " << endl;
				
			}
			
			else if (area_code == "782" ||area_code == "902" )
                
			{
				
				cout << " This is Prince Edward Island number  " << endl;
				
			}
			
			
            else if ( area_code == "403" || area_code == "587" || area_code == "780"|| area_code == "825" )

			{
				
				cout << " This is Alberta number " << endl;
				
			}
			
			else if (area_code == "506")
                
			{
				
				cout << " This is New Brunswick number " << endl;
				
			}
			
			else if (area_code == "709")
                
			{
				
				cout << " This is Newfoundland or Labrador number " << endl;
				
			}
			
            else if (area_code == "782" ||area_code == "902")
                
			{
				
				cout << " This is  Nova Scotia number " << endl;
				
			}
			
            
		}
        
        cout << " please enter ten digit numbers with the sign (-) , for exampme , ddd-ddd-dddd   " << endl ;
        
		cin  >> PhoneNumber ;
		
		
	}
	
	cout << " THANK YOU! "<< endl;
    

    return 0;
    
}
// END of PROGRAM