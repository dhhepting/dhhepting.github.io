//**************************************************************************
//
// Student name: Mina GAD
//
// Student number: 200 359 159
//
// Assignment number: 2
//
// Program name: Reading phone number.
//
// Date written: 18 February 2015
//
// Problem statement:  A program that prompts the user to enter a telephone number in the format ddd-ddd-dddd.
//
// Input: user's phone number.
//
// Output: the area corrsponding to the 3 digits.
//
// Algorithm: enter phone number, get the first 3 digits, verify if it is an area code, display the area corrsponding to the digits.
//
// Major variables: phone.
//
// Assumptions: User enters a phone number.
//
// Program limitations: format is ddd-ddd-dddd.
//
//**************************************************************************

#include <iostream>
#include <string>
using namespace std;

int main()
{
	string phone;
	char selection;
	string areaCode;
	int code;

	do
	{
		cout << "Please enter your phone number in the format ddd-ddd-dddd" << endl;
		getline(cin, phone);
		if ((phone.length() != 12) && (phone[0] >= '0') && (phone[0] >= '9') && (phone[3] != '-') && (phone[7] != '-'))
		{

			cout << "sorry wrong format!" << endl;
		}
		else
		{

			areaCode = phone.substr(0, 3);
			code = stoi(areaCode);
			cout << code << endl;

			switch (code)
			{
			case 403:
			case 587:
			case 780:
			case 825:
				cout << "Your province is: Alberta" << endl;
				break;
			case 236:
			case 250:
			case 604:
			case 672:
			case 778:
				cout << "Your province is : British Columbia" << endl;
				break;
			case 204:
			case 431:
				cout << "Your province is : Manitoba" << endl;
				break;
			case 506:
				cout << "Your province is : New Brunswick" << endl;
				break;
			case 709:
				cout << "Your province is : Newfoundland and Labrador" << endl;
				break;
			case 782:
			case 902:
				cout << "Your province is : Nova Scotia or Prince Edward Island" << endl;
				break;
			case 548:
			case 249:
			case 289:
			case 343:
			case 365:
			case 387:
			case 416:
			case 437:
			case 519:
			case 226:
			case 613:
			case 647:
			case 705:
			case 742:
			case 807:
			case 905:
				cout << "Your province is : Ontario" << endl;
				break;
			case 418:
			case 438:
			case 450:
			case 514:
			case 579:
			case 581:
			case 819:
			case 873:
				cout << "Your province is : Quebec" << endl;
				break;
			case 306:
			case 639:
				cout << "Your province is : Saskatchewan" << endl;
				break;
			case 867:
				cout << "Your province is : Yukon, Northwest Territories, or Nunavut" << endl;
				break;
			default:
				cout << "Your phone number does not correspond to any province" << endl;
				break;
			}
			cout << "If you want to exit the program press q " << endl;
			cout << "If you want to proceed press any button " << endl;
			cin >> selection;
		}
	} while (selection != 'q');
	return 0;
}