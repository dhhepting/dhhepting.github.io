//
//
//  Student name: Jessica Shepherd
//  Student number: 200341982
//  Assignment number: Assignment 2
//  Problem name: Where are you in Canada?
//  Date written: February 21, 2015
//  Problem statement: Trying to figure out where you are in Canada based on your area code
//  Input: User inputs their area code
//  Output: Tells you which Province (and sometimes area within Province) in which that area code is located
//  Algorithm: Have the computer go through all the area codes until it comes across the one the user inputed
//  Major variables: All the area codes, and the variable "code"
//  Assumptions: The user puts in an area code that is within Canada and the program tells them the right Province
//  Program limitations: Only works for Canadian area codes, sorry Obama
//
//


#include <iostream>
using namespace std;

int digit1;
int digit2;
int digit3;
int code;
int phonenum;
int main ()

{
     cout << "Please enter in your area code!" << endl;
     cin >> code;
    
    
    if (code == 782 || code == 902)
    {
    cout << "You are located in either Nova Scotia or Prince Edward Island" << endl;
    }

    else if (code == 403)
    {
        cout << "You are located in Southern Alberta" << endl;
    }
    
    else if (code == 587)
    {
        cout << "You are located in Alberta" << endl;
    }
    
    else if (code == 780)
    {
        cout << "You are located in Northern Alberta" << endl;
    }
    
    else if (code == 236)
    {
        cout << "You are located in British Columbia" << endl;
    }
    
    else if (code == 250)
    {
        cout << "You are located in British Columbia, including Vancouver Island" << endl;
    }
    
    else if (code == 604)
    {
        cout << "You are located in the lower mainland of British Columbia" << endl;
    }
    
    else if (code == 778)
    {
        cout << "You are located in the Metro Vancouver and the Fraser Valley Regional District of British Columbia" << endl;
    }
    
    else if (code == 204 || code == 431)
    {
        cout << "You are located in Manitoba" << endl;
    }
    
    else if (code == 506)
    {
        cout << "You are located in New Brunswick" << endl;
    }
    
    else if (code == 709)
    {
        cout << "You are located in Newfoundland and Labrador" << endl;
    }
    
    else if (code == 867)
    {
        cout << "You are located in either Yukon, Nunavut, or the Northwest Territories" <<endl;
    }
    
    else if (code == 306 || code == 639)
    {
        cout << "You are located in Saskatchewan" << endl;
    }
    
    else if (code == 548 || code == 226 || code == 519)
    {
        cout << "You are located in South West Ontario" << endl;
    }
    
    else if (code == 289 || code == 365 || code == 905)
    {
        cout << "You are located in Southern Ontatio" << endl;
    }
    
    else if (code == 647 || code == 416 || code == 437)
    {
        cout << "You are located in Toronto, Ontario" << endl;
    }
    
    else if (code == 613 || code == 343)
    {
        cout << "You are located in either Ottawa, or Eastern Ontario" << endl;
    }
    
    else if (code == 249 || code == 705 || code == 807)
    {
        cout << "You are located in Northern West, or Central Ontario" << endl;
    }
    
    else if (code == 418 || code == 581)
    {
        cout << "You are located in Eastern Quebec" << endl;
    }
    
    else if (code == 438 || code == 514)
    {
        cout << "You are located in either Montréal or the surronding area, in Quebec" << endl;
    }
    
    else if (code == 450 || code == 579)
    {
        cout << "You are located on the off island suburbs of Montréal, Quebec" << endl;
    }
    
    else if (code == 819 || code == 873)
    {
        cout << "You are located in either Central or Western Quebec" << endl;
    }
    
    else if (code == 742 || code == 387 || code == 825 || code == 672)
    {
        cout << "That area code is not in affect yet!" << endl;
    }
    
    else
    {
        cout << "That is not a vaild area code" << endl;
    }
    
    return 0;
}