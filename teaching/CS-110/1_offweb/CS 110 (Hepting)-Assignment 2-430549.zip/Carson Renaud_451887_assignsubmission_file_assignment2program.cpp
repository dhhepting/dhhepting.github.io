//
//**************************************************************************
//
// Student name: Carson Renaud
//
// Student number: 200304106
//
// Assignment number:2
//
// Program name: Phone number areacode identifier
//
// Date written: Febuary 25, 2015
//
// Problem statement: Write a program that prompts the user to enter a telephone number in the format
// ddd-ddd-dddd, where d is digits. This is the format for telephone numbers in North America. Test that
// the input is in the correct format and further check ifthe phone number has a Canadian area code.
// The program will report if the input is valid or not. If the input includes a Canadian area code,
// the program will display the name of the province or territory with that area code. The program
// will continue to process numbers until the user enters the letter q.
//
// Input: Phone Number from user keyboard input.
//
// Output: The areacode if its a canadian number will tell you which province the number came from, and
//  if valid but not canadian areacode will prompt user for a new number, and will exist if invalid input.
//
// Algorithm:Takes the input and test the conditions if it's valid input in the form ddd-ddd-dddd and has
// hyphenses in the correct places,Then processes the input and checks if its a canadian areacode and if
// so details which one.
//
// Major variables: The phonenumber and while loops one controls the exit condition, other validates the
// user input and makes sure it in the proper form, next it takes a sub string of the strings first 3
// digits and tests to see if there
//    a canadian area code.
//
// Assumptions: This will only work for phone numbers in North American form.
//
// Program limitations: Can only handle phone numbers of North American form.
//
//**************************************************************************
//  Created by carson renaud on 2015-02-24.
//  Copyright (c) 2015 carson renaud. All rights reserved.

#include <iostream>
#include <string>

using namespace std;

int main()
{
    string phonenumber,ac, province; // declare phonenumber and area code I short formed it to ac to save space latter
    
    
    cout << "This program will take a phone number and check what province it belongs to" << endl;
    cout << "Please enter a Phone number in the form xxx-xxx-xxxx press q/Q to exit" << endl;
    cin >> phonenumber; // This portion takes the intial user phone number input
    
    while (phonenumber[0] != 'q' && phonenumber [0] != 'Q') // condition exits program
    {
        int count = 0; // intializes the count variable
        bool valid = true; // declares bool and will be used to test the input
        if (phonenumber.length() != 12)// tests the length
        {
            valid = false; // if to long evaluates to false and prompts for a new number
        }
        while (count < phonenumber.length() && valid == true) // loop uses the count to check the digits
        {
            if (count == 3 || count == 7) // this if is used to check for the dashes between numbers
            {
                if (phonenumber[count] != '-') // if the hyphenses are in the incorrect locations then evaluates false a prompts for new input
                    valid = false;
            }
            else
            {
                if(phonenumber[count]<'0' || phonenumber[count] > '9') // checks the conditions in which the values are not between 0&9
                    valid = false;
                
            }
            count++; // count increment
        }
        if (valid == true) // if the proper style of phonenumber is enter this if will be true and execute the code inside the if
        {
            
            ac = phonenumber.substr(0,3); // breaks the phonenumber down into a substring and uses it to find
            // the province this number came from. ac = areacode
            
            if (ac == "306" || ac == "639") // checks the string against each province and tells you which province the number originated from
            {
                province = "Saskatchewan";
                cout << phonenumber << " Has a Candian Area Code " << ac << " And is from " << province << endl;
            }
            else if (ac == "403"|| ac == "587" || ac == "780" || ac == "825")
            {
                province = "Alberta";
                cout << phonenumber << " Has a Candian Area Code " << ac << " And is from " << province << endl;
            }
            else if (ac == "236" || ac == "250" || ac == "604" || ac == "672" || ac == "778")
            {
                province = "British Columbia";
                cout << phonenumber << " Has a Candian Area Code " << ac << " And is from " << province << endl;
            }
            else if (ac == "204" || ac == "431")
            {
                province = "Manitoba";
                cout << phonenumber << " Has a Candian Area Code " << ac << " And is from " << province << endl;
            }
            else if (ac == "506")
            {
                province = "New Brunswick";
                cout << phonenumber << " Has a Candian Area Code " << ac << " And is from " << province << endl;
            }
            else if (ac == "709")
            {
                province = "Newfoundland and Labrador";
                cout << phonenumber << " Has a Candian Area Code " << ac << " And is from " << province << endl;
            }
            else if (ac == "782" || ac == "902")
            {
                province = "Nova Scotia";
                cout << phonenumber << " Has a Candian Area Code " << ac << " And is from " << province << endl;
            }
            else if (ac == "548" || ac == "249" || ac == "289" || ac == "343" || ac == "519" || ac == "226")
            {
                province = "Ontario";
                cout << phonenumber << " Has a Candian Area Code " << ac << " And is from " << province << endl;
            }
            else if (ac == "365" || ac == "387" || ac == "416" || ac == "437" || ac == "613" || ac == "647")
            {
                province = "Ontario";
                cout << phonenumber << " Has a Candian Area Code " << ac << " And is from " << province << endl;
            }
            else if (ac == "705" || ac == "742" || ac == "807" || ac == "905")
            {
                province = "Ontario";
                cout << phonenumber << " Has a Candian Area Code " << ac << " And is from " << province << endl;
            }
            else if (ac == "782" || ac == "902")
            {
                province = "Prince Edward Island";
                cout << phonenumber << " Has a Candian Area Code " << ac << " And is from " << province << endl;
            }
            else if (ac == "418" || ac == "438" || ac == "450" || ac == "514")
            {
                province = "Quebec";
                cout << phonenumber << " Has a Candian Area Code " << ac << " And is from " << province << endl;
            }
            else if (ac == "579" || ac == "581" || ac == "819" || ac == "873")
            {
                province = "Quebec";
                cout << phonenumber << " Has a Candian Area Code " << ac << " And is from " << province << endl;
            }
            else if (ac == "867")
            {
                province = "Yukon, Northwest Territories, and Nunavut";
                cout << phonenumber << " Has a Candian Area Code " << ac << " And is from " << province << endl;
            }
            else
                cout << "Proper input but not a Canadian areacode " << endl;
            
            
            // this above line will give correct output
            cout << "Please enter another telephone number to test " << endl;
            cin >> phonenumber; // starts the loop again and checks the phone number
            
        }
        else if (valid == false) // if the user has enter input in the wrong form or type this statement will execute
        {
            cout << "Invalid input please enter another telephone number to test " << endl; // invalid input statement
            cin >> phonenumber; // starts the loop again and checks the phone number
        }
        
    }
    
    cout << "q was entered and program exitted" << endl;
    return 0;
    
}

