//
// Student name:Yue Wang
//
// Student number: 200350793
//
// Assignment number: 2
//
// Program name: Assignment 2
//
// Date written: Feb 24th,2015
//
// Problem statement: Figure out whether a phone number belongs to Canadian region.
//
// Input:Phone number in the format of ddd-ddd-dddd
//
// Output:Corresponding area code region.
//
// Algorithm: EOf and if-else statement.
//
// Major variables: string phone_number and area_code.
//
// Assumptions:user follows the ddd-ddd-dddd format.
//
// Program limitations:only showing area code in Canada.
//
//**************************************************************************


#include <iostream> // library that contains basic input output functions

#include <string> // library to use advanced c++ strings

using namespace std;

int main()
{
	string phone_number; //declare 2 variable as string
	string area_code;



	while (phone_number != "q")//testing phase, using boolean expression indicating enters the letter q to exit loop

	{
		cout << "please  enter a telephone number in the format ddd - ddd - dddd,enters the letter q to exit" << endl;//prompt
		cin >> phone_number;//whatever user enters store as phone_number



		if (phone_number[3] == '-' || phone_number[7] == '-' || phone_number[0] >= '0'&&phone_number[0] >= '9')// if-selse statement saying if the phone number is made of digits and there  is a '-' after the 3rd and 7th digit if not, jumps to the else statement
		{

			cout << phone_number << "is a legit phone number" << endl;//if the above statement is true, this is a legit phone number
			cout << "your area code is:" << phone_number.substr(0, 3) << endl;
			string area_code = phone_number.substr(0, 3);//take the first 3 digits of 'phone_number' as 'area_code'
			if (area_code == "403" || area_code == "587" || area_code == "780" || area_code == " 825")//if-else statement eliminate the possible area code starting from alberta
			{
				cout << area_code << " Is a Area Code of Alberta" << endl;//if the area code matches the area is alberta and ignore all other 'else if'
			}
			else if (area_code == "236" || area_code == "250" || area_code == "604" || area_code == "672" || area_code == "778")
			{
				cout << area_code << " Is a Area code of British Columbia" << endl;//if the area code does matches the area in alberta goes to  other 'else if'
			}
			else if (area_code == "418" || area_code == "438" || area_code == "450" || area_code == "514" || area_code == "579" || area_code == "581" || area_code == "819" || area_code == "873")
			{
				cout << area_code << " Is a Area code of Quebec" << endl;//repeat all the other statement if the above ones does not match your area code
			}
			else if (area_code == "204" || area_code == "432")
			{
				cout << area_code << " Is a Area code of Manitoba" << endl;

			}
			else if (area_code == "506")
			{
				cout << area_code << " Is a Area code of New Brunswick" << endl;

			}
			else if (area_code == "709")
			{
				cout << area_code << " Is a Area code of Newfoundland and Labradora" << endl;

			}
			else if (area_code == "548" || area_code == "249" || area_code == "289" || area_code == "343" || area_code == "365" || area_code == "387" || area_code == "416" || area_code == "437" || area_code == "519" || area_code == "226" || area_code == "613" || area_code == "647" || area_code == "705" || area_code == "742" || area_code == "807" || area_code == "905")
			{
				cout << area_code << " Is a Area code of Ontario" << endl;
			}
			else if (area_code == "782" || area_code == "902")
			{
				cout << area_code << " Is a Area code of Nova Scotia/Prince Edward Island" << endl;


			}
			else if (area_code == "306" || area_code == "639")
			{
				cout << area_code << " Is a Area code of Saskatchewan" << endl;


			}
			else if (area_code == "867")
			{
				cout << area_code << " Is a Area code of Yukon, Northwest Territories, and Nunavut" << endl;


			}
			else
			{
				cout << "This is not a Canadian phone number, please double check." << endl;//if none of the above area code matches
			}
		}
		else
		{
			cout << "This is not  proper format" << endl;// if the inut does not match the ddd-ddd-dddd format
		}





	}
	return 0;
}

