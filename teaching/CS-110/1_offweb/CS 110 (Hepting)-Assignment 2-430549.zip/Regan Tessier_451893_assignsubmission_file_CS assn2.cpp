//**************************************************************************
//
// Student name:Regan Tessier
//
// Student number: 200300419	
//
// Assignment number: 2
//
// Program name: Identifying the province through the use of an inputted area code
//
// Date written: February 17 2015
//
// Problem statement: Identify the province that corresponds to the inputed area code
//
// Input: Phone number
//
// Output:Where the area code of the number corresponds too -invalid number if the number is to long or short
//
// Algorithm: Use while statement to introduce q so program knows when to quit. Use a boolean variable to ensure the length and format of number is the one asked.IF length, and format are correct program continues and reads out the province to respond to area code. If format or length is not correct, computer blows up.
//
// Major variables: Number, areacode
//
// Assumptions:There is at present no area code longer than three digits and will continue to have no area code longer
//
// Program limitations:Too three digit area code.
//
//**************************************************************************
#include <iostream>
#include <string>
using namespace std;

int main()
{

	string number;

	while (number != "q")
	{
		cout << "Input a phone number in the format of ###-###-#### to find out where it's from. Press q to exit the program. Or don't, stay in here for the rest of your life for all I care" << endl;
		cin >> number;
		cout << endl;

		if (number == "q")
			return 0;

		bool lengthgood = number.length() == 12;

		if (lengthgood)
		{
			bool hyphenworks = number.at(3) == '-';
			bool hyphenworks2 = number.at(7) == '-';
			if (hyphenworks && hyphenworks2 && lengthgood)
			{
				string areacode = number.substr(0, 3);
				if (areacode == "403" || areacode == "587" || areacode == "780" || areacode == "825")
				{
					cout << "You have entered a number with a Alberta areacode" << endl;
					cout << endl;
				}
				else if (areacode == "236" || areacode == "250" || areacode == "604" || areacode == "672" || areacode == "778")
				{
					cout << "You have entered a number with a  British Columbia area code" << endl;
					cout << endl;
				}
				else if (areacode == "204" || areacode == "431")
				{
					cout << "You have entered a number with a Manitoban area code" << endl;
					cout << endl;
				}
				else if (areacode == "506")
				{
					cout << "You have entered a number with a New Brunswick area code" << endl;
					cout << endl;
				}
				else if (areacode == "709")
				{
					cout << "You have entered a number with a Newfoundland and Labrador area code" << endl;
					cout << endl;
				}
				else if (areacode == "782" || areacode == "902")
				{
					cout << "You have entered a number with a Nova Scotia area code" << endl;
					cout << endl;
				}
				else if (areacode == "548" || areacode == "249" || areacode == "289" || areacode == "343" || areacode == "365" || areacode == "387" || areacode == "416" || areacode == "437" || areacode == "619" || areacode == "226" || areacode == "613" || areacode == "647" || areacode == "705" || areacode == "742" || areacode == "807" || areacode == "905")
				{
					cout << "You have entered a number with a Ontario area code" << endl;
					cout << endl;
				}
				else if (areacode == "782" || areacode == "902")
				{
					cout << "You have entered a number with a Prince Edward Island area code" << endl;
					cout << endl;
				}
				else if (areacode == "418" || areacode == "438" || areacode == "450" || areacode == "514" || areacode == "579" || areacode == "581" || areacode == "819" || areacode == "873")
				{
					cout << "You have entered a number with a  Quebec area code" << endl;
					cout << endl;
				}
				else if (areacode == "306" || areacode == "639")
				{
					cout << "You have entered a number with a Saskatchewan area code" << endl;
					cout << endl;
				}
				else if (areacode == "867")
				{
					cout << "You have an areacode that is in Yukon, Northwest Territories,Nunavut" << endl;
					cout << endl;
				}
				else
				{
					cout << "Unfortunately we do not know this area code... ET" << endl << endl;
					cout << endl;
				}

			}
			else
			{
				cout << "Invalid number";
				cout << endl;
			}
		}
		else
		{
			cout << "Invalid number" << endl << endl;
		}
		}


}
