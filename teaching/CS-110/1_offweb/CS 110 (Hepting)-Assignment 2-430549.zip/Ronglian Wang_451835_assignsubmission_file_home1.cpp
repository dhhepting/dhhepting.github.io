//******************************************************************
//
//Student name: Ronglian Wang
//
//Student number: 200269662
//
//Assignment number: 2
//
//Program name: Checking phonenumbers  
//
//Date written: 2015-02-23
//
//Problem statement:  Checking the phonenumbers
//
//Input: ddd-ddd-dddd
//
//Output: Telling where the phonenumber from
//
//Algorithm: string, char,boolean, while loop, if statement
//
//Major variables: phoneNumber,chars
//
//Assumptions: 
//
//Program limitations: Only takes correct formats
//
//*********************************************************************




#include <iostream>
#include<string>
using namespace std;

int main()
{	// get a phonenumber from user.
	cout << "enter a phone number, like 306-580-0000 " << endl<<endl;

	string phoneNumber = " ";
	cin >> phoneNumber; 

	string quit = "q";
	// uging while loop to run the code until 'q' is entered.
	while (phoneNumber != quit)
	{// set char variables
		char c= phoneNumber.at(3);
		char d = phoneNumber.at(7);
		char e = phoneNumber.at(0);
		char f = phoneNumber.at(1);
		char g = phoneNumber.at(2);
		char h = phoneNumber.at(4);
		char i = phoneNumber.at(5);
		char j = phoneNumber.at(6);
		char k = phoneNumber.at(8);
		char l = phoneNumber.at(9);
		char m = phoneNumber.at(10);
		char n = phoneNumber.at(11);
		// set and get area code
		string number = phoneNumber.substr(0, 3);
		// set comparing conditions
		if (phoneNumber.length() != 12 || c != '-' || d != '-' || (e>'9' || e<'0') || (f>'9' || f<'0') || (g>'9' || g<'0') || (h>'9' || h<'0') ||
			(i>'9' || i<'0') || (j>'9' || j<'0') || (k>'9' || k<'0') || (l>'9' || l<'0') || (m>'9' || m<'0') || (n>'9' || n<'0'))

		{ 
			cout << "Wrong format" << endl<<endl;

		}
		
			else if (number == "306" || number == "639")
				cout << "Saskatchewan" << endl<<endl;

			else if (number == "403" || number == "587" || number == "780" || number == "825")
				cout << "Alberta" <<endl<< endl;

			else if (number == "236" || number == "250" || number == "604" || number == "672" || number == "778")
				cout << "British Columbia" << endl<<endl;

			else if (number == "506")
				cout << "New Brunswick" <<endl<< endl;

			else if (number == "709")
				cout << "Newfoundland and Labrador" <<endl<< endl;

			else if (number == "782" || number == "902")
				cout << "Nova Scotia" <<endl<< endl;

			else if (number == "548 || number == 249" || number == "289" || number == "343" || number == "365" || number == "387" || number == "416" || number == "437"
				|| number == "519" || number == "226" || number == "613" || number == "647" || number == "705" || number == "742" || number == "807" || number == "905")
				cout << "Ontario" <<endl<< endl;

			else if (number == "782" || number == "902")
				cout << "Prince Edear Island" <<endl<< endl;

			else if (number == "418" || number == "438" || number == "450" || number == "514" || number == "579" || number == "581" || number == "819" || number == "873")
				cout << "Quebed" <<endl<< endl;

			else if (number == "867")
				cout << "Yukon,Northwest Territories and Nunauvt" <<endl<< endl;
			else
				cout << "The number is not from Canada " <<endl<< endl;
		
		cout << "enter another number" << endl<<endl;
		cout << "or enter 'q' to quit " <<endl<< endl;
		cin >> phoneNumber;
	}


	cout << "Thanks" << endl;
	return 0;


}

















