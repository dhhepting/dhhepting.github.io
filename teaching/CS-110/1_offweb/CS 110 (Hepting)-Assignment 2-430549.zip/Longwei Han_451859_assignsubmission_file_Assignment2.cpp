//**************************************************************************
//
// Student name: Longwei Han
//
// Student number: 200313136
//
// Assignment number: num2
//
// Program name: Telphone
//
// Date written: 24 Feb 2015
//
// Problem statement: Write a program that prompts the user to enter a telephone number in the format ddd-ddd-dddd
//
// Input: telphone number with format ddd-ddd-dddd, where d is digit.
//
// Output: the areacode in the Canada with number.
//
// Algorithm: First we need to enter 12 digits telphone number.
//			  The program will report if the input is valid or not.
//			  If the input includes a Canadian area code, the program will display the name of the provinc or territory with that area code.
//			  The program will continue to process numbers until the user enters the letter q.
//
// Major variables: areacode, tele1, tele2,telephonenumber
//
// Assumptions: we assume user input number.
//
// Program limitations:  it works only with 10 digits telephonenumbers, and only output the Canadian areacode,
//                       if the input is not belong to Canada or different form as north America phonenumber form, the program will report that. 
//**************************************************************************
#include <iostream>
#include <string>
using namespace std;

int main()
{
	string telephonenumber;
	cout << "Please enter in your telephone number in the form (ddd-ddd-dddd), if you wish to quit, prise q : " << endl;
	cin >> telephonenumber;
	while (telephonenumber != "q")
	{
		cout << "You entered: " << telephonenumber;
		string areacode = telephonenumber.substr(0, 3);
		string tele1 = telephonenumber.substr(4, 3);
		string tele2 = telephonenumber.substr(8, 4);
		if (areacode >= "000" && areacode <= "999"&&tele1 >= "000"&&tele1 <= "999"&&tele2 >= "0000"&&tele2 <= "9999"&&telephonenumber[3] == '-'&&telephonenumber[7] == '-'&&telephonenumber.length() == 12)
		{
			if (areacode == "403" || areacode == "587" || areacode == "780" || areacode == "825")
			{
				cout << "Alberta" << endl;
			}
			else if (areacode == "236" || areacode == "250" || areacode == "604" || areacode == "672" || areacode == "778")
			{
				cout << "British Columbia" << endl;
			}
			else if (areacode == "204" || areacode == "431")
			{
				cout << "Manitoba" << endl;
			}
			else if (areacode == "506")
			{
				cout << "New Brunswick" << endl;
			}
			else if (areacode == "709")
			{
				cout << "Newfoundland and Labrador" << endl;
			}
			else if (areacode == "782" || areacode == "902")
			{
				cout << "Nova Scotia" << endl;
			}
			else if (areacode == "548" || areacode == "249" || areacode == "289" || areacode == "343" || areacode == "365" || areacode == "387" || areacode == "416" || areacode == "437" || areacode == "519" || areacode == "226" || areacode == "613" || areacode == "647" || areacode == "705" || areacode == "742" || areacode == "807" || areacode == "905")
			{
				cout << "Ontario" << endl;
			}
			else if (areacode == "782" || areacode == "902")
			{
				cout << "Prince Edward Island" << endl;
			}
			else if (areacode == "418" || areacode == "438" || areacode == "450" || areacode == "514" || areacode == "579" || areacode == "581" || areacode == "819" || areacode == "873")
			{
				cout << "Quebec" << endl;
			}
			else if (areacode == "306" || areacode == "639")
			{
				cout << "Saskatchewan" << endl;
			}
			else if (areacode == "867")
			{
				cout << "Yukon, Northwest Territories, and Nunavut" << endl;
			}
			else
			{
				cout << "This is not a canadian telephonenumber" << endl;
			}
		}
		else
		{
			cout << "It's not a valid telephone number." << endl;
			cout << "Please enter again." << endl;
		}
		cout << "Please enter in your telephone number in the form (ddd-ddd-dddd), if you want to quit, prise q : " << endl;
		cin >> telephonenumber;

	}

	return 0;
}