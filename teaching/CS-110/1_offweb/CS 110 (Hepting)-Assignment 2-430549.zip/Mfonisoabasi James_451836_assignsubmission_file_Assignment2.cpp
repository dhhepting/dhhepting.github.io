/*
Name: Mfonisoabasi James
Student number: 200344498
Assignment 2
Program name: Assignment2.cpp
Date written: 2/25/2015
Problem statement: This program displays the Province assigned to the area code of a telephone number in Canada
Input: cin
Output: cout
Algorithm: 1. declare a string and character variable for the telephone number and the letter 'q'
           2. prompt the user to enter phone number
           3. create a while loop to test the input format entered by the user
           4. create a do while loop that re runs the program until the user ends it by inputing 'q'
           5. if phone number falls within provided area code, province belonging to that area code will be displayed
Major variables: 1. number
		         2. letter
Assumptions: The assumption made is that the user would input number with respective dashes as shown in format
Program limitations: The algorithm doesn't restrict the user from inputing number in place of the dashes
*/
#include <iostream> 
#include <string> 
using namespace std;
int main()
{
	string number;  //declaring variables 
	char letter;

	do  //creating a do while loop to re run the program until user terminates it
	{
		cout << "please enter telephone number in the format 'ddd-ddd-dddd':" << endl;  //prompting the user for input
		cin >> number;  //reads users input
		while (number.length() != 12)  //a while loop to test the input format of the user when its incorrect
		{
			cout << "Number format incorrect!!!" << endl;
			cout << "Please enter number with correct format: ";
			cin >> number;
		}
		string areaCode = number.substr(0, 3);  //a substr the picks the first 3 digits (area code) of the number

		if (areaCode == "403" || areaCode == "578" || areaCode == "780" || areaCode == "825")   //an if and else if statement to check the province of the area code
		{
			cout << "The area code of the number belongs to Alberta.\n";
		}

		else if (areaCode == "236" || areaCode == "250" || areaCode == "604" || areaCode == "672" || areaCode == "778")
		{
			cout << "The area code of the number belongs to British Columbia.\n";
		}
		else if (areaCode == "204" || areaCode == "431")
		{
			cout << "The area code of the number belongs to Manitoba.\n";
		}
		else if (areaCode == "506")
		{
			cout << "The area code of the number belongs to New Brunswick.\n";
		}
		else if (areaCode == "709")
		{
			cout << "The area code of the number belongs to Newfoundland and Labrador.\n";
		}
		else if (areaCode == "782" || areaCode == "902")
		{
			cout << "The area code of the number belongs to Nova Scotia.\n";
		}
		else if (areaCode == "548" || areaCode == "249" || areaCode == "289" || areaCode == "343" || areaCode == "365" || areaCode == "387" || areaCode == "416" || areaCode == "437" || areaCode == "519" || areaCode == "226" || areaCode == "613" || areaCode == "647" || areaCode == "705" || areaCode == "742" || areaCode == "807" || areaCode == "905")
		{
			cout << "The area code of the number belongs to Ontario.\n";
		}
		else if (areaCode == "782" || areaCode == "902")
		{
			cout << "The area code of the number belongs to Prince Edward Island.\n";
		}
		else if (areaCode == "418" || areaCode == "438" || areaCode == "450" || areaCode == "514" || areaCode == "579" || areaCode == "581" || areaCode == "819" || areaCode == "873")
		{
			cout << "The area code of the number belongs to Quebec.\n";
		}
		else if (areaCode == "306" || areaCode == "639")
		{
			cout << "The area code of the number belongs to Saskatchewan.\n";
		}
		else if (areaCode == "867")
		{
			cout << "The area code of the number belongs to Yukon, Northwest Territories, and Nunavut.\n";
		}
		
		//an else if statement that handles codes not within Canada
		else if (areaCode != "403" || areaCode != "587" || areaCode != "780" || areaCode != "825" || areaCode != "236" || areaCode != "250" || areaCode != "604" || areaCode != "672" || areaCode != "778" || areaCode != "204" || areaCode != "431" || areaCode != "506" || areaCode != "709" || areaCode != "782" || areaCode != "902" || areaCode != "548" || areaCode != "249" || areaCode != "289" || areaCode != "343" || areaCode != "365" || areaCode != "387" || areaCode != "416" || areaCode != "437" || areaCode != "519" || areaCode != "226" || areaCode != "613" || areaCode != "647" || areaCode != "705" || areaCode != "742" || areaCode != "807" || areaCode != "905" || areaCode != "782" || areaCode != "902" || areaCode != "418" || areaCode != "438" || areaCode != "450" || areaCode != "514" || areaCode != "579" || areaCode != "581" || areaCode != "819" || areaCode != "873" || areaCode != "306" || areaCode != "639" || areaCode != "867")
		{
			cout << "Sorry area code isn't within Canada" << endl;
		}

		cout << "Enter 'q' to quit the program or any letter to continue: ";
		cin >> letter;
	} while (letter != 'q');  //a while loop that terminates the program if user inputs letter 'q'

	return 0;
}