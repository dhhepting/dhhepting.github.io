
//**************************************************************************
//
// Student name: Ashlyn Heintz
//
// Student number: 200287036
//
// Assignment number: Assignment 2
//
// Program name: C++ 
//
// Date written: February 25, 2015
//
// Problem statement: To enter a ten digit phone number and find whether it has a Canadian area code
//
// Input: 10 digit phone number
//
// Output: Whether the area code is in Canada and from what province or territory.
//
// Algorithm: String
//
// Major variables: phonenumber, areacode
//
// Program limitations: The program will only work with a North American phone number
//
//**************************************************************************

#include <iostream>
#include <string>
using namespace std;

int main()
{
	//Ask the user to input a phone number 
	string phonenumber;
	cout << "please enter a 10 digit phone number in the form ddd-ddd-dddd: ";
	cin >> phonenumber;

	//Find whether the phonenumber is an areacode in Canada and if it is, what province/territory
	string areacode = phonenumber.substr(0, 3);

	if (areacode == "403" || areacode == "587" || areacode == "780" || areacode == "825")
	{
		cout << areacode << " is an area code in Alberta, Canada" << endl;
	}
	else if (areacode == "236" || areacode == "250" || areacode == "604" || areacode == "672" || areacode == "778")
	{
		cout << areacode << " is an area code in British Columbia, Canada" << endl;
	}
	else if (areacode == "204" || areacode == "431")
	{
		cout << areacode << " is an area code in Manitoba, Canada" << endl;
	}
	else if (areacode == "506")
	{
		cout << areacode << " is an area code in New Brunswick, Canada" << endl;
	}
	else if (areacode == "709")
	{
		cout << areacode << " is an area code in Newfoundland and Labrador, Canada" << endl;
	}
	else if (areacode == "782" || areacode == "902")
	{
		cout << areacode << " is an area code in Nova Scotia, Canada" << endl;
	}
	else if (areacode == "548" || areacode == "249" || areacode == "289" || areacode == "343" ||
		areacode == "365" || areacode == "387" || areacode == "416" || areacode == "437" || areacode == "519"
		|| areacode == "226" || areacode == "613" || areacode == "647" || areacode == "705" || areacode == "742"
		|| areacode == "807" || areacode == "905")
	{
		cout << areacode << " is an area code in Ontario, Canada" << endl;
	}
	else if (areacode == "782" || areacode == "902")
	{
		cout << areacode << " is an area code in Prince Edward Island, Canada" << endl;
	}
	else if (areacode == "418" || areacode == "438" || areacode == "450" || areacode == "514" ||
		areacode == "579" || areacode == "581" || areacode == "819" || areacode == "873")
	{
		cout << areacode << " is an area code in Quebec, Canada" << endl;
	}
	else if (areacode == "306" || areacode == "639")
	{
		cout << areacode << " is an area code in Saskatchewan, Canada" << endl;
	}
	else if (areacode == "867")
	{
		cout << areacode << " is an area code in the Territories, Canada " << endl;
	}

	// Put a comment if the area code is not in Canada
	else if
			(areacode != "403" || areacode != "587" || areacode != "780" || areacode != "825" ||
			areacode != "236" || areacode != "250" || areacode != "604" || areacode != "672" ||
			areacode != "778" || areacode != "204" || areacode != "431" || areacode != "506" ||
			areacode != "709" || areacode != "782" || areacode != "902" || areacode != "548" ||
			areacode != "249" || areacode != "289" || areacode != "343" || areacode != "365" ||
			areacode != "387" || areacode != "416" || areacode != "437" || areacode != "519" ||
			areacode != "226" || areacode != "613" || areacode != "647" || areacode != "705" ||
			areacode != "742" || areacode != "807" || areacode != "905" || areacode != "782" ||
			areacode != "902" || areacode != "418" || areacode != "438" || areacode != "450" ||
			areacode != "514" || areacode != "579" || areacode != "581" || areacode != "819" ||
			areacode != "873" || areacode != "306" || areacode != "639" || areacode != "867")
		{
			cout << areacode << " area code is not in Canada!" << endl;
		}
		
	return 0;
}
