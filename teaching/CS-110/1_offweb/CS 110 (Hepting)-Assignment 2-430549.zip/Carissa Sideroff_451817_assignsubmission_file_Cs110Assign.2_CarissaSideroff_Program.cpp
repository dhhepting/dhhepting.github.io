/*
 Carissa Sideroff
 200348410
 Assignment 2
 Area Code
 Feb 24th , 2015
 Problem: User enters phone number, after checking you output what province or territory they are from.
 The program ends when the user hits q.
 
 Major variable include if statements and strings, i use cout and cin for input and output
 
 Limitations include : if they enter an invalid number after the area code... what if the number does not actually exist.. we have no way of checking it we are just tell them where the area code is from
 */


#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

int main()
{
string phonenumber;
    string areacode;
    cout << " Please enter a phone number in the format ddd-ddd-dddd, where d is a digit. " << endl;// ask for digits in
    //correct format

    cin >> phonenumber; //define phonenumber

    string::size_type length;
    length = phonenumber.length();// making sure length is tweleve
    
    if (length == 12)
    {
    if (phonenumber.at(3) == '-' || phonenumber.at(7) == '-')
    {
    areacode = phonenumber.substr(0,3);// get the first three digits.. which would be the area code and see where they are from
    if (areacode == "403" || areacode == "587" || areacode =="780" || areacode == "825")
        cout << " This is from Alberta! " << endl;
    if (areacode == "236" || areacode == "250" || areacode == "604" ||  areacode == "672" || areacode == "778")
        cout << " This is from British Columbia! " << endl;
    if (areacode == "204" || areacode == "431'")
        cout << "This is from Manitoba!" << endl;
    if (areacode == "506" )
        cout << " This is New Brunswick! " << endl;
    if (areacode == "709")
        cout << " This is from Newfoundland and Labradour!" << endl;
    if (areacode == "782" || areacode == "902" )
        cout << " This is from Nova Scotia!" << endl;
    if (areacode == "548" || areacode == "249" || areacode == "289" || areacode == "343" || areacode == "365" || areacode == "387" || areacode == "416" || areacode == "437" || areacode == "519" || areacode == "226" || areacode == "613" || areacode == "647" || areacode == "705" || areacode == "742" || areacode == "807" || areacode == "905" )
        cout << " This is from Ontario!" << endl;
    if (areacode == "782" || areacode == "902" )
        cout << " This is from Prince Edward Island!" << endl;
    if (areacode == "418" || areacode == "438" || areacode == "450" || areacode == "514" || areacode == "579" || areacode == "581" || areacode == "819" || areacode == "873" )
        cout << "This is from Quebec!" << endl;
    if (areacode == "306" || areacode == "639")
        cout << " This is from Saskatchewan!" << endl;
    if (areacode == "867")
        cout << " This is from Yukon, Northwest Territories and Nunuvat! " << endl;
     }
         else
            cout << " sorry, Not in Canada!" << endl;
    }
else
    cout << " Sorry, you have enetered an invald phone number! " << endl;
// if the area code is not one of the previous if statements it is invalid

    return 0;
}