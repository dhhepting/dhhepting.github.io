// Student Name: Joshua Ajakaiye
// Student Number: 200348270
// Assignment number: two
// Program Name: CanadianPhoneNumbers
// Date Written: 25th February 2015
// 
// Problem statement: This program takes in phone numbers of Canadians to determine 
//                    what province it is associated with
// input: persons Canadian phone number (Cfonenum) 'q' to quit the program
// ouput: province associated with phone number 
// algorithm: use do while loop for the 'q' quit statement.
//            ask the user for their phone number. error check
#include<iostream>
#include<string>
using namespace std;

int main()
{
	string Cfonenum;   // string declaration for the phone number entry
	char letter = 0;   // declare character letter for the 'q' quit statement

	// do while loop to check for q statement
	do
	{
		// prompt the user to input his/her phone number in the format ddd-ddd-dddd
		cout << "Please enter your telephone number in this format ddd-ddd-dddd: " << endl;
		cin >> Cfonenum;

		// error checking the input
		if (Cfonenum.length() == '12')
		{
			if (Cfonenum.at(3) == '-' && Cfonenum.at(7) == '-')

				cout << "correct input." << endl;
			cout << endl;

			if (Cfonenum.at(3) != '-' && Cfonenum.at(7) != '-')
			{
				cout << "Wrong input... Canadian only" << endl;
			}

			else
				cout << "wrong input.. " << endl;
		}

		// selecting the first three digits with the substring function
		string areacode = Cfonenum.substr(0, 3);

		// if statement for checking areacode
		if (areacode == "408" || areacode == "587" || areacode == "780" || areacode == "825")
		{
			cout << "The province with this area code is: " << "Alberta" << endl;
		}
		else
			if (areacode == "236" || areacode == "250" || areacode == "604" || areacode == "672" || areacode == "778")
			{
			cout << "The province with this area code is: " << "British Columbia" << endl;
			}
			else
				if (areacode == "204" || areacode == "431")
				{
			cout << "The province with this area code is: " << "Manitoba" << endl;
				}
				else
					if (areacode == "506")
					{
			cout << "The province with this area code is: " << "New Brunswick" << endl;
					}
					else
						if (areacode == "709")
						{
			cout << "The province with this area code is: " << "Newfoundland and Labrador" << endl;
						}
						else
							if (areacode == "782" || areacode == "902")
							{
			cout << "The province with this area code is: " << "Nova Scotia" << endl;
							}
							else
								if (areacode == "548" || areacode == "249" || areacode == "289" || areacode == "343" || areacode == "365" || areacode == "387" || areacode == "416" || areacode == "437" || areacode == "519" || areacode == "226" || areacode == "613" || areacode == "647" || areacode == "705" || areacode == "742" || areacode == "807" || areacode == "905")
								{
			cout << "The province with this area code is: " << "Onatario" << endl;
								}
								else
									if (areacode == "782" || areacode == "902")
									{
			cout << "The province with this area code is: " << "Prince Edward island" << endl;
									}
									else
										if (areacode == "418" || areacode == "438" || areacode == "450" || areacode == "514" || areacode == "579" || areacode == "581" || areacode == "819" || areacode == "873")
										{
			cout << "The Province with this area code is: " << "Quebec" << endl;
										}
										else
											if (areacode == "306" || areacode == "639")
											{
			cout << "The province with this area code is: " << "Saskatchewan" << endl;
											}
											else
												if (areacode == "867")
												{
			cout << "The province with this area code is: " << "Yukon, Northwest Territories, and Nunavut" << endl;
												}
		cout << "press q to quit the program: ";
		cin >> letter;

	} while (letter != 'q');

	return 0;

}


