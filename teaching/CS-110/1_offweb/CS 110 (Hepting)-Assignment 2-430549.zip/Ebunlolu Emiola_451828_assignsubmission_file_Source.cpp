//**************************************************************************
//
// Student name: EMIOLA EBUNLOLU
//
// Student number: 200348870
//
// Assignment number: CS 110Assignment #2
//
// Program name: phonenumber.cpp
//
// Date written: 25/02/2015
//
// Problem statement: write a program that prompt user to enter a phone number in the format ddd-ddd-dddd, where d is a digit.
// Input: a string variable  
//        

// Output: result is phone number is from canada

// Main algorithm: Ask user to enter phone number
//                    check phone number format
//                    check phone number for pronvince
//                    print results
// Major variables: phoneNumber
//
// Program limitations: - hardcoded for checking phone numbers for canada province
//
//**************************************************************************



#include <iostream> //needed for console input and output
#include <string> // needed for string operations
#include <cctype> //needed for correctness of format.

using namespace std;

int main() // start program
{
	string phoneNumber; // declare a string for phone number
	do //using a do-while statement ask user to enter phone number, store in the variable *phoneNumber*, and, check for correct format, if format is wrong, reprompt user to enter phonenumber again until user gets it right.
	{
		cout << "Please enter phone number in the format: ***-***-****  " << endl;
		cout << "For example, 306-647-8769 . User must include *hyphens(-)*." << endl;
		cout << "Enter 'q' to exit the program." << endl;
		cin >> phoneNumber;
		if (phoneNumber.length() > 12)
			cout << "Phone number is greater than 12 characters"<<endl;
		else if (phoneNumber.length() < 12)
			cout << "Phone number is less than 12 characters" << endl;
		else if ((phoneNumber[3] == '-') && (phoneNumber[7] == '-'))
			cout << "The third and sevennth character should be a hyphen " << endl;
		else if (!(isdigit(phoneNumber[0]) && isdigit(phoneNumber[1]) && isdigit(phoneNumber[2]) && isdigit(phoneNumber[4]) && isdigit(phoneNumber[5]) && isdigit(phoneNumber[6]) && isdigit(phoneNumber[8]) && isdigit(phoneNumber[9]) && isdigit(phoneNumber[10]) && isdigit(phoneNumber[11])))
			cout << "Check that all characters except third and sevventh are digits between 0 and 9" << endl;
	} while (!((phoneNumber.length() == 12) && (phoneNumber[3] == '-') && (phoneNumber[7] == '-') && isdigit(phoneNumber[0]) && isdigit(phoneNumber[1]) && isdigit(phoneNumber[2]) && isdigit(phoneNumber[4]) && isdigit(phoneNumber[5]) && isdigit(phoneNumber[6]) && isdigit(phoneNumber[8]) && isdigit(phoneNumber[9]) && isdigit(phoneNumber[10]) && isdigit(phoneNumber[11]) && phoneNumber != "q"));
	//cross check first three digit of phone number from canada's provincial area codes.
	// if the first three digit matches any area code, print that area code as result, else, phone number is not from canada.
	if (phoneNumber[0] == '4' && phoneNumber[1] == '0' && phoneNumber[2] == '3')
		cout << "Phone number is from Alberta Canada" << endl;
	else if (phoneNumber[0] == '5' && phoneNumber[1] == '8' && phoneNumber[2] == '7')
		cout << "Phone number is from Alberta Canada" << endl;
	else if (phoneNumber[0] == '7' && phoneNumber[1] == '8' && phoneNumber[2] == '0')
		cout << "Phone number is from Alberta Canada" << endl;
	else if (phoneNumber[0] == '2' && phoneNumber[1] == '3' && phoneNumber[2] == '6')
		cout << "Phone number is from British Columbia" << endl;
	else if (phoneNumber[0] == '6' && phoneNumber[1] == '0' && phoneNumber[2] == '4')
		cout << "Phone number is from British Columbia" << endl;
	else if (phoneNumber[0] == '2' && phoneNumber[1] == '5' && phoneNumber[2] == '0')
		cout << "Phone number is from British Columbia" << endl;
	else if (phoneNumber[0] == '7' && phoneNumber[1] == '7' && phoneNumber[2] == '8')
		cout << "Phone number is from British Columbia" << endl;
	else if (phoneNumber[0] == '2' && phoneNumber[1] == '0' && phoneNumber[2] == '4')
		cout << "Phone number is from Manitoba" << endl;
	else if (phoneNumber[0] == '4' && phoneNumber[1] == '3' && phoneNumber[2] == '1')
		cout << "Phone number is from Manitoba" << endl;
	else if (phoneNumber[0] == '5' && phoneNumber[1] == '0' && phoneNumber[2] == '6')
		cout << "Phone number is from New Brunswick" << endl;
	else if (phoneNumber[0] == '7' && phoneNumber[1] == '0' && phoneNumber[2] == '9')
		cout << "Phone number is from Newfoundland" << endl;
	else if (phoneNumber[0] == '8' && phoneNumber[1] == '6' && phoneNumber[2] == '7')
		cout << "Phone number is from Northwest Territories" << endl;
	else if (phoneNumber[0] == '9' && phoneNumber[1] == '0' && phoneNumber[2] == '2')
		cout << "Phone number is from Nova Scotia" << endl;
	else if (phoneNumber[0] == '8' && phoneNumber[1] == '6' && phoneNumber[2] == '7')
		cout << "Phone number is from Nunavut" << endl;
	else if (phoneNumber[0] == '2' && phoneNumber[1] == '2' && phoneNumber[2] == '6')
		cout << "Phone number is from Ontario" << endl;
	else if (phoneNumber[0] == '2' && phoneNumber[1] == '4' && phoneNumber[2] == '9')
		cout << "Phone number is from Ontario" << endl;
	else if (phoneNumber[0] == '2' && phoneNumber[1] == '8' && phoneNumber[2] == '9')
		cout << "Phone number is from Ontario" << endl;
	else if (phoneNumber[0] == '3' && phoneNumber[1] == '4' && phoneNumber[2] == '3')
		cout << "Phone number is from Ontario" << endl;
	else if (phoneNumber[0] == '3' && phoneNumber[1] == '6' && phoneNumber[2] == '5')
		cout << "Phone number is from Ontario" << endl;
	else if (phoneNumber[0] == '4' && phoneNumber[1] == '1' && phoneNumber[2] == '6')
		cout << "Phone number is from Ontario" << endl;
	else if (phoneNumber[0] == '4' && phoneNumber[1] == '3' && phoneNumber[2] == '7')
		cout << "Phone number is from Ontario" << endl;
	else if (phoneNumber[0] == '5' && phoneNumber[1] == '1' && phoneNumber[2] == '9')
		cout << "Phone number is from Ontario" << endl;
	else if (phoneNumber[0] == '6' && phoneNumber[1] == '1' && phoneNumber[2] == '3')
		cout << "Phone number is from Ontario" << endl;
	else if (phoneNumber[0] == '6' && phoneNumber[1] == '4' && phoneNumber[2] == '7')
		cout << "Phone number is from Ontario" << endl;
	else if (phoneNumber[0] == '7' && phoneNumber[1] == '0' && phoneNumber[2] == '5')
		cout << "Phone number is from Ontario" << endl;
	else if (phoneNumber[0] == '8' && phoneNumber[1] == '0' && phoneNumber[2] == '7')
		cout << "Phone number is from Ontario" << endl;
	else if (phoneNumber[0] == '9' && phoneNumber[1] == '0' && phoneNumber[2] == '5')
		cout << "Phone number is from Ontario" << endl;
	else if (phoneNumber[0] == '4' && phoneNumber[1] == '1' && phoneNumber[2] == '8')
		cout << "Phone number is from Quebec" << endl;
	else if (phoneNumber[0] == '4' && phoneNumber[1] == '3' && phoneNumber[2] == '8')
		cout << "Phone number is from Quebec" << endl;
	else if (phoneNumber[0] == '4' && phoneNumber[1] == '5' && phoneNumber[2] == '0')
		cout << "Phone number is from Quebec" << endl;
	else if (phoneNumber[0] == '4' && phoneNumber[1] == '1' && phoneNumber[2] == '4')
		cout << "Phone number is from Quebec" << endl;
	else if (phoneNumber[0] == '5' && phoneNumber[1] == '7' && phoneNumber[2] == '9')
		cout << "Phone number is from Quebec" << endl;
	else if (phoneNumber[0] == '5' && phoneNumber[1] == '8' && phoneNumber[2] == '1')
		cout << "Phone number is from Quebec" << endl;
	else if (phoneNumber[0] == '8' && phoneNumber[1] == '1' && phoneNumber[2] == '9')
		cout << "Phone number is from Quebec" << endl;
	else if (phoneNumber[0] == '8' && phoneNumber[1] == '7' && phoneNumber[2] == '3')
		cout << "Phone number is from Quebec" << endl;
	else if (phoneNumber[0] == '3' && phoneNumber[1] == '0' && phoneNumber[2] == '6')
		cout << "Phone number is from Saskatchewan" << endl;
	else if (phoneNumber[0] == '6' && phoneNumber[1] == '3' && phoneNumber[2] == '9')
		cout << "Phone number is from Saskatchewan" << endl;
	else if (phoneNumber[0] == '8' && phoneNumber[1] == '6' && phoneNumber[2] == '7')
		cout << "Phone number is from Yukon" << endl;
	else if (phoneNumber == "q")
	{
		cout << "Closing program. exiting..." << endl;
		return 1;
	}
	else
		cout << "Phone number is not from Canada" << endl;
return 0; //end program
}