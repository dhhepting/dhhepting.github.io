/*
Student name: Philipp Maxeiner
Student number: 200343181
Assignment number: 2
Program name: Area Code detector
Date Written: February 2015
Problem Statement: Determine the north american area code that a user inputs
Input: Some telephone number in the form of (ddd-ddd-dddd)
Output: Output the province from which the area code originates
Algorithm: A loop style program that performs the task until the user enters 'q'
Major Variables: telNum, code
Assumptions: The user will enter a North American telephone number
Program Limitations: The prgram will only be able to comprehend area codes from Canada
*/

#include <iostream>
#include <string>
#include <sstream>

using namespace std;
int main()

{

// We want this program to act as a conditional loop
// When the user enters 'q', the program should close

/*
// Declare 'q' as false
bool q = false
while (true)
{
*/
// Declare telNum as a string
string telNum;

// Request input of a valid phone number
cout << "Please type in a valid phone number from North America (ddd-ddd-dddd): " << endl;
cin >> telNum;

// Test input to determine if it is valid
if (telNum.length() == 12)
	cout << "Valid North American telephone number has been entered." << endl;
else if (telNum.length() != 12)
	cout << "Invalid phone number." << endl;

// Determine the area code entered by the user
// The area code will always be the first three characters in the string

// int code = atoi(telNum.c_str(0, 2));

int atoi( const char * telNum );
cout << telNum << endl;

int code;
code = (telNum.at(0) && telNum.at(1) && telNum.at(2));
cout << code << endl;
cout << "The area code of the entered number is: " << telNum.at(0);
cout << telNum.at(1) << telNum.at(2) << endl;
if (code == 403 || code == 587 || code == 780 || code == 825)
    cout << "Alberta" << endl;
if (code == 236 || code == 250 || code == 604 || code == 672 || code == 778)
    cout << "British Columbia" << endl;
if (code == 204 || code == 431)
    cout << "Manitoba" << endl;
if (code == 506)
    cout << "New Brunswick" << endl;
if (code == 709)
    cout << "Newfoundland and Labrador" << endl;
if (code == 782 || code == 902)
    cout << "Nova Scotia" << endl;
if (code == 548 || code == 249 || code == 289 || code == 343 || code == 365)
	cout << "Ontario" << endl;
if (code == 387 || code == 416 || code == 437 || code == 519 || code == 226)
	cout << "Ontario" << endl;
if (code == 613 || code == 647 || code == 705 || code == 742 || code == 807 || code == 905)
	cout << "Ontario" << endl;
if (code == 782 || code == 902)
	cout << "Prince Edward Island" << endl;
if (code == 418 || code == 438 || code == 450 || code == 514)
	cout << "Quebec" << endl;
if (code == 579 || code == 581 || code == 819 || code == 873)
	cout << "Quebec" << endl;
if (code == 306 || code == 639)
	cout << "Saskatchewan" << endl;
if (code == 867) 
	cout << "Yukon, Northwest Territories, and Nunavut" << endl;



return 0;
}