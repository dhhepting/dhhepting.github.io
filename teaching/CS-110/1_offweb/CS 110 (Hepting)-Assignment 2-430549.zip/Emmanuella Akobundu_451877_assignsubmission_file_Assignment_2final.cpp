//Name: Emmanuella Akobundu
//
//Class: CS 110
//
//Assignment: 2
//
//Student number: 200359057
//
// Program name: Program for determining Canadian area code
//
// Date written: 25th February, 2015
//
// Problem statement: This code is aimed at testing an inputed number to check if it has the correct format and
//					  then displaying the Canadian area code of the phone number.
//
// Input: The user is expected to input a phone number in the format, ddd-ddd-dddd
//
// Output: The output should display the area code of the phone number or an appropriate error message if the format is wrong
//
// Algorithm: In order to solve the assigned problem, the computer is  first instructed to ensure that the number entered
//			  by the user is in the correct format, that is, in the correct length and with the dashes in the appropriate positions and with
//			  all the other characters as digits.
//			  Thereafter, the province wth the area code of the phone number is determined by defining the first three numbers in the input
//			  using string functions. The provinces are then assigned based on this set of numbers using logical operators.
//			  Finally, the program is terminated when the user enters the letter q
//
// Major variables: phone number, code
//
// Limitations: The program cannot determine the locations to which any non-Canadian phone numbers entered belong

#include <iostream>
#include <string>
using namespace std;

int main()
{

	//Ask user to enter a phone number in the format ddd-ddd-dddd
	cout << "Please enter a phone number in the format ddd-ddd-dddd." << endl;
	cout << "Enter q to terminate program." << endl;
	cout << "Phone number: ";
	string phone;
	cin >> phone;


	//Define the first three numbers (area codes) in the phone number
	string code = phone.substr(0, 3);

	//Check if phone number entered is in the correct format
	//Firstly, check that the phone number is 12 characters long
	//Then check if the phone number if the input matches ddd-ddd-dddd by checking if all the 
	//characters are digits except the dashes and if the dashes are in the correct positions.
	//Finally, check if the phone number has a Canadian area code. If it does, display what province it belongs to
	//If any of these are not followed, output the appropriate error message

	if (phone == "q")
		return 0;

	else
		if (phone.length() == 12)

			if (phone[3] == '-' && phone[7] == '-')

				if ((phone[0] >= 0 && phone[0] <= 9) && (phone[1] >= 0 && phone[1] <= 9) && (phone[2] >= 0 && phone[2] <= 9)
					&& (phone[3] >= 0 && phone[3] <= 9) && (phone[4] >= 0 && phone[4] <= 9) && (phone[5] >= 0 && phone[5] <= 9)
					&& (phone[6] >= 0 && phone[6] <= 9) && (phone[7] >= 0 && phone[7] <= 9) && (phone[8] >= 0 && phone[8] <= 9)
					&& (phone[9] >= 0 && phone[9] <= 9))


					if (code == "403" || code == "587" || code == "780" || code == "825")
						cout << "Canadian Area Code: Alberta" << endl;
					else if (code == "236" || code == "250" || code == "604" || code == "672" || code == "778")
						cout << "Canadian Area Code: British Columbia" << endl;
					else if (code == "204" || code == "431")
						cout << "Canadian Area Code: Manitoba" << endl;
					else if (code == "506")
						cout << "Canadian Area Code: New Brunswick" << endl;
					else if (code == "709")
						cout << "Canadian Area Code: Newfoundland and Labrador" << endl;
					else if (code == "782" || code == "902")
						cout << "Canadian Area Code: Nova Scotia and Prince Edward Island" << endl;
					else if (code == "548" || code == "249" || code == "289" || code == "343" || code == "365" || code == "387"
						|| code == "416" || code == "437" || code == "519" || code == "226" || code == "613" || code == "647"
						|| code == "705" || code == "742" || code == "807" || code == "905")
						cout << "Canadian Area Code: Ontario" << endl;
					else if (code == "418" || code == "438" || code == "450" || code == "514" || code == "579" || code == "581"
						|| code == "819" || code == "873")
						cout << "Canadian Area Code: Quebec" << endl;
					else if (code == "306" || code == "639")
						cout << "Canadian Area Code: Saskatchewan" << endl;
					else if (code == "867")
						cout << "Canadian Area Code: Yukon, Northwest Territories, and Nunavut" << endl;
					else
						cout << "This phone number does not have a valid Canadain area code." << endl;


				else
					cout << "Not all the characters in the phone number are digits. Please try again!" << endl;


			else
				cout << "Check the position of your dashes. Please make sure the format of the number is ddd-ddd-dddd." << endl;


		else
			cout << "The phone number is not 12 characters long as required. Please try again!" << endl;


	return 0;

}