//**************************************************************************
//
// Student name: Olivia Philippon
//
// Student number: 200294151
//
// Assignment number: 2
//
// Program name: Assignment2
//
// Date written: Feb. 17, 2015
//
// Problem statement: Write a code that allows the user to enter a phone number. The user must know that the phone number has to be entered in
// the format ddd-ddd-dddd. The program must check to make sure that what the user has entered it in this correct format;
// the number must contain hyphens and digits in the correct places. Based on the phone number entered by the user, the program
// must find the area code location if the phone number is from Canada. If at any time the number entered is not from Canada, the 
// program will indicate that the number is not from Canada. The program must continue by allowing the user to enter 
// phone numbers and find their Canadian area code location until the user no longer wishes to do so. In this case, the user has been 
// notified that they may enter q at any time during the program in order to exit. 
//
// Input: A phone number, containing digits and hyphens, in the format ddd-ddd-dddd.
//
// Output: The region of the area code in Canada. 
//
// Algorithm: I will instruct the user to enter a phone number in the correct format. I will provide an example of the format so the user 
// understands. A loop is created so that if the user enters "q" at any time, the program will stop. If they do not enter "q", the 
// program will continue to check the input that is entered. It begins by checking length of the phone number. If the number length is incorrect
// the program will notify the user that the length is invalid. If the length is correct, the program will check each digit to make sure 
// that they are within the rango of 0 to 9; this eliminates the possbility of the input being another character. Each number is 
// checked for hyphens and correct placement. If these conditions are true, then the if statement containing all of the Canadian 
// area codes will be executed. The first three digits of the phone number will be assessed for their area code location. If the
// area code is not contained in the listed Canadian ones, it will tell the user that the area code is not from Canada.
//
// Major variables: The phone number is a major variable. This contains the main digits that will be assessed within the program. 
// 
// Assumptions: That the user doesn't enter an international number with a 1 in front. We also assume that the user is looking for a Canadian
// phone number area code. 
//
// Program limitations: If the phone number entered is too long or too short, it does not tell the user this specific problem. It only notifies
// the user that it is an incorrect length. The area codes do not tell the user where in each province or territory that the number 
// originates. The area codes for Prince Edward Island and Nova Scotia are the same; the program cannot indicate exactly which province the 
// number is from in this case. If the user enters an area code that does not classify as being from Canada, the program does not tell the user
// where the area code is from. It is also possible that the user entered a nonexistant area code but the program does not 
// notify the user of this. It only says that the area code is not from Canada. 
//
//**************************************************************************
#include <iostream>
#include <string>
using namespace std;
int main()
{
	//We need to create the phone number as a string variable so that it can include both digits and dashes.
	string phoneNumber;
	//This is the beginning of the loop. If the user does not eneter q, the loop will begin and the program will do what it is supposed to do.
	while (phoneNumber != "q")
	{
		cout << "Please enter a phone number in the format ddd-ddd-dddd. If you wish to quit the program at any time, please enter q." << endl;
		cin >> phoneNumber;
		//The loop will end at any time if the user enters q instead of a phone number.
		if (phoneNumber == "q")
			return 0;

		//This checks the length of the input.
		bool lengthGood = phoneNumber.length() == 12;

		//If the length is good, the program will check the phone number. 
		if (lengthGood)
		{
			//The program checks each hyphen and digit at all locations of the input. 
			bool hyphen1Good = phoneNumber.at(3) == '-';
			bool hyphen2Good = phoneNumber.at(7) == '-';
			bool firstDigit = (phoneNumber.at(0) >= '0' && phoneNumber.at(0) <= '9');
			bool secondDigit = (phoneNumber.at(1) >= '0' && phoneNumber.at(1) <= '9');
			bool thirdDigit = (phoneNumber.at(2) >= '0' && phoneNumber.at(2) <= '9');
			bool fourthDigit = (phoneNumber.at(4) >= '0' && phoneNumber.at(4) <= '9');
			bool fifthDigit = (phoneNumber.at(5) >= '0' && phoneNumber.at(5) <= '9');
			bool sixthDigit = (phoneNumber.at(6) >= '0' && phoneNumber.at(6) <= '9');
			bool seventhDigit = (phoneNumber.at(8) >= '0' && phoneNumber.at(8) <= '9');
			bool eightDigit = (phoneNumber.at(9) >= '0' && phoneNumber.at(9) <= '9');
			bool ninthDigit = (phoneNumber.at(10) >= '0' && phoneNumber.at(10) <= '9');
			bool tenthDigit = (phoneNumber.at(11) >= '0' && phoneNumber.at(11) <= '9');
			
			//The program will indicate to the user if they have made a mistake in entering a digit or hyphen. It will indicate which part 
			// is invalid. 
			if (firstDigit)
				cout << "The first digit is valid." << endl;
			else
				cout << "The first digit is invalid." << endl;
			if (secondDigit)
				cout << "The second digit is valid." << endl;
			else
				cout << "The second digit is invalid." << endl;
			if (thirdDigit)
				cout << "The third digit is valid." << endl;
			else
				cout << "The third digit is invalid." << endl;
			if (hyphen1Good)
				cout << "The first hyphen is valid." << endl;
			else
				cout << "The first hyphen is invalid" << endl;
			if (fourthDigit)
				cout << "The fourth digit is valid." << endl;
			else
				cout << "The fourth digit is invalid." << endl;
			if (fifthDigit)
				cout << "The fifth digit is valid." << endl;
			else
				cout << "The fifth digit is invalid." << endl;
			if (sixthDigit)
				cout << "The sixth digit is valid." << endl;
			else
				cout << "The sixth digit is invalid." << endl;
			if (hyphen2Good)
				cout << "The second hyphen is valid." << endl;
			else
				cout << "The second hyphen is invalid." << endl;
			if (seventhDigit)
				cout << "The seventh digit is valid." << endl;
			else
				cout << "The seventh digit is invalid." << endl;
			if (eightDigit)
				cout << "The eigth digit is valid." << endl;
			else
				cout << "The eight digit is invalid." << endl;
			if (ninthDigit)
				cout << "The ninth digit is valid." << endl;
			else
				cout << "The ninth digit is invalid." << endl;
			if (tenthDigit)
				cout << "The tenth digit is valid." << endl;
			else
				cout << "The tenth digit is invalid." << endl;
			//If all of the previous conditions are true (the length is good, all digits and hyphens are correct) then the program will continue 
			// to check the area code of the number to see where it originates in Canada. 
			if (lengthGood && firstDigit && secondDigit && thirdDigit && hyphen1Good && fourthDigit && fifthDigit && sixthDigit && hyphen2Good && seventhDigit && eightDigit && ninthDigit && tenthDigit)
			{
				cout << "Thanks for entering the correct format, we can continue now." << endl;
				//This substring allows the program to check only part of the phone number. We are able to check the first three digits of the number,
				// the area code, and indicate where the phone number is in Canada based on this. 
				string areaCode = phoneNumber.substr(0, 3);
				if (areaCode == "403" || areaCode == "587" || areaCode == "780" || areaCode == "825")
				{
					cout << "The number you have entered is from Alberta." << endl;
				}
				else if (areaCode == "236" || areaCode == "250" || areaCode == "604" || areaCode == "672" || areaCode == "778")
				{
					cout << "The number you have entered is from British Columbia." << endl;
				}
				else if (areaCode == "204" || areaCode == "431")
				{
					cout << "The number you have entered is from Manitoba." << endl;
				}
				else if (areaCode == "506")
				{
					cout << "The number you have entered is from New Brunswick" << endl;
				}
				else if (areaCode == "709")
				{
					cout << "The number you have entered is from Newfoundland and Labrador" << endl;
				}
				else if (areaCode == "782" | areaCode == "902")
				{
					cout << "The number you have entered is from Nova Scotia or Prince Edward Island" << endl;
				}
				else if (areaCode == "548" || areaCode == "249" || areaCode == "289" || areaCode == "343" || areaCode == "365" || areaCode == "387" || areaCode == "416" || areaCode == "437" || areaCode == "519" || areaCode == "226" || areaCode == "613" || areaCode == "647" || areaCode == "705" || areaCode == "742" || areaCode == "807" || areaCode == "905")
				{
					cout << "The number you have entered is from Ontario" << endl;
				}
				else if (areaCode == "306" | areaCode == "639")
				{
					cout << "The number you have entered is from Saskatchewan" << endl;
				}
				else if (areaCode == "867")
				{
					cout << "The number you have entered is from the Yukon, Northwest Territories, or Nunavut" << endl;
				}
				else
				{
					cout << "Sorry, the area code that you have entered is not from Canada." << endl;
				}
				cout << endl;
			}
			//There is something wrong in the phone number entered. 
			else
			{
				cout << "Invalid phone number." << endl;
				cout << endl;
			}
		}
		//The length is invalid.
		else
		{
			cout << "Invalid phone number." << endl;
			cout << endl;
		}
	}
}