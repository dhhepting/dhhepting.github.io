// Name: Maxx Hordichuk
// Student Number: 200353849
// Assignment: 2
// Program Name: Canadian Phone Number Checker
// Date: 02/22/15
/* Problem: Write a program that prompts the user to enter a telephone number in the format ddd-ddd-dddd, where d is digit.
Test that the input is in the correct format and further check if the phone number has a Canadian area code.
The program will report if the input is valid or not. If the input includes a Canadian area code, the program will display the name of the province or territory with that area code.
The program will continue to process numbers until the user enters the letter q. */
// Input: Phone number (in the form of three separate integers) and a command to continue or end the program.
// Output: Statement of whether the number is valid or not and if the number belongs to a province or a non-Canadian number.
/* Algorithm: Ask for number -> receive number -> determine whether number is valid (Canadian OR Non-Canadian) or invalid ->
display result -> ask if user wants to continue -> end program OR continue. */
// Major Variables: tele1, tele2, tele3, str
// Assumptions: User will follow the initial instruction regarding the format of the phone number.
// Program Limits: Encounters infinite loop if letters are in-putted instead of numbers. Cannot compute correctly if dashes are not used as asked.

#include <iostream>
#include <string>

using namespace std;

int main()
{

	string str;

	// Initiate loop.

	do {

		// Ask for and receive number.

		cout << "Please enter a telephone number in the format ddd-ddd-dddd (where d is a digit):" << endl;

		int tele1;
		int tele2;
		int tele3;

		cin >> tele1 >> tele2 >> tele3;

		// Determine validity/Canadian status and output result.

		if (tele1 <= 999 && tele1 >= 100 && tele2 >= -999 && tele2 <= -100 && tele3 >= -9999 && tele3 <= -1000)
		{
			switch (tele1)
			{
			case 403: cout << "Input valid. Alberta area code." << endl;
				break;
			case 587: cout << "Input valid. Alberta area code." << endl;
				break;
			case 780: cout << "Input valid. Alberta area code." << endl;
				break;
			case 825: cout << "Input valid. Alberta area code." << endl;
				break;
			case 236: cout << "Input valid. BC area code." << endl;
				break;
			case 250: cout << "Input valid. BC area code." << endl;
				break;
			case 604: cout << "Input valid. BC area code." << endl;
				break;
			case 672: cout << "Input valid. BC area code." << endl;
				break;
			case 778: cout << "Input valid. BC area code." << endl;
				break;
			case 204: cout << "Input valid. Manitoba area code." << endl;
				break;
			case 431: cout << "Input valid. Manitoba area code." << endl;
				break;
			case 506: cout << "Input valid. New Brunswick area code." << endl;
				break;
			case 709: cout << "Input valid. Newfoundland/Labrador area code." << endl;
				break;
			case 782: cout << "Input valid. Nova Scotia/PEI area code." << endl;
				break;
			case 902: cout << "Input valid. Nova Scotia/PEI area code." << endl;
				break;
			case 548: cout << "Input valid. Ontario area code." << endl;
				break;
			case 249: cout << "Input valid. Ontario area code." << endl;
				break;
			case 289: cout << "Input valid. Ontario area code." << endl;
				break;
			case 343: cout << "Input valid. Ontario area code." << endl;
				break;
			case 365: cout << "Input valid. Ontario area code." << endl;
				break;
			case 387: cout << "Input valid. Ontario area code." << endl;
				break;
			case 416: cout << "Input valid. Ontario area code." << endl;
				break;
			case 437: cout << "Input valid. Ontario area code." << endl;
				break;
			case 519: cout << "Input valid. Ontario area code." << endl;
				break;
			case 226: cout << "Input valid. Ontario area code." << endl;
				break;
			case 613: cout << "Input valid. Ontario area code." << endl;
				break;
			case 647: cout << "Input valid. Ontario area code." << endl;
				break;
			case 705: cout << "Input valid. Ontario area code." << endl;
				break;
			case 742: cout << "Input valid. Ontario area code." << endl;
				break;
			case 807: cout << "Input valid. Ontario area code." << endl;
				break;
			case 905: cout << "Input valid. Ontario area code." << endl;
				break;
			case 418: cout << "Input valid. Quebec area code." << endl;
				break;
			case 438: cout << "Input valid. Quebec area code." << endl;
				break;
			case 450: cout << "Input valid. Quebec area code." << endl;
				break;
			case 514: cout << "Input valid. Quebec area code." << endl;
				break;
			case 579: cout << "Input valid. Quebec area code." << endl;
				break;
			case 581: cout << "Input valid. Quebec area code." << endl;
				break;
			case 819: cout << "Input valid. Quebec area code." << endl;
				break;
			case 873: cout << "Input valid. Quebec area code." << endl;
				break;
			case 306: cout << "Input valid. Saskatchewan area code." << endl;
				break;
			case 639: cout << "Input valid. Saskatchewan area code." << endl;
				break;
			case 867: cout << "Input valid. Yukon/Northwest Territories/Nunavut area code." << endl;
				break;
			default: cout << "Input valid. Non-Canadian area code." << endl;
				break;
			}
		}

		else
			cout << "Invalid number." << endl;


		// Ask user if they want to continue.    

		cout << "Enter any key to process another number or enter 'q' to terminate. ";

		cin >> str;

		// End program if user enters a "q".

	} while (str != "q");

	return 0;

}