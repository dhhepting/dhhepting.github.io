/*
Name: Brett Banadyga
Student #: 200318551
date created: February 25/15
Problem Question:
Wruite a program that prompts the user to enter a phone number in the form ddd-ddd-dddd. Test that the input number is in the
correct format and check if the number has a Canadian area code. The program will report if the input is valid or not. If the
input includes a Canadian area code, the program will display the name of the prvince or territory with that area code. The program
continues until the user enters the letter 'q'.

*/


#include <iostream>
#include <string>
using namespace std;
int main()
{
	string areacode; 
	string phonenumber; // Use a string to get the phone number.
	cout << "Please enter a phone number in the form ddd-ddd-dddd or q to end the program: ";
	cin >> phonenumber;
	while (phonenumber[0] != 'q')
	{
		
		cout << "The number you have submitted is: " << phonenumber << endl;

		if (phonenumber.length() == 12 && phonenumber[3] == '-' && phonenumber[7] == '-' && phonenumber[0] >= '0' && phonenumber[0] <= '9' && phonenumber[1] >= '0' &&
			phonenumber[1] <= '9' && phonenumber[2] >= '0' && phonenumber[2] <= '9' && phonenumber[4] >= '0' && phonenumber[4] <= '9' && phonenumber[5] >= '0' && phonenumber[5] <= '9'
			&& phonenumber[6] >= '0' && phonenumber[6] <= '9' && phonenumber[8] >= '0' && phonenumber[8] <= '9' && phonenumber[9] >= '0' && phonenumber[9] <= '9'
			&& phonenumber[10] >= '0' && phonenumber[10] <= '9' && phonenumber[11] >= '0' && phonenumber[11] <= '9') // Makes sure that the input number is acceptable
		{
			areacode = phonenumber.substr(0, 3);
		
			if (areacode == "403" || areacode == "507" || areacode == "780" || areacode == "825")
			{
				cout << "The number that you input is a Canadian phone number from the Province Alberta" << endl;
			}
			if (areacode == "236" || areacode == "250" || areacode == "604" || areacode == "627" || areacode == "778")
			{
				cout << "The number that you input is a Canadian phone number from the Province British Columbia" << endl;
			}
			if (areacode == "204" || areacode == "431")
			{
				cout << "The number that you input is a Canadian phone number from the Province Manitoba" << endl;
			}
			if (areacode == "506")
			{
				cout << "The number that you input is a Canadian phone number from the Province New Brunswick" << endl;
			}
			if (areacode == "709")
			{
				cout << "The number that you input is a Canadian phone number from the Province Newfoundland and Labrador" << endl;
			}
			if (areacode == "782" || areacode == "903")
			{
				cout << "The number that you input is a Canadian phone number from the Province Nova Scotia or Prince Edward Island" << endl;
			}
			if (areacode == "548" || areacode == "249" || areacode == "289" || areacode == "343" || areacode == "365" || areacode == "387" || areacode == "416" || areacode == "437" || areacode == "519" || areacode == "226" || areacode == "613" || areacode == "647" || areacode == "705" || areacode == "742" || areacode == "807" || areacode == "905")
			{
				cout << "The number that you input is a Canadian phone number from the Province Ontario" << endl;
			}
			if (areacode == "418" || areacode == "438" || areacode == "450" | areacode == "514" || areacode == "579" || areacode == "581" || areacode == "819" || areacode == "873")
			{
				cout << "The number that you input is a Canadian phone number from the Province Quebec" << endl;
			}
			if (areacode == "306" || areacode == "639")
			{
				cout << "The number that you input is a Canadian phone number from the Province Saskatchewan" << endl;
			}
			if (areacode == "867")
			{
				cout << "The number that you input is a Canadian phone number from the Northwest Territories, the Yukon, or Nunavut" << endl;
			}
			// Tests all of the different Canadian area codes.
		}
		else
			cout << "You entered a Non-Canadian phone number or an invalid phone number please try again" << endl;
		// Outputs if the input number is not acceptable
		
		cout << "Please enter a phonenumber in the form ddd-ddd-dddd or press q to quit: "; 
		cin >> phonenumber; // Continues the loop
	}
	cout << "End of program" << endl;
	return 0;

}