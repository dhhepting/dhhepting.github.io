//**************************************************************************
//
// Student name: Juan Echavarria
//
// Student number: 200360759
//
// Assignment number: 2
//
// Program name:
//
// Date written: 25-02-2015
//
// Problem statement: Write a program that prompts the user to enter a telephone number in the format ddd-ddd-dddd, where d is digit. This is the format for telephone numbers in North America. Test that the input is in the correct format and further check if the phone number has a Canadian area code.
//
// Input: Numbers in the format ddd-ddd-dddd
//
// Output: Valid or invalid number, the number is from canada or not, and the province of the number.
//
// Algorithm:
//
// Major variables: a, b, c, i, flag, telephoneNumber;
//
// Assumptions:
//
// Program limitations:
//
//**************************************************************************

/*Write a program that prompts the user to enter a telephone number
in the format ddd-ddd-dddd, where d is digit. This is the format for
telephone numbers in North America. Test that the input is in the
correct format and further check if the phone number has a Canadian
area code (see the list of Canadian area codes). The program will
report if the input is valid or not. If the input includes a Canadian
area code, the program will display the name of the province or
territory with that area code. The program will continue to process
numbers until the user enters the letter q.


Alberta							403, 587, 780, 825
British Columbia				236, 250, 604, 672, 778
Manitoba						204, 431
New Brunswick					506
Newfoundland and Labrador		709
Nova Scotia						782, 902
Ontario							548, 249, 289, 343, 365, 387, 416, 437, 519, 226, 613, 647, 705, 742, 807, 905
Prince Edward Island			782, 902
Quebec							418, 438, 450, 514, 579, 581, 819, 873
Saskatchewan					306, 639
Yukon							867
Northwest Territories			867
Nunavut							867

*/

#include<iostream>
#include<string>
#include <conio.h>

using namespace std;
int a, b, c, i, flag;
string telephoneNumber;
int main(){

	//Input phone number

	cout << "Enter a telephone number in the format ddd-ddd-dddd, where d is digit\n";
	//Loop to keep asking the phone number and a sentinel value to stop asking for the number
	while (telephoneNumber[0] != 'q'){
		
		flag = 0;
		
		cin >> telephoneNumber;

		if (telephoneNumber[0] == 'q')
			break;

		//Check if the phone number is correct
		if ((telephoneNumber[0] - '0' >= 0) && (telephoneNumber[0] - '0' <= 9))
			if ((telephoneNumber[1] - '0' >= 0) && (telephoneNumber[1] - '0' <= 9))
				if ((telephoneNumber[2] - '0' >= 0) && (telephoneNumber[2] - '0' <= 9))
					if (telephoneNumber[3] == '-')
						if ((telephoneNumber[4] - '0' >= 0) && (telephoneNumber[4] - '0' <= 9))
							if ((telephoneNumber[5] - '0' >= 0) && (telephoneNumber[5] - '0' <= 9))
								if ((telephoneNumber[6] - '0' >= 0) && (telephoneNumber[6] - '0' <= 9))
									if (telephoneNumber[7] == '-')
										if ((telephoneNumber[8] - '0' >= 0) && (telephoneNumber[8] - '0' <= 9))
											if ((telephoneNumber[9] - '0' >= 0) && (telephoneNumber[9] - '0' <= 9))
												if ((telephoneNumber[10] - '0' >= 0) && (telephoneNumber[10] - '0' <= 9))
													if ((telephoneNumber[11] - '0' >= 0) && (telephoneNumber[11] - '0' <= 9))
														flag = 1;
		//Report if the input is valid or not
		if (flag == 0){
			cout << "Invalid number\n";
		}
		else if (flag == 1){
			cout << "Valid number\n";

			a = telephoneNumber[0] - '0';
			b = telephoneNumber[1] - '0';
			c = telephoneNumber[2] - '0';

			//Check if the phone number has a Canadian area code
			//Report if the input has a Canadian area code
			//Alberta                            403, 587, 780, 825
			if (a == 4 && b == 0 && c == 3)
				cout << "Alberta\n";
			else if (a == 5 && b == 8 && c == 7)
				cout << "Alberta\n";
			else if (a == 7 && b == 8 && c == 0)
				cout << "Alberta\n";
			else if (a == 8 && b == 2 && c == 5)
				cout << "Alberta\n";
			//British Columbia                236, 250, 604, 672, 778
			else if (a == 2 && b == 3 && c == 6)
				cout << "British Columbia\n";
			else if (a == 2 && b == 5 && c == 0)
				cout << "British Columbia\n";
			else if (a == 6 && b == 0 && c == 4)
				cout << "British Columbia\n";
			else if (a == 6 && b == 7 && c == 2)
				cout << "British Columbia\n";
			else if (a == 7 && b == 7 && c == 8)
				cout << "British Columbia\n";
			//Manitoba                        204, 431
			else if (a == 2 && b == 0 && c == 4)
				cout << "Manitoba\n";
			else if (a == 4 && b == 3 && c == 1)
				cout << "Manitoba\n";
			//New Brunswick                    506
			else if (a == 5 && b == 0 && c == 6)
				cout << "New Brunswick\n";
			//Newfoundland and Labrador        709
			else if (a == 7 && b == 0 && c == 9)
				cout << "Newfoundland and Labrador\n";
			//Nova Scotia                        782, 902
			else if (a == 7 && b == 8 && c == 2)
				cout << "Nova Scotia\n";
			else if (a == 9 && b == 0 && c == 2)
				cout << "Nova Scotia\n";
			//Ontario                            548, 249, 289, 343, 365, 387, 416, 437, 519, 226, 613, 647, 705, 742, 807, 905
			else if (a == 5 && b == 4 && c == 8)
				cout << "Ontario\n";
			else if (a == 2 && b == 4 && c == 9)
				cout << "Ontario\n";
			else if (a == 2 && b == 8 && c == 9)
				cout << "Ontario\n";
			else if (a == 3 && b == 4 && c == 3)
				cout << "Ontario\n";
			else if (a == 3 && b == 6 && c == 5)
				cout << "Ontario\n";
			else if (a == 3 && b == 8 && c == 7)
				cout << "Ontario\n";
			else if (a == 4 && b == 1 && c == 6)
				cout << "Ontario\n";
			else if (a == 4 && b == 3 && c == 7)
				cout << "Ontario\n";
			else if (a == 5 && b == 1 && c == 9)
				cout << "Ontario\n";
			else if (a == 2 && b == 2 && c == 6)
				cout << "Ontario\n";
			else if (a == 6 && b == 1 && c == 3)
				cout << "Ontario\n";
			else if (a == 6 && b == 4 && c == 7)
				cout << "Ontario\n";
			else if (a == 7 && b == 0 && c == 5)
				cout << "Ontario\n";
			else if (a == 7 && b == 4 && c == 2)
				cout << "Ontario\n";
			else if (a == 8 && b == 0 && c == 7)
				cout << "Ontario\n";
			else if (a == 9 && b == 0 && c == 5)
				cout << "Ontario\n";
			//Prince Edward Island            782, 902
			else if (a == 7 && b == 8 && c == 2)
				cout << "Prince Edward Island\n";
			else if (a == 9 && b == 0 && c == 2)
				cout << "Prince Edward Island\n";
			//Quebec                            418, 438, 450, 514, 579, 581, 819, 873
			else if (a == 4 && b == 1 && c == 8)
				cout << "Prince Edward Island\n";
			else if (a == 4 && b == 3 && c == 8)
				cout << "Prince Edward Island\n";
			else if (a == 4 && b == 5 && c == 0)
				cout << "Prince Edward Island\n";
			else if (a == 5 && b == 1 && c == 4)
				cout << "Prince Edward Island\n";
			else if (a == 5 && b == 7 && c == 9)
				cout << "Prince Edward Island\n";
			else if (a == 5 && b == 8 && c == 1)
				cout << "Prince Edward Island\n";
			else if (a == 8 && b == 1 && c == 9)
				cout << "Prince Edward Island\n";
			else if (a == 8 && b == 7 && c == 3)
				cout << "Prince Edward Island\n";
			//Saskatchewan                    306, 639
			else if (a == 3 && b == 0 && c == 6)
				cout << "Saskatchewan\n";
			else if (a == 6 && b == 3 && c == 9)
				cout << "Saskatchewan\n";
			//Yukon                            867
			//Northwest Territories            867
			//Nunavut                          867
			else if (a == 8 && b == 6 && c == 7)
				cout << "Yukon or Northwest Territories or maybe Nunavut \n";
			else
			cout << "The number is not from Canada plase type it again\n";
			
			
			//Display the nampe of the province or territory with the area code
		}
	}
	return 0;
}