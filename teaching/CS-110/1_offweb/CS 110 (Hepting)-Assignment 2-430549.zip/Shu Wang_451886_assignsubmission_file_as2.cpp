//********************************************************************
//Name: Shu Wang
//Student number: 200335170
//Assignment number: 2
//Program name: Checking Canadian Area Code of A Telephone Number
//Date written: Feb 25, 2015
//Problem statement: Write a program that prompts the user to enter a telephone number in the format ddd-ddd-dddd, where d is digit. This is the format for telephone numbers in North America. Test that the input is in the correct format and further check if the phone number has a Canadian area code (see the list of Canadian area codes). The program will report if the input is valid or not. If the input includes a Canadian area code, the program will display the name of the province or territory with that area code. The program will continue to process numbers until the user enters the letter q.
//Input: A 12 digits telephone number
//Output: Validation of telephone number, area code, and the province
//Algorithm: 
//(1) Input numb as string
//(2) While (numb != "q"), program runs
//(3) If (numb == "q"), program exits
//(4) If length = 12, program runs; else output invalid length
//(5) If format of telephone number is correct, program runs; else output wrong format
//(6) If and else if syntax: check the provice of the area code or if it is not a canadian number.
//Major variables: numb, ac
//Assumptions:  Helping to check if telephone numbers are valid, and more spicificly, the program will tell user the area for the telephone number.
//Program limitations: We can only check if the telephone number is for province of Canada
//**********************************************************************


#include <iostream>
#include <string>
using namespace std;

int main()
{
	
	string numb,ac;
	

	while (numb != "q")  //satisfy the requirement that when we doesn't type q, the program will run.  Otherwise, quit the program.

	{
		cout << "Please enter a telephone number in the format ddd-ddd-dddd, where d is digit." << endl;
		cin >> numb;
		// when user type q, program will exit
		if (numb == "q")
		{
			cout << "Quite the program" << endl;
			return 0;
		}

		//check the length of telephone number
		if (numb.length() == 12)

			// check [3] & [7] are dashs
			// check if all other digits are numbers, not letter
			if (numb[3] == '-' && numb[7] == '-' && numb[0] >= '0' && numb[0] <= '9' && numb[1] >= '0' && numb[1] <= '9' && numb[2] >= '0' && numb[2] <= '9' && numb[4] >= '0' && numb[4] <= '9' && numb[5] >= '0' && numb[5] <= '9' && numb[6] >= '0' && numb[6] <= '9' && numb[8] >= '0' && numb[8] <= '9' && numb[9] >= '0' && numb[9] <= '9' && numb[10] >= '0' && numb[10] <= '9' && numb[11] >= '0' && numb[11] <= '9')
			{
			cout << "The number is valid and the area code is " << numb.substr(0, 3) << "." << endl;
			ac = numb.substr(0, 3);
			if (ac == "403" || ac == "587" || ac == "780" || ac == "825")
				cout << "The number is of Province of Alberta." << endl;
			else if (ac == "236" || ac == "250" || ac == "604" || ac == "672" || ac == "778")
				cout << "The number is of Province of British Columbia." << endl;
			else if (ac == "204" || ac == "431")
				cout << "The number is of Province of Manitoba." << endl;
			else if (ac == "236" || ac == "250" || ac == "604" || ac == "672" || ac == "778")
				cout << "The number is of Province of New Brunswick." << endl;
			else if (ac == "709")
				cout << "The number is of Province of Newfoundland and Labrador." << endl;
			else if (ac == "782" || ac == "902")
				cout << "The number is of Province of Nova Scotia." << endl;
			else if (ac == "548" || ac == "249" || ac == "289" || ac == "343" || ac == "365" || ac == "387" || ac == "416" || ac == "437" || ac == "519" || ac == "226" || ac == "613" || ac == "647" || ac == "705" || ac == "742" || ac == "807" || ac == "905")
				cout << "The number is of Province of New Brunswick." << endl;
			else if (ac == "782" || ac == "902")
				cout << "The number is of Province of Prince Edward Island." << endl;
			else if (ac == "418" || ac == "438" || ac == "450" || ac == "514" || ac == "579" || ac == "581" || ac == "819" || ac == "873")
				cout << "The number is of Province of Quebec." << endl;
			else if (ac == "306" || ac == "639")
				cout << "The number is of Province of Saskatchewan." << endl;
			else if (ac == "867")
				cout << "The number is of Province of Yukon, Northwest Territories, and Nunavut." << endl;
			else
				cout << "The number is not a Canadian number";

			
			}
			else
				cout << "The format is not valid" << endl;
			
		else
			cout << "The length is not valid" << endl;
		
	}
	return 0;
}



