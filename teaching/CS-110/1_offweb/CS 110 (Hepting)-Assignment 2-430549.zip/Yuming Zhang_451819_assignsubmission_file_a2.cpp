//**************************************************************************
//
// Student name: YumingZhang
//
// Student number: 200338416
//
// Assignment number: num2
//
// Program name: Telephonenumber
//
// Date written: 24th Feb 2015
//
// Problem statement: State the area for telephonenumbers, q for quit, report the invalid telephonenumbers and the telephonenumbers that are not belong to Canada.
//
// Input: telephonenumber in the form ddd-ddd-dddd
//
// Output: area, q for quit,c for continue,invalid telephonenumbers and the telephonenumbers that are not belong to Canada.
//
// Algorithm: First we need to declare 4 variables for string
//			  Program ask user to input telephonenumber in ddd-ddd-dddd form, then we need to check if it is 10 digits telephonenumbers and with 2digits dash lines
//			  if the satisfied above requirement, we use first telephonenumbers'3 digits as the areacode to check the correct area,then output the area and recall the telephonenumbers.If the area is not include in the code, report it doesn't belong to Canada.
//			  if the requirements are not satisfied, we ask user to reinput the telephonenumbers.
//
// Major variables: telephonenumber, areacode, tele1, tele2.
//
// Assumptions: we assume user input 10 digits telephonenumbers
//
// Program limitations: it works only with 10 digits telephonenumbers, and only output the Canadian areacode, if the input is not belong to Canada or different form as north America phonenumber form, the program will report that. 
//
//**************************************************************************
#include <iostream>
#include <string>
using namespace std;

int main()
{
	string telephonenumber;
	cout << "Please enter in your telephone number in the form (ddd-ddd-dddd), if you wish to quit, prise q : " << endl;
	cin >> telephonenumber;
	while (telephonenumber != "q")
	{
		cout << "You entered: " << telephonenumber;
		string areacode = telephonenumber.substr(0, 3);
		string tele1 = telephonenumber.substr(4, 3);
		string tele2 = telephonenumber.substr(8, 4);
		if (areacode >= "000" && areacode <= "999"&&tele1 >= "000"&&tele1 <= "999"&&tele2 >= "0000"&&tele2 <= "9999"&&telephonenumber[3]=='-'&&telephonenumber[7]=='-'&&telephonenumber.length() == 12)
		{
			if (areacode == "403" || areacode == "587" || areacode == "780" || areacode == "825")
			{
				cout << "Alberta" << endl;
			}
			else if (areacode == "236" || areacode == "250" || areacode == "604" || areacode == "672" || areacode == "778")
			{
				cout << "British Columbia" << endl;
			}
			else if (areacode == "204" || areacode == "431")
			{
				cout << "Manitoba" << endl;
			}
			else if (areacode == "506")
			{
				cout << "New Brunswick" << endl;
			}
			else if (areacode == "709")
			{
				cout << "Newfoundland and Labrador" << endl;
			}
			else if (areacode == "782" || areacode == "902")
			{
				cout << "Nova Scotia" << endl;
			}
			else if (areacode == "548" || areacode == "249" || areacode == "289" || areacode == "343" || areacode == "365" || areacode == "387" || areacode == "416" || areacode == "437" || areacode == "519" || areacode == "226" || areacode == "613" || areacode == "647" || areacode == "705" || areacode == "742" || areacode == "807" || areacode == "905")
			{
				cout << "Ontario" << endl;
			}
			else if (areacode == "782" || areacode == "902")
			{
				cout << "Prince Edward Island" << endl;
			}
			else if (areacode == "418" || areacode == "438" || areacode == "450" || areacode == "514" || areacode == "579" || areacode == "581" || areacode == "819" || areacode == "873")
			{
				cout << "Quebec" << endl;
			}
			else if (areacode == "306" || areacode == "639")
			{
				cout << "Saskatchewan" << endl;
			}
			else if (areacode == "867")
			{
				cout << "Yukon, Northwest Territories, and Nunavut" << endl;
			}
			else
			{
				cout << "This is not a canadian telephonenumber" << endl;
			}
		}
		else
		{
			cout << "It's not a valid telephone number." << endl;
			cout << "Please enter again." << endl;
		}
		cout << "Please enter in your telephone number in the form (ddd-ddd-dddd), if you want to quit, prise q : " << endl;
		cin >> telephonenumber;

	}

	return 0;
}

