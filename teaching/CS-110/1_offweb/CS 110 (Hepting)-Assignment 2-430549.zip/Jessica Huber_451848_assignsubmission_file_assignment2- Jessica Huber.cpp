#include <iostream>
#include <string>
using namespace std;

int main ()
{ 
	int areacode; 
	string phonenumber;

	cout << "Enter your phone number" << endl;
	cin >> phonenumber;

	string areacode = phonenumber.substr (0,4);
	while (phonenumber != "q") 

	switch (areacode) 

	{ 
	case 306 || 639:

		cout << "Saskatchewan" << endl; 
			break; 

	case 403 || 587 || 780 || 825:

		cout << "Alberta" << endl; 
		break; 

	case 236 || 250 || 604 || 672 || 778:

		cout << "British Columbia" << endl; 
		break;

	case 204 || 431:

		cout << "Manitoba" << endl;
		break; 

	case 506: 

		cout << "New Brunswick" << endl; 
		break; 

	case 709:

		cout << "Newfoundland and Labrador" << endl; 
		break; 

	case 782 || 902:

		cout << "Nova Scotia" << endl; 
		break;

	case 548 || 249 || 289 || 343 || 365 || 387 || 416 || 437 || 519 ||226 || 613 || 647 || 705 || 742 || 807 || 905: 

		cout << "Ontario" << endl; 
		break; 

	case 782 || 902:

		cout << "Prince Edward Island" << endl; 
		break; 

	case 418 || 438 || 450 || 514 || 579 || 581 || 819 || 873:

		cout << "Quebec" << endl; 
		break;

	case 867:

		cout << "Territories" << endl;
		break; 

		return 0;
	} 
	if (phonenumber.length() != 12)
	
	{ 
		cout << "Error" << endl; 
		return 1; 
	} 
} 


	
	