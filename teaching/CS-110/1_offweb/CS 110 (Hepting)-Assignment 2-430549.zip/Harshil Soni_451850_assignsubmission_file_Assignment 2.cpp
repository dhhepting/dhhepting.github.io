#include < iostream >
#include < string >
using namespace std;
int main()
{

string code;
cout << " Please enter the telephone number " << endl;
cin >> code; 
string areacode = code.substr( 0, 3 );

if (code == "403" ||code == "587" ||code == "780" ||code == "825")
{
cout << " Is a Area Code of Alberta" << code << endl;
}
else if (code == "236" ||code == "250" ||code == "604" ||code == "672" ||code == "778")
{
cout << " Is a Area code of British Columbia" << code << endl;
}
else if (code == "204" || code == "431" )
{
cout << "Is a Area code of Manitoba" << code << endl;
}
else if ( code == "506" )
{
cout << "Is Area code of New Brunswick" << code << endl;
}
else if ( code == "709" )
{
cout << "Is a Area code of Newfoundland and Labrador" << code << endl;
}
else if ( code == "782" || code == "902" )
{
cout << " Is a Area code of Nova Scotia or Prince Edward Island " << code << endl;
}
else if (code == "548" ||code == "249" ||code == "289" ||code == "343" ||code == "365" ||
         code == "387" ||code == "416" ||code == "437" ||code == "519" ||code == "226" ||
         code == "613" ||code == "647" ||code == "705" ||code == "742" ||code == "807" || code == "905")
{
cout << "Is a Area code of Ontario " << code << endl;
}
else if (code == "418" ||code == "438" ||code == "450" ||code == "514" ||code == "579"||
         code == "581" ||code == "819" ||code == "873" )
{
cout << "Is a Area code of Quebec " << code << endl;
}
else if (code == 306 || code == "639" )
{
cout << "Is a Area code of Saskatchewan " << code << endl;
}
else if ( code == "867" )
{
cout << "Is a Area code of Yukon, Northwest Territories, and Nunavut " << code << endl;
}
else 
{
cout << "Match not found" << endl;
}
retrun 0;
}

