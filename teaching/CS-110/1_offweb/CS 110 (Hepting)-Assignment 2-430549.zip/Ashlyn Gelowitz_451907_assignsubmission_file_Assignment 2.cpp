//Ashlyn Gelowitz
//200315531
//Assignment #2
//Visual Studios
//February 21, 2015


#include <iostream>
#include <string>
using namespace std;

int main()
{
		int abc;
		string def;
		int ghij;
		string exit;
		char ignore;
		string stay;

		while (stay != "q")
		{
			cout << "Please enter a Canadian telephone number in the format  ddd-ddd-dddd." << endl;
			cin >> abc >> ignore >> def;
			
			int length = def.length();

			if (length != 8)
			{
				cout << "The phone number entered is in the wrong format." << endl;
				cout << "press any key to exit" << endl;
				cin >> exit;
				return 0;
			}


			if (abc == 403 || abc == 587 || abc == 780 || abc == 825)
			{
				cout << " This number is of the province Alberta " << endl;
			}
			else if (abc == 250 || abc == 236 || abc == 604 || abc == 672 || abc == 778)
			{
				cout << " This number is of the province British Columbia " << endl;
			}
			else if (abc == 204 || abc == 431)
			{
				cout << " This number is of the province Manitoba " << endl;
			}
			else if (abc == 506)
			{
				cout << " This number is of the province Nova Scotia " << endl;
			}
			else if (abc == 548 || abc == 249 || abc == 289 || abc == 343 || abc == 365 || abc == 387 || abc == 416 || abc == 437 || abc == 519 || abc == 226 || abc == 613 || abc == 647 || abc == 705 || abc == 742 || abc == 807 || abc == 905)
			{
				cout << "This number is of the province Ontario " << endl;
			}
			else if (abc == 782 || abc == 902)
			{
				cout << "This number is of the province Prince Edward Island " << endl;
			}
			else if (abc == 418 || abc == 438 || abc == 450 || abc == 514 || abc == 579 || abc == 581 || abc == 819 || abc == 873)
			{
				cout << "This number is of the province of Quebec " << endl;
			}
			else if (abc == 306 || abc == 639)
			{
				cout << "This number is of the province of Saskatchewan " << endl;
			}
			else if (abc == 867)
			{
				cout << "This number is of the Territories Yukon, Northwest Territories, and Nunavut" << endl;
			}
			else
			{
				cout << " This is an incorrect entry" << endl;
			}

			cout << " Would you like to run this program again? If not press q; if yes, press any other key." << endl;
			cin >> stay;
		}
	return 0;

}