
// STUDENT NAME: Emily Chea

// STUDENT NUMBER: 200352055

// ASSIGNMENT NUMBER: 2

// PROGRAM NAME: C++ Visual Studio 2013

// DATE WRITTEN: February 9, 2015

// PROBLEM STATEMENT: Ask the participant for a phone number and determine if it is a canadian area code and for what province/territory

// INPUT: a telephone number in the form of ddd-ddd-dddd (where d is a digit)

// OUTPUT: if the number is in the correct format. If yes, is the number has a canadian area code and if yes, which provice and territory

// ALGORITHM: prompt participant to input a phone number in the format xxx-xxx-xxxx, check to see if phone number is in the correct format (does it contain 12 characters? Are the numbers between 0 and 9?), determine if the phone number is from Canada and if it is from which province, allow the participant to continue to enter phone numbers until they enter "q"

// MAJOR VARIABLES: phone, letter, area

// ASSUMPTIONS: none

// PROGRAM LIMITATIONS: will only state the specific province/ territory if area code is found in Canada,  

//**************************************************************************************************************************************************************

#include <iostream>
#include <string>
using namespace std;

int main()
{
	string phone;
	char letter;
	// Ask participant to enter a phone number in the form ddd-ddd-dddd
	cout << "Please enter a phone number in the form xxx-xxx-xxxx." << endl;
	cin >> phone;
	//Test if input is in correct formula
	if (phone.length() != 12) // does the phone number contain 12 characters (10 digits and 2 hyphens)?
	{
		cout << "Error. Incorrect number of characters." << endl;
	}
	else //are the digits of the phone number in the range of 0-9? Are the hyphens in the correct position?
	{
		if (phone[0] >= '0' && phone[0] <= '9')
		{
			if (phone[1] >= '0' && phone[1] <= '9')
			{
				if (phone[2] >= '0' && phone[2] <= '9')
				{
					if (phone[3] == '-')
					{
						if (phone[4] >= '0' && phone[4] <= '9')
						{
							if (phone[5] >= '0' && phone[5] <= '9')
							{
								if (phone[6] >= '0' && phone[6] <= '9')
								{
									if (phone[7] == '-')
									{
										if (phone[8] >= '0' && phone[8] <= '9')
										{
											if (phone[9] >= '0' && phone[9] <= '9')
											{
												if (phone[10] >= '0' && phone[10] <= '9')
												{
													if (phone[11] >= '0' && phone[11] <= '9')
													{
														string area = phone.substr(0, 3);
														//test if phone number has Canadian area code. If it is a canadian area code number, display the province or territory it is from
														if (area == "403" || area == "587" || area == "780" || area == "825")
														{
															cout << "Alberta" << endl;
														}
														else if (area == "236" || area == "250" || area == "604" || area == "672" || area == "778")
														{
															cout << "British Columbia" << endl;
														}
														else if (area == "204" || area == "431")
														{
															cout << "Manitoba" << endl;
														}
														else if (area == "506")
														{
															cout << "New Brunswick" << endl;
														}
														else if (area == "709")
														{
															cout << "Newfoundland and Labrador" << endl;
														}
														else if (area == "782" || area == "902")
														{
															cout << "Nova Scotia or Prince Edward Island" << endl;
														}
														else if (area == "548" || area == "249" || area == "289" || area == "343" || area == "365" || area == "387" || area == "416" || area == "437" || area == "519" || area == "226" || area == "613" || area == "647" || area == "705" || area == "742" || area == "807" || area == "905")
														{
															cout << "Ontario" << endl;
														}
														else if (area == "418" || area == "438" || area == "450" || area == "514" || area == "579" || area == "581" ||  area == "819" || area == "873")
														{
															cout << "Quebec" << endl;
														}
														else if (area == "306" || area == "639")
														{
															cout << "Saskatchewan" << endl;
														}
														else if (area == "867")
														{
															cout << "Yukon, Northwest Territories, or Nunavut" << endl;
														}
														else
														{
															cout << "This is not a number with a Canadian area code. " << endl;
														}
													}
													else
													{
														cout << "Error with 10th number" << endl;
													}
												}
												else
												{
													cout << "Error with 9th number" << endl;
												}
											}
											else
											{
												cout << "Error with 8th number" << endl;
											}
										}
										else
										{
											cout << "Error with 7th number" << endl;
										}
									}
									else
									{
										cout << "Error. Missing hyphen." << endl;
									}
								}
								else
								{
									cout << "Error with 6th number" << endl;
								}
							}
							else
							{
								cout << "Error with 5th number" << endl;
							}
						}
						else
						{
							cout << "Error with 4th number" << endl;
						}
					}
					else
					{
						cout << "Error. Missing hyphen." << endl;
					}
				}
				else
				{
					cout << "Error with 3rd number" << endl;
				}
			}
			else
			{
				cout << "Error with 2nd number" << endl;
			}
		}
		else
		{
			cout << "Error with 1st number" << endl;
		}
	}
	//Ask the participant if they want to quit the program. If q is not entered, program will loop.
	cout << "Would you like to quit? If so, enter q ." << endl;
	cin >> letter;
	while (letter != 'q')
	{
		cout << "Please enter a phone number in the form xxx-xxx-xxxx." << endl;
		cin >> phone;
		if (phone.length() != 12)
		{
			cout << "Error. Incorrect number of characters." << endl;
		}
		else
		{
			if (phone[0] >= '0' && phone[0] <= '9')
			{
				if (phone[1] >= '0' && phone[1] <= '9')
				{
					if (phone[2] >= '0' && phone[2] <= '9')
					{
						if (phone[3] == '-')
						{
							if (phone[4] >= '0' && phone[4] <= '9')
							{
								if (phone[5] >= '0' && phone[5] <= '9')
								{
									if (phone[6] >= '0' && phone[6] <= '9')
									{
										if (phone[7] == '-')
										{
											if (phone[8] >= '0' && phone[8] <= '9')
											{
												if (phone[9] >= '0' && phone[9] <= '9')
												{
													if (phone[10] >= '0' && phone[10] <= '9')
													{
														if (phone[11] >= '0' && phone[11] <= '9')
														{
															string area = phone.substr(0, 3);
															if (area == "403" || area == "587" || area == "780" || area == "825")
															{
																cout << "Alberta" << endl;
															}
															else if (area == "236" || area == "250" || area == "604" || area == "672" || area == "778")
															{
																cout << "British Columbia" << endl;
															}
															else if (area == "204" || area == "431")
															{
																cout << "Manitoba" << endl;
															}
															else if (area == "506")
															{
																cout << "New Brunswick" << endl;
															}
															else if (area == "709")
															{
																cout << "Newfoundland and Labrador" << endl;
															}
															else if (area == "782" || area == "902")
															{
																cout << "Nova Scotia or Prince Edward Island" << endl;
															}
															else if (area == "548" || area == "249" || area == "289" || area == "343" || area == "365" || area == "387" || area == "416" || area == "437" || area == "519" || area == "226" || area == "613" || area == "647" || area == "705" || area == "742" || area == "807" || area == "905")
															{
																cout << "Ontario" << endl;
															}
															else if (area == "418" || area == "438" || area == "450" || area == "514" || area == "579" || area == "581" || area == "819" || area == "873")
															{
																cout << "Quebec" << endl;
															}
															else if (area == "306" || area == "639")
															{
																cout << "Saskatchewan" << endl;
															}
															else if (area == "867")
															{
																cout << "Yukon, Northwest Territories, or Nunavut" << endl;
															}
															else
															{
																cout << "This is not a phone number with a Canadian area code." << endl;
															}
														}
														else
														{
															cout << "Error with 10th number" << endl;
														}
													}
													else
													{
														cout << "Error with 9th number" << endl;
													}
												}
												else
												{
													cout << "Error with 8th number" << endl;
												}
											}
											else
											{
												cout << "Error with 7th number" << endl;
											}
										}
										else
										{
											cout << "Error. missing hyphen." << endl;
										}
									}
									else
									{
										cout << "Error with 6th number" << endl;
									}
								}
								else
								{
									cout << "Error with 5th number" << endl;
								}
							}
							else
							{
								cout << "Error with 4th number" << endl;
							}
						}
						else
						{
							cout << "Error. missing hyphen." << endl;
						}
					}
					else
					{
						cout << "Error with 3rd number" << endl;
					}
				}
				else
				{
					cout << "Error with 2nd number" << endl;
				}
			}
			else
			{
				cout << "Error with 1st number" << endl;
			}
		}
		cout << "Would you like to quit? If so, enter q ." << endl;
		cin >> letter;
	}
}
	
													