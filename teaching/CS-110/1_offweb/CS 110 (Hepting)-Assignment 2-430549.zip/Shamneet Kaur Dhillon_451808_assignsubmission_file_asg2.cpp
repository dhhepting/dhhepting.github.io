//Shamneet Dhillon
//200333548
//Assignment#2
//Checking the valid phone numbers and areacodes for Canada
//25th February, 2015



#include <iostream>
#include <string>
using namespace std;
int main()
{
	string num;
	cout << " Enter the number;" << endl;
	cin >> num;
	if (num.length() == 12 && num[3] == '_' && num[7] == '_')

		cout << " The number is valid." << endl;


	string areacode = num.substr(0, 3);
	{


		if (areacode == "403" || areacode == "587" || areacode == "780" || areacode == "825")
			cout << areacode << " Is the number  for Alberta" << endl;


		else if (areacode == "236" || areacode == "250" || areacode == "604" || areacode == "672" || areacode == "778")
			cout << areacode << "  Is the number for British Columbia" << endl;


		else if (areacode == "204" || areacode == "431")
			cout << areacode << " Is the number  for Manitoba" << endl;


		else if (areacode == "506")
			cout << areacode << " Is the number  for New Brunswick" << endl;

		else if (areacode == "709")
			cout << areacode << "Is the number  for New Foundland 7 Labrador" << endl;


		else if (areacode == "782" || areacode == "902")
			cout << areacode << " Is the number  for Nova Scotia" << endl;

		else if (areacode == "548" || areacode == "249" || areacode == "289" || areacode == "343" || areacode == "384" || areacode == "416" || areacode == "437" || areacode == "519" || areacode == "226" || areacode == "613" || areacode == "647" || areacode == "705" || areacode == "742" || areacode == "807" || areacode == "405")
			cout << areacode << " Is the number for Ontario" << endl;


		else if (areacode == "782" || areacode == "902")
			cout << areacode << " Is the number  for Prince Edward Island " << endl;


		else if (areacode == "418" || areacode == "438" || areacode == "450" || areacode == "514" || areacode == "579" || areacode == "581" || areacode == "819" || areacode == "873")
			cout << areacode << " Is the number  for Quebec" << endl;


		else if (areacode == "306" || areacode == "693")
			cout << areacode << " Is the number  for Saskatchewan" << endl;

		else if (areacode == "867")
			cout << areacode << " Is the number for Yukon, Northwest Territories and Nunavut" << endl;

		else if (areacode == "q")
			cout << "The program has been terminated." << endl;


	}
    

	return 0;
	


     }