
//Grannel Pinto
//200351222
//Assignment #2
//Microsoft Visual Studio 2013
//2015-02-25
//inputs: phone
//outputs 
//Assumption that they know a North American number. 
//Final result should tell you the area code of the province or territory. An example would be entering a 403 area code should make the program tell you the area code belongs to Alberta.




#include <iostream>
#include <string> 
using namespace std; 

int main()
{
	char letter;
	do
	{
		cout << "Please enter a phone number in the Noth American format of ddd-ddd-dddd: " << endl;
		string phone;
		cin >> phone;

		while (phone.length() != 12)
		{
			cout << "Phone number incorrect!" << endl;
			cout << "Please enter a phone number with the correct format";
			cin >> phone;
		}

		string areaCode = phone.substr(0, 3);

		if (areaCode == "403" || areaCode == "587" || areaCode == "825"|| areaCode == "780")
			cout << "Area code belongs to Alberta " << endl;
		else if (areaCode == "236" || areaCode == "250" || areaCode == "604" || areaCode == "672" || areaCode == "778")
			cout << "Area code belongs to British Columbia" << endl;
	      else if (areaCode == "306" || areaCode == "639")
			cout << "Area code belongs to Saskatchewan " << endl;
		

		else if (areaCode == "204" || areaCode == "431")
			cout << "Area code belongs to Manitoba " << endl;

		 else if (areaCode == "506")
			 cout << "Area code belongs to New Brunswick " << endl;
		 else if (areaCode == "709")
			 cout << "Area code belongs to Newfoundland and Labrador" << endl; 
		 else if (areaCode == "782" || areaCode == "902")
			 cout << "Area code belongs to Nova Scotia" << endl;
		 else if (areaCode == "548" || areaCode == "249" || areaCode == "289" || areaCode == "343" || areaCode == "365" || areaCode =="387" || areaCode == "416" || areaCode == "437" || areaCode == "519" || areaCode == "226" || areaCode == "613" || areaCode == "647" || areaCode == "705" || areaCode == "742" || areaCode == "807" || areaCode == "905")
			 cout << "Area code belongs to Ontario" << endl; 
		 else if (areaCode == "782" || areaCode == "902")
			 cout << "Area code belongs to Prince Edward Island" << endl;
		 else if (areaCode == "418" || areaCode == "438" || areaCode == "450" || areaCode == "514" || areaCode == "579" || areaCode == "581" || areaCode == "819" || areaCode == "873")
			 cout << "Area code belongs to Quebec" << endl;
		 else if (areaCode == "867")
			 cout << "Area code belongs to Yukon, Northwest Territories and Nunavut" << endl;
		cin >> letter;
	} while (letter != 'q');
	return(0);
}

