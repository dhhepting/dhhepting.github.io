/*  
	STUDENT NAME:  Joseph Ashworth
	STUDENT ID:  200354384
	ASSIGNMENT NO.:  2
	PROGRAM NAME:  Assignment_2.cpp
	DATE WRITTEN:  18-02-2015
	PROBLEM STATEMENT:  Create a program that can find the area code, and hence the province, of a telephone number
		entered by the user.
	INPUT:  A telephone number in the North American format.
	OUTPUT:  The Canadian Province or Territory which the telephone number belongs to, if it could be found.
	ALGORITHM:  Recieve a telephone number from the user. Check that it is in the correct form. Locate the area code 
		from the original input, then compare it to an array of codes to find a match. Ouput the corresponding 
		Province or Territory, or that a match was not found. Wait until 'q' is inputted, then terminate.
	MAJOR VARIABLES:  achPhoneNumber[], bInvalidInput, nAreaCode
	ASSUMPTIONS:  User's input will be at least 12 characters.
	PROGRAM LIMITATIONS:  Some area codes belong to multiple provinces or territories, so a single province or
		territory cannot be found.
*/

#include <iostream>
using namespace std;

int main()
{
	cout << "Enter a telephone number in the form ###-###-####" << endl;			//Request input.
	
	char achPhoneNumber[12];			//Define variables to store and check the input.
	bool bInvalidInput;

	do
	{
		bInvalidInput = false;
		for (int iii = 0; iii < 12; iii++)
		{
			cin >> achPhoneNumber[iii];				//Store a character in it's correct slot

			//The following if statements check whether each single character is valid. If it is not, InvalidInput is
			//changed to true.

			if (iii != 3 && iii != 7 && (achPhoneNumber[iii] < '0' || achPhoneNumber[iii] > '9'))
				bInvalidInput = true;
			else if ((iii == 3 || iii == 7) && (achPhoneNumber[iii] != '-'))
				bInvalidInput = true;

			if (bInvalidInput)															//If the character was invalid, 
			{																			//send a message to the console
				cout << "Your input was not correct. Please try again." << endl;		//and end the loop.
				break;
			}
		}
		cin.sync();			//Remove any remaining characters from the input stream.
	}
	while (bInvalidInput);			//If any character was invalid, start the input process again.


	//The folowing code finds the area code of the telephone number as an integer.

	int nAreaCode = (achPhoneNumber[0] - '0') * 100 + (achPhoneNumber[1] - '0') * 10 +
		(achPhoneNumber[2] - '0');

	//The following code declares an array containing all 42 valid area codes and associates each one with a number.
	//This number will later be used to find the corresponding province.

	const int anCodeList[2][42] = {
	{403, 587, 780, 825, 236, 250, 604, 672, 778, 204, 431, 506, 709, 782, 902, 548, 249, 289, 343, 365, 387, 416, 
	437, 519, 226, 613, 647, 705, 742, 807, 905, 418, 438, 450, 514, 579, 581, 819, 873, 306, 639, 867},
	{1, 1, 1, 1, 2, 2, 2, 2, 2, 3, 3, 4, 5, 6, 6, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 8, 8, 8, 8, 8,
	8, 8, 8, 9, 9, 10}
	};

	int nProvince = 0;

	for (int jjj = 0; jjj < 42; jjj++)				//Compare the area code of the input number to each are code in the 
		if (nAreaCode == anCodeList[0][jjj])		//array. Once a match is found, the number corresponding to the
		{											//correct are code is stored in a variable.
			nProvince = anCodeList[1][jjj];
			break;
		}

	//The following code outputs which province the area code matches, using the given "province number". The default
	//case is used if a match could not be found and nProvince has not been given a relevant value.
	
	switch(nProvince)
	{
	case 1: cout << "This telephone number belongs to Alberta." << endl;
		break;
	case 2: cout << "This telephone number belongs to British Columbia." << endl;
		break;
	case 3: cout << "This telephone number belongs to Manitoba." << endl;
		break;
	case 4: cout << "This telephone number belongs to New Brunswick." << endl;
		break;
	case 5: cout << "This telephone number belongs to Newfoundland and Labrador." << endl;
		break;
	case 6: cout << "This telephone number belongs to NovaScotia or Prince Edward Island." << endl;
		break;
	case 7: cout << "This telephone number belongs to Ontario." << endl;
		break;
	case 8: cout << "This telephone number belongs to Quebec." << endl;
		break;
	case 9: cout << "This telephone number belongs to Saskatchewan." << endl;
		break;
	case 10: cout << "This telephone number belongs to Yukon, Northwest Territories or Nunavut." << endl;
		break;
	default: cout << "Could not find a Canadian province or territory for this telephone number." << endl;
		break;
	}
	
	cout << "Enter 'Q' to quit." << endl;						//Wait for the user to enter the 'q' character before
	char chTerminate = 0;										//terminating the program.
	while (!(chTerminate == 'q' || chTerminate == 'Q'))
	{
		cin >> chTerminate;
	}

	return 0;
}