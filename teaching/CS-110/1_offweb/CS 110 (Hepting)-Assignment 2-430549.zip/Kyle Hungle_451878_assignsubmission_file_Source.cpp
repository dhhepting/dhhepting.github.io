/*

Name: Kyle HUngle
Student #: 200354270
Assignment #2
Program Name: Assignment#2
Feb 25/15
Problem Question
Write a program that prompts the user to enter a telephone number in the format ddd-ddd-dddd,
where d is digit. This is the format for telephone numbers in North America. Test that the input
is in the correct format and further check if the phone number has a Canadian area code.
The program will report if the input is valid or not. If the input includes a Canadian area code,
the program will display the name of the province or territory with that area code. The program
will continue to process numbers until the user enters the letter q.


*/

#include <iostream>

#include <string> //brings in the ability to use strings

using namespace std;

int main()

{
	string areacode; //string for the area code
	string phonenumber; // string for whole phone number

	cout << "Please enter a phone number in the form ddd-ddd-dddd or q to end the program: " << endl; //prompts the user for the phone number

	cin >> phonenumber;

	while (phonenumber[0] != 'q') //while loop to make sure the user wants the program and does not want to end the program by entering q
	{



		cout << "The number you have submitted is: " << phonenumber << endl;  //displays the whole 10 digit number



		if (phonenumber.length() == 12 &&   phonenumber[3] == '-' && phonenumber[7] == '-' && phonenumber[0] >= '0' && phonenumber[0] <= '9' && phonenumber[1] >= '0' &&
			phonenumber[1] <= '9' && phonenumber[2] >= '0' && phonenumber[2] <= '9' && phonenumber[4] >= '0' && phonenumber[4] <= '9' && phonenumber[5] >= '0' && phonenumber[5] <= '9'
			&& phonenumber[6] >= '0' && phonenumber[6] <= '9' && phonenumber[8] >= '0' && phonenumber[8] <= '9' && phonenumber[9] >= '0' && phonenumber[9] <= '9'
			&& phonenumber[10] >= '0' && phonenumber[10] <= '9' && phonenumber[11] >= '0' && phonenumber[11] <= '9') // checks to make sure that the phone number is the right length and is all numbers

		{
			areacode = phonenumber.substr(0, 3); //sets the areacode to be the first three parts of the string

			 

			if (areacode == "403" || areacode == "507" || areacode == "780" || areacode == "825") //checks the area code to see if it matches alberta
			{
				cout << "The number that you input is a Canadian phone number from the Province Alberta" << endl; // tells the user that their number is from alberta
			}
			if (areacode == "236" || areacode == "250" || areacode == "604" || areacode == "627" || areacode == "778")  //checks the area code to see if it matches British Columbia
			{
				cout << "The number that you input is a Canadian phone number from the Province British Columbia" << endl; // tells the user that their number is from British Columbia
			}
			if (areacode == "204" || areacode == "431")  //checks the area code to see if it matches Manitoba
			{
				cout << "The number that you input is a Canadian phone number from the Province Manitoba" << endl; // tells the user that their number is from Manitoba
			}
			if (areacode == "506")  //checks the area code to see if it matches New Brunswick
			{
				cout << "The number that you input is a Canadian phone number from the Province New  Brunswick" << endl; // tells the user that their number is from New Brunswick
			}
			if (areacode == "709")  //checks the area code to see if it matches Newfoundland or Labrador
			{
				cout << "The number that you input is a Canadian phone number from the Province Newfoundland and Labrador" << endl; // tells the user that their number is from Newfoundland or Labrador
			}
			if (areacode == "782" || areacode == "903")  //checks the area code to see if it matches Prince Edward Island
			{
				cout << "The number that you input is a Canadian phone number from the Province Nova Scotia or Prince Edward Island" << endl; // tells the user that their number is from Prince Edward Island
			}
			//checks the area code to see if it matches Ontario
			if (areacode == "548" || areacode == "249" || areacode == "289" || areacode == "343" || areacode == "365" || areacode == "387" || areacode == "416" || areacode == "437" || areacode == "519" || areacode == "226" || areacode == "613" || areacode == "647" || areacode == "705" || areacode == "742" || areacode == "807" || areacode == "905")
			{
				cout << "The number that you input is a Canadian phone number from the Province Ontario" << endl; // tells the user that their number is from Ontario
			}
			//checks the area code to see if it matches Quebec
			if (areacode == "418" || areacode == "438" || areacode == "450" | areacode == "514" || areacode == "579" || areacode == "581" || areacode == "819" || areacode == "873")
			{
				cout << "The number that you input is a Canadian phone number from the Province Quebec" << endl; // tells the user that their number is from Quebec
			}
			if (areacode == "306" || areacode == "639")  //checks the area code to see if it matches Saskatchewan
			{
				cout << "The number that you input is a Canadian phone number from the Province Saskatchewan" << endl; // tells the user that their number is from Saskatchewan
			}
			if (areacode == "867")  //checks the area code to see if it matches the Northwest Territories, the Yukon, or Nunavut
			{
				cout << "The number that you input is a Canadian phone number from the Northwest Territories, the Yukon, or Nunavut" << endl; // tells the user that their number is from the Northwest Territories, the Yukon, or Nunavut
			}

			
		}
		else  cout << "Invalid or Non-Canadian phone number please try again: " << endl; //tells the user that there input is incorrect


		cout << "Please enter a phone number in the form ddd-ddd-dddd or q to end the program: " << endl; //Asks the user for a new area code for the next loop
		cin >> phonenumber;

	}

	cout << "End of program" << endl; //tells the user the program is over
	return 0;


}