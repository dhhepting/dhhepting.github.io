//**************************************************************************
//
// Student name: Kennedy Dollard
//
// Student number: 200236150
//
// Assignment number: two
//
// Program name: Phone Numbers
//
// Date written: February 25th, 2014
//
// Problem statement: Identify Canadian phone numbers
//
// Input: phone number
//
// Output: which province number is from or if not in Canada
//
// Algorithm: 
//
// Major variables: 
//
// Assumptions: user will input a 10 digit phone number
//
// Program limitations: only identifies Canadian numbers or non-Canadian numbers
//
//**************************************************************************


#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main()
{
	string number; //we need a string
	int CAN; // for fun

	cout << "To quit this program enter the letter q." << endl; //output
	cout << "Please enter a telephone number in the format ddd-ddd-dddd." << endl; //output
	cin >> number; //user input
	string areacode = "";

	while (number != "q") //quit!!
	{

		while ((number[3] == '-') && (number[7] == '-')) //need these!!
			while ((number[0] >= '0') && (number[0] <= '9')) // no letters or symbols in phone numbers!!
				while ((number[1] >= '0') && (number[1] <= '9'))
					while ((number[2] >= '0') && (number[2] <= '9'))
						while ((number[4] >= '0') && (number[4] <= '9'))
							while ((number[5] >= '0') && (number[5] <= '9'))
								while ((number[6] >= '0') && (number[6] <= '9'))
									while ((number[8] >= '0') && (number[8] <= '9'))
										while ((number[9] >= '0') && (number[9] <= '9'))
											while ((number[10] >= '0') && (number[10] <= '9'))
												while ((number[11] >= '0') && (number[11] <= '9'))
												{
													{
														areacode = number.substr(0, 3); // baby string!!!!!

														if (areacode == "403" || areacode == "587" || areacode == "780" || areacode == "825")
															cout << "Your phone number is from Alberta." << endl;
														else if (areacode == "236" || areacode == "250" || areacode == "604" || areacode == "672" || areacode == "778")
															cout << "Your phone number is from British Columbia." << endl;
														else if (areacode == "204" || areacode == "431")
															cout << "Your phone number is from Manitoba." << endl;
														else if (areacode == "506")
															cout << "Your phone number is from New Brunswick." << endl;
														else if (areacode == "709")
															cout << "Your phone number is from Newfoundland and Labrador." << endl;
														else if (areacode == "782" || areacode == "902")
															cout << "Your phone number is from Nova Scotia or Prince Edward Island." << endl;
														else if (areacode == "548" || areacode == "249" || areacode == "289" || areacode == "343" || areacode == "365" || areacode == "387" || areacode == "416" || areacode == "437" || areacode == "519" || areacode == "226" || areacode == "613" || areacode == "647" || areacode == "705" || areacode == "742" || areacode == "807" || areacode == "905")
															cout << "Your phone number is from Ontario." << endl;
														else if (areacode == "418" || areacode == "438" || areacode == "450" || areacode == "514" || areacode == "579" || areacode == "581" || areacode == "819" || areacode == "873")
															cout << "Your phone number is from Quebec." << endl;
														else if (areacode == "306" || areacode == "639")
															cout << "Your phone number is from Saskatchewan." << endl;
														else if (areacode == "867")
															cout << "Your phone number is from Yukon, Northwest Territories, and Nunavut." << endl;
														else
														{
															cout << "That is not a CANADIAN number." << endl; //could be anywhere else in the world
														}
													}
			cout << "Please enter a telephone number in the format ddd-ddd-dddd." << endl; //
			cin >> number;
												}

		cout << "Please enter a telephone number in the format ddd-ddd-dddd." << endl;
		cin >> number;
	}
	return 0; // the end!!
}