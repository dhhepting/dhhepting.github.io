#include <iostream>
#include <string>
using namespace std;

int main()
{
	while (true)
	{
		cout << "You should enter a phone number (format ddd-ddd-dddd)," << endl;
		cout << "and I'll tell you where it's from" << endl;
		cout << "Or enter q to quit" << endl;
		char inp1;
		cin >> inp1;

		if (inp1 == 'q' || inp1 == 'Q')
			return 1;

		string phnum1;
		getline(cin, phnum1);

		string phnum = inp1 + phnum1;
		string acode, dash, dig3, dig4;
		acode = phnum.substr(0, 2);
		dash = phnum.substr(3, 3);
		dig3 = phnum.substr(4, 6);
		dash = phnum.substr(7, 7);
		dig4 = phnum.substr(8, 10);

		if (dash != "-")
		{
			cout << "Invalid input" << endl;
			break;
		}

		cout << "The phone number is from ";

		if (acode == "403" || acode == "587" || acode == "780")
			cout << "Alberta" << endl;
		else if (acode == "236" || acode == "250" || acode == "604" || acode == "778")
			cout << "British Columbia" << endl;
		else if (acode == "204" || acode == "431")
			cout << "Manitoba" << endl;
		else if (acode == "506")
			cout << "New Brunswick" << endl;
		else if (acode == "709")
			cout << "Newfoundland and Labrador" << endl;
		else if (acode == "782" || acode == "902")
			cout << "Nova Scotia" << endl;
		else if (acode == "548" || acode == "249" || acode == "289" || acode == "343" || acode == "365" || acode == "416"
			|| acode == "437" || acode == "519" || acode == "226" || acode == "613" || acode == "647" || acode == "705"
			|| acode == "807" || acode == "905")
			cout << "Ontario" << endl;
		else if (acode == "782" || acode == "902")
			cout << "Prince Edward Island" << endl;
		else if (acode == "418" || acode == "438" || acode == "450" || acode == "514" || acode == "579" || acode == "581"
			|| acode == "819" || acode == "873")
			cout << "Quebec" << endl;
		else if (acode == "306" || acode == "639")
			cout << "Saskatchewan" << endl;
		else if (acode == "867")
			cout << "Yukon, Northwest Territories, or Nunavut" << endl;
		else
			cout << "I don't know: probably Mordor" << endl;
	} 
	return 0;
}