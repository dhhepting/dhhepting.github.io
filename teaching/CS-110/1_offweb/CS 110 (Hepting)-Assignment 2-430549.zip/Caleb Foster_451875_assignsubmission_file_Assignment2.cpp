//**************************************************************************
//
// Student name: Caleb Foster
//
// Student number: 200354226
//
// Assignment number: 2
//
// Program name: Assignment 2
//
// Date written: Feb 25/2015
//
// Problem statement:  a program that reads a phone number and tells you what Canadian province or territory the area code belongs too.
//
// Input: Phone Number and a letter to end or continue loop
//
// Output: Canadian province or territory the area code belongs too, if any, or tells you wrong format if its wrong format.
//
// Algorithm: First i set some variable to use in the code. Then i made a loop with a while statement by making the main program keep repeating until the character variable 'end' equals q. 
//				The main program asks the user to enter a number then checks if the format is correct if it isnt correct it sas wrong format. If the format is correct it creates a new string which is a substring of the area code in the first string.
//				After that it tests if the area code string matchs any of the canadian area codes. If it matchs it tell where it is from, if it doesnt match it tells you so. Then it asks you to enter 'q' if you want to quit.
//				If the user enters 'q' it ends the loop, anything other letter restarts the main program. 
//
// Major variables: phone, code, end.
//
// Assumptions: assume they read instructions properly
//
// Program limitations:  Only knows Canadian area codes 
//
//**************************************************************************





#include <iostream> 
#include <string>
using namespace std;

int main()
{
	string phone;
	char end;
	
	end = 'a';

	while (end != 'q')
	{

		cout << "Please enter a telephone number in the format ddd-ddd-dddd, where d is digit. " << endl;
		cin >> phone;


		if (phone.length() != 12)
		{
			cout << "Sorry wrong format. " << endl;
			
		}
		else
		{
			if (phone[3] == '-' && phone[7] == '-')
			{
				if (phone[0] >= '0' && phone[0] <= '9' && phone[1] >= '0' && phone[1] <= '9' && phone[2] >= '0' && phone[2] <= '9' && phone[4] >= '0' && phone[4] <= '9' && phone[5] >= '0' && phone[5] <= '9' && phone[6] >= '0' && phone[6] <= '9' && phone[8] >= '0' && phone[8] <= '9' && phone[9] >= '0' && phone[9] <= '9' && phone[10] >= '0' && phone[10] <= '9' && phone[11] >= '0' && phone[11] <= '9')
				{

					string code = phone.substr(0, 3);

					if (code == "403" || code == "587" || code == "780" || code == "852")
					{
						cout << "The area code " << code << " belongs to the province of Alberta." << endl;
					}

					else if (code == "236" || code == "250" || code == "604" || code == "672" || code == "778")
					{

						cout << "The area code " << code << " belongs to the province of British Columbia." << endl;
					}

					else if (code == "204" || code == "431")
					{
						cout << "The area code " << code << " belongs to the province of Manitoba." << endl;
					}

					else if (code == "506")
					{
						cout << "The area code " << code << " belongs to the province of New Brunswick." << endl;
					}

					else if (code == "709")
					{

						cout << "The area code " << code << " belongs to the province of Newfoundland and Labrador." << endl;
					}

					else if (code == "782" || code == "902")
					{
						cout << "The area code " << code << " belongs to the provinces of Nova Scotia and Prince Edward Island." << endl;
					}

					else if (code == "548" || code == "249" || code == "289" || code == "343" || code == "365" || code == "387" || code == "416" || code == "437" || code == "519" || code == "226" || code == "613" || code == "647" || code == "705" || code == "742" || code == "807" || code == "905")
					{

						cout << "The area code " << code << " belongs to the province of Ontario." << endl;
					}

					else if (code == "418" || code == "438" || code == "450" || code == "514" || code == "579" || code == "581" || code == "819" || code == "873")
					{

						cout << "The area code " << code << " belongs to the province of Quebec." << endl;
					}

					else if (code == "306" || code == "639")
					{

						cout << "The area code " << code << " belongs to the province of Saskatchewan." << endl;
					}

					else if (code == "867")
					{

						cout << "The area code " << code << " belongs to the territories of Yukon, Northwest Territories, and Nunavut." << endl;
					}

					else
					{
						cout << "That is not an area code from Canada." << endl;
					}
				}
				else
					cout << "Sorry wrong format. " << endl;
			}
			else
			{
				cout << "Sorry wrong format. " << endl;
				
			}

		}
		
		cout << "Enter q if you want to quit." << endl;
		cin >> end;
	}
	
	return 0;
}