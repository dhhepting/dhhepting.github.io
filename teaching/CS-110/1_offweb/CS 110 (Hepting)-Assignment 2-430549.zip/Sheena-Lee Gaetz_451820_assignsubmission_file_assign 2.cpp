#include <iostream>
using namespace std;

int main()
{
	int d1, d2, d3;
	char c1, c2;
	

	cout << "Please enter a phone number in the format ddd-ddd-dddd: ";
	cin >> d1 >> c1 >> d2 >> c2 >> d3;

	while (d1 < 100 || d1 > 999 || d2 < 0 || d2 > 999 || d3 < 0 || d3 > 9999)
	{
		cout << "This is an invalid phone number (or in the wrong format).Please enter a phone number in the format ddd-ddd-dddd: ";
		cin >> d1 >> c1 >> d2 >> c2 >> d3;
	}
	bool repeat;
	repeat = false;

		switch (d1)

		{
		case 403: cout << "This is an area code for Alberta." << endl; break;
		case 587: cout << "This is an area code for Alberta." << endl; break;
		case 780: cout << "This is an area code for Alberta." << endl; break;
		case 825: cout << "This is an area code for Alberta." << endl; break;
		case 236: cout << "This is an area code for British Columbia." << endl; break;
		case 250: cout << "This is an area code for British Columbia." << endl; break;
		case 604: cout << "This is an area code for British Columbia." << endl; break;
		case 672: cout << "This is an area code for British Columbia." << endl; break;
		case 778: cout << "This is an area code for British Columbia." << endl; break;
		case 204: cout << "This is an area code for Manitoba." << endl; break;
		case 431: cout << "This is an area code for Manitoba." << endl; break;
		case 506: cout << "This is an area code for New Brunswick." << endl; break;
		case 709: cout << "This is an area code for Newfoundland and Labrador." << endl; break;
		case 782: cout << "This is an area code for Nova Scotia and Prince Edward Island." << endl; break;
		case 902: cout << "This is an area code for Nova Scotia and Prince Edward Island." << endl; break;
		case 548: cout << "This is an area code for Ontario." << endl; break;
		case 249: cout << "This is an area code for Ontario." << endl; break;
		case 289: cout << "This is an area code for Ontario." << endl; break;
		case 343: cout << "This is an area code for Ontario." << endl; break;
		case 365: cout << "This is an area code for Ontario." << endl; break;
		case 387: cout << "This is an area code for Ontario." << endl; break;
		case 416: cout << "This is an area code for Ontario." << endl; break;
		case 437: cout << "This is an area code for Ontario." << endl; break;
		case 519: cout << "This is an area code for Ontario." << endl; break;
		case 226: cout << "This is an area code for Ontario." << endl; break;
		case 613: cout << "This is an area code for Ontario." << endl; break;
		case 647: cout << "This is an area code for Ontario." << endl; break;
		case 705: cout << "This is an area code for Ontario." << endl; break;
		case 742: cout << "This is an area code for Ontario." << endl; break;
		case 807: cout << "This is an area code for Ontario." << endl; break;
		case 905: cout << "This is an area code for Ontario." << endl; break;
		case 418: cout << "This is an area code for Quebec." << endl; break;
		case 438: cout << "This is an area code for Quebec." << endl; break;
		case 450: cout << "This is an area code for Quebec." << endl; break;
		case 514: cout << "This is an area code for Quebec." << endl; break;
		case 579: cout << "This is an area code for Quebec." << endl; break;
		case 581: cout << "This is an area code for Quebec." << endl; break;
		case 819: cout << "This is an area code for Quebec." << endl; break;
		case 873: cout << "This is an area code for Quebec." << endl; break;
		case 306: cout << "This is an area code for Saskatchewan." << endl; break;
		case 639: cout << "This is an area code for Saskatchewan." << endl; break;
		case 867: cout << "This is an area code for Yukon, Northwest Territories, and Nunavut." << endl; break;
		default: cout << "This number does not have a Canadian area code. ";
			repeat = true;
			
		}
		while (repeat)
		{
			cout << "Please enter a phone number in the format ddd-ddd-dddd: ";
			cin >> d1 >> c1 >> d2 >> c2 >> d3;
		}
	
	return 0;
}