//Name: Kian Blanchette
//Student ID: 200354600
//Assignment 2
//Program Name: The Area Code
//Date: 24 February 2015
//Problem Statement: Have the user enter phone numbers of the form 'ddd-ddd-dddd' where the 'd' are integers. Determine if the numbers are from Canada and continue
//					 taking input until the user enters q.
//Input: Multiple phone numbers 
//Output: The province or territory the numbers come from if Canadian or a statement saying the number is not Canadian.
//Major Variables: number - whatever the user enters
//				   areaCode - the first three characters of number
//Assumptions: That the user knows what integers are
//Program Limitations: The program requires that the user enters only one string at a time. It still gives the proper output for all the strings consecutively,
//					   but it looks a bit weird.
#include <iostream>
#include <string>
using namespace std;

int main()
{
	string number; //Declare the variable corresponding to the phone number
	cout << "Please input a phone number in the form 'ddd-ddd-dddd' where the 'd' are\nintegers. When you no longer wish to enter phone numbers, enter 'q' to exit." << endl;
	do
	{
		cin >> number; //Enter a phone number
		string areaCode = number.substr(0, 3); //Declare the other variable, areaCode, to be the first three characters of number
		if (number == "q") //If the user inputs 'q' the program ends
			return 0;
		if (number.length() == 12) //Check if the number is the correct length. If not, output that it is not.
		{
			if (number[0] >= '0' && number[0] <= '9' && number[1] >= '0' && number[1] <= '9' && number[2] >= '0' && number[2] <= '9' && number[3] == '-'
				&& number[4] >= '0' && number[4] <= '9' && number[5] >= '0' && number[5] <= '9' && number[6] >= '0' && number[6] <= '9' && number[7] == '-'
				&& number[8] >= '0' && number[8] <= '9' && number[9] >= '0' && number[9] <= '9' && number[10] >= '0' && number[10] <= '9' && number[11] >= '0'
				&& number[11] <= '9') //Check if the number is written in the correct format. If not, output that it is not.
			{
				//If the number is the correct length and format, check if it is from a Canadian area code and output the results
				if (areaCode == "403" || areaCode == "587" || areaCode == "780" || areaCode == "825")
					cout << "This phone number is from Alberta." << endl;
				else if (areaCode == "236" || areaCode == "250" || areaCode == "604" || areaCode == "672" || areaCode == "778")
					cout << "This phone number is from British Columbia." << endl;
				else if (areaCode == "204" || areaCode == "431")
					cout << "This phone number is from Manitoba." << endl;
				else if (areaCode == "506")
					cout << "This phone number is from New Brunswick." << endl;
				else if (areaCode == "709")
					cout << "This phone number is from Newfoundland and Labrador." << endl;
				else if (areaCode == "782" || areaCode == "902")
					cout << "This phone number is from Nova Scotia or Prince Edward Island." << endl;
				else if (areaCode == "548" || areaCode == "249" || areaCode == "289" || areaCode == "343" || areaCode == "365" || areaCode == "365"
					|| areaCode == "387" || areaCode == "416" || areaCode == "437" || areaCode == "519" || areaCode == "226" || areaCode == "613"
					|| areaCode == "647" || areaCode == "705" || areaCode == "742" || areaCode == "807" || areaCode == "905")
					cout << "This phone number is from Ontario." << endl;
				else if (areaCode == "418" || areaCode == "438" || areaCode == "450" || areaCode == "514" || areaCode == "579" || areaCode == "581"
					|| areaCode == "819" || areaCode == "873")
					cout << "This phone number is from Quebec." << endl;
				else if (areaCode == "306" || areaCode == "639")
					cout << "This phone number is from Saskatchewan." << endl;
				else if (areaCode == "867")
					cout << "This phone number is from Yukon, Northwest Territories or Nunavut." << endl;
				else
					cout << "This phone number is not from Canada." << endl;
			}
			else cout << "Wrong input homie" << endl;
		}
		else cout << "Wrong input homie" << endl;
	} while (number != "q"); //This loop keeps the program going as long as the user does not enter 'q.' It functions exactly identically to the previous section.
	{
		cin >> number;
		string areaCode = number.substr(0, 3);
		if (number == "q")
			return 0;
		else if (number.length() == 12)
		{
			if (number[0] >= '0' && number[0] <= '9' && number[1] >= '0' && number[1] <= '9' && number[2] >= '0' && number[2] <= '9' && number[3] == '-'
				&& number[4] >= '0' && number[4] <= '9' && number[5] >= '0' && number[5] <= '9' && number[6] >= '0' && number[6] <= '9' && number[7] == '-'
				&& number[8] >= '0' && number[8] <= '9' && number[9] >= '0' && number[9] <= '9' && number[10] >= '0' && number[10] <= '9' && number[11] >= '0'
				&& number[11] <= '9')
			{
				if (areaCode == "403" || areaCode == "587" || areaCode == "780" || areaCode == "825")
					cout << "This phone number is from Alberta." << endl;
				else if (areaCode == "236" || areaCode == "250" || areaCode == "604" || areaCode == "672" || areaCode == "778")
					cout << "This phone number is from British Columbia." << endl;
				else if (areaCode == "204" || areaCode == "431")
					cout << "This phone number is from Manitoba." << endl;
				else if (areaCode == "506")
					cout << "This phone number is from New Brunswick." << endl;
				else if (areaCode == "709")
					cout << "This phone number is from Newfoundland and Labrador." << endl;
				else if (areaCode == "782" || areaCode == "902")
					cout << "This phone number is from Nova Scotia or Prince Edward Island." << endl;
				else if (areaCode == "548" || areaCode == "249" || areaCode == "289" || areaCode == "343" || areaCode == "365" || areaCode == "365"
					|| areaCode == "387" || areaCode == "416" || areaCode == "437" || areaCode == "519" || areaCode == "226" || areaCode == "613"
					|| areaCode == "647" || areaCode == "705" || areaCode == "742" || areaCode == "807" || areaCode == "905")
					cout << "This phone number is from Ontario." << endl;
				else if (areaCode == "418" || areaCode == "438" || areaCode == "450" || areaCode == "514" || areaCode == "579" || areaCode == "581"
					|| areaCode == "819" || areaCode == "873")
					cout << "This phone number is from Quebec." << endl;
				else if (areaCode == "306" || areaCode == "639")
					cout << "This phone number is from Saskatchewan." << endl;
				else if (areaCode == "867")
					cout << "This phone number is from Yukon, Northwest Territories or Nunavut." << endl;
				else
					cout << "This phone number is not from Canada." << endl;
			}
			else cout << "Wrong input homie" << endl;
		}
		else cout << "Wrong input homie" << endl;
	}
	
}
