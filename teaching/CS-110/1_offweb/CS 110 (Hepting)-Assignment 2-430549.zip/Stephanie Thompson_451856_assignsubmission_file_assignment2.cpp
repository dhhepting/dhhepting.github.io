//**************************************************************************
//
// Student name: Stephanie Thompson
//
// Student number: 200355041
//
// Assignment number: Assignmnet 2
//
// Program name: Area Code Tester
//
// Date written: February 24, 2015
//
// Problem statement: The user needs to know the province or territory of Canada that that area code applies to. 
//
// Input: The user will input a phone number to find where in Canada the number belongs to, or the letter Q if they wish to close the program.
//
// Output: The program will output a message to prompt the user to enter a phone number.  After testing the areacode the program will display what Canadian province
// or territory the areacode belongs to.
//
// Algorithm: The program will first prompt the user to enter a ten digit phone number with a certain format.  Once the number is entered the program will
// test if the value is equal to Q (if it is the program will close).  If the input does not equal Q the program will enter a loop.  Inside the loop are
// a series of if statements.  The first will test for the correct format including length, dashes, and letters.  If the phone number is in the correct format
// the areacode will be tested to match a province and then the user will be prompted again to enter another phone number.  If the phone number is in an improper
// format an error message will be displayed and the user will be asked to enter another phone number.
//
// Major variables: The major variables in the program include phonenumber, areacode, dash1, dash2, nnx, and suffix.
//
// Assumptions: The user will only input Canadian phone numbers.
//
// Program limitations: The program will only be able to tell the area code of a province or territory of Canada (any area codes outside of Canada cannot be assigned to a state, 
// province, territory, etc.) that is entered with a phone number.
//
//**************************************************************************
#include <iostream>
#include <string>
using namespace std;

int main()
{
	// Initialization of major variables
	string phonenumber, areacode, dash1, dash2, nnx, suffix;
	// Prompting the user to enter a phone number
	cout << "Please enter a ten digit phone number in the form ddd-ddd-dddd where d is a digit.  If you wish to close the program press the letter 'Q'." << endl;
	cin >> phonenumber;

	// Creates a loop that runs until the user inputs Q
	while (phonenumber != "Q")
	{
		if (phonenumber.length() == 12) // Tests the format of the users input
		{
			// Assignment of values to variables based on user input
			areacode = phonenumber.substr(0, 3);
			nnx = phonenumber.substr(4, 3);
			suffix = phonenumber.substr(8, 4);
			dash1 = phonenumber.substr(3, 1);
			dash2 = phonenumber.substr(7, 1);
			if (dash1 == "-" && dash2 == "-" && areacode >= "000" && areacode <= "999" && nnx >= "000" && nnx <= "999" && suffix >= "0000" && suffix <= "9999") // Tests the format of the users input (for dashes and letters)
			{
				// Tests the area code of the phone number and displays the province or territory it belongs to
				if (areacode == "403" || areacode == "587" || areacode == "780" || areacode == "825")
				{
					cout << "The area code of the phone number you have entered belongs to Alberta." << endl;
				}
				if (areacode == "236" || areacode == "250" || areacode == "604" || areacode == "672" || areacode == "778")
				{
					cout << "The area code of the phone number you have entered belongs to British Columbia." << endl;
				}
				if (areacode == "204" || areacode == "431")
				{
					cout << "The area code of the phone number you have entered belongs to Manitoba." << endl;
				}
				if (areacode == "506")
				{
					cout << "The area code of the phone number you have entered belongs to Newfoundland and Labrador." << endl;
				}
				if (areacode == "782" || areacode == "902")
				{
					cout << "The area code of the phone number you have entered belongs to Nova Scotia." << endl;
				}
				if (areacode == "548" || areacode == "249" || areacode == "289" || areacode == "343" || areacode == "365" || areacode == "387" || areacode == "416" ||
					areacode == "437" || areacode == "519" || areacode == "226" || areacode == "613" || areacode == "647" || areacode == "705" || areacode == "742" || areacode == "807" || areacode == "905")
				{
					cout << "The area code of the phone number you have entered belongs to Ontario." << endl;
				}
				if (areacode == "789" || areacode == "902")
				{
					cout << "The area code of the phone number you have entered belongs to Prince Edward Island." << endl;
				}
				if (areacode == "418" || areacode == "438" || areacode == "450" || areacode == "514" || areacode == "579" || areacode == "581" || areacode == "819" || areacode == "873")
				{
					cout << "The area code of the phone number you have entered belongs to Quebec." << endl;
				}
				if (areacode == "306" || areacode == "639")
				{
					cout << "The area code of the phone number you have entered belongs to Saskatchewan." << endl;
				}
				if (areacode == "867")
				{
					cout << "The area code of the phone number you have entered belongs to the Yukon, Northwest Territories, and Nunavut." << endl;
				}
				if (areacode != "403" && areacode != "587" && areacode != "780" && areacode != "825" && areacode != "236" && areacode != "250" && areacode != "604" && areacode != "672" && areacode != "778" && areacode != "204" && areacode != "431" && areacode != "506" && areacode != "782" && areacode != "902" && areacode != "548" && areacode != "249" && areacode != "289" && areacode != "343" && areacode != "365" && areacode != "387" && areacode != "416" &&
					areacode != "437" && areacode != "519" && areacode != "226" && areacode != "613" && areacode != "647" && areacode != "705" && areacode != "742" && areacode != "807" && areacode != "905" && areacode != "789" && areacode != "902" && areacode != "418" && areacode != "438" && areacode != "450" && areacode != "514" && areacode != "579" && areacode != "581" && areacode != "819" && areacode != "873" && areacode != "306" && areacode != "639" && areacode != "867")
				{
					cout << "The area code of the phone number you have entered does not belong to a Canadian province or territory." << endl;
				}
			}
			// Error message if the number does not include dashes or includes letters
			else
			{
				cout << "The number you entered is invalid." << endl;
			}
		}
		// Error messgae if the number is not 12 characters
		else
		{
			cout << "The number you entered is invalid." << endl;
		}
		// Prompts the user to input a new phone number
		cout << "Please enter a ten digit phone number in the form ddd-ddd-dddd where d is a digit.  If you wish to close the program press the letter 'Q'." << endl;
		cin >> phonenumber;
	}
	// End of program message when the user inputs Q to quit the program
	cout << "Thank you." << endl;

	return 0;

}