// Muhammad Alghadhban
// SID: 200318904
// CS 110: Programming & Problem Solving
// Assignment 2

#include <iostream>
#include <string>
#include <ctype.h>

using namespace std;

//Func: isInteger(string)
//	Input: A string of characters
//	Output:
//		- TRUE: If all characters in the string are digits
//		- FALSE: If any character in the string is not a digit
inline bool isInteger(const string str)
{
	//Convert string to a char array
	const char *cstr = str.c_str();

	//Iterate through the character array
	for (unsigned i = 0; i < str.length(); i++)
	{
		//return false if a non-digit character is found
		if (!isdigit(cstr[i]))
			return false;
	}

	//return true if all the characters are digits
	return true;
}

int main()
{
	//String variable to hold the telephone number
	string userInput;

start:

	//Remove existing content
	userInput.clear();

	//Prompt the user to enter a telephone number
	cout << "Enter a telephone number (q to end): ";

	//Get input from the user
	getline(cin, userInput);

	//Acceptable input formats:
	// 1.	ddd-ddd-dddd
	//		chars: 12
	//
	// 2.	dddddddddd
	//		chars: 10
	//
	// esc.	q
	//		chars: 1

	//Format 1 if the string has 12 chars 
	if (userInput.length() == 12)
	{
		//Check if the hypens are at the correct positions
		if (userInput[3] == '-' && userInput[7] == '-')
		{
			// Remove hyphens
			userInput.erase(3,1);
			userInput.erase(6,1);

			goto trimmed;
		}

		else
		{
			goto error;
		}
	}

	//Format 2 if the string has 10 chars
	else if (userInput.length() == 10)
	{
	trimmed:

		//Check if all the char is an integer
		if (!isInteger(userInput))
		{
			goto error;
		}

		//Convert first 3 chars of the string to int to get area code 
		int areaCode = stoi(userInput.substr(0, 3));
		
		//Check where the area code belongs to and display the appropriate message 
		if (areaCode == 403 || areaCode == 587 || areaCode == 780 || areaCode == 825)
			cout << "Alberta" << endl;
		else if (areaCode == 236 || areaCode == 250 || areaCode == 604 || areaCode == 672 || areaCode == 778)
			cout << "British Columbia" << endl;
		else if (areaCode == 204 || areaCode == 431)
			cout << "Manitoba" << endl;
		else if (areaCode == 506)
			cout << "New Brunswick" << endl;
		else if (areaCode == 709)
			cout << "Newfoundland and Labrador" << endl;
		else if (areaCode == 782 || areaCode == 902)
			cout << "Nova Scotia" << endl;
		else if (areaCode == 548 || areaCode == 249 || areaCode == 289 || areaCode == 343 || areaCode == 365
			|| areaCode == 387 || areaCode == 416 || areaCode == 437 || areaCode == 519 || areaCode == 226
			|| areaCode == 613 || areaCode == 647 || areaCode == 705 || areaCode == 742 || areaCode == 807
			|| areaCode == 905)
			cout << "Ontario" << endl;
		else if (areaCode == 782 || areaCode == 902)
			cout << "Prince Edward Island" << endl;
		else if (areaCode == 418 || areaCode == 438 || areaCode == 450 || areaCode == 514 || areaCode == 579
			|| areaCode == 581 || areaCode == 819 || areaCode == 873)
			cout << "Quebec" << endl;
		else if (areaCode == 306 || areaCode == 639)
			cout << "Saskatchewan" << endl;
		else if (areaCode == 867)
			cout << "Yukon, Northwest Territories, and Nunavut" << endl;
		else
			cout << "Non-Canadian Area Code" << endl;

		//Jump to the start to get user input again
		goto start;
	}

	//q is the escape code
	else if (userInput == "q")
	{
		//Quit program
		return 0;
	}

	// Invalid length
	else
	{
	error:
		//Display Error Message
		cout << "Invalid input" << endl;
		cout << "Format should be: ddd-ddd-dddd" << endl;

		//Jump to the start to get user input again
		goto start;
	}

	return 0;
}