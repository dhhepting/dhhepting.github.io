//**************************************************************************
//
// Student name: Amanda Flaman
//
// Student number: 200340561
//
// Assignment number: 2
//
// Program name: Assignment 2.cpp
//
// Date written: Feb. 23/2015
//
// Problem statement:  a program that asks the user for a phone number of certain format and take the first 3 digits of that phonoenumber and tells which province the area code belongs to or if the area code does not belong to a Canadian province. If the phone number entered is not in the correct format then the program will tell the user "wrong format" and if the user wants to quit the program they press 'q'.
//
// Input: Phone Number
//
// Output: The province that the area code belongs to.
//
// Algorithm: Ask user to enter a phone number of the format ddd-ddd-dddd. If the phone number is 12 characters long then the program continues if not then it tells the user "wrong format" and the user can enter a new input. Then if the third character and the seventh character then the program will check if all the other characters are numerical digits. If they are then the program will pull out the first 3 digits of the phone number and read them. If the first 3 numbers are a Canadian area code then the output will say which province the area code belongs to. A whille loop is used so that phone numbers can be entered continually. The program then gives the option to press 'q'. If the user presses 'q' the program quits.
//
// Major variables: phonenum, finish, acode
//
// Assumptions: The user is entering numbers
//
// Program limitations: It doesn't tell area codes for places outside of Canada
//
//**************************************************************************
#include <iostream>
#include <string>
using namespace std;

int main()
{
    string phonenum;
    char finish;
    
    finish = 'a';
    
    while (finish != 'q')
    {
        
        cout << "Enter a phone number in the format ddd-ddd-dddd, where d is digit. " << endl;
        cin >> phonenum;
        
        
        if (phonenum.length() != 12)
        {
            cout << "Sorry, wrong format. " << endl;
            
        }
        else
        {
            if (phonenum[3] == '-' && phonenum[7] == '-')
            {
                if (phonenum[0] >= '0' && phonenum[0] <= '9' && phonenum[1] >= '0' && phonenum[1] <= '9' && phonenum[2] >= '0' && phonenum[2] <= '9' && phonenum[4] >= '0' && phonenum[4] <= '9' && phonenum[5] >= '0' && phonenum[5] <= '9' && phonenum[6] >= '0' && phonenum[6] <= '9' && phonenum[8] >= '0' && phonenum[8] <= '9' && phonenum[9] >= '0' && phonenum[9] <= '9' && phonenum[10] >= '0' && phonenum[10] <= '9' && phonenum[11] >= '0' && phonenum[11] <= '9')
                {
                    
                    string acode = phonenum.substr(0, 3);
                    
                    if (acode == "403" || acode == "587" || acode == "780" || acode == "852")
                    {
                        cout << "The area code " << acode << " belongs to the province of Alberta." << endl;
                    }
                    
                    
                    else if (acode == "204" || acode == "431")
                    {
                        cout << "The area code " << acode << " belongs to the province of Manitoba." << endl;
                    }
                    
                     else if (acode == "236" || acode == "250" || acode == "604" || acode == "672" || acode == "778")
                    {
                        
                        cout << "The area code " << acode << " belongs to the province of British Columbia." << endl;
                    }
                    
                    
                    else if (acode == "709")
                    {
                        
                        cout << "The area code " << acode << " belongs to the province of Newfoundland and Labrador." << endl;
                    }
                    
                    else if (acode == "506")
                    {
                        cout << "The area code " << acode << " belongs to the province of New Brunswick." << endl;
                    }

                    else if (acode == "782" || acode == "902")
                    {
                        cout << "The area code " << acode << " belongs to the provinces of Nova Scotia and Prince Edward Island." << endl;
                    }
                    
                    else if (acode == "548" || acode == "249" || acode == "289" || acode == "343" || acode == "365" || acode == "387" || acode == "416" || acode == "437" || acode == "519" || acode == "226" || acode == "613" || acode == "647" || acode == "705" || acode == "742" || acode == "807" || acode == "905")
                    {
                        
                        cout << "The area code " << acode << " belongs to the province of Ontario." << endl;
                    }
                    
                    
                    else if (acode == "306" || acode == "639")
                    {
                        
                        cout << "The area code " << acode << " belongs to the province of Saskatchewan." << endl;
                    }
                    
                    else if (acode == "418" || acode == "438" || acode == "450" || acode == "514" || acode == "579" || acode == "581" || acode == "819" || acode == "873")
                    {
                        
                        cout << "The area code " << acode << " belongs to the province of Quebec." << endl;
                    }
                    
                    else if (acode == "867")
                    {
                        
                        cout << "The area code " << acode << " belongs to the territories of Yukon, Northwest Territories, and Nunavut." << endl;
                    }
                    
                    else
                    {
                        cout << "That is not an area code from Canada." << endl;
                    }
                }
                else
                    cout << "Sorry wrong format. " << endl;
            }
            else
            {
                cout << "Sorry wrong format. " << endl;
                
            }
            
        }
        
        cout << "Enter q to quit." << endl;
        cin >> finish;
    }
    
    return 0;
}