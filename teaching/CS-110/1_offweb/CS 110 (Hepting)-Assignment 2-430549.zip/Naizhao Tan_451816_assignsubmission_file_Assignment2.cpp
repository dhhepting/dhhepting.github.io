/*
Name: Naizhao Tan
Student Number: 200353140
Assignment Number: 2
Program name: Assignment 2
Data: Feb 19 2015
	Problem Statement:Write a program that prompts the user to enter a telephone number in the format ddd-ddd-dddd, 
	where d is digit. This is the format for telephone numbers in North America. 
	Test that the input is in the correct format and further check if the phone number has a Canadian area code (see the list of Canadian area codes). 
	The program will report if the input is valid or not. 
	If the input includes a Canadian area code, the program will display the name of the province or territory with that area code. 
	The program will continue to process numbers until the user enters the letter q.

Input: Phone Number
Output: Phone Number and where it below
Algorithm:
	Step 1: Read in the phone number
	Step 2: Judge if the input is the right format
	Step 3: Find the region of this phonenumber
	Step 4: Output the region and phone number
Major variables:
	phoneNumber: the input number
	checkFormat: varibles used to check if there is "-" in the input
	checkNumber: varibles used to check if the input is all numbers
	f: first three digits of the input used to find the region
	g: the varible used to accept the region
	c: last eight digits of the input
	h: the length of the input
*/

#include <iostream>
#include <string>
using namespace std;

int main(){
	string phoneNumber, f, g;
	int checkFormat1, checkFormat2;
	bool checkNumber1, checkNumber2, checkNumber3;
	do{
		checkNumber1 = false;
		checkNumber2 = false;
		checkNumber3 = false;
		// Read in the phone number 
		cout << "Please enter your phone number" << endl;
		cin >> phoneNumber;				
		// Judge if the user wants to quit
		if (phoneNumber != "q"){
			//	Judge if the length of input is 12
			int h = phoneNumber.length();	
			if (h == 12){
				// Check if there is "-" in the input and find where it is
				checkFormat1 = phoneNumber.find("-");
				string c = phoneNumber.substr(4, 11);
				checkFormat2 = c.find("-");
				f = phoneNumber.substr(0, 3);
				g = "";
				// Check if the input is in the right format
				if (checkFormat1 == 3 && checkFormat2 == 3){
					// Used three loops to see if the input is all numbers
					for (int i = 0; i <= 2; i++){
						if (phoneNumber[i] >= '0' && phoneNumber[i] <= '9'){
							checkNumber1 = true;
						}
						// Break the loop if there is a character
						else{
							checkNumber1 = false;
							break;
						}
					}
					for (int i = 4; i <= 6; i++){
						if (phoneNumber[i] >= '0' && phoneNumber[i] <= '9'){
							checkNumber2 = true;
						}
						else{
							checkNumber2 = false;
							break;
						}
					}
					for (int i = 8; i <= 11; i++){
						if (phoneNumber[i] >= '0' && phoneNumber[i] <= '9'){
							checkNumber3 = true;
						}
						else{
							checkNumber3 = false;
							break;
						}
					}
					
					// Keep going if there is no character in the input
					if (checkNumber1 && checkNumber2 && checkNumber3){
						// Find the region of the phone number
						if (f == "403" || f == "587" || f == "780" || f == "825"){
							g = "Alberta";
						}
						else if (f == "206" || f == "250" || f == "604" || f == "672" || f == "778"){
							g = "British Columbia";

						}
						else if (f == "204" || f == "431"){
							g = "Manitoba";
						}
						else if (f == "506"){
							g = "New Brunswick";
						}
						else if (f == "709"){
							g = "Newfoundland and Labrador";
						}
						else if (f == "782" || f == "902"){
							g = "Nova Scotia";
						}
						else if (f == "548" || f == "249" || f == "289" || f == "343" || f == "365" || f == "387" || f == "416" || f == "437" ||
							f == "519" || f == "226" || f == "613" || f == "647" || f == "705" || f == "742" || f == "807" || f == "905"){
							g = "Ontario";
						}
						else if (f == "782" || f == "902"){
							g = "Prince Edward Island";
						}
						else if (f == "418" || f == "438" || f == "450" || f == "514" || f == "579" || f == "581" || f == "819" || f == "873"){
							g = "Quebec";
						}
						else if (f == "306" || f == "639"){
							g = "Saskatchewan";
						}
						else if (f == "867"){
							g = "Yukon, Northwest Territories, and Nunavut";
						}
						else{
							g = "Abroad";
						}
						// Output the result if the input meet the conditions
						cout << "Your region is: " << g << endl;
						cout << "Your phone number is: " << phoneNumber << endl;
					}
					else {
						cout << "Invalid input: there should be no character" << endl;
					}

				}
				else{
					cout << "Invalid input: wrong format" << endl;
				}


			}
			else{
				cout << "Invalid input: there should be 12 digits" << endl;
			}
		}
		// Stop the loop if the input is "q"
	} while (phoneNumber != "q");




	return 0;
}