/*
Student name: Brooke Ham
Student number: 200353759
Assignment number: 2
Program name: Area Coding
Date: written for Feb. 25, 2015
Problem Statement: Write a program that prompts the user to enter a telephone number in the format ddd-ddd-dddd, where d is digit.
	This is the format for telephone numbers in North America. Test that the input is in the correct format and further check if the
	phone number has a Canadian area code (see the list of Canadian area codes). The program will report if the input is valid or not.
	If the input includes a Canadian area code, the program will display the name of the province or territory with that area code.
	The program will continue to process numbers until the user enters the letter q.
Input: A number preferably in the form ddd-ddd-dddd (where d is a digit), although other inputs will give an output on this program.
Output: The correctness of the format of the input and whether the area code is Canadian are the outputs of this program.
Algorithm: The user will enter a number string in the correct format (after being prompted to do so) and the format will be tested (using
	boolean operators to test each section of the phone number and its total length) and if/else statments to show if the area code the user inputted corresponds to a Canadian province or is in the correct format.
Major variables: pNum, areaCode
Assumptions: The program will compile and run correctly, no syntax or logic or runtime errors are present in the code.
Program Limitations: A number in the form of ddd-ddd-dddd must be inputted to obtain a result.
*/

#include <iostream>																												// This is the preprocessor directive that is used to support input and output.
#include <string>																												// This preprocessor directive allows stings to be used in the code.

using namespace std;																											// Standard namespace is used in this code.

int main()																														// The main funciton intitates the program by creating an integer and an argument (which is the code below).
{
	while (true)																												// The code will repeat until "Q" or "q" is entered by the user (which will be expressed below).
	{
		cout << endl;																											// This simply spaces the output each time the code repeats.
		cout << "Hallo, please enter a phone number in the form ddd-ddd-dddd," << endl;											// This message is relayed to the user and prompts the user to enter a phone number in a specific format.
		cout << "where d is a digit. For example, 123-456-7890 is a viable entry." << endl;
		cout << "Or press Q or q to exit." << endl;																				// This lets the user know that they can exit the program by entering "Q" or "q."
		string pNum;																											// The string "pNum" is declared for the phone number that will be inputteed by the user.
		cin >> pNum;																											// The computer can now recognize the phone number that the user inputted, and the input is assigned to the string "pNum."

		if (pNum.length() == 12 &&																								// The correct length of the phone number is 12 characters (this includes the dashes). This tests the length of the input to see if it is correct.
			pNum[0] >= '0' && pNum[0] <= '9' && pNum[1] >= '0' && pNum[1] <= '9' && pNum[2] >= '0' && pNum[2] <= '9' &&			// The area code is being tested here. The first three characters must have values between the values for "0" and "9" (inclusive) for the area code to be correct.
			pNum[3] == '-' &&																									// The fourth character from the left in the phone number must be a dash if the format is correct.
			pNum[4] >= '0' && pNum[4] <= '9' && pNum[5] >= '0' && pNum[5] <= '9' && pNum[6] >= '0' && pNum[6] <= '9' &&			// The set of three characters in the phone number is tested here. Each character must have a value between the values for "0" and "9" (inclusive).
			pNum[7] == '-' &&																									// The eighth character from the left in the phone number must be a dash.
			pNum[8] >= '0' && pNum[8] <= '9' && pNum[9] >= '0' && pNum[9] <= '9' && pNum[10] >= '0' && pNum[10] <= '9' &&		// The last set of characters in the phone number are being tested here. Each character must have a value between the values for "0" and "9" (inclusive).
			pNum[11] >= '0' && pNum[11] <= '9')	
		{
			string areaCode(pNum, 0, 3);																						// A substring, composed of the first three characters of the phone number, is created. This allows the area code to be tested later.
																																// If the phone number is correct, then the outputted statement will be determined by which if statement it matches. 
			if (areaCode == "403" || areaCode == "587" || areaCode == "780" || areaCode == "825")								// Each if statement has a set of area codes that correspond to a province or territory in Canada. If the statement is true, then the following cout statement will be displayed. If the 
				cout << "This area code is used in Alberta." << endl;															// statement is not true, then the next if statement will be tested. If none of the if statemtents are true, then the area code that was typed in by the user is not used in Canada. This
																																// is covered by the else statement.
			else if (areaCode == "236" || areaCode == "250" || areaCode == "604" || areaCode == "672" || areaCode == "778")
				cout << "This area code is used in British Columbia." << endl;

			else if (areaCode == "204" || areaCode == "431")
				cout << "This area code is used in Manitoba." << endl;

			else if (areaCode == "506")
				cout << "This area code is used in New Brunswick." << endl;

			else if (areaCode == "709")
				cout << "This area code is used in Newfoundland and Labrador." << endl;

			else if (areaCode == "782" || areaCode == "902")
				cout << "This area code is used in Nova Scotia and Prince Edward Island." << endl;

			else if (areaCode == "548" || areaCode == "249" || areaCode == "289" || areaCode == "343" || areaCode == "365" || areaCode == "387" || areaCode == "416" || areaCode == "437" || areaCode == "519" || areaCode == "226" || areaCode == "613" || areaCode == "647" || areaCode == "705" || areaCode == "742" || areaCode == "807" || areaCode == "905")
				cout << "This area code is used in Ontario." << endl;

			else if (areaCode == "418" || areaCode == "438" || areaCode == "450" || areaCode == "514" || areaCode == "579" || areaCode == "581" || areaCode == "819" || areaCode == "873")
				cout << "This area code is used in Quebec." << endl;

			else if (areaCode == "306" || areaCode == "639")
				cout << "This area code is used in Saskatchewan." << endl;

			else if (areaCode == "867")
				cout << "This area code is used in the Yukon, Northwest Territories, and Nunavut." << endl;

			else
				cout << "This is not a Canadian area code." << endl;
		}

		else																													// This is usedd if the phone number length is not the correct length or if the characters aren't either numbers or dashes in the correct order.
		{
			if (pNum == "Q" || pNum == "q")																						// If the user wants to quit the loop, then entering "Q" or "q" will quit the code.
				return 0;																										// The main function returns the value zero and finishes the code.
																																// If "Q" or "q" wasn't entered, then the format for the phone number wasn't correct.
			cout << "This is not the correct format. Try again." << endl;														// This message is relayed to the user if the phone number fails the parameters in the if statements above.
		}

	}
	return 0;																													// The main function returns the value zero and finishes the code.
}