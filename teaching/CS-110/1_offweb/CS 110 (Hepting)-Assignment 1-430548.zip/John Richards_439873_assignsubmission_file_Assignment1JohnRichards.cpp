// John Richards
// 200351524
// CS110 - 001
// Assingment 1 
// Janurary 27, 2015

#include <iostream>  
// Including iomanip for precision oporator      
#include <iomanip>
using namespace std;
int main()
{
	//Precision set to 1 for use later in average
	cout << fixed << setprecision(1);
	int answer = 0;							// Variables used in colecting the inputted number and seperating it
	int number = 0;							// into its single digits
	int num1 = 0;
	int num2 = 0;
	int num3 = 0;
	int num4 = 0;
	int num5 = 0;
	cout << "Input an integer between 0 and 10000: ";		// Starting prompt for user
	cin >> number;											// Taking in inputed number and 
	if (number < 0)											// checking for initial validation
	{
		cout << "Invalid number" << endl;
	}
	else if (number < 10)									// Cases dealing with numbers less than 10
	{
		cout << "Number of digits is: 1" << endl
			<< "The sum of the digits is: " << number << endl			// Outputs under 10 do not require calculations 
			<< "The average of the digits is: " << number << endl
			<< "The product of the digits is: " << number << endl;
	}
	else if (number < 100)
	{
		num1 = number / 10;					// Taking the two digit number and splitting it into its two seperate digits
		num2 = number % 10;
		answer = num1 + num2;
		cout << "Number of digits is: 2" << endl
			<< "The sum of the digits is: " << answer << endl
			<< "The average of the digits is: " << float(answer) / 2 << endl	// Float is used to get more acurate reading in average
			<< "The product of the digits is: " << num1 * num2 << endl;
	}
	else if (number < 1000)
	{
		num1 = number % 10;
		num2 = (number / 10) % 10;			// Numbers under 1000 need an extra operation and variable for the digits
		num3 = (number / 100) % 10;
		answer = num1 + num2 + num3;
		cout << "The number of digits is: 3" << endl
			<< "The sum of the digits is: " << answer << endl
			<< "The average of the digits is: " << float(answer) / 3 << endl
			<< "the product of the digits is: " << num1 * num2 * num3 << endl;
	}
	else if (number < 10000)
	{
		num1 = number % 10;
		num2 = (number / 10) % 10;
		num3 = (number / 100) % 10;
		num4 = (number / 1000) % 10;
		answer = num1 + num2 + num3 + num4;
		cout << "The number of digits is: 4" << endl
			<< "The sum of the digits is: " << answer << endl
			<< "The average of the digits is: " << float(answer) / 4 << endl
			<< "The product of the digits is: " << num1 * num2 * num3 * num4 << endl;
	}
	else if (number == 10000)
	{
		num1 = number % 10;
		num2 = (number / 10) % 10;
		num3 = (number / 100) % 10;
		num4 = (number / 1000) % 10;
		num5 = (number / 10000) % 10;
		answer = num1 + num2 + num3 + num4 + num5;
		cout << "The number of digits is: 5" << endl
			<< "The sum of the digits is: " << answer << endl
			<< "The average of the digits is: " << float(answer) / 5 << endl
			<< "The product of the digits is: " << num1 * num2 * num3 * num4 * num5 << endl;
	}
	else
		cout << "Invalid number" << endl;		// Covering all cases where input is not supported

	return 0;
}