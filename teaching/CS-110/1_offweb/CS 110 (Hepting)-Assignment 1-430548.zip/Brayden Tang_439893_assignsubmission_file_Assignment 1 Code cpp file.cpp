//**************************************************************************
//
// Student name: Brayden Tang
//
// Student number: 200350623
//
// Assignment number: 1
//
// Program name: Assignment 1- Writing a Program That Calculates the Number of Digits, Sum of Digits, Average of Digits, and Product of Digits from an Inputted Interger Value of 0-10000. 
//
// Date written: January 26th, 2015
//
// Problem statement: "Write a program that reads an integer between 0 and 10000 and then calculates and displays (from the integer that has been read):
//
//          the number of digits
//          the sum of all the digits
//          the average of all the digits
//          the product of all of the digits"
//
//
//
// Input: A whole number from 0-10000, inclusive.
//
// Output: The number of digits that make up the inputted integer, the sum of those digits, the average of those digits, and the product of those digits. 
//
// Algorithm: The algorithm varies depending on how many digits there are in the input. However, the overall idea is to use a combination of multiples of ten and the modulus operator to effectively model single digits using the inputted number. Factors of ten do not change the physical number, and the modulus operator can effectively be used to model the last digit in any number since the remainder when divided by a factor of ten will simply just be the last digit.
// Example Algorithms: For two digit values: sum= (number / 10) + (number % 10); average= ((number / 10) + (number % 10)) / 2.0;
// Major variables: int number, int number_of_digits, int sum_of_digits, double average_of_digits, int product_of_digits (listed at the top)
//
// Assumptions: The biggest assumption is that the user will input a whole number, ie. no values with decimal places. If one uses a value with decimal places the program will not work, but with the knowledge I have this would be very very difficult to code regardless. Decimal places can theoretically go to infinity whereas intergers are finite. This poses a large problem and exposes a glaring flaw in my programming experience.
//              Obviously, the program will not be able to interpret values that must be calculated first using math (ex. if the user inputted 3 + 5), and literal constants (such as e). Also, negative values cannot be modelled with this program, but this could fall under the assumption that the user will follow the directions in the first place. Finally, numbers inputted as 042 (to represent 42) cannot be interpreted correctly.
// Program limitations: -The program cannot intepret decimal values correctly. 
//                      -Literal constants such as e cannto be inputted or interpreted correctly.
//                      -Values with 0's before the actual interger to be read, (example: 042 to represent 42) cannot be represented correctly
//
//**************************************************************************

#include <iostream>
using namespace std;
int main()

{

	int number;                         //declaration of all the varaibles used in the program. I understand that we are supposed to declare variables as we use them but I personally stay more organized when all of my variables are in a single place.
	int number_of_digits;
	int sum_of_digits;
	double average_of_digits;
	int product_of_digits;

	cout << "Input a whole number from 0 to 10000." << endl;   //instructing the user to input a whole number from 0-10000, inclusive.
	cin >> number;   //user inputs a number

	if (number < 10)         //first if statement in which one digit numbers will be modelled, ie. all numbers less than 10.

	{

		number_of_digits = 1;                    //the math here is relatively simple. Since there is only one digit, this simplifies the expressions greatly since only one number needs to be modelled. Thus, the variable number for the most part can be directly inputted into the basic equations.
		sum_of_digits = number;
		average_of_digits = (number / 1.0);
		product_of_digits = number;

		cout << "The number of digits: " << number_of_digits << endl;      //output results from the code
		cout << "The sum of digits: " << sum_of_digits << endl;
		cout << "The average of digits: " << average_of_digits << endl;
		cout << "The product of digits: " << product_of_digits << endl;

	}

	else if (number >= 10 && number < 100)     //two digit numbers being modelled if the first "if" statement is false. I used else if instead of just if because if "if" is just used, the program will run through each statement regardless if the former "if" statement is true or not, leading to an inevitable false and the output for "else" being outputted when it shouldn't be

	{

		number_of_digits = 2;                                                  //the math here is explained in my header documentation under algorithm.
		sum_of_digits = (number / 10) + (number % 10);
		average_of_digits = ((number / 10) + (number % 10)) / 2.0;               //note that average= (sum of digts)/(number of digits)
		product_of_digits = (number / 10) * (number % 10);

		cout << "The number of digits: " << number_of_digits << endl;           //output results from the code above
		cout << "The sum of digits: " << sum_of_digits << endl;
		cout << "The average of digits: " << average_of_digits << endl;
		cout << "The product of digits: " << product_of_digits << endl;


	}

	else if (number >= 100 && number < 1000)    //three digit numbers being modelled if the first two if statements are both false.

	{

		number_of_digits = 3;
		sum_of_digits = (number / 100) + (number % 10) + ((number % 100) / 10);                //same principles as before when it comes to the math. The first expression (number / 100) represents the first digit, (number % 10) represents the third digit, and ((number % 100) / 10) represents the middle or second digit. Note that the expression (number % 100) / 10 represents the two digit value in the three digit value (for instance, 455 with this expression is represented with 55 and then 55/10 gets 5)
		average_of_digits = ((number / 100) + (number % 10) + ((number % 100) / 10)) / 3.0;
		product_of_digits = (number / 100) * (number % 10) * ((number % 100) / 10);

		cout << "The number of digits: " << number_of_digits << endl;     //output results from the code above
		cout << "The sum of digits: " << sum_of_digits << endl;
		cout << "The average of digits: " << average_of_digits << endl;
		cout << "The product of digits: " << product_of_digits << endl;

	}

	else if (number >= 1000 && number < 10000)   //four digit numbers being modelled if the first three if statements are both false.

	{

		number_of_digits = 4;
		sum_of_digits = (number / 1000) + (number % 10) + ((number % 100) / 10) + ((number % 1000) / 100);                  //math is explained here already from before. The only difference being that we need to include a fourth expression to model the third digit, but this can be done by again using multiples of ten (in this case 1000 and 100).
		average_of_digits = ((number / 1000) + (number % 10) + ((number % 100) / 10) + ((number % 1000) / 100)) / 4.0;
		product_of_digits = (number / 1000) * (number % 10) * ((number % 100) / 10) * ((number % 1000) / 100);

		cout << "The number of digits: " << number_of_digits << endl;      //output results to the console
		cout << "The sum of digits: " << sum_of_digits << endl;
		cout << "The average of digits: " << average_of_digits << endl;
		cout << "The product of digits: " << product_of_digits << endl;

	}



	else if (number == 10000)    //fifth digit number where 10000 is the only number that has five digits in the domain 

	{

		number_of_digits = 5;                       //the math similar to the single digit intergers is again simple since we know that 10000 is the only interger in the domain with five digits. Thus, we can make the variables be represented by actual values instead of using multiples of ten.
		sum_of_digits = 1 + 0 + 0 + 0 + 0;
		average_of_digits = 1 / 5.0;
		product_of_digits = 1 * 0 * 0 * 0 * 0;

		cout << "The number of digits: " << number_of_digits << endl;  //output results to the console
		cout << "The sum of digits: " << sum_of_digits << endl;
		cout << "The average of digits: " << average_of_digits << endl;
		cout << "The product of digits: " << product_of_digits << endl;

	}

	else       //if all the if statements above have failed then an invalid number was entered. 
	{
		cout << "The whole number is not within 0-10000." << endl;      //this will be outputted to the user if they enter an invalid number.
	}


	return 0;

}

//end of program