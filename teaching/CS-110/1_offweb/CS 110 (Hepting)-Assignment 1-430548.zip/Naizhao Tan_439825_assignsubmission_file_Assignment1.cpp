/*
	Name: Naizhao Tan
	Student number: 200353140
	Assignment number: 1
	Program Name: Assignment 1
	Program Due: Feb 2 2015
	Date: Jan 31 2015
	problem statement: 
		Write a program that reads an integer between 0 and 10000 and then calculates and displays (from the integer that has been read):
        the number of digits
        the sum of all the digits
        the average of all the digits
        the product of all of the digits
	input:  1.  2468  2.  5070   3.  42   4.  23451
	output:	
		1.  (4, 20, 5, 384)
		2.  (4, 12, 3, 0)
		3.  (2, 6, 3, 8)
		4.  (The number is too small or too big)
	algorithm: 
		Step 1. Read in variables
		Step 2. Set the conditions for the number that user enters
		Step 3. Obtain digits and do the compute
	major variables: There are 6 variables in the code 
	program limitations: 
		It could only compute with integer

*/




#include <iostream>
#include <iomanip>
using namespace std;

int main(){
	// Read in number1 and digits
	int number1;
	int digit1;
	int digit2;
	int digit3;
	int digit4;
	int digit5;

	// Prompt the user to enter an number
	cout << "Please enter a number" << endl;
	cin   >> number1;

	// Obtain each digit from the number and do the compute 
	if (number1 > 0){
		if (number1 < 10 && 0 <= number1){
			cout << "The number of the dight is: 1" << endl;
			cout << "The sum of dights is:" << number1 << endl;
			cout << "The average of dights is:" << number1 << endl;
			cout << "The product of dights is:" << number1 << endl;
		}if (number1 < 100 && 10 <= number1){
			digit1 = number1 / 10;
			digit2 = number1 % 10;
			cout << "The number of the dight is: 2" << endl;
			cout << "The sum of dights is:" << digit1 + digit2 << endl;
			cout << "The average of dights is:" << (digit1 + digit2) / 2 << endl;
			cout << "The product of dights is:" << digit1 * digit2 << endl;
		}if (number1 < 1000 && 100 <= number1){
			digit1 = number1 / 100;
			digit2 = (number1/10) % 10;
			digit3 = number1 % 10;
			cout << "The number of the dight is: 3" << endl;
			cout << "The sum of dights is:" << digit1 + digit2 + digit3<< endl;
			cout << "The average of dights is:" << (digit1 + digit2 + digit3) / 3 << endl;
			cout << "The product of dights is:" << digit1 * digit2 * digit3<< endl;
		}if (number1 < 10000 && 1000 <= number1){
			digit1 = number1 / 1000;
			digit2 = (number1/100) % 10;
			digit3 = (number1 / 10) % 10;
			digit4 = number1 % 10;
			cout << "The number of the dight is: 4" << endl;
			cout << "The sum of dights is:" << digit1 + digit2 + digit3 + digit4<< endl;
			cout << "The average of dights is:" << (digit1 + digit2 + digit3 + digit4) / 4 << endl;
			cout << "The product of dights is:" << digit1 * digit2 * digit3 * digit4<< endl;
		}
		else
		{
			cout << "The number is too small or too big";
		}

	}
	return 0;

}