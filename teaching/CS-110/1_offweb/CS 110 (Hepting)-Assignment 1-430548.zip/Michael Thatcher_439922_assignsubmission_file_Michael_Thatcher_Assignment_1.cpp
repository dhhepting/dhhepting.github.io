/* 
 Name: Michael Thatcher

 Student Number: 200 353 864

 Assignment 1: CS 110

 Program Name: Informational Integer Calculator

 Date: January 27, 2015

 Problem statement:
          Write a program that reads an integer between 0 and 10000 and then calculates and displays (from the integer that has been read):
             the number of digits
             the sum of all the digits
             the average of all the digits
             the product of all of the digits

 Input: Integer between 0 and 10000 declared as number1

 Output: number of digits, sum of all digits, average of all digits, and product of all digits

 Algorithm: receive input for number1, determine number of digits using if statements, print out number of digits, use modulus command to determine sum 
of digits, use if statements to determine average of digits, use if statements to determine product of digits

 Major variables: | number1 | dig1 | dig2 | dig3 | dig4 | dig5 |
         ALL variables stored as integers

 Assumptions: User will only enter a number into the console between 0 and 10000

 Program limitations: Limited functionality for numbers other than those between 0 and 10000. Doesn't prevent user from entering non-number characters

*/

#include <iostream>
using namespace std;

int main()
{
    int number1;
    cout << "This is a program that reads an integer between 0 and 10000 and then calculates and displays:" << endl << "number of digits" << endl << "sum of all the digits" << endl << "average of all the digits" << endl << "product of all of the digits" << endl;
    cout << "Please enter a number between 0 and 10000" << endl;
    cin >> number1;
    
    cout << "You have entered: " << number1 << endl;
    
    // Determine the number of digits by using if statements
    //prints out number of digits to the console
    
    cout << "Number of digits: ";
        if (number1 == 10000)
        cout << "5" << endl;
    
        if (number1 < 10000 && number1 >= 1000)
        cout << "4" << endl;
    
        if (number1 < 1000 && number1 >= 100)
        cout << "3" << endl;
    
        if (number1 < 100 && number1 >= 10)
        cout << "2" << endl;
    
        if (number1 < 10 && number1 >= 0)
        cout << "1" << endl;  
 
 
    // Determine the sum of all digits
        
        cout << "Sum of all digits: ";
        
        int dig1 = (number1 % 10);
        int dig2 = (number1 / 10 % 10);
        int dig3 = (number1 / 100 % 10);
        int dig4 = (number1 / 1000 % 10);
        int dig5 = (number1 / 10000 % 10);
        
        cout << dig1 + dig2 + dig3 + dig4 + dig5 << endl;
        
        
    // Determine average of all digits
    
    if (number1 == 10000)
        cout << "Average of all digits: " << (dig1 + dig2 + dig3 + dig4 + dig5) / 5;

    if (number1 < 10000 && number1 >= 1000)
        cout << "Average of all digits: " << (dig1 + dig2 + dig3 + dig4 + dig5) / 4;    
        
    if (number1 < 1000 && number1 >= 100)
        cout << "Average of all digits: " << (dig1 + dig2 + dig3 + dig4 + dig5) / 3;    
        
    if (number1 < 100 && number1 >= 10)
        cout << "Average of all digits: " << (dig1 + dig2 + dig3 + dig4 + dig5) / 2;   
    
    if (number1 < 10 && number1 >= 0)
        cout << "Average of all digits: " << (dig1 + dig2 + dig3 + dig4 + dig5) / 1;    
        cout << endl;

        
    // Determine product of all digits
    
    if (number1 == 10000)
    cout << "Product of all digits: " << dig1 * dig2 * dig3 * dig4 * dig5;
    
    if (number1 < 10000 && number1 >= 1000)
    cout << "Product of all digits: " << dig1 * dig2 * dig3 * dig4;
    
    if (number1 < 1000 && number1 >= 100)
    cout << "Product of all digits: " << dig1 * dig2 * dig3;
    
    if (number1 < 100 && number1 >= 10)
    cout << "Product of all digits: " << dig1 * dig2;
    
    if (number1 < 10 && number1 >= 0)
     cout << "Product of all digits: " << dig1;
     

    
return 0;
}

// End of program

