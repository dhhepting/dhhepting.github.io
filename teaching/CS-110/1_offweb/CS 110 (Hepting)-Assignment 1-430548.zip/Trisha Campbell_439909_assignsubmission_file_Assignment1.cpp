/* Name: Trisha Campbell
   Student ID: 200321297
   Assignment #: 1
   Due: February 2, 2015 */

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
	// This program first prompts the user to enter an integer between 0 and 10000
	int number;
	cout << "Please enter an integer between 0 and 10000:";
	cin >> number;

	if (number >= 0)
	{
		if (number <= 10000)
		{
			cout << "Thank you." << endl;
		}
		else
		{
			cout << "Please try again:";
			cin >> number;
			if (number <= 10000)
			{
				cout << "Thank you." << endl;
			}
		}
	}
	else
	{
		cout << "Please try again:";
		cin >> number;
		if (number >= 0)
		{
			cout << "Thank you." << endl;
		}
	}

	// The program then calculates the number of digits in the integer entered
	cout << "Number of digits:";

	if (number < 10)
	{
		cout << "1" << endl;
	}
	if (number >= 10)
	{
		if (number <= 99)
		{
			cout << "2" << endl;
		}
	}
	if (number >= 100)
	{
		if (number <= 999)
		{
			cout << "3" << endl;
		}
	}
	if (number >= 1000)
	{
		if (number <= 9999)
		{
			cout << "4" << endl;
		}
	}
    if (number == 10000)
	{
		if (number > 9999)
		{
			cout << "5" << endl;
		}
	}

	//The program then calculates the sum of all the digits
	cout << "Sum of all the digits:";


		int temp = number;
		int digit5 = temp % 10;
		int digit4 = temp / 10 % 10;
		int digit3 = temp / 100 % 10;
		int digit2 = temp / 1000 % 10;
		int digit1 = temp / 10000 % 10;
		
		if (number < 10)
		{
			cout << (digit5) << endl;
		}
		
	     if (number >= 10)
		{
			if (number <= 99)
			{
				cout << (digit5 + digit4) << endl;
			}
		}
		if (number >= 100)
		{
			if (number <= 999)
			{
				cout << (digit5 + digit4 + digit3) << endl;
			}
		}
		if (number >= 1000)
		{
			if (number <= 9999)
			{
				cout << (digit5 + digit4 + digit3 + digit2) << endl;
			}
		}
		if (number == 10000)
		{
			if (number > 9999)
			{
				cout << (digit5 + digit4 + digit3 + digit2 + digit1) << endl;
			}
		}

	// The program then calculates the average of all the digits
	cout << "Average of all the digits:";

	if (number < 10)
	{
		cout << (digit5) / 1 << endl;
	}

	if (number >= 10)
	{
		if (number <= 99)
		{
			cout << (digit5 + digit4) / 2 << endl;
		}
	}
	if (number >= 100)
	{
		if (number <= 999)
		{
			cout << (digit5 + digit4 + digit3) / 3 << endl;
		}
	}
	if (number >= 1000)
	{
		if (number <= 9999)
		{
			cout << (digit5 + digit4 + digit3 + digit2) / 4 << endl;
		}
	}
	if (number == 10000)
	{
		if (number > 9999)
		{
			cout << (digit5 + digit4 + digit3 + digit2 + digit1) / 5 << endl;
		}
	}

	//The program then calculates the product of all the digits
	cout << "Product of all the digits:";

	if (number < 10)
	{
		cout << (digit5) << endl;
	}

	if (number >= 10)
	{
		if (number <= 99)
		{
			cout << (digit5 * digit4) << endl;
		}
	}
	if (number >= 100)
	{
		if (number <= 999)
		{
			cout << (digit5 * digit4 * digit3) << endl;
		}
	}
	if (number >= 1000)
	{
		if (number <= 9999)
		{
			cout << (digit5 * digit4 * digit3 * digit2) << endl;
		}
	}
	if (number == 10000)
	{
		if (number > 9999)
		{
			cout << (digit5 * digit4 * digit3 * digit2 * digit1) << endl;
		}
	}

	return 0;
}
