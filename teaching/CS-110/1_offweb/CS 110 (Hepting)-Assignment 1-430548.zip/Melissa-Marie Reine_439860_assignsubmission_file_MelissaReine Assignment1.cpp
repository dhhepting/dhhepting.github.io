/**************************************************************************
*
*Student name: Melissa-Marie Reine
*
*Student number: 200259996
*
*Assignment number: 1
*
*Program name: Assignment 1-Integer Digits
*
*Date written: 02/02/2015
*
*Problem statement: To use the digits of an integer to calculate mathematical functions
*
*Input: An integer between 0 and 10000 inclusive
*
*Output: The number of digits in the integer
*		 The sum of all the digits in the integer
*		 The average of all the digits in the integer
*		 The product of all the digits in the integer
*
*Algorithm: 
*
*Major variables: integer1, digit1, digit2, digit3, digit4, digit5, 
*				  numberofdigits, sumofdigits, averageofdigits, productofdigits
*
*Assumptions: N/A
*
*Program limitations: The program will only run with positive integers between 0 and 10000 inclusive
*
//**************************************************************************/

#include <iostream>
using namespace std;

int main()

{

int count = 0;
while (count < 4)
{
	//Define Integer
	int integer1;

	// Integer Input
	cout << "Please enter an integer between 0 and 10000:";
	cin >> integer1;

	//Verify that integer is within allowable limits
	if (integer1 < 0)
	{
		do
		{
			cout << "Too small. Please enter a positive integer between 0 and 10000:" << endl;
			cin.clear();
			cin >> integer1;
		} while (integer1 < 0);

	}
	else if (integer1 > 10000)
	{
		do
		{
			cout << "Too large. Please enter an integer between 0 and 10000:" << endl;
			cin.clear();
			cin >> integer1;
		} while (integer1 > 10000);

	}
	else
	{	//Define Variables

		int digit1 = (integer1 / 1 % 10);
		int digit2 = (integer1 / 10 % 10);
		int digit3 = (integer1 / 100 % 10);
		int digit4 = (integer1 / 1000 % 10);
		int digit5 = (integer1 / 10000 % 10);

		//Calculates number of Digits
		int numberofdigits;
		if (integer1 < 10)
		{
			numberofdigits = 1;
		}
		else if (integer1 < 100)
		{
			numberofdigits = 2;
		}
		else if (integer1 < 1000)
		{
			numberofdigits = 3;
		}
		else if (integer1 < 10000)
		{
			numberofdigits = 4;
		}
		else
		{
			numberofdigits = 5;
		}
		cout << "Number of Digits:" << numberofdigits << endl;

		//Calculate and Output Sum of Digits
		int sumofdigits = digit1 + digit2 + digit3 + digit4 + digit5;
		cout << "Sum of Digits:" << sumofdigits << endl;

		//Calculate and Output Average of Digits
		int averageofdigits = (sumofdigits / numberofdigits);
		cout << "Average of Digits:" << averageofdigits << endl;

		//Calculate and Output Product of Digits
		int productofdigits;
		if (digit5 > 0)
		{
			productofdigits = (digit1*digit2*digit3*digit4*digit5);
		}
		else if (digit4 > 0)
		{
			productofdigits = (digit1*digit2*digit3*digit4);
		}
		else if (digit3 > 0)
		{
			productofdigits = (digit1*digit2*digit3);
		}
		else if (digit2 > 0)
		{
			productofdigits = (digit1*digit2);
		}
		else
		{
			productofdigits = digit1;
		}
		cout << "Product of Digits:" << productofdigits << endl;
		cout << endl;
		count++;
	}
}
}