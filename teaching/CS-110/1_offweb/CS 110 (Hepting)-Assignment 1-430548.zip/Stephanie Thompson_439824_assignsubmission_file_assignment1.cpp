//**************************************************************************
//
// Student name: Stephanie Thompson
//
// Student number: 200355041
//
// Assignment number: Assignment 1
//
// Program name: Digit Parsing Calculator
//
// Date written: 31 January 2015
//
// Problem statement: The user needs to know the number of, the sum of, the average of, and the product of the digits of an integer.
//
// Input: The user will input an integer value between 0 and 10000 (inclusive).
//
// Output: The program will ask for user input and then read the number, compute, and display the original number, the number of digits, the sum of the digits,
//			the average of the digits, and the product of the digits. 
//
// Algorithm: The user enters an integer value.  The program will read in the value and use the modulus operator to find the value of each seperate
//				digit which is then stored into a variable.  The variable containing each digit will then be used in calculations for computing the sum, 
//				average, and product.
//
// Major variables: Important variables used in the program inculde: number, digit1, digit2, digit3, digit4, digit5, and numberofdigits.
//
// Assumptions: The user will only enter valid numbers. (see limitations)
//
// Program limitations: The program will not be able to compute for numbers lower than 0 or larger than 10000.
//
//**************************************************************************
#include <iostream>
using namespace std;

int main()
{
	// Initializing of variables
	int number;
	int numberofdigits;
	float sum;
	float average;
	float product;
	
	// Prompts the user to enter an integer
	cout << "Enter an integer number from 0 to 10000 (inclusive)." << endl;
	cin >> number;

	if (number >= 0) // Tests if the number is an acceptable value
	{
		if (number > 10000) // Tests if the number is an acceptable value
		{
			cout << "The number you enetered is invalid." << endl;
		}
		else
		{
			cout << "The number you entered is: " << number << endl;
			
			int digit1, digit2, digit3, digit4, digit5; // Initialization of important variables
			// Declaring values of variables based on user input
			// Uses modulus operator to get the value of the right most digit
			//The number is repeatedly divided by 10 to shift the digits in the number to the right
			digit1 = number % 10;
			number /= 10;
			digit2 = number % 10;
			number /= 10;
			digit3 = number % 10;
			number /= 10;
			digit4 = number % 10;
			number /= 10;
			digit5 = number % 10;

			// Tests the number of digits and displays the sum, average, and product based on the number of digits
			if (digit5 > 0)
			{
				numberofdigits = 5;
				cout << "The number of digits is: " << numberofdigits << endl;

				sum = (digit1 + digit2 + digit3 + digit4 + digit5);
				cout << "The sum of the digits is: " << sum << endl;

				average = sum / numberofdigits;
				cout << "The average of the digits is: " << average << endl;

				product = (digit1 * digit2 * digit3 * digit4 * digit5);
				cout << "The product of the digits is: " << product << endl;
			}
			else if (digit4 > 0)
			{
				numberofdigits = 4;
				cout << "The number of digits is: " << numberofdigits << endl;

				sum = (digit1 + digit2 + digit3 + digit4);
				cout << "The sum of the digits is: " << sum << endl;
				 
				average = sum / numberofdigits;
				cout << "The average of the digits is: " << average << endl;

				product = (digit1 * digit2 * digit3 * digit4);
				cout << "The product of the digits is: " << product << endl;
			}
			else if (digit3 > 0)
			{
				numberofdigits = 3;
				cout << "The number of digits is: " << numberofdigits << endl;

				sum = (digit1 + digit2 + digit3);
				cout << "The sum of the digits is: " << sum << endl;

				average = sum / numberofdigits;
				cout << "The average of the digits is: " << average << endl;

				product = (digit1 * digit2 * digit3);
				cout << "The product of the digits is: " << product << endl;
			}
			else if (digit2 > 0)
			{ 
				numberofdigits = 2;
				cout << "The number of digits is: " << numberofdigits << endl;

				sum = (digit1 + digit2);
				cout << "The sum of the digits is: " << sum << endl;

				average  = sum / numberofdigits;
				cout << "The average of the digits is: " << average << endl;

				product = (digit1 * digit2);
				cout << "The product of the digits is: " << product << endl;
			}
			else if (digit1 >= 0)
			{
				numberofdigits = 1;
				cout << "The number of digits is: " << numberofdigits << endl;

				sum = digit1;
				cout << "The sum of the digits is: " << sum << endl;

				average = sum / numberofdigits;
				cout << "The average of the digits is: " << average << endl;

				product = digit1;
				cout << "The product of the digits is: " << product << endl;
			}
		}
	}
	else // Displays a message if theh number is less than 0
	{
		cout << "The number you entered is invalid." << endl;
	}


	return 0;
}