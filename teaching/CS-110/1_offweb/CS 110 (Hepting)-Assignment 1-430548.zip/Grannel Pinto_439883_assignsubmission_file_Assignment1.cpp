#include <iostream>

using namespace std; 

int main()
{
	int input;
	int number_of_digits;
	int sum;
	float average;
	int product;
	

	cout << "Please eneter an integer from 0 to 10000";
	cin >> input;

	if (input < 0);
	{
		cout << "Your number was negative. Please enter only integers that range from 0 to 10000. Please restart the program." << endl;
		return 0;
	}
	if(input > 10000)
	{ 
		cout << "Your number was greater than 10000. Please enter only integers that range from 0 to 10000. Please restart the program." << endl;
		return 0;
	}
	
	



}