//**************************************************************************
//
// Student name: Rana Mujahid Tariq	
// 
// Student number: 200 321 914
//
// Assignment number: 1
//
// Program name: Sum, Product, Average of digits entered plus the number of digits entered
//
// Date written: Feb 02-2015
//
// Problem statement: Write a program that reads an integer between 0 and 10000 and then calculates and displays (from the integer that has been read):

// the number of digits
// the sum of all the digits
// the average of all the digits
// the product of all of the digits
//
// Input: A number between 0 and 10,000
//
// Output: 
// the number of digits
// the sum of all the digits
// the average of all the digits
// the product of all of the digits
//
// Algorithm: 
//
// Major variables: sum, average, product, number
//
// Assumptions:
//
// Program limitations: only works for integers from 0 to 10,000
//
//**************************************************************************
#include <iostream>
#include <string>
using namespace std;
int main ()
{

	int number;
	int digit1, digit2, digit3, digit4, digit5;
	
	cout << "Please enter a number between 0 and 10,000" << endl;
	cin >> number;
	
	digit1 = (number / 1) % 10;
	digit2 = (number / 10) % 10;
	digit3 = (number / 100) % 10;
	digit4 = (number / 1000) % 10;
	digit5 = (number / 10000) % 10;
	
if (number <= 0 || number > 10000)
{
	cout << "you enterd a invalid integer" << endl;
}
	
	else 
{
	cout << digit1 << endl;
	cout << digit2 << endl;
	cout << digit3 << endl;
	cout << digit4 << endl;
	cout << digit5 << endl;
	
	int sum;
	sum = digit1 + digit2 + digit3+ digit4 + digit5;
	cout << "Sum of digits = " << sum << endl;

	int product;
	product = digit1 * digit2 * digit3 * digit4 * digit5;
	cout << "Product of digits = " << product << endl;
	
	int average;
	average = ((digit1 * digit2 * digit3 * digit4 * digit5) / 10);
	cout << "Average of digits = " << average << endl;
}
	
// how do I calculate the number of digits. I could not find product and average cuz I got stuck at number of digits.
// can you tell me the function name or how I would calculate the number of digits. I know we have to use more if and else statements.
return 0; 
}