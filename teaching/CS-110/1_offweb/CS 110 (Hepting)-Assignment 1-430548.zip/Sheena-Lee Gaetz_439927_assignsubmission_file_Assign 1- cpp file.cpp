// 
//**************************************************************************
//
// Student name: Sheena-Lee Gaetz
//
// Student number: 200317727
//
// Assignment number: 1
//
// Program name: 1 to 10000
//
// Date written: January 30, 2015
//
// Problem statement: Get an input of an integer in between 0 and 10000 and calculate
// the number of digits, sum, average, and product
//
// Input: An integer between 0 and 10000
//
// Output: The number of digits, sum, averagem and produt
//
// Algorithm: using if statements will determine the number of digits.
// Using modulus and division will determine what number each digit is.
// Simple math calculations will be done from there to find sum and, average, and product.
//
// Major variables: int num, int d1-d5, int sum, int product, int average.
//
// Assumptions: The program will work with any number that is inputed.
// If the number is not in the range the user will be informed.
//
// Program limitations: None
//
//**************************************************************************

#include <iostream>
using namespace std;

int main()

{
	int num; // declare an integer for number
	// prompt user to enter an integer
	cout << "Please enter an integer between 0 and 10000: " << endl;
	cin >> num; //read in number from the keyboard
	{
		if (num > 10000) //use if statments to organize number of digits
		{
			cout << "Please choose a number below 10000! " << endl;
		}
		else
			if (num < 0)
			{
				cout << "Please choose a number above 0!" << endl;
			}
		else
		if (num < 10)
		{
			int digits = 1; // declare an integer for digits
			cout << "Number of digits: " << digits << endl;
			int sum = num;
			cout << "Sum of digits: " << sum << endl;
			int average = num;
			cout << "Average of digits: " << average << endl;
			int product = num;
			cout << "Product of the digits: " << product << endl;
		}
		else

		if (num < 100)
		{
			int digits = 2; // declare variable for digits
			cout << "Number of digits: " << digits << endl;
			int d1; //declare varibale for digit 1
			int d2; // declare variable for digit 2
			d1 = num % 10; //modulus calculation to find digit 1
			num /= 10;
			d2 = num % 10;
			int sum; // declare a variable for sum
			sum = (d1 + d2); // Calculate the sum
			cout << "Sum of digits: " << sum << endl;
			int average; //declare a varibale for average
			average = (sum / 2); //calculate the average
			cout << "Average of digits: " << average << endl;
			int product; // declare a variable for product
			product = (d1 * d2); // calculate the product
			cout << "Product of the digits: " << product << endl;
		}
		else

		if (num < 1000)
		{
			int digits = 3;
			cout << "Number of digits: " << digits << endl;
			int d1;
			int d2;
			int d3;
			d1 = num % 10;
			num /= 10;
			d2 = num % 10;
			num /= 10;
			d3 = num % 10;
			int sum;
			sum = (d1 + d2 + d3);
			cout << "Sum of digits: " << sum << endl;
			int average;
			average = (sum / 3);
			cout << "Average of digits: " << average << endl;
			int product;
			product = (d1 * d2 * d3);
			cout << "Product of the digits: " << product << endl;

		}
		else

		if (num < 10000)
		{
			int digits = 4;
			cout << "Number of digits: " << digits << endl;
			int d1;
			int d2;
			int d3;
			int d4;
			d1 = num % 10;
			num /= 10;
			d2 = num % 10;
			num /= 10;
			d3 = num % 10;
			num /= 10;
			d4 = num % 10;			
			int sum;
			sum = (d1 + d2 + d3 + d4);
			cout << "Sum of digits: " << sum << endl;
			int average;
			average = (sum / 4);
			cout << "Average of digits: " << average << endl;
			int product;
			product = (d1 * d2 * d3 * d4);
			cout << "Product of the digits: " << product << endl;
		}
		else

		if (num = 10000)
		{
			int digits = 5;
			cout << "Number of digits: " << digits << endl;
			int d1;
			int d2;
			int d3;
			int d4;
			int d5;
			d1 = num % 10;
			num /= 10;
			d2 = num % 10;
			num /= 10;
			d3 = num % 10;
			num /= 10;
			d4 = num % 10;
			num /= 10;
			d5 = num % 10;			
			int sum;
			sum = (d1 + d2 + d3 + d4 + d5);
			cout << "Sum of digits: " << sum << endl;
			int average;
			average = (sum / 5);
			cout << "Average of digits: " << average << endl;
			int product;
			product = (d1 * d2 * d3 * d4 * d5);
			cout << "Product of the digits: " << product << endl;
		}
		
	}

	return 0;
	
 }

 // end of program