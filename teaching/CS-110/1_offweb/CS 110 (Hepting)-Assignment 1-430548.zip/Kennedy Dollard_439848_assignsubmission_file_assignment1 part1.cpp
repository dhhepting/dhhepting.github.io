#include <iostream>
using namespace std;

/*************************************
Student name: Kennedy Dollard
Student number: 200236150
Assignment number: 1
Program name: Assignment 1
Date written: 1.27.2015
Problem statement: program calculating and displaying the number, sum, average and product of digits in an integer between 0 and 10000
Input: an integer from user's keyboard
Output: the number, sum, average and product of the digits in the integer
Algorithm: program stores space for integer variables, prompts user to enter a number, and then user enters a number and program calculates the problem statement
Major variables: My skills
Assumptions: I'm good at coding
Program limitations: I only know so much

***************************************/

int main()
{
	int number, sum, average, product, digit1, digit2, digit3, digit4, digit5; //integer variable number

	cout << "Please enter a number between 0 and 10000." << endl; //prompt user for input
	cin >> number; //user enters a number
	
		digit1 = (number / 1) % 10; //remainder
		digit2 = (number / 10) % 10;
		digit3 = (number / 100) % 10;
		digit4 = (number / 1000) % 10;
		digit5 = (number / 10000) % 10;

	if (number >= 0)
	{
		if (number <= 10000)
		{

			if (digit1 >= 0) 
			{
				number = 1; // there is always 1 digit
				product = digit1;
			}
			if (digit2 > 0)
			{
				number = 2; //there are two digits
				product = digit1*digit2; //so zero doesn't mess everything up
			}
			if (digit3 > 0)
			{
				number = 3; //3 digits!!!!!!
				product = digit1*digit2*digit3; //so zero doesn't mess everything up
			}
			if (digit4 > 0)
			{
				number = 4; //omg 4 digits
				product = digit1*digit2*digit3*digit4; //so zero doesn't mess everything up
			}
			if (digit5 > 0)
			{
				number = 5; //woah so many digits (5)
				product = digit1*digit2*digit3*digit4*digit5; //if u have 0 it'll be 0 anyways but ok
			}

			cout << "Your number has " << number << " digits." << endl; //much info

			sum = digit1 + digit2 + digit3 + digit4 + digit5; 
			cout << "The sum of the digits in your number is: " << sum << endl; //much importance

			float faverage = static_cast<float>(sum) / number; //float in case of unhappy numbers
			cout << "The average of the digits in your number is: " << faverage << endl; //much average

			cout << "The product of the digits in your number is: " << product << endl; //output the product from earlier
		}
		else
			cout << "The number must be <= 10000." << endl; //follow instructions!!!!!
	}
	else
		cout << "The number must be >= 0" << endl; //follow instructions!!!!!
	return 0;
}