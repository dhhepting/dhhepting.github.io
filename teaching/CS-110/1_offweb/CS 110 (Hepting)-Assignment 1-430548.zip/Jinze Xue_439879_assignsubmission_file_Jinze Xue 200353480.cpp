//**************************************************************************
//
// Student name: Jinze Xue
//
// Student number: 200353480
//
// Assignment number: #1
//
// Program name: calculation
//
// Date written: January 31/2015
//
// Problem statement: Input a number ,can get number of digits,sum of all digits, average of all digits and product of all digits.
//
// Input: number
//
// Output: number of digits , average, product,sum
//
// Algorithm: error<---bigger than 100000<---number---->smaller or equal 100000--->compute number of digits--->sum---->average---->product
//
// Major variables: number,average, product, sum
//
// Assumptions:the number smaller than 10000
//
// Program limitations:number is integer number form 0 to 10000
//
//**************************************************************************


#include <iostream>
using namespace std;
int main()
{
	int number;
	double Average;
	double Product;
	
	
		cout << "Please enter a number.";
		cin >> number;
		if (number <= 9)
			cout << "number of digits: " << 1 << endl;
		if (number > 9)
		if (number<100)
			cout << "number of digits: " << 2 << endl;
		if (number>99)
		if (number<1000)
			cout << "number of digits: " << 3 << endl;
		if (number>999)
		if (number < 10000)
			cout << "number of digits: " << 4 << endl;
		if (9999 < number)
		if (number<=10000)
			cout << "number of digits: " << 5 << endl;
		if (number > 10000)
			cout << "number of digits:error" << endl;
		
		 double sum = number % 10 + (number / 10 - (number % 10) / 10) % 10 + (number / 100 - (number % 100) / 100) % 10 + (number / 1000 - (number % 1000) / 1000) % 10 + (number / 10000 - (number % 10000) / 10000) % 10;
		if (number <= 10000)
		cout << "sum of all the digits:" << sum << endl;
		 if (number > 10000)
	    cout << "sum of all the digits:error" << endl;
	
		 
			  Average = sum / 1;
			  if (number <= 9)
		 cout << "Average of digits: " << Average << endl;
		  Average = sum / 2;
		  if (number > 9)
		 if (number<100)
			 cout << "Average of digits: " << Average << endl;
		 Average = sum / 3;
		 if (number>99)
		 if (number<1000)
		cout << "Average of digits: " << Average << endl;
		  Average = sum / 4;
		  if (number>999)
		 if (number < 10000) 
		 cout << "Average of digits: " << Average << endl;
		   Average = sum / 5;
		   if (9999 < number)
		 if (number <= 10000)
		 cout << "Average of digits: " << Average << endl;
		 if (number > 10000)
			 cout << "Average of digits:error" << endl;


		 Product = (number % 10);
		 if(number<=9)
			cout << "Product of digits:" << Product << endl;
		 Product = (number % 10) *((number / 10 - (number % 10) / 10) % 10) ;
		 if (number>9)
		 if (number<100)
			 cout << "Product of digits:" << Product << endl;
		 Product = (number % 10) *((number / 10 - (number % 10) / 10) % 10) *((number / 100 - (number % 100) / 100) % 10);
		 if (number>99)
		 if (number<1000)
			 cout << "Product of digits:" << Product << endl;
		 Product = (number % 10) *( (number / 10 - (number % 10) / 10) % 10) *( (number / 100 - (number % 100) / 100) % 10) *( (number / 1000 - (number % 1000) / 1000) % 10);
		 if (number>999)
		 if (number < 10000)
			 cout << "Product of digits:" << Product<< endl;
		 Product = (number % 10) *((number / 10 - (number % 10) / 10) % 10) *((number / 100 - (number % 100) / 100) % 10) *((number / 1000 - (number % 1000) / 1000) % 10)*(number / 10000 - (number % 10000) / 10000) % 10;
		 if (number>9999)
		 if (number <=10000)
			 cout << "Product of digits:" << Product << endl;
		 if (number> 10000)
			 cout << "Product of all the digits:error" << endl;


	return 0;
}

// end program