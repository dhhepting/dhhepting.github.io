//**************************************************************************
//
// Student name: Bright Nwanoruo
//
// Student number: 200337192
//
// Assignment number: #1
//
// Program name:   Bright.Cpp
//
// Date written: 30/1/2015
//
// Problem statement: A program that reads an integer between 0 and 10000
//and then calculates and displays (from the integer that has been read)
//
// Input:  An integer between 0 and 10000
//
// Output: Number of digits:The Sum of digits 
//                          The Average of digits
//                          The Product of digits
//                          
//
// Algorithm:
//Declare 5 number of digits, d0 to d4; Prompt the user to enter an integer between 0 and 10000; 
//if the integer entered is between 0 and 10000 proceed and give the outputs: number of all the digits, sum of all the digits, 
//average of all the digits, and product of digits. But, if the integer entered is less than 0 ; display the message:
// Sorry the integer you entered is too small; and if the integer is greater than 10000, display the message :
//Sorry the integer you entered is too big
// Major variables: d0,d1,d2,d3,d4; numdigit, sum, average, product and n
//
// Assumptions: The product is initialized to 1 to prevent giving the output 0 when less than 5digit integer is entered;
//
// Program limitations: 
//The program will proceed to give the outputs if the integer entered is between 0 and 10000. 
//If less than zero the program will display: Sorry the integer you entered is too small and stop; 
//and if the integer entered is greater than 10000, the program will display:
//Sorry the integer you entered is too big
//
//**************************************************************************




#include<iostream>
using namespace std;

int main()
{
	// Declare d0, d1, d2, d3, d4 to represents the location or position of your integer 
	int d0, d1, d2, d3, d4;

	// declare the variable "numdigits" and initialize it to 0
    int numdigits = 0;

	// declare the variable "sum" and initialize it to 0
	int sum = 0;

	// declare the variable "average."
	float average;

	// declare the variable "product" and initialize it to 1
	int product = 1;

	// Declare the variabel "n" to represent an integer
	int n;

	//Prompt the user to enter an integer
	cout << "Enter an integer between 0 and 10000 :" << endl;


	cin >> n;
	if (n >= 0)
	{
		if (n <= 10000)
		{
			// Compute the first digit of your integer using modulus
			d0 = n % 10;

			if (d0 > 0)
			{
				numdigits = 1;

			}
			if (n > 0)
			{
				product = product * d0;
			}
			n = n / 10;

			// Compute the second digit of your integer using modulus
			d1 = n % 10;

			if (d1 > 0)
			{
				numdigits = 2;

			}
			if (n > 0)
			{
				product = product * d1;
			}
			n = n / 10;

			// Compute the third digit of your integer using modulus
			d2 = n % 10;

			if (d2 > 0)
			{
				numdigits = 3;
			}

			if (n > 0)
			{
				product = product * d2;
			}
			n = n / 10;

			// Compute the fourth digit of your integer using modulus
			d3 = n % 10;

			if (d3 > 0)
			{
				numdigits = 4;
			}

			if (n > 0)
			{
				product = product * d3;
			}
			n = n / 10;

			// Compute the fifth digit of your integer using modulus
			d4 = n % 10;

			if (d4 > 0)
			{
				numdigits = 5;
			}
			if (n > 0)
			{
				product = product * d4;
			}

			// Display the number of your  
			cout << " The number of all the digits in your integer is : " << numdigits << endl;

			// Compute the sum of all the digits of the integer
			sum = d0 + d1 + d2 + d3 + d4;

			// Display the sum of your digits in your integer
			cout << " The sum of all digits in your integers is : " << sum << endl;

			//Compute the average of all the digits of the integer
			average = sum / numdigits;

			// Display the average of all the digits in your integer
			cout << " The average of all the digits in your integer is : " << average << endl;


			
			if (product == 1)
			{
				product = 0;
			}
			// Display the product of d0 *d1 *d2 *d3 *d4;
			cout << " The Product of the integer is : " << product << endl;
		}
		else
		{
			cout << "Sorry the integer you entered is too big" << endl;
		}
	}
	else
	{
		cout << "Sorry the integer you entered you entered is too small" << endl;
	}
	cout << "  " << endl;

	return 0;


}