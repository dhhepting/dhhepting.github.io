//**************************************************************************
//
// Student name:Yue(Tyra) Wang
//
// Student number: 200350793
//
// Assignment number: 1
//
// Program name: Visual Studio
//
// Date written: 2015-02-02
//
// Problem statement: Find sum, product, average of a number's digits
//
// Input:enter a number between 0 and 10000
//
// Output:the number of digits
//the sum of all the digits
//the average of all the digits
//
// Algorithm: 
//
// Major variables: Var,sum, number
//
// Assumptions:
//
// Program limitations:only calculates integer within 0 to 10000
//
//**************************************************************************

#include <iostream>
using namespace std;
int main()
{
	int number;

	cout << "Please enter a number between 0 and 10000." << endl;
	cin >> number;

	if (number >= 0)
	{
		if (number <= 10000)
		{
			cout << "Thank you for following instructions!" << endl;

			int digit1 = 0;
			int digit2 = 0;
			int digit3 = 0;
			int digit4 = 0;
			int digit5 = 0;
			int digits;

			digit1 = (number / 1) % 10;
			digit2 = (number / 10) % 10;
			digit3 = (number / 100) % 10;
			digit4 = (number / 1000) % 10;
			digit5 = (number / 10000) % 10;

			cout << "Digits: " << digit5 << " , ";
			cout << digit4 << " , " << digit3 << " , ";
			cout << digit2 << " , " << digit1 << endl;

			if (digit1 > 0)
			{
				digits = 1;
				cout << "The number of digits is: " << digits << endl;
				if (digit2 > 0)
				{
					digits = 2;
					cout << "The number of digits is: " << digits << endl;
					if (digit3 > 0)
					{
						digits = 3;
						cout << "The number of digits is: " << digits << endl;
						if (digit4 > 0)
						{
							digits = 4;
							cout << "The number of digits is: " << digits << endl;
							if (digit5 > 0)
							{
								digits = 5;
								cout << "The number of digits is: " << digits << endl;
							}
						}
					}
				}
			}

		}
		else
		{
			cout << "Sorry, too big!" << endl;
		}
	}
	else
	{
		cout << "Sorry, too small!" << endl;
	}

	return 0;
}
int var()
{

	int val, num, n, sum = 0;
	cout << "please enter an integer between 0 and 10000 : " << endl;
	cin >> val;
	num = val;

	cin >> n;
	cout << "\nEnter " << n << " elements\n";

	while (num != 0)
	{
		sum = sum + num % 10;
		num = num / 10;

	}
	cout << "The sum of the digits of "
		<< val << " is " << sum << endl;
	cout << "The product of the digits is:" << sum * num % 10;
	cout << "The average of the digits is:" << sum / n;
	return 0;
}