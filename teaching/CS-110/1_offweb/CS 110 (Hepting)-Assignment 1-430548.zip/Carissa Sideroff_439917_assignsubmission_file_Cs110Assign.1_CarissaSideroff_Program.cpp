//*******************************************************************************************
//
//Student name: Carissa Sideroff
//
//Student number: 200348410
//
//Assignment Number: 1
//
//Program Name: Assignment1.cpp
//
//Date Wriiten: January 30th 2015
//
//Problem Statement: Write a program that will read an integer between 0 and 100000 and will then calculate and display the number of digits and the sum,average and product of the digits.
//
//Input: User will input a number into the program
//
// Output: The ouput will be the number of digits, sum of digits, average of digits and product of digits. Provided that the number meets the requirements
//Algorithm: 1.ask for number 2. check to see if number is within requested paramters.. if it is continue, and if it is not then ourput error message 3. break down the enetered number into individual numbers  and find the number of digits for each number entered 4. find sum, average and product 5. output the found sum,average and product
//
//Major Variables: a,b,c,d,e, number, sum, product, average, numdigits
//
// Assumptions: The input will be numerical
//
// Program Limitations: The Input must be an integer, if there is a string enetered there will be an error.

#include <iostream>
using namespace std;



int main()
{
    int number;
    cout << "Please enter a integer between 0 - 10000 : " << endl;
    cin >> number;
    //checking to see if number is within limits
    //output if number is less than 0
    if(number <= 0)
    {
        cout << "Sorry,number is to small!" << endl;
    }
    //output if number is more than 10000
    if(number >= 10000)
    {
        cout<< "Sorry, number is to Big!"<< endl;
    }
    //if number fits the requirements the code proceeds
    else
    {
    
    
    
    int a,b,c,d,e; //define variables that are assigned to each digit
    float numdigits; //define numdigits
    //assign. digit in 1's  a
    a = number%10;
    if (a>0)
    {
        numdigits=1; //number of digits if a exists
    }
        //assign digits in 10's b
    b = (number/10)%10;
    if (b>0)
    {
        numdigits=2; //number of digits if b exists
    }
        //assign digit in 100's c
    c = (number/100)%10;
    if (c>0)
    {
        numdigits=3; //number of digits if c exists
    }
        //assign digit in 1000's d
    d = (number/1000)%10;
    if (d>0)
    {
        numdigits=4; //number of digits if d exists
    }
        //assign digit in 10000's e
    e = (number/10000)%10;
    if (e>0)
    {
        numdigits=5; //number of digits if e exists
    }
    // numdigits will now be which every "if statement" was last satisfied

    
   
    
    int sum,product;
    float average; // this one is float so that if it coms out as a decimal the decimal will be printed
    
    //finding sum of digits input
    sum= a+b+c+d+e;
    //finding average of digits input
    average= sum / numdigits;
    
    // producing product for the number of digits input
    if (numdigits==1)
    {
        product= a;
    }
    if (numdigits==2)
    {
        product= a*b;
    }

    if (numdigits==3)
    {
        product= a*b*c;
    }
    if (numdigits==4)
    {
        product= a*b*c*d;
    }
    if (numdigits==5)
    {
        product= a*b*c*d*e;
    }
    
    // output for program based on information previously found
    // output for number of digits
    cout<<"Number of digits:"<< numdigits << endl;
        //output for sum of digits
    cout<<"Sum of digits:"<< sum << endl;
        //output for average of digits
    cout<<"Average of digits:"<< average << endl;
        //output for products of digits
    cout<<"Product of digits:"<< product << endl;
    
        return 0;
        }
}
