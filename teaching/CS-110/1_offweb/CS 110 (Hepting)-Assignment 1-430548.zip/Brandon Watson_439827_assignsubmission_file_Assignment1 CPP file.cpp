//************************************************************************
//
// Student Name: Brandon Watson
//
// Student Number: 200269911
//
// Assignment number: 1
//
// Program name: assignment1
//
// Date Written: January, 30th 2015
//
// Problem Statement: Create a program that displays the number, sum, 
// average and product of digits in a number.
//
// Input: numbers from 0 to 10,000.
//
// Output: The number, sum, average and product of the digits in the 
// number the user enters.
//
// Major Variables: number, average, digit, count, product.
//
// Program Limitations: negative numbers.
//
//***********************************************************************

#include <iostream>
using namespace std;

int main()
{

	int number;
	int sum = 0;
	int digits = 0;
	int average = 0;
	int count = 0;
	int product = 1;

	cout << endl; 	// using this to make a space so output is easier to see.
	cout << "Hello, please enter any whole number between 0 and 10,000." << 
endl;
	cout << endl;
	cin >> number; 	// input number to program.

// formula for sum and product.

	while ( number > 0 ) {	
	{product *= number % 10;}
	sum += number % 10;
	number /= 10;

// formula for number of digits.
	
	if ( number < 10 ) { count += 1; }	
	else
	if ( number < 100 ) { count += 2 - 1; }
	else
	if ( number < 1000 ) { count += 3 - 2; }
	else
	if ( number < 10000 ) { count += 4 - 3; }
	else
	if ( number = 10000 ) { count += 5; }
	
// formula for the average of the digits.

	average = sum/count;

	}

// output of the required information.

	cout << endl; 
	cout << "The number of digits is: " << count << endl;
	cout << endl;
	cout << "The sum of the digits is: " << sum << endl;
	cout << endl;
	cout << "The average of the digits is: " << average << endl;
	cout << endl;
	cout << "The product of the digits is: " << product << endl;
	cout << endl;
	cout << "Thank you for trying the program." << endl;
	cout << endl;
	return 0;
}

