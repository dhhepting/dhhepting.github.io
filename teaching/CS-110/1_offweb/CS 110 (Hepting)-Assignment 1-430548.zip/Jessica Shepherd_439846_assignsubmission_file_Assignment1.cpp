//**************************************************************************
//
// Student name: Jessica Shepherd
//
// Student number: 200341982
//
// Assignment number: Assignment 1
//
// Program name: Questionable Numbers
//
// Date written: January 31, 2014
//
// Problem statement: Trying to figure out the number of digits, the sum of the digits, the mean of the digits, and the product of the digits
//
// Input: User submits a number between 0 and 10,000
//
// Output: The program should tell the user the number of digits, the sum of the digits, the mean of the digits and the product of the digits they submitted
//
// Algorithm: Make the computer calculate various things as I have stated above
//
// Major variables: digit1, digit2, digit3, digit4, digit5
//
// Assumptions: That the user follows instructions and does not submit a number that is too big or too small.
//
// Program limitations: I sure hope not
//
//**************************************************************************


#include <iostream>
#include <iomanip>
using namespace std;
int main()
{
    int number;
    
    cout << "Please enter a number between 0 and 10000" << endl;
    cin >> number;
    
    if (number >= 0)
    {
    if (number <= 10000)
    {
            
    int digit1 = 0;
    int digit2 = 0;
    int digit3 = 0;
    int digit4 = 0;
    int digit5 = 0;
    int digits = 0;
            
            digit1 = (number / 1) % 10;
            digit2 = (number / 10) % 10;
            digit3 = (number / 100) % 10;
            digit4 = (number / 1000) % 10;
            digit5 = (number / 10000) % 10;
            
            cout << "Digits: " << digit5  << " , ";
            cout << digit4  << " , " << digit3 << " , ";
            cout << digit2  << " , " << digit1 << endl;
            
            if (digit1 > 0)
            {
                digits = 1;
            }
        
            if (digit2 > 0)
            {
                digits = 2;
            }
        
            if (digit3 > 0)
            {
                digits = 3;
            }
        
            if (digit4 > 0)
            {
                digits = 4;
            }
        
            if (digit5 > 0)
            {
                digits = 5;
            }
        cout << "The number of digits is: " << digits << endl;
        
        int sum;
        
        sum= (digit1+digit2+digit3+digit4+digit5);
        cout << "The sum of the digits is: " << sum << endl;
        
        
        
        float mean;
        mean=(digit1+digit2+digit3+digit4+digit5)/digits;
        cout<<setprecision(2)<<fixed<< "The mean of the number is: " << mean << endl;
        
        int p3 = 0;
        if (digits == 1)
        {
            p3 = digit1;
        }
        if (digits == 2)
        {
            p3 = digit1 * digit2;
        }
        if (digits == 3)
        {
            p3 = digit1 * digit2 * digit3;
        }
        if (digits == 4)
        {
            p3 = digit1 * digit2 * digit3 * digit4;
        }
        if (digits == 5)
        {
            p3 = digit1 * digit2 * digit3 * digit4 * digit5;
        }
        
        cout << "The product of the number is: " << p3 << endl;
        
        
    }
        else
        
        {
            cout << "Too big! Please follow instructions!" << endl;
        }
       
    }
       else
    {
        cout << "Too small! Please follow instructions!" << endl;
    }

    return 0;
}
