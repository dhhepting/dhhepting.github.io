//**************************************************************************
//
// Student name: Ruihao Zhao	
//
// Student number: 200338484	
//
// Assignment number: #1
//
// Program name: CS110 assignment1
//
// Date written: Jan 30th 2015
//
// Problem statement: input an integer from 0-10000 and find out # of digits, sum, average and product
//
// Input: a number from 0-10000
//
// Output: # of digits, sum, average and product
//
// Algorithm1:Input Checking: To ensure that the input is between 0-10000, I made an if else statement and if the input activated the else function then the code would return 0; or close
// 
// Algorithm2:Digit Finder: The next part is to give each digit a numerical value. To do this I used the modulus and divion operators. Firstly I used modulus to find the value of the digit on the ones digit.
// then i divided the number by 10 and multiples of ten to find the desired digit's value. 
//
// Algorithm3:Displaying Number of Digits: I went from left to right checking the value of the largest digit and the first digit that is not one causes the code to output that digit's place as the number of digits.
// as well it gives a way to output a response to 0.
//
// Algorithm4:Sum and average: summing was simple as all I had to do was add all the values of the digits together (even if they were 0), however for the average I had to elimate the same way as displaying the number
// of digits by checking left to right and dividing by the number of digits that way.
//
// Algorithm5:Product: Product was similar to averaging and displaying number of digits. Start with the largest digit value that was not 0 and then multiply all the values after that. 
//
// Algorithm6:Looping: I did a loop purely out of convience because 4 numbers (2468, 5070, 42, 23451) were used and if i not loop four screenshots needed to be uploaded. 
//
// Major variables: dig1,dig2,dig3,dig4,dig5,avg,sum,prod
//
// Assumptions: only whole numbers and only between 0-10000
//
// Program limitations: cannot do any numbers outside the range of 0-10000
//
//**************************************************************************
#include <iostream>
using namespace std;

int main()
{
	
	int num, sum, prod, dig1, dig2, dig3, dig4, dig5;
	double avg;
	
	for (int i = 0; i < 4; i++)												// Algorithm6: Looping:start
	{
		cout << "Please input an integer from 0-10,000" << endl;			// Algorithm1: Input Checking: Start 
		cin >> num;
		if (num >= 0, num <= 10000)
			cout << "The integer you entered is: " << num << endl;
		else
		{
			cout << "The number you entered is incorrect" << endl;
			return 0;														//ending program if the integer entered was incorrect
		}																	//Algorithm1: Input Checking: End

		dig1 = num % 10;													//Algorithm2: Digit Finder: Start
		dig2 = num / 10 % 10;												//going by ascending order (ones to ten thousand digit)
		dig3 = num / 100 % 10;
		dig4 = num / 1000 % 10;
		dig5 = num / 10000 % 10;
		
		
		cout << "digit 1 is: " << dig1 << endl;
		cout << "digit 2 is: " << dig2 << endl;
		cout << "digit 3 is: " << dig3 << endl;
		cout << "digit 4 is: " << dig4 << endl;
		cout << "digit 5 is: " << dig5 << endl;								//Algorithm2: Digit Finder: End

		if (dig5 > 0)														//Algorithm3: Displaying Number of Digits: Start
			cout << "This integer has five digits" << endl;					//going by descending order (tens of thousands to ones digit)
		else
			if (dig4 > 0)
				cout << "This integer has four digits" << endl;
			else
				if (dig3 > 0)
					cout << "This integer has three digits" << endl;
				else
					if (dig2 > 0)
						cout << "This integer has two digits" << endl;
					else
						if (dig1 > 0)
							cout << "This integer has one digits" << endl;
						else
							cout << "This integer is equal to zero" << endl; //Algorithm3: Displaying Number of Digits: End


		sum = dig1 + dig2 + dig3 + dig4 + dig5;								//Algorithm4: Sum and Average: Start
		cout << "The sum of these digits is: " << sum << endl;

		if (num == 0)
			avg = 0;
		else
			if (dig5 > 0)														//going by descending order (tens of thousands to ones digit)
				avg = sum / 5.0;
			else
				if (dig4 > 0)
					avg = sum / 4.0;
				else
					if (dig3 > 0)
						avg = sum / 3.0;
					else
						if (dig2 > 0)
							avg = sum / 2.0;
						else
							if (dig1 > 0)
								avg = sum / 1.0;
							else
								cout << "Error";
		cout << "The average of these digits is:" << avg << endl;			//Algorithm4: Sum and Average: End

		if (num == 0)
			prod = 0;
		else
			if (dig5 > 0)														//Algorithm5: Product: Start
				prod = dig1*dig2*dig3*dig4*dig5;								//going by descending order (tens of thousands to ones digit)
			else
				if (dig4 > 0)
					prod = dig1*dig2*dig3*dig4;
				else
					if (dig3 > 0)
						prod = dig1*dig2*dig3;
					else
						if (dig2 > 0)
							prod = dig1*dig2;
						else
							if (dig1 > 0)
								prod = dig1;
							else
								cout << "error";
		cout << "The product of the digits is: " << prod << endl;			//Algorithm5: Product: End
		cout << endl;														//When looping this blank line adds to the coherency of the code and makes it easily readable
	}
	
	
	return 0;																//Algorithm 6: Looping: End and codes ends after 4 loops

}