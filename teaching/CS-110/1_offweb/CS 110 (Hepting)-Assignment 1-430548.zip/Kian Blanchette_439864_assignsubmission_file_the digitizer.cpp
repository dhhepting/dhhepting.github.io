//**************************************************************************
//
// Student name: Kian Blanchette
//
// Student number: 200354600
//
// Assignment number: 1
//
// Program name: The Digitizer
//
// Date written: February 1, 2015
//
// Problem statement: Write a program that reads an integer between 0 and 10000 and then calculates and displays (from the integer that has been read) the number
// of digits, the sum of all the digits, the average of all the digits, and the product of all the digits.
//
// Input: The user will input an integer between 0 and 10000, inclusive.
//
// Output: The program will output the number of digits in the integer, as well as the sum, average and product of the digits.
//
// Algorithm: First, the program asks the user to input an integer between 0 and 10000. Then, it decides if the number is sufficient. If the number is sufficient,
// the program computes the values of the individual digits, the sum of all the digits, the average of all the digits, and the product of all the digits. After
// the computation is finished, the program outputs the data. If the number is not sufficient, the program outputs a message to the user telling them that what they
// have entered will not suffice for the purposes of this program.
//
// Major variables: The variables used are:
//					number - the integer the user inputs
//					digits 1 through 5 - the individual digits of the integer number
//					numberofDigits - the number of the digits in the integer
//					sum - the sum of the digits
//					average - the sum of the digits divided by the number of digits
//					product - the product of the digits
//
// Assumptions: The program assumes that the user will input an integer, not characters, float numbers or a string.
//
// Program limitations: The limitation of this program is that it's only really applicable to integers. It will still output information if the user inputs a float
//						value, but only for the integer part of the float.
//
//**************************************************************************
#include <iostream>
using namespace std;

int main()
{
	// First, prompt the user to enter an integer between 0 and 10000
	int number;
	cout << "Hey, pal. You should input an integer between 0 and 10000: ";
	cin >> number;
	
	// Next, test whether the number is between 0 and 10000. If it is proceed with the calculations.
	// If not, it will output a message to the user telling him he has made a mistake.
	if (number >= 0 && number <= 10000)
	{
		cout << "Thank you." << endl;
		
		// First, calculate the individual digits.
		int digit5 = number % 10;
		int digit4 = (number % 100 - digit5) / 10;
		int digit3 = (number % 1000 - (digit5 + digit4 * 10)) / 100;
		int digit2 = (number % 10000 - (digit5 + digit4 * 10 + digit3 * 100)) / 1000;
		int digit1 = (number % 100000 - (digit5 + digit4 * 10 + digit3 * 100 + digit2 * 1000)) / 10000;
		
		// Then determint the number of digits in the number based on the calculations above and output the results.
		int numberofDigits;
		if (digit1 != 0)
			numberofDigits = 5;
		else if (digit2 != 0)
			numberofDigits = 4;
		else if (digit3 != 0)
			numberofDigits = 3;
		else if (digit4 != 0)
			numberofDigits = 2;
		else if (digit5 != 0)
			numberofDigits = 1;
		cout << "Your integer has " << numberofDigits << " digits." << endl;
		
		// Calculate the sum of the digits.
		int sum = digit1 + digit2 + digit3 + digit4 + digit5;
		cout << "The sum of the digits is " << sum << "." << endl;
		
		// Calculate the average of the digits.
		int average = sum / numberofDigits;
		cout << "The average of the digits is " << average << "." << endl;
		
		// Determine how the product should be calculated and then calculate it.
		int product;
		if (numberofDigits == 5)
			product = digit1 * digit2 * digit3 * digit4 * digit5;
		else if (numberofDigits == 4)
			product = digit2 * digit3 * digit4 * digit5;
		else if (numberofDigits == 3)
			product = digit3 * digit4 * digit5;
		else if (numberofDigits == 2)
			product = digit4 * digit5;
		else if (numberofDigits == 1)
			product = digit5;
		cout << "The product of the digits is " << product << "." << endl;
	}
	else cout << "My simple computer brain was not programmed to understand these peculiar \ncharacters you have entered. Taking reasonable action. \nSELF DESTRUCT ACTIVATED! " << endl;
	
	return 0;
	
}