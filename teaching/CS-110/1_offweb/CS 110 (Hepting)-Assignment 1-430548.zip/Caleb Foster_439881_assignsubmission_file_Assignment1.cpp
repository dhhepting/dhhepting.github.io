//**************************************************************************
//
// Student name: Caleb Foster
//
// Student number: 200354226
//
// Assignment number: 1
//
// Program name: Assignment 1
//
// Date written: Jan 30/2015
//
// Problem statement:  a program that reads an integer between 0 and 10000 and then calculates and displays the number of digits and the sum, average, and product of all the digits
//
// Input: Number
//
// Output: Number of digits, Sum of digits, Average of digits, Product of digits 
//
// Algorithm: Ask user to enter a number between 0 and 10000. Then to find the number of digits we set a variable for each digit and use %10 to define the variables. We then use an if statement on all the digit variable to find the last non zero digit and make that the number of digits. 
//			  In the same if statements we find out the product of all digits depending on the number of digits in the number. Then to get the sum of the digits we simple add all the digits together and display the sum on the screen. Then we divide the sum by the number of digits and display it on the screen as the average of all the digits.
//			  After that we display the product of all the digits on the screen. Finally we do two else statements. One for if the number is greater than 10000 and one for if the number if smaller than 0. 
//
// Major variables: Number, Digitn, Digitnumber, Digitproduct, Digitsum
//
// Assumptions: The user isn't entering a letter
//
// Program limitations: It doesn't divide 
//
//**************************************************************************

#include <iostream>


using namespace std;

int main()
{
	int number;
	int digit1;
	int digit2;
	int digit3;
	int digit4;
	int digitnumber;
	int digitsum;
	int digitproduct;

	cout << "Please enter a number between 0 and 10000: ";
	cin >> number;

	if (number > 0)
	{
		if (number < 10000)
		{
			digit1 = number % 10;
			number /= 10;
			digit2 = number % 10;
			number /= 10;
			digit3 = number % 10;
			number /= 10;
			digit4 = number % 10;

			if (digit1 > 0)
			{
				digitnumber = 1;
				digitproduct = digit1;
			}
			if (digit2 > 0)
			{
				digitnumber = 2;
				digitproduct = digit1 * digit2;
			}
			if (digit3 > 0)
			{
				digitnumber = 3;
				digitproduct = digit1 * digit2 * digit3;
			}
			if (digit4 > 0)
			{
				digitnumber = 4;
				digitproduct = digit1 * digit2 * digit3 * digit4;
			}

			cout << "Number of digits: " << digitnumber << endl;

			digitsum = digit1 + digit2 + digit3 + digit4;
			cout << "Sum of digits: " << digitsum << endl;

			cout << "Average of all the digits: " << digitsum / float(digitnumber) << endl;

			cout << "Product of all the digits: " << digitproduct << endl;

		}
		else
		{
		cout << "That number is too big!" << endl;
		}
	}
	else
	{
		cout << "That number is too small! Be positive!" << endl;
	}

	return 0;
}