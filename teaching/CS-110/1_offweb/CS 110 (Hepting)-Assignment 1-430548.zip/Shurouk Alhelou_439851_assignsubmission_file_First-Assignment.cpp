//Shurouk Alhelou
//ID: 200336944
//Assignemtn1
//Visual Studio
//Jan 31, 2015
/************************************************************************************************************************************
* Write a program that reads an integer between 0 and 10000 and then calculates and displays (from the integer that has been read):
* the number of digits
* the sum of all the digits
* the average of all the digits
* the product of all of the digits
**************************************************************************************************************************************/

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
	int number;
	float sum = 0, remainder, n = 0, product=1, average;
	cout << "please enter a integer between 0 and 10000: ";
	cin >> number;
	if (number >= 0 && number <= 10000)
	{
		while (number)
		{
			remainder = number % 10;
			number = number / 10;
			sum = remainder + sum;
			product = product * remainder;
			n++;
		}
		if (n == 0)
		{
			n += 1;
			product = 0;

		}
		average = sum / n;
		cout << endl;
		cout << "The number of all digits you entered is: " << n << endl;
		cout << "The sum of all digits you entered is: " << sum << endl;
		cout << "The average of all digits you entered is: " << average << endl;
		cout << "the product of all digits you entered is: " << product << endl;
	}
	else cout << " Invalid input, please re-enter an integer between 0 and 10000." << endl;
	return 0;
}
