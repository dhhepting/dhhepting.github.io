//*******************************************************
//Student Name: Matthew Vician
//
//Student Number: 200344933
//
//Assignment Number: 1
//
//Program Name: Average, Sum and Product Calculator
//
//Date Written: January 29, 2015
//
//Problem Statement: The user must enter a number between 0 and 10,000 and the computer will display
//					 the number of values entered, the Sum, the Average and the Product of the values entered.
//
//Input: 2,4,6,8
//
//Output: Number of Values: 4;
//		  Sum=20;	
//        Average= 5;
//        Product= 384;
//Algorithm: Prompt user to enter the number of values so desried.
//			 The compiler will allow user to enter all those values requested by the user.
//			 The compiler will then compute the Sum, Average and Product and display those values on screen.
// 
// Major Variables: main() and iostream library.
//
//Assumptions: We are assuming that the user follows the instructions indicated on screen.
//Program limitations: This program can compute any Sum, Average, and Product from inputed values.
//*******************************************************
#include <iostream>
using namespace std;
int main()
{
	// Declaring variables that will be used in computing the Sum and Average
	int num, count;
	float sum, avg;
	sum = 0;
	//Introducing the user to the program
	cout << "This is a program that allows you to compute the Sum, Average and Product" << endl;
	cout << endl;
	// Asking the user to enter the desired amount of numbers so desired
	cout << "How many numbers would you like computed?  ";
	// Displays how mnay Numbers will be used in this program
	cin >> num;
	// Declaring variables that will be used in computing the Product.
	int a;
	float product;
	product = 1;
	cout << endl;
	// Program that will compute the Sum, the Average and the Product
	for (count = 1; count <= num; count++)
	{
		//Asking the user to enter a number
		cout << "Enter a number: ";
		//Allows the user to input that desired number
		cin >> a;
		cout << endl;
		// Computing the Sum of the values entered
		sum = sum + a;		
		// Computing the Prodcut of the values entered 
		product = product *a;
	}
	//Displays the number of digits entered
	cout << "The number of digits: " << num << endl;
	cout << endl;
	//Displays the Sum of the values entered
	cout << "The sum of all digits: " << sum << endl;
	// Computes the Average of the umbers entered
	avg = sum / num;
	cout << endl;
	// Displays the Average of the numbers entered
	cout << "The average of all the digits: " << avg << endl;
	cout << endl;
	// Displays the Prodcut of the numbers entered
	cout <<"The product of all digits: "<< product<<endl;
	cout << endl;
	return 0;
}