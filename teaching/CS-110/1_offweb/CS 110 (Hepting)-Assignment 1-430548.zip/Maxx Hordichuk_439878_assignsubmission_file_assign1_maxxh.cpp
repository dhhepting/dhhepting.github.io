// Name: Maxx Hordichuk
// Student #: 200353849
// Assignment: 1
// Program Name: Maxx's Calculator
// Date Written: 01/26/15
/* Problem: Write a program that reads an integer between 0 and 10000 and calculates
and displays the number of digits, the sum of digits, the average of the digits, and the
product of the digits. */
// Input: A number (number1)
// Output: Number of digits, sum of digits, average of digits, product of digits.
/* Algorithm: Receive number > Identify size of number > Display number of digits >
Calculate each individual digit > Calculate sum of digits > Display sum of digits >
Determine size of number > Divide sum by the number of digits (given by size) > Display average of digits >
Determine size of number > Multiply digits based on size of number > Display product of digits. */
// Major variables: number1, numbersum, dig1, dig2, dig3, dig4, dig5
// Assumptions: User will not input a six digit number.
// Limitations: Cannot correctly compute output for 6 digit integers.

#include <iostream>
using namespace std;

int main()

{

	int number1;

	cout << "Enter an integer between 0 and 10000: ";
	cin >> number1;

	// PART A - Number of Digits

	cout << "Number of digits: ";

	if (number1 >= (10000)){
		cout << "5" << endl;
	}

	if (number1 <= 9999 && number1 >= 1000){
		cout << "4" << endl;
	}

	if (number1 <= 999 && number1 >= 100){
		cout << "3" << endl;
	}

	if (number1 <= 99 && number1 >= 10){
		cout << "2" << endl;
	}

	if (number1 <10){
		cout << "1" << endl; // Determines how large the number is.
	}

	// PART B - Sum of Digits

	int dig1 = number1 % 10;

	int dig2 = (number1 % 100 - dig1) / 10;

	int dig3 = (number1 % 1000 - dig1 - dig2) / 100;

	int dig4 = (number1 % 10000 - dig1 - dig2 - dig3) / 1000;

	int dig5 = (number1 % 100000 - dig1 - dig2 - dig3 - dig4) / 10000; // Determines each digit.

	int numbersum = (dig1 + dig2 + dig3 + dig4 + dig5);

	cout << "Sum of digits: ";

	cout << numbersum << endl;

	// PART C - Average of Digits

	cout << "Average of digits: ";

	if (number1 >= (10000)){
		cout << numbersum / 5 << endl;
	}

	if (number1 <= 9999 && number1 >= 1000){
		cout << numbersum / 4 << endl;
	}

	if (number1 <= 999 && number1 >= 100){
		cout << numbersum / 3 << endl;
	}

	if (number1 <= 99 && number1 >= 10){
		cout << numbersum / 2 << endl;
	}

	if (number1 <10){
		cout << numbersum / 1 << endl;
	}

	// PART D

	cout << "Product of digits: ";

	if (number1 >= (10000)){
		cout << dig1*dig2*dig3*dig4*dig5 << endl;

	}

	if (number1 <= 9999 && number1 >= 1000){
		cout << dig1*dig2*dig3*dig4 << endl;
	}

	if (number1 <= 999 && number1 >= 100){
		cout << dig1*dig2*dig3 << endl;
	}

	if (number1 <= 99 && number1 >= 10){
		cout << dig1*dig2 << endl;
	}

	if (number1 <10){
		cout << dig1 << endl;
	}

	return 0;

}