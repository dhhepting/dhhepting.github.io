//********************************************

//Instructor Name: Daryl Hepting
//Student Name: Shu Wang
//SID Number: 200335170
//Written Date: Feb 2, 2015
//Due Date: 11:55 PM  Feb 2,2015
//Assignment #1 Requirement: Write a program that reads an integer between 0 and 10000 and then calculates and displays
//Subtasks: the number of digits
//          the sum of all the digits
//          the average of all the digits
//          the product of all of the digits
//Variables: int num, sum, prod, dig1, dig2, dig3, dig4, dig5;
//           double avg;

//*********************************************



#include <iostream>
using namespace std;

int main()
{

	int num, sum, prod, dig1, dig2, dig3, dig4, dig5;
	double avg;

	for (int i = 0; i < 4; i++)
	{
		cout << "Please input an integer from 0-10,000" << endl;
		cin >> num;
		if (num >= 0, num <= 10000)
			cout << "The integer you entered is: " << num << endl;
		else
		{
			cout << "The number you entered is incorrect" << endl;
			return 0;
		}
		// calculate every digit
		dig1 = num % 10;
		dig2 = num / 10 % 10;
		dig3 = num / 100 % 10;
		dig4 = num / 1000 % 10;
		dig5 = num / 10000 % 10;

		// if/else syntax for number of digits
		if (dig5 > 0)
			cout << "Number of digits: 5" << endl;
		else
			if (dig4 > 0)
				cout << "Number of digits: 4" << endl;
			else
				if (dig3 > 0)
					cout << "Number of digits: 3" << endl;
				else
					if (dig2 > 0)
						cout << "Number of digits: 2" << endl;
					else
						if (dig1 > 0)
							cout << "Number of digits: 1" << endl;
						else
							cout << "This integer is zero" << endl;

		//  sum
		sum = dig1 + dig2 + dig3 + dig4 + dig5;
		cout << "Sum of these digits: " << sum << endl;

		if (dig5 > 0)
			avg = sum / 5.0;
		else
			if (dig4 > 0)
				avg = sum / 4.0;
			else
				if (dig3 > 0)
					avg = sum / 3.0;
				else
					if (dig2 > 0)
						avg = sum / 2.0;
					else
						if (dig1 > 0)
							avg = sum / 1.0;
						else
							cout << "Error: 0 Cannot be divided";
		cout << "Average of these digits:" << avg << endl;
		
		// product
		if (dig5 > 0)
			prod = dig1*dig2*dig3*dig4*dig5;
		else
			if (dig4 > 0)
				prod = dig1*dig2*dig3*dig4;
			else
				if (dig3 > 0)
					prod = dig1*dig2*dig3;
				else
					if (dig2 > 0)
						prod = dig1*dig2;
					else
						if (dig1 > 0)
							prod = dig1;
						else
							prod = 0;
		cout << "Product of the digits: " << prod << endl;
		cout << endl;
	}

	return 0;
}
