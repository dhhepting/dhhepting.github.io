/*
NAME : HITESH KUMAR SINGH
STUDENT ID : 200352097
ASSIGNMENT NUMBER : 1
ASSIGNMENT NAME : VARIABLE CALCULATION IN INTEGER DIGITS
PROBLEM STATEMENT : Write a program that reads an integer between 0 and 10000 and then calculates and displays 
                    (from the integer that has been read):
                    the number of digits
                    the sum of all the digits
                    the average of all the digits
                    the product of all of the digits
INPUT : 2468, 5070, 42, 23451  
OUTPUT : SHOWN BELOW
*/
#include<iostream>         
#include<iomanip>
using namespace std;
int main()
{
	cout << "In this project we will perform several calculations on the digits of an integer value." << endl;
	cout << "It includes sum, average and product." << endl;
	cout << "Please enter an integer from 0 to 10000" << endl;
	int i;    //Integer varriable.
	cin >> i;      
	if (i < 100)      // condition for i variable.
	{
		int i1;    //i1 & i2 are digits split for integer value.
		int i2;
		cout << "Number of digits = 2" << endl;
		i1 = i % 10;  // division and modulus rule to split integer intp its digits
		i /= 10;
		i2 = i % 10;
		i /= 10;
		cout << i2 << endl;
		cout << i1 << endl;
		cout << "SUM : " << i1 + i2 << endl;
		cout << "PRODUCT : " << i1*i2 << endl;
		cout << "AVERAGE : " << i1 + i2 / 2 << endl;
		return 1;
	}
	if (100 < i && i <= 999)               // condition for i variable.
	{
		int i1;
		int i2;
		int i3;           // i3 is rhird split integer
		cout << "Number of digits = 3" << endl;
		i1 = i % 10;            // division and modulus rule to split integer intp its digits
		i /= 10;
		i2 = i % 10;
		i /= 10;
		i3 = i % 10;
		i /= 10;
		cout << i3 << endl;
		cout << i2 << endl;
		cout << i1 << endl;
		cout << "SUM : " << i1 + i2 + i3 << endl;
		cout << "PRODUCT : " << i1*i2*i3 << endl;
		cout << "AVERAGE : " << i1 + i2 + i3 / 2 << endl;
		return 1;
	}
	if (i > 999 && i < 10000)            // condition for i variable.
	{
		int i1;
		int i2;
		int i3;
		int i4;                 // i4 in fourth split integer digit
		cout << "Number of digits = 4" << endl;
		i1 = i % 10;                  // division and modulus rule to split integer intp its digits
		i /= 10;
		i2 = i % 10;
		i /= 10;
		i3 = i % 10;
		i /= 10;
		i4 = i % 10;
		i /= 10;
		cout << i4 << endl;
		cout << i3 << endl;
		cout << i2 << endl;
		cout << i1 << endl;
		cout << "SUM : " << i1 + i2 + i3 + i4 << endl;
		cout << "PRODUCT : " << i1*i2*i3*i4 << endl;
		cout << "AVERAGE : " << i1 + i2 + i3 + i4 / 2 << endl;
		return 1;
	}
	if (i > 10000)               // condition for i variable.
	{
		cout << "INVALID ENTRY." << endl;
		return 1;
	}
	return 0;
}
