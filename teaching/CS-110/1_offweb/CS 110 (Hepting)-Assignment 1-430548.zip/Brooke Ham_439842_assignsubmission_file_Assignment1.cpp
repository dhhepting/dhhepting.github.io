/* 
Student name: Brooke Ham
Student number: 200353759
Assignment number: 1
Program name: Coding is Difficult for Newbies
Date: written for Feb. 2, 2015
Problem Statement: Write a program that reads an integer between 0 and 10000 and then calculates and displays (from the integer that has been read):
	the number of digits
	the sum of all the digits
	the average of all the digits
	the product of all of the digits
Input: A number preferably between 0 and 10000 (inclusive), although other integers will work on this program
Output: The number of digits, the sum of all the digits, the average of all the digits, and the product of all the digits
Algorithm:The user will enter a number between 0 and 10000 (after being prompted to do so) and the respective quantities will be computed (using modulus and division to separate the digits from the input, and simple math operations to find the quantities) and then listed
Major variables: UserInput, digit1, digit2, digit3, digit4, digit5, NumDigit, SumDigit, AvgDigit, ProdDigit
Assumptions: The program will compile and run correctly, no syntax or logic or runtime errors are present in the code
Program Limitations: A whole number must be inputted to obtain a result.
*/

																										// For the purpose of keeping the code organized, comments relating directly to the code will be placed to the right of the code.
#include <iostream>																						// This is the library that is used to support input and output. It is the only library necessary for this code to run.
using namespace std;																					// Standard namespace is used in this program.
																										
int main()																								// The main funciton intitates the program by creating an integer and an argument (which is the code below).
{																										// These types of braces encompass statements and separate code. Their purpose is the same throughout the code.
	cout << "Hallo, please enter an integer between 0 and 10000!" << endl;								// This statement is displayed for the user and prompts them to provide a number for computation.
	int UserInput;																						// A variable for the input that the user has given is now established.
	cin >> UserInput;																					// The computer can now recognize that the input is assigned to the variable UserInput
	
	if (UserInput <= 10000 && UserInput >= 0)															// This establishes the parameters stated in the problem statement. This format simplifies the cascading if statements that 
	{																									// would otherwise be used by condensing it into one statement.
		int digit1;																						// Establishing digit1 as an integer allows it to be used in later computations. It represents the rightmost digit inputted.
		digit1 = UserInput % 10;																		// The integer digit1 has been assigned the value of the remainder of the number inputted by the user divided by ten. This 
		UserInput /= 10;																				// restricts the assigned value to the numbers 0 to 9 and is equal to the rightmost digit. The number the user inputted is now that
																										// number divided by ten. This allows the next computation (modulus 10 to find digit2) to take the value of the now rightmost digit. This process
		int digit2;																						// is repeated for integers digit2 to digit5 until all the digits have been extrapolated from the input that the user typed in. Because 
		digit2 = UserInput % 10;																		// it is the digits that are inportant in this code, it does not matter that the value for UserInput is changed from what the user typed
		UserInput /= 10;																				// in. If the number inputted by the user is less than five digits, then (5 - the number of digits the user inputted) zeros will be to the
																										// left of the number inputted and act similarly to placeholders.
		int digit3;																						// The variable digit1 is the rightmost digit and digit5 is the leftmost digit.
		digit3 = UserInput % 10;
		UserInput /= 10;

		int digit4;
		digit4 = UserInput % 10;
		UserInput /= 10;

		int digit5;
		digit5 = UserInput % 10;																		// The value for the variable UserInput does not have to be divided by ten here because no further computations for more digits are necessary.

		int NumDigit;																					// This variable represents the number of digits that the integer the user inputted has. Its value will be computed below in the if statements.
		int ProdDigit;																					// This variable represents the product of the digits that the user inputted. The equation to find its value will be computed below in the if statements.

		if (digit1 >= 0)																				// The if statement is used to evaluate whether or not a statement is true. If the parameter is true, then the code written between the braces is used. If
		{																								// the parameter is not true, then the statements within the braces are not used and the next if statement is evaluated. Zero is included in the first  
			NumDigit = 1;																				// parameter because it is within the input range, so it must be included.
			ProdDigit = digit1;																			// If the digit within the parameter is greater than zero, then it occupies a place value and contributes to the number of digits, and so should be included
		}																								// in the number of digits.
																										// The equation for the product of the digits must be included within the if statement because if all of the digits were included in the product then the answer
		if (digit2 > 0)																					// would always be zero. This is because all of the value would be included in the product, including the zeros, which would always give the value zero. 
		{
			NumDigit = 2;
			ProdDigit = digit1 * digit2;
		}

		if (digit3 > 0)
		{
			NumDigit = 3;
			ProdDigit = digit1 * digit2 * digit3;
		}

		if (digit4 > 0)
		{
			NumDigit = 4;
			ProdDigit = digit1 * digit2 * digit3 * digit4;
		}

		if (digit5 > 0)
		{
			NumDigit = 5;
			ProdDigit = digit1 * digit2 * digit3 * digit4 * digit5;										// It would be just as viable to have ProDigit = 0
		}

		cout << "Number of digits: " << NumDigit << endl;												// This displays the number of digits that has been computed above.

		int SumDigit;
		SumDigit = digit1 + digit2 + digit3 + digit4 + digit5;											// After the digits have been separated from the inputtted value, they can be summed.

		cout << "Sum of digits: " << SumDigit << endl;													// Using the assignment equation above, the variable SumDigit can be displayed onscreen.
		cout << "Average of digits: " << SumDigit / float(NumDigit) << endl;							// A float is used to find the average of the digits to allow a more precise number to be displayed.
		cout << "Product of digits: " << ProdDigit << endl;												// The appropriate assignment equation from the if statements above is used to calculate the product of the digits. This 
	}																									// eliminates 0 as a product for numbers with less than five digits without zeros. The brace closes the first if statement.

	else																								// The rest of the if/else statement provides output to the user if they did not give a number between 0 and 10000.
		cout << "No, you loonie, I asked for a number between 0 and 10000!" << endl;					// The message that is displayed to the user if they didn't stick to the parameters for the value of the input. It doesn't need enclosing
																										// braces because there is only one line of code associated with the else statement.
	return 0;																							// This returns the value zero to the main function and finishes the code
	}