/*
Riley Herman

200352833

Assignment 1

Pretty Int-ense Program

Jan 30/2015

Problem Statement: Write a program that reads an integer between 0 and 10000 and then calculates and displays (from the integer that has been read):
					the number of digits
					the sum of all the digits
					the average of all the digits
					the product of all of the digits

Input: An integer that is preferably between 0 and 10000, inclusive.

Output: the number of digits, the sum of all the digits, the average of all the digits, the product of all of the digits.

Algorithm: An integer will be taken into the program. If the number is between or equal to 0 and 10 000, the program will determine the respective quantities
			and output them. It will compute the quantities using basic arithmetic and while loops.

Major Variables: inp (User's input); inp1, inp2, inp3 (copies of inp to be manipulated); numdig, sumdig, avedig, prodig (number, sum, average, and product of digits respectively).

Assumptions: I assmume that their are no spontaneous errors, that the nnumber entered is an integer, and that I haven't committed any semantic errors.

Program limitations: This program is purposely limited to integers between 0 and 10 000, inclusive, and is limited to only the four parameters.
*/
#include <iostream>																	//This includes the library within C++ which deals with input and output streams
using namespace std;																//Makes sure I'm using a standard namespace

int main ()																			//Establishing the main function. It is an integer, so the end of the program is signified by the
{																					// function returning a value of 0

	int inp;																		//Establishing the integer variable inp (short for input)
	cout << "Hey! You!" << endl;													//Prompting the user for their choice in number
	cout << endl;
	cout << "You should totally give me an integer between 0 and 10000," << endl;	
	cout << "and I'll show you what I can do with it!" << endl;
	cin >> inp;																		//Gathering the number which the user inputted
	
	if (inp <= 10000)																//If the input is between or equal to 0 and 10 000
	{
		if (inp >= 0)
		{
			int numdig = 1;															//Creating the integer variable numdig (short for  number of digits). This will store the number 
			int inp1 = inp;															// of digits to be printed later. Also, storing the user inputted value in another variable, which
																					// allows me to manipulate one of them.
			while (inp1 > 10)														//A while loop runs the bit of code between the braces as long as the statement between the parenthesis
			{																		// is true. In this case, it is while the integer inp1 larger than 0 (ergo it stops once counting  when 
				numdig += 1;														// it has divided the number to amounts tiny enough to be decimal values, as any decimal less than one 
				inp1 /= 10;															// is considered the integer 0). Whenever the statement is true, the loop adds to  the number of digits,
			}																		// thus counting the number of digits. Furthermore, the variable inp1 is divided by 10 each time the loop
																					// runs. In this manner, the code will count how many digits are in the number.
			cout << "The number of digits in your number is " << numdig << endl;	//Printing out the number of digits

			int sumdig = 0;															//Creating the variable sumdig (short for sum of digits). It is  0 until we add to it.
			int inp2 = inp;															//As above, storing the user input away for later and creating a variable to manipulate

			while (inp2 > 0)														//A similar loop to above, with one exception. Instead of counting how many time the loop runs (once for every digit),
			{																		// this loop adds the next place value. So the statement is the sum of the digits is the previous sum (beginnning 
				sumdig += inp2 % 10;												// with 0) added to the remainder of the number divided by 10. Then the input is divided by 10, which moves the place
				inp2 /= 10;															// value over for the cycle to continue.
			}

			cout << "The sum of those digits is " << sumdig << endl;				//Prints out the sum of the digits


			float avedig = float(sumdig)/numdig;									//Since average is the sum of the numbers divided by the amount of numbers, and we have conveniently already calculated
			cout << "The average of all of those digits is " << avedig << endl;		// both of those values, the avedig (average of the digits) is just the simple formula sumdig/numdig. Notice
																					// that the avedig is a float and the sumdig has been changed to a float. This allows the value to have decimals

			int prodig = 1;															//Creating the variable prodig, which must equal 1 since we will be multiplying it with the digits and
			int inp3 = inp;															// anything else would change the value. Also, storing the inp value away for later. I realize that is not necessary
																					// but the reason I include it is so that if I wanted to add to the program I could.
			while (inp3 > 0)														// Identical to the sum loop, except instead of adding it is multiplying.
			{
				prodig *= inp3 % 10;
				inp3 /= 10;
			}

			cout << "The product of those digits is " << prodig << endl;			//Prints out the prodig value
		}
	}

	return 0;																		//The function is an integer, and so it must be given an integer value. Thus, the return statement returns a value
}																					// of 0 to the main function, completing the program.