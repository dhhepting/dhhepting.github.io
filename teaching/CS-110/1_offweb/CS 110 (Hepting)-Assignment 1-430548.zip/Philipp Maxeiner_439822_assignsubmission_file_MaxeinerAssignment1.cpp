//**************************************************************************
//
// Student name: Philipp Maxeiner
//
// Student number: 200343181
//
// Assignment number: 1
//
// Program name: 
//
// Date written: January 27
//
// Problem statement: Write a program that reads and integer between 0 and 10000 and then calculates and displays results
//
// Input: user will input the following values: 2468, 5070, 42, 23451
//
// Output: Number of digits, sum, average and product
//
// Algorithm: Write a program that reads an integer between 0 and 10000 and then calculates
// and displays the number of digits, the sum of all the digits, the average of all the digits 
// and the product of all the digits.
//
// Major variables: number, dig1, dig2, dg3, dig4, dig5
//
// Assumptions: The program will calculate and display all numbers correctly for any number 
// between 0 and 10000
//
// Program limitations: 
//**************************************************************************

#include <iostream>
using namespace std;

int main()

// Begin program 

{
int number;

cout << "Enter an integer between 0 and 10000!" << endl; 
cin >> number;  //Request input of an integer from user

// Determine the number of digits in the number
cout << "Digits: ";

if (number >= 0 && number < 10)
	cout << "1" << endl;
else if (number >= 10 && number < 100)
	cout << "2" << endl;
else if (number >= 100 && number < 1000)
	cout << "3" << endl;
else if (number >= 1000 && number < 10000)
	cout << "4" << endl;
else if (number == 10000)
	cout << "5" << endl;
else if (number > 10000)
	cout << "Invalid number" << endl;

// Determine the sum of the digits in the number
// Break the number into individual digits
int dig1;
int dig2;
int dig3;
int dig4;
int dig5;
// Define the sum variable and equation
int sum;
dig1 = (number % 10);
dig2 = (number / 10 % 10);
dig3 = (number / 100 % 10);
dig4 = (number / 1000 % 10);
dig5 = (number / 10000 % 10);
sum = dig1 + dig2 + dig3 + dig4 + dig5;
cout << "Sum: " << sum << endl; // Display the sum to the monitor


// Determine the average of the digits
double average;	// Declare average as a variable

cout << "Average: "; // If statements allow average to be calculated based on the number of digits involved
if (number >= 0 && number < 10)
	cout  << ( dig1 ) / 1 << endl;
else if (number >= 10 && number < 100)
	cout << ( dig1 + dig2 ) / 2 << endl;
else if (number >= 100 && number < 1000)
	cout << ( dig1 + dig2 + dig3 ) / 3 << endl;
else if (number >= 1000 && number < 10000)
	cout << ( dig1 + dig2 + dig3 + dig4 ) / 4 << endl;
else if (number == 10000)
	cout << ( dig1 + dig2 + dig3 + dig4 + dig5 ) / 5 << endl;
else if (number > 10000)
	cout << "Invalid number" << endl;



// Determine the product of all the digits
int product;    //  Define product as a variable

cout << "Product: ";    // Use if statements to determine the number of digits and then perform a related calculation to find the product
if (number >= 0 && number < 10)
	cout  << dig1 << endl;
else if (number >= 10 && number < 100)
	cout << dig1 * dig2 << endl;
else if (number >= 100 && number < 1000)
	cout << dig1 * dig2 * dig3 << endl;
else if (number >= 1000 && number < 10000)
	cout << dig1 * dig2 * dig3 * dig4 << endl;
else if (number == 10000)
	cout << dig1 * dig2 * dig3 * dig4 * dig5 << endl;
else if (number > 10000)
	cout << "Invalid number" << endl;



// End program

return 0;
}