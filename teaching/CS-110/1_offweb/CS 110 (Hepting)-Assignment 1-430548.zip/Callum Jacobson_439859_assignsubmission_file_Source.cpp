//**************************************************************************
//
// Student name: Callum Jacobson
//
// Student number: 200234874
//
// Assignment number: 1
//
// Program name: Digit Reader and Calculator
//
// Date written: 3 February 2015
//
// Problem statement: 
//		The problems that need to be solved by this program are:
//		1) The separation of an integer between 1 and 10000 into its constituent digits;
//		2) Counting the number of digits in the inputted integer;
//		3) Obtaining a sum for the digit values added together;
//		4) Obtaining the average of the digit values;
//		4) Obtaining a product for the digit values multiplied together.
//
// Input:
//		The user will input an integer between 0 and 10000 (range inclusive of 0 and 10000).
//
// Output:
//		After computation, the program will output:
//		1) A value for the number of digits in the inputted integer;
//		2) A value for the sum of the inputted digits;
//		3) A value for the average of the inputted digits;
//		4) A value for the product of the inputted digits.
//
// Algorithm: 
//		1) Instruct user to enter an integer between 1 and 10000;
//			-If the inputted integer is outside this parameter then program closes;
//		2) The program calculates an integer value for each digit in the integer using the modulus operator;
//		3) The program outputs the value of the number of digits in the integer;
//		4) The program calculates an integer value for the sum of the digits;
//		5) The program outputs the value of the sum of the digits;
//		6) The program calculates an integer value for the average value of the digits;
//		7) The program outputs the average value of the digits;
//		8) The program calculates an integer value for the product of the digits;
//		9) The program outputs the value of the product of the digits;
//
// Major variables: 
//		1) User-inputted integer between 1 and 10000.
//
// Assumptions:
//		None.
//
// Program limitations:
//		No limitations, so long as the inputted integer is within the specified parameters.
//
//**************************************************************************
#include <iostream>
using namespace std;

int main()
{

// User inputs integer between 0 and 10000
	
	int number;
	{
		cout << "Please enter a number between 0 and 10000 " << endl;
		cin >> number;
		if( number >= 0 && number <= 10000 )
		{
			cout << "Thanks." << endl;
		}
		else
		{
			cout << "The number is not between 0 and 10000.";
			cout << endl;
			return 0;
		}
		cout << endl;
	}

// Obtaining a value for the number of digits in the inputted integer

	int d1;
	d1 = number % 10;

	int d2;
	d2 = (number / 10) % 10;

	int d3;
	d3 = ((number / 10) / 10) % 10;

	int d4;
	d4 = (((number / 10) / 10) / 10) % 10;

	int d5;
	d5 = ((((number / 10) / 10) / 10) / 10) % 10;

// Counting the number of digits in the integer:

	int number_of_digits;
	{
		if (d5 > 0)
		{
			number_of_digits = 5;
		}
		else if (d4 > 0)
		{
			number_of_digits = 4;
		}
		else if (d3 > 0)
		{
			number_of_digits = 3;
		}
		else if (d2 > 0)
		{
			number_of_digits = 2;
		}
		else if (d1 > 0)
		{
			number_of_digits = 1;
		}
	}
	cout << "The number of digits in the number is " << number_of_digits << endl;

// Sum of the digits:

	int sum_of_digits;
	sum_of_digits = d1 + d2 + d3 + d4 + d5;
	cout << "The sum of the digits in the number is " << sum_of_digits << endl;

// Average of the digits:

	int average_of_digits;
	average_of_digits = (d1 + d2 + d3 + d4 + d5) / number_of_digits;
	cout << "The average of the digits in the number is " << average_of_digits << endl;

// Product of the digits:

	int product_of_digits;
	{
		if (number_of_digits == 5)
		{
			product_of_digits = d1 * d2 * d3 * d4 * d5;
		}
		if (number_of_digits == 4)
		{
			product_of_digits = d1 * d2 * d3 * d4;
		}
		if (number_of_digits == 3)
		{
			product_of_digits = d1 * d2 * d3;
		}
		if (number_of_digits == 2)
		{
			product_of_digits = d1 * d2;
		}
		if (number_of_digits == 1)
		{
			product_of_digits = d1;
		}
	}
	cout << "The product of the digits in the number is " << product_of_digits << endl;

	return 0;
}

