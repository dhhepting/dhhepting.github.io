//**************************************************************************
//
// Student name: YumingZhang
//
// Student number: 200338416
//
// Assignment number: num1
//
// Program name: Digits
//
// Date written: 31 Jan 2015
//
// Problem statement: Counting number of digits, and calculate the sum, average, product of digits.
//
// Input: number between 0 and 10000
//
// Output: number of digits, sum ,average and the product of digits
//
// Algorithm: First we need to declare 5 interage variable for 5 digits.
//			  Program ask user to input number between 0-10000, then we need to check if the number is bigger than 0 less than 10000
//			  if the satisfied above requirement, we use % to store get and store each digits.then output digit,sum,product and average.
//			  if the number is less than 0 and bigger than 10000, we ask user to reinput the number
//
// Major variables: number, digit1,digit1,digit1,digit1,digit1,sum,product,average
//
// Assumptions: we assume user input integer.
//
// Program limitations: it's not a loop, if the input is a negative numbers or any numbers go over 10000, the program have to be set up again to lead the outputer to the correct way
//
//**************************************************************************
# include <iostream>
using namespace std;

int main()
{
	int digit1;
	int digit2;
	int digit3;
	int digit4;
	int digit5;
	int number;
	int numberofdigits = 0;
	double sum = 0;
	int product = 0;
	double average = 0;
	cout << "Please enter your number between 0 - 10000 : ";
	cin >> number;
	digit2 = number / 10 % 10;
	digit3 = number / 100 % 10;
	digit4 = number / 1000 % 10;
	digit5 = number / 10000 % 10;
	if (number>= 0 && number <= 10000)
	{
	digit1 = number % 10;
		if (digit1 > 0)
		{
			numberofdigits = 1;
			sum = sum + digit1;
			product = digit1;
			average = sum / 1;
		}
		if (digit2 > 0)
		{
			numberofdigits = 2;
			sum = sum + digit2;
			product = product * digit2;
			average = sum / 2;
		}
		if (digit3 > 0)
		{
			numberofdigits = 3;
			sum = sum + digit3;
			product = product * digit3;
			average = sum / 3;

		}
		if (digit4 > 0)
		{
			numberofdigits = 4;
			sum = sum + digit4;
			product = product * digit4;
			average = sum / 4;
		}
		if (digit5 > 0)
		{
			numberofdigits = 5;
			sum = sum + digit5;
			product = product * digit5;
			average = sum / 5;
		}
		cout << "Number of digits : " << numberofdigits << endl;
		cout << "Sum of digits : " << sum << endl;
		cout << "Average of digits : " << average << endl;
		cout << "Product of digits : " << product << endl;
	}
		else
		{
			if (number < 0)
			{
				cout << "Your number is too small, please enter a number between 0 - 10000 , " << endl;
			}
			if (number > 10000)
			{
				cout << "Your number is too big, please enter a number between 0 - 10000 ," << endl;
			}
		}
	return 0;

}