//**************************************************************************
//
// Student name: Amanda Flaman
//
// Student number: 200340561
//
// Assignment number: 1
//
// Program name: Assignment_1.cpp
//
// Date written: Jan 30/2015
//
// Problem statement:  a program that reads an integer between
// 0 and 10000 and then calculates and displays the number of 
// digits and the sum, average, and product of all the digits
//
// Input: Number
//
// Output: Number of digits, Sum of digits, Average of digits, Product of digits
//
// Algorithm: Ask user to enter a number between 0 and 10000. 
// To find the number of digits set a variable for each digit 
// and use % 10 to define the variables. Then use an if 
// statement on all the digit variables to find the last 
// non-zero digit and that would determine the number of digits.
// The if statements also tell the product of all the digits 
// based on the number of digits. To get the sum of the digits 
// just add all the digits together and assign them to the 
// variable sumdig. Then divide the sum by the number of digits
// and the average of all the digits will be displayed. Display
// the product of all the digits on the screen which was 
// determined in the if statements. Do two else statements: 
// one for if the number is less than 0 and one if the number 
// is greater than 100000. And then close the program with 
// return 0.
//
// Major variables: number, digitn, numdig, sumdig, productdigit
//
// Assumptions: The user will enter an integer and not a letter.
//
// Program limitations: It doesn't divide the digits and doesn't deal with decimal numbers.
//
//**************************************************************************

#include <iostream>

using namespace std;

int main()
{
    int number;
    int digit1;
    int digit2;
    int digit3;
    int digit4;
    int numdig;
    int sumdig;
    int productdig;
    
    cout << "Please enter an integer between 0 and 10000: ";
    cin >> number;
    
    if(number > 0)
    {
        if(number < 10000)
        {
            digit1 = number % 10;
            number /= 10;
            digit2 = number % 10;
            number /= 10;
            digit3 = number % 10;
            number /= 10;
            digit4 = number % 10;
            
            if (digit1 > 0)
            {
                numdig = 1;
                productdig = digit1;
            }
            if (digit2 > 0)
            {
                numdig = 2;
                productdig = digit1 * digit2;
                
            }
            if (digit3 > 0)
            {
                numdig = 3;
                productdig = digit1 * digit2 * digit3;
                
            }
            if (digit4 > 0)
            {
                numdig = 4;
                productdig = digit1 * digit2 * digit3 * digit4;
            }
            
            cout << "Number of digits: " << numdig << endl;
            
            sumdig = digit1 + digit2 + digit3 + digit4;
            cout << "Sum of digits: " << sumdig << endl;
            
            cout << "Average of all the digits: " << sumdig / float(numdig) << endl;
            
            cout << "Product of all the digits: " << productdig << endl;
            
        }
        else
        {
            cout << "That number is too big!" << endl;
        }
    }
    else
    {
        cout << "That number is too small! Stay positive!" << endl;
    }
    return 0;
}