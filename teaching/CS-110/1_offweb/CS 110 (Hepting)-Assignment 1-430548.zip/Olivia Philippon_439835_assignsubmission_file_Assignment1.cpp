//**************************************************************************
//
// Student name: Olivia Philippon
//
// Student number: 200294151
//
// Assignment number: 1
//
// Program name: Assignment1
//
// Date written: Feb 1, 2015
//
// Problem statement: Allow the user to enter a number, ranging from 0 to 10000. From here, write a program that 
//                    will find the number of digits in that number, as well as the sum, product and average of those digits.
//                    
// Input: A number between the range of 0 and 10000 is expected from the user.
//
// Output: If the user enters a number that is out of the correct range, they will be told that the number is either
//         too small or too large. If the number is entered within the correct range, the number of digits in the number, as well 
//         as the sum, product and average of those digits will be expected as output. 
//
// Algorithm: I will instruct the computer to make sure that the user enters a number from 0 to 10000. If it is not
//			  within this range, they will be told to change their number. When the number is entered correctly, the computer
//            will find the value of each digit in the number by using the modulus operator. Continuing to divide the original 
//            number by 10 will allow each digit to be found in its correct decimal place in the number.  The calculations to 
//            find the sum, product and average are presented. From here, depending on the value of each digits, the "if" 
//            statements are employed. The correct sum, product and average will be presented based on the value of the digits 
//            in the original number that the user had entered. 
//            
// Major variables: The most important variables that I will use in my code are the variables that represent the digits. These variables 
//                  allow the program to be directed to the correct "if" statement and present the correct output for that set
//                  of digits. Also, the variables that represent the sum, product and average are important. 
//                 
// Assumptions: The assumptions I need to make in order for the solution to work are that the user wants to find the 
//              number of digits, sum, product and average of those digits simultaneously. 
//
// Program limitations: There are limitations. The number must be between 0 and 10000 for the program to go to the next step. Also, 
//               even though the program will still work, I see a limitation for the number of decimal places presented in the average. I 
//	             could not get the decimals to be displayed. Therefore, the value is presented is not as accurate as it could be. 
//               
//**************************************************************************

#include <iostream>

using namespace std;

int main()
{
	//We begin by asking for a number between 0 and 10000
	//We want to make sure that it is within the right range. Using the "if" statements from class allows us to do so.

	//Declare the variable for the number that will be entered
	int number; 
	// This command allows a loop to occur. The user is able to enter values, one after the other, to find their number 
	// number of digits, sum, product and average.
	for (;;)
	{
		//The user will enter a number
		cout << "Please enter a number between 0 and 10000: " << endl;
		cin >> number;

		if (number >= 0)
		{
			if (number <= 10000)
			{
				// Here, the user has entered a number correctly within the range.
				cout << "Excellent. We can now continue!" << endl;
				int d1 = 0;
				int d2 = 0;
				int d3 = 0;
				int d4 = 0;
				int d5 = 0;
				//The following calculations find the digits within the number.
				d1 = number % 10;
				number /= 10;
				d2 = number % 10;
				number /= 10;
				d3 = number % 10;
				number /= 10;
				d4 = number % 10;
				number /= 10;
				d5 = number % 10;
				//This places the digits in their correct order based on teh original number entered by the user.
				cout << d5 << d4 << d3 << d2 << d1 << endl;
				
				//First I will declare the varibales to find the sum.
				//Now we will find the sum based on the digits we have found in the previous step.

				int sum = 0;

				sum = d1 + d2 + d3 + d4 + d5;

				//We will find the average of the digits based on the digits found.
				//I will declare an average variable for each set of digits.
				int avg1 = 0, avg2 = 0, avg3 = 0, avg4 = 0, avg5 = 0;

				avg1 = d1;
				avg2 = (sum) / 2;
				avg3 = (sum) / 3;
				avg4 = (sum) / 4;
				avg5 = (sum) / 5;

				//Now we will find the product of the digits based on the digits found. 
				//I will declare a product variable for each set of digits.
				int prod1 = 0, prod2 = 0, prod3 = 0, prod4 = 0, prod5 = 0;

				prod1 = d1 * 1;
				prod2 = d1 * d2;
				prod3 = d1 * d2 * d3;
				prod4 = d1 * d2 * d3 * d4;
				prod5 = d1 * d2 * d3 * d4 * d5;


				//Here is the sequence of "if" statements to follow.
				//Depending on the number of digits, the output should indicate the number of digits, sum, average and product.
				//The "if" statements have set the conditions depending on the digits presented; i.e., in the first "if" statement, 
				//the value of digit one must be equal to or greater than zero. However, we cannot have digits 2, 3, 4, and 5 equal to 
				//zero in this case. 

				if (d1 >= 0 && d2 == 0 && d3 == 0 && d4 == 0 && d5 == 0) {
					cout << "The number of digits is: " << 1 << endl;
					//Find the sum of the digits.
					//By writing "sum", the value calculated before will be entered here and appear to the user.
					//Entering the name of the values calculated before will allow the caculated number to appear. This pattern is 
					//continued throughout the assignment.
					cout << "The sum of the digits is: " << sum << endl;
					//The average will appear in the output based on the calculation completed earlier in the program.
					cout << "The average of the digits is: " << avg1 << endl;
					//The product will appear in the output based on a previous caluclation.
					cout << "The product of the digits is: " << prod1 << endl;
				}
				if (d2 > 0 && d3 == 0 && d4 == 0 && d5 == 0) {
					cout << "The number of digits is: " << 2 << endl;
					cout << "The sum of the digits is: " << sum << endl;
					cout << "The average of the digits is: " << avg2 << endl;
					cout << "The product of the digits is: " << prod2 << endl;
				}
				if (d3 > 0 && d4 == 0 && d5 == 0) {
					cout << "The number of digits is: " << 3 << endl;
					cout << "The sum of the digits is: " << sum << endl;
					cout << "The average of the digits is: " << avg3 << endl;
					cout << "The product of the digits is: " << prod3 << endl;
				}
				if (d4 > 0 && d5 == 0) {
					cout << "The number of digits is: " << 4 << endl;
					cout << "The sum of the digits is: " << sum << endl;
					cout << "The average of the digits is: " << avg4 << endl;
					cout << "The product of the digits is: " << prod4 << endl;

				}
				if (d5 > 0) {
					cout << "The number of digits is: " << 5 << endl;
					cout << "The sum of the digits is: " << sum << endl;
					cout << "The average of the digits is: " << avg5 << endl;
					cout << "The product of the digits is: " << prod5 << endl;
				}

			}
			else
			{
				cout << "Sorry, the number that you have selected is too large!" << endl;
			}
		}
		if (number < 0)
		{
			cout << "Sorry, the number that you have selected is too small!" << endl;
		}

		continue;
	}

	return 0;
}