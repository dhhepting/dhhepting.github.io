/*
//
// Student name: Quinn Bast
// Student number: 200352973
//
// Assignment number: 1
// Program name: Number Calculator
// Date written: 1/26/15
//
// Problem statement: THe program must:
//
// - Get a user input form 0-10000
// - determine the number of digits entered
// - determine the sum of the digits
// - determine the average of the digits
// - determine the product of the digits
//
//
// Algorithm: number % 10; number -= (number % 10) and repeat for higher powers of 10.
//
// Major variables: 
//
// - number					- holds the user's input
// - digit[n] (an array)	- holds the value of each digit
// - digits					- holds the number of digits input
// - sum					- the sum of digit[n]
// - average				- the average of digit[n]
// - product				- the product of digit[n]
//
// Assumptions:
//
// - People won't enter a number that is 10 digits long, for some reason it goes into a weird loop if there are more than 10 digits
//
// Program limitations:
//
// - The number must be between 0-10,000 (as required)
// - I don't think there is any
//
*/

#include <iostream>
#include <iomanip>
using namespace std;

int			main()
{
int			input = 1;									//Used in the do-while loop
do														//Will ask the user to enter another number after the program has ran once.
{
int			number = 0;									//A variable to store the user's input
		
cout << "Enter a number between 0 and 10,000." << endl; //asks the user for input
cin >> number;											//gets user input

/************************Prevents the number being too large or too small**************************/

		if (number > 10000 || number < 0)
		{
				cout << "Sorry, that number is not between 0 and 10,000." << endl << endl;
				number = 4.1652E5;						//sets the value of number to something ridiculous that nobody would enter
		}

if ( number != 4.1652E5)								// tests if the program should proceed based on if the value is in range
{
int			digit[] = { 0, 0, 0, 0, 0}; 
// An array to store each individual digit that was typed in by the user.

/************************Determines a value for each digit the user inputs**************************/
int			num=number;

		if (number <= 10000 || number >= 0)				//checks if the number is in range
		{
			digit[0] =		num % 10 ;
		num -=	digit[0] * 1;
			digit[1] =		(num % 100)/10;
		num -=	digit[1] * 10;
			digit[2] =		(num % 1000)/100;
		num -=	digit[2] * 100;
			digit[3] =		(num % 10000)/1000;
		num -=	digit[3] * 1000;
			digit[4] =		(num % 100000)/10000;
		}
cout << "Your number was: " << number << endl;			//reads out the entered number
		
float		digits = 0;									//the number of digits in the number
int			digits1 = 0;								// a dummy varaible

		// now to determine the number of digits//
		int i;
		for (i = 4.00; i >= 0; i--)						//decreases i until it equals zero
		{
			if (digit[i] != 0)							//if the value is not the default value
			{
				digits1 = i + 1.00;						//then add one to dummy varialbe

				if (digits >= digits1)					//if the value of digits is higher (as i started at 4 and am working downward),
				{
					digits = digits;					// prevets the program from thinking there is only 'one' digit as there is i--
				}
				else
				{
					digits = digits1;					//if this is the first value to return true, set that to how many digits there are
				}
			}

		}
cout << "There are " << digits << " digits." << endl;

/************************Determines the sum**************************/

float		 sum = 0.0;

if (digits != 0)									//prevents adding nothing
{
		int s;
		for (s = 4.00; s >= 0; s--)
		{
			sum += digit[s];						//adds the arry together
		}

cout << "The sum of the digits is: " << fixed << setprecision(0) << sum << "." << endl;
}
else
	cout << "There are no digits to add." << endl;		

/************************Determines the average**************************/
float		average = 0.000;
if (digits != 0)						//Checks to prevent a divide by zero error
{
	average = ((sum * 1.0)/ (digits * 1.0));
	cout << "The mean of the digits is: " << setprecision(3) << average << "." << endl;
}
else 
	cout << "The mean of the ditis is Undefined." << endl;

/************************Determines the product**************************/
int			test = 0;
int			product = 1;						//equals one because multiplying it would result in 0 if it equaled 0 to begin with


if (digits != 0)								//Prevents calculating if no digits entered
{
		for (test = digits; test > 0; test--)	//setting the test varialbe equal to the value of the largest array value
		{
			product *= digit[test-1];
		}
		cout << "The product of the digits is: " << setprecision(0) << product << "." << endl << endl;
}
else
	cout << "There are no digits to take a product of." << endl << endl;
}
cout << "Press 1 to enter another number or 0 to exit." << endl;
cin >> input;
}
while (input >= 1);								//ends the do-while loop if the user decides they dont want to continue

return 0;
}
