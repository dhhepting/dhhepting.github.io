//**************************************************************************
//
// Student name: Juan Echavarria
//
// Student number: 200360759
//
// Assignment number: 1
//
// Program name: 
//
// Date written: 02-02-2015
//
// Problem statement: Write a program that reads an integer between 0 and 10000 and then calculates and displays(from the integer that has been read) :
				//the number of digits
				//the sum of all the digits
				//the average of all the digits
				//the product of all of the digits
//
// Input:			2468
//
// Output:
				//Number of digits : 4
				//Sum of digits : 20
				//Average of digits : 5
				//Product of digits : 384
//
// Algorithm: if, else if.
//
// Major variables: i, a, b, c, d, e.
//
// Assumptions:
//
// Program limitations: Does not work with some cases with the product, and my output is not working in the Visual Studio.
//
//**************************************************************************

/* */

#include<iostream>

using namespace std;

int n, a, b, c, d, e, i, w, x;

int main()
{
	cout << "Please type an integer between 0 and 10000:\n";

	cin >> n;
	//Divide the number
	a = (n / 10000) % 10;
	b = (n / 1000) % 10;
	c = (n / 100) % 10;
	d = (n / 10) % 10;
	e = (n / 1) % 10;

	//Count how many numbers are and assign the nuber to a variable
	if (a != 0){
		i = 5;
	}
	else if (b != 0)
		i = 4;
	else if (c != 0)
		i = 3;
	else if (d != 0)
		i = 2;
	else if (e != 0)
		i = 1;
	else
		i = 0;

	//w = a + b + c + d + e;
	//x = (a + b + c + d + e) / i;

	//Product, that do not affect the result
	if (i = 5){
		a = 1;
	}
	else if (i = 4)
		a = 1, b = 1;
	else if (i = 3)
		a = 1, b = 1, c = 1;
	else if (i = 2)
		a = 1, b = 1, c = 1, d = 1;
	else if (i = 1)
		a = 1, b = 1, c = 1, d = 1, e = 1;



	//Output
	cout << a << "\n" << b << "\n" << c << "\n" << d << "\n" << e << "\n";
	cout << "The number of digits are: " << " " << i << "\n";
	cout << "The sum of the digits is:" << " " << w <<  a + b + c + d + e << "\n";
	cout << "The average of all digits is:" << " " << x <<  (a + b + c + d + e) / i <<  "\n";;
	cout << "The product of all digits is:" << " " << a*b*c*d*e << "\n";;

	return 0;
}
