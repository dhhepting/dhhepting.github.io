//**************************************************************************
// Student name: EMIOLA EBUNLOLU
//
// Student number: 200348870
//
// Assignment number: #1
//
// Program name: integer of digits
//
// Date written: 31-01-15
//
// Problem statement: Input sum, product, average and numbers of digits
//
// Input: 4 digits.
// Major variables: int Sum, Int Average, Int Product, Int num1, int num2, int num3, int num4
//
// Assumptions:
//
// Program limitations: calcalating the variables
//
// Output: sum, product, average and numbers of digits
//
// Algorithm: Ask the user to enter 4 numbers, calculate the sum using this numbers and store it in a variable called sum and same will be done to calculate the product of the numbers 
//the average of the numbe This program omly calculate the sum, product and average of numbers
//
//**************************************************************************

#include<iostream>

using namespace std;

int main()

{
	int n, p;                    //declaring varibales
	int sum = 0;
	int count = 0;
	int product = 1;
	int average;

	cout << "please enter a number between 0 and 10000 :";    //Ask the user to enter a number between 0 and 10000
	cin >> n;

	while (n != 0)                     //Calculations
	{
		p = n % 10;
		sum += p;
		count++;
		average = sum / count;
		n = n / 10;
		product *= p;

	}

	cout << "Number of digits :" << count << endl;                  //output the sum, product, average and number of digits to the user
	cout << "Sum of digits :" << sum << endl;
	cout << "Average of digits :" << average << endl;
	cout << "Product of digits :" << product << endl;

	return 0;   //End of program
}