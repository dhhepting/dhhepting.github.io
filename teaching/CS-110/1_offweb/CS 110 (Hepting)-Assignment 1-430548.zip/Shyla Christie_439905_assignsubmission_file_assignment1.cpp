// Shyla's Assignment #1
//Number, Sum, Average and Products of Digits

#include <iostream>
using namespace std;

int main()
{
	double digit1;
	double digit2;
	double digit3;
	double digit4;
	double digit5;
	double sum;
	double average;
	double numberOfDigits;
	double product;

	// Prompt user to input a number between 0-10000
	cout << "Please input a number betweeen 0-10000 inclusive: " << endl;
	cin >> digit1 >> digit2 >> digit3 >> digit4 >> digit5;

	if (digit1 = 1)
	cout << " Number of digits: 5 ";
	numberOfDigits = 5;
	product = digit1 * digit2 * digit3 * digit4 * digit5;
	cout << "The product is: " << product << endl;
	else if (digit2 > 0)
		cout << " Number of digits: 4 ";
	numberOfDigits = 4;
	product = digit2 * digit3 * digit4 * digit5;
	cout << "The product is: " << product << endl;
	else if (digit3 > 0)
		cout << " Number of digits: 3 ";
	numberOfDigits = 3;
	product = digit3 * digit4 * digit5;
	cout << "The product is: " << product << endl;
	else if (digit4 > 0)
		cout << " Number of digits: 2 ";
	numberOfDigits = 2;
	product = digit4 * digit5;
	cout << "The product is: " << product << endl;
	else if (digit5 > 0)
		cout << " Number of digits: 1 ";
	numberOfDigits = 1;
	product = digit5;
	cout << "The product is: " << product << endl;

	sum = digit1 + digit2 + digit3 + digit4 + digit5;
	cout << " Sum of digits: " << sum << endl;

	average = sum / numberOfDigits;
	cout << " Average of digits: " << average << endl;

	 
	cout << "Product of digits: "
	
	return 0;
}