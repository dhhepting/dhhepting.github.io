//**************************************************************************
//
// Student name: Ashlyn Heintz
//
// Student number: 200287036	
//
// Assignment number: 1
//
// Program name: C++
//
// Date written: February 2, 2015
//
// Problem statement: Enter an integer between 0 and 10000, calculate the number of digits, sum, product and average
//
// Input: A number between 0 and 10000
//
// Output: the integer, number of digits, sum, product and average
//**************************************************************************

#include <iostream>
using namespace std;

int main()
{
	//Prompt the user to enter a number between 0 and 10000 
	int number;
	cout << "Please Enter a Number between 0 and 10000: ";
	cin >> number;
	cout << "Your number is: " << (number) << endl;

	// The number of digits

	int digit1 = 0;
	int digit2 = 0;
	int digit3 = 0;
	int digit4 = 0;
	int digit5 = 0;
	int digits;

	digit1 = (number / 1) % 10;
	digit2 = (number / 10) % 10;
	digit3 = (number / 100) % 10;
	digit4 = (number / 1000) % 10;
	digit5 = (number / 10000) % 10;

	cout << "Digits: " << digit5 << " , ";	
	cout << digit4 << " , " << digit3 << " , ";
	cout << digit2 << " , " << digit1 << endl;


	digits = 1;
		if (digit2 > 0)
			digits = 2;
		if (digit3 > 0)
			digits = 3; 
		if (digit4 > 0)
			digits = 4;
		if (digit5 > 0)
			digits = 5;
	cout << "The number of Digits is: " << digits << endl;

// Sum of digits 
	int sum; 

	if (digits == 1)
	{ 
		sum = digit1;
	}
	if (digits == 2)
	{
		sum = digit1 + digit2;
	}
	if (digits == 3)
	{
		sum = digit1 + digit2 + digit3;
	}
	if (digits == 4)
	{
		sum = digit1 + digit2 + digit3 + digit4;
	}
	if (digits == 5)
	{
		sum = digit1 + digit2 + digit3 + digit4 + digit5;
	}
	cout << "The sum of Digits is: " << sum << endl;

// The average of all digits 
	int average;


	if (digits == 1)
	{
		average = digit1; 
	}
	if (digits == 2)
	{
		average = (digit1 + digit2) / 2;
	}
	if (digits == 3)
	{
		average = (digit1 + digit2 + digit3) / 3;
	}
	if (digits == 4)
	{
		average = (digit1 + digit2 + digit3 + digit4) / 4;
	}
	if (digits == 5)
	{
		average = (digit1 + digit2 + digit3 + digit4 + digit5) / 5;
	}
	cout << "The average of Digits is: " << average << endl;

// The product of all digits
	int proddigits;

	if (digits == 1)
	{
		proddigits = digit1;
	}
	if (digits == 2)
	{
		proddigits = digit1 * digit2;
	}
	if (digits == 3)
	{
		proddigits = digit1 * digit2 * digit3;
	}
	if (digits == 4)
	{
		proddigits = digit1 * digit2 * digit3 * digit4;
	}
	if (digits == 5)
	{
		proddigits = digit1 * digit2 * digit3 * digit4 * digit5;
	}

	cout << "The product of Digits is: " << proddigits << endl; 

	return 0;
}