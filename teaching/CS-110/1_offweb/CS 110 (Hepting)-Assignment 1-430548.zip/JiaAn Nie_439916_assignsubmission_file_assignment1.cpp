#include <iostream>
#include <string>	// using for declearing string and other functions
#include <sstream>	// conveting string to int or int to string
using namespace std;
int main()
{
	int inputnumber;		
	int outputdigits, sum = 0, product = 1, average; 
	// i have to set the prodcut equal to 1 otherwise no matter what number user enter the prodcut would equal to 0
	int digits;
	int x = 1;
	int y = 10;
	string usernumber; // i declear a string is use to convet a int to a string 
	// declearing variables  
	cout << "enter a number: ";		// asking user to enter a number
	cin >> inputnumber;				// this is where the user enter a number

	if (inputnumber <= 10000)  // if the inputnumberr is true it will run the code 
	{
		ostringstream convert;
		convert << inputnumber;
		usernumber = convert.str();
		// these 3 line above is use to convert a int to a string becasue i dont know any other ways to do it 
		// first line i call the conveting function   (i think that how it work )
		// second line convert the int to a string		(i think that how it work )
		// thrid line is set the string that i declear earlier equal to the conversion  (i think that how it work)
		//corret me if i am wrong because i am not 100 % sure

		digits = usernumber.length();
		// using the .length function in string i can get the length of the string that we converted earlier in the code 
		// since the .lenght read how many character in a string 
		// now we know the number of character in that string which is equal to the "digits" in the number


		for (int i = 0; i < digits; i++)			// becasue i know how many digits in the user's number i can use
		{											// a for loop to loop depending on the users number
			outputdigits = (inputnumber % y) / x;	// becasue i know 1234 % 10 will give me 4
			cout << outputdigits << endl;			// and (1234 % 100) /10 will give me 3  
			y = y * 10;								//	now i can set up my equation to 
			x = x * 10;								//	(user's number  % y) / x
			product *= outputdigits;				// each time the loop finish its round my 'x' and 'y' 
			sum += outputdigits;					// will times by 10 
			average = sum / digits;					//
		}


		// this is all outputing the reslut 
		cout << "the sum is " << sum << endl;
		cout << "the average is " << average << endl;
		cout << "the product is " << product << endl;
		cout << "the number of digits is " << digits << endl;
	}	// if statment end here 
	else // else inputnumber is bigger then 10000 it will run this code 
	{
		cout << "number is too big" << endl; // output the sentense
	}
	return 0;
}