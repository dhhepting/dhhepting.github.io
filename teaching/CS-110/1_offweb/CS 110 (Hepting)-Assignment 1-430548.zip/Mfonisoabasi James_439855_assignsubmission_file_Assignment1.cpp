//************************************************************************************************
//
//Name: Mfonisoabasi James
//
//Student number: 200344498
//
//Assignment 1
//
//Program name: Assignment1.cpp
//
//Date written: 1/28/2015
//
//Problem statement: This program displays the number of digits, sum, average and prouct of all the digits
//
//Input: cin
//
//Output: cout
//
//Algorithm: 1. declare variables for intergers between 0 and 1000, sum, average, product
//           2. compute a code that would code that would count the integers input by the user
//           3. add the sum of each integer
//           4. coompute the average using the formula: sum of integers/ number of integers
//           5. lastly compute the product of the integers 
//
//Major variables: 1. sum
//                 2. num
//                 3. count
//
//Assumptions: The assumption made is that the user would not input any decimal number
//
//Program limitations: 1.The algorithm doesn't cover numbers with decimal parts 
//                     2.The program doesn't function when numbers >/ 10000 and \< 0 are inputed
//
//****************************************************************************************************

#include <iostream>

using namespace std;

int main()
{
		int num;            // variable declaration
		int sum;
		int product;
		int average;
		int count;

		sum = count = 0; // assigning values to variables
		product = 1;

		cout << "please user enter integer number: " << endl; // prompting the user to input number
		cin >> num; // reads number
		
		if (num <0 || num>10000) // limiting the number the user inputs
		{
			cout << "please enter a number between 0 and 10000" << endl;	 
		}

		else
		{
			while (num != 0) // creating a loop statement to help the algorithm
			{
				sum = sum + num % 10; // finds the sum
				product = product * (num % 10); // finds the product
				num = num / 10; // eliminates last digits
				count = count + 1; // counting the digits
			}

			average = sum / count; // calculates the average
		}
		cout << "number of digits:" << count << endl; // displays number of digits
		cout << "sum of digits :" << sum << endl; // displays sum
		cout << "the average of the digits:" << average << endl; // displays average
		cout << "the product of the digits :" << product << endl; // displays product

	return 0;
}