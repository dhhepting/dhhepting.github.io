/* CS 110 Assignment 1
 
 Name: Alexander Cameron
 Student Number:200246288
 Lab Section: 094
 
*/

#include <iostream>

using namespace std;
int main ()

{
    int number; //initializing the integer that will be input by the user
    
    cout<< "Please input a number between 0 and 10000: "; //instructions for the user
    cin>> number;
    
    if (number >10000)
    {
        cout<< "Too big!!";    //this message is displayed if the user inputs a number larger than the 10000 specified
        
        return 1;
        
    }
    
    if (number <0)
    {
        cout<< "Please input a positive integer!";    //this message is displayed if the user inputs a number smaller than 0
        
        return 2;
        
    }
   
    int digit1=0;     //this initializes all the five integers
    int digit2=0;
    int digit3=0;
    int digit4=0;
    int digit5=0;
    float numdig=0;   // this initializes the number of digits, "numdig", as a float, allowing the average to become a decimal number
   
    digit1= number%10;       //using modulus to identify the existence of the first digit, then dividing by ten
    number/=10;
    digit2= number%10;       //using modulus to identify the existence of the second digit
    number/=10;         
    digit3= number%10;       //using modulus to identify the existence of the third digit
    number/=10;
    digit4= number%10;       //using modulus to identify the existence of the forth digit
    number/=10;
    digit5= number%10;       //using modulus to identify the existence of the fifth digit
    
    
    if (digit1>0)    //if statements to set the number of digits in the number input by the user
                     //as each statement occurs, if true (ie contains a digit) it replaces the value of "numdig"
    {                //if left empty, the previous value of "numdig" is retained
        numdig=1;
    }
    if (digit2>0)
    
    {
        numdig=2;
    }
    if (digit3>0)
    
    {
        numdig=3;
    }
    if (digit4>0)
    
    {
        numdig=4;
    }
    if (digit5>0)
    
    {
        numdig=5;
    }
    
    cout<< "The number of digits in your number is: "<< numdig<<endl;
    
    int sum= digit1+digit2+digit3+digit4+digit5;   //initializing the value of "sum"
    cout << "The sum of digits is: "<< sum<<endl;
    
    cout << "The average of the digits is: "<< sum/numdig <<endl;
    
    if (digit5>0)
        
    {
        cout << "The product of the digits is: "<<digit1*digit2*digit3*digit4*digit5<<endl;
    }
    else if (digit4>0)
        
    {
        cout<< "The product of the digits is: "<<digit1*digit2*digit3*digit4<<endl;
    }
    else if (digit3>0)
        
    {
        cout << "The product of the digits is: "<<digit1*digit2*digit3<<endl;
    }
    else if (digit2>0)
    
    {
        cout << "The product of the digits is: "<<digit1*digit2<<endl;
    }
    else if (digit1>0)
        
    {
        cout << "The product of the digit is: "<<digit1<<endl;
    }
   

    
    return 0;
}