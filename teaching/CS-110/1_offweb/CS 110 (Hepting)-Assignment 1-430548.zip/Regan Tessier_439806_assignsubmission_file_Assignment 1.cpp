//**************************************************************************
//
// Student name: Regan Tessier		
//
// Student number: 200300419
//
// Assignment number: 1
//
// Program name: The digit compiler and manipulater
//
// Date written: 1 Feb 2015
//
// Problem statement: Identify, sum, product, and avg of digits in a number
//
// Input:Number between 0 & 10000
//
// Output:Number of digits, sum of digits, product of digits, and  the average of digits in an entered number
//
// Algorithm: Number will be entered, an if statement will sort between a number between 0 and 10000 and not in these parameters. A do-while statement will take the product and the sum of the numbered entered while parameters exsist. Average will be found by using if statements. 
//
// Major variables: number, sum, avg, product, pl
//
// Assumptions: When Dr. Hepting said between 0 and 10000 he also included 10000. This program will give out put corresponding to the assignment for 0 and 10000 but nothing less than 0 or greater than 10000. 
//
// Program limitations:
//
//**************************************************************************
#include <iostream>
#include <cmath>
#include <string>
using namespace std;
int main()
{
	int number;
	int sum = 0;
	int avg = 0;

	int product = 1;


	cout << "Enter a number between 0 and 10000" << endl;
	cin >> number;
	int pl = number;
	if (number < 0 || number > 10000)
	{
		cout << "That number is garbage" << endl;
		return 0;
	}
	else if (number <= 9)
		cout << "The number of digits in your number" << endl << 1 << endl;
	else if (number <= 99)
		cout << "The number of digits in your number" << endl << 2 << endl;
	else if (number <= 999)
		cout << "The number of digits in your number" << endl << 3 << endl;
	else if (number < 10000)
		cout << "The number of digits in your number" << endl << 4 << endl;
	else if (number = 10000)
		cout << "The number of digits in your number" << endl << 5 << endl;



	do
	{
		product *= pl % 10;
		sum += pl% 10;
		pl /= 10;


	} while (pl >0 && pl < 10001);

	cout << "The product of your number is " << endl << product << endl;
	cout << "The sum of your number is" << endl << sum << endl;
	if (number <= 9)
	{
		avg = sum / 1;
		cout << "The average of your number is" << endl << avg << endl;;
	
	
	}
	else if (number < 100){
		avg = sum / 2;
		cout << "The average of your number is" << endl << avg << endl;;
	}
	else if (number < 1000){
		avg = sum / 3;
		cout << "The average of your number is" << endl << avg << endl;
	}
	else if (number < 10000)
	{
		avg = sum / 4;
		cout << "The average of your number is" << endl << avg << endl;
	}

	else if (number = 10000){
	avg = sum / 5;
	cout << "The average of your number is" << endl << avg << endl;
}
		


	return 0;
}



