
/**************************************************************************

// Student name: Aaron Waldner

// Student number: 200335154

// Assignment number: 1

// Program name: Assignment 1

// Date written: 2.2.2015

// Problem statement: Write a program that reads an integer between 0 and 10000 and then calculates and displays (from the integer that has been read):

	the number of digits
	the sum of all the digits
	the average of all the digits
	the product of all of the digits

// Input:

	2468
	5070
	42
	23451

// Output:

Dependant on Input

// Algorithm: 

See Comments

// Major variables: 

number, d1, d2, d3, d4, d5, sum, average, product

// Assumptions:

Expects a postive integer as user input

// Program limitations:

Can't make soup.

***************************************************************************/





# include <iostream>
using namespace std;

int main()
// requests user input a number from 0 to 10000
{
	cout << "Please enter positive integer between 0 and 10000" << endl;
// declare variables for digit assignments and assigns user input to varible "number"
	int number, d1, d2, d3, d4, d5, dn;

	cin >> number;
// logic statement that tests user input for range validity.  If valid, place holders
// are determined by dividing by powers of 10, and tested for divisibility by 10.
	if (number > 0 && number <= 10000)
	{
		cout << "Thank you!" << endl;
		{
			d1 = (number / 1) % 10;
			d2 = (number / 10) % 10;
			d3 = (number / 100) % 10;
			d4 = (number / 1000) % 10;
			d5 = (number / 10000) % 10;
		}
// number of digits determined by testing the value of each possible user selected number to
// a maximum of 5 digits.
					{
						if (d1 > 0)
							dn = 1;
						if (d2 > 0)
							dn = 2;
						if (d3 > 0)
							dn = 3;
						if (d4 > 0)
							dn = 4;
						if (d5 > 0)
							dn = 5;
						cout << "Number of Digits: " << dn << endl;
// variables for mathmantical calculations are declared for sum, average, and product
						{
							int sum, average, product;
							sum = (d1 + d2 + d3 + d4 + d5);
							cout << "The sum of the digits is: " << sum << endl;
							{
								average = (sum / dn);
								cout << "The average of all digits is: " << average << endl;
// logic test to determine the number of digits, and multiply their value
								{
									if (dn == 1)
										product = (d1 * 1);
									if (dn == 2)
										product = (d1 * d2);
									if (dn == 3)
										product = (d1 * d2 * d3);
									if (dn == 4)
										product = (d1 * d2 * d3 * d4);
									if (dn == 5)
										product = (d1 * d2 * d3 * d4 * d5);
									cout << "The product of all the digits is: " << product << endl;
								}
							}
						}
					}
// logic parameter that outputs error for user input outside of specifed number range.
		}
		else
		{
			cout << "Number selected is outside of the requested parameters.  Please try again." << endl;
		}
	
		return 0;
}
