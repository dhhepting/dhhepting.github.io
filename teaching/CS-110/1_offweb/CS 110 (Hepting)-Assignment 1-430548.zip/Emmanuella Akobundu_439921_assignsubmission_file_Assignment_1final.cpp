//**************************************************************************
//
// Student name: Emmanuella Akobundu
//
// Student number: 200359057
//
// Assignment number: 1
//
// Program name: Integer reader
//
// Date written: 30th January, 2015
//
// Problem statement: The program is aimed at reading the digits contained in a number from 0 to 10000 entered by the user.
//					  The code then proceeds to calculate and display the number of digits, the sum of the digits, 
//					  the average of the digits, and the product of the digits.
//
// Input: The user is expected to input an integer between 0 and 10000 (inclusive).
//
// Output: The output should display the number of digits, the sum of the digits, the average of the digits, 
//		   and the product of the digits on the screen.
//
// Algorithm: In order to solve the assigned problem, the computer is instructed to first ensure that the number entered 
//			  by the user satisfies the condition that it must be between 0 and 10000 by using nested if statements.
//			  Thereafter, the modulus function in order to separate the digits of the inputed number. If statements are 
//			  incorporated in the code again in order to find the number of digits contained in the number. 
//			  After this, the sum of digits is found by adding all the digits together; the average of the digits is found 
//			  by dividing the sum of digits by the number of digits. And lastly, the product of the digits is found by 
//			  multiplying all of the digits together depending on how many digits there are (using numDigits). 
//			  The results are finally outputed to the screen.
//
// Major variables: The highly important variables include: number, digitn (where n ranges from 1 to 5), numDigits, and sumDigits.
//
// Assumptions: The only assumption noted is that the user inputs a number ranging from 0 to 10000.
//
// Program limitations:	The program does not assign a result for any input that does not meet the range requirement.
//
//**************************************************************************

#include <iostream>
using namespace std;

int main()
{
	cout << "Enter an integer from 0 to 10000: ";
	int number;
	cin >> number;

	if (number >= 0)
	{
		if (number <= 10000)
		{
			// The minimum number of digits is 1, and the maximum is 5 because the range is 0-10000.
			// Calculate and display number of digits.
			// But first, define each of the digits entered by the user.
			int digit1 = number % 10;
			// Because the remainder (the result of the modulus step above), gives the first digit. For example,
			// 5070 % 10 = 507 * (0 / 10) = 0, which is the first digit in 5070 (this numbering starts from behind).
			number /= 10;
			// the number entered now changes in order to assist with upcoming calculations. For example,
			// (new) number = 5070 / 10 = 507 (no floating point or rounding because they're integers).
			// The 507 is the new value used as 'number' in order to help get the second digit using the modulus step.

			int digit2 = number % 10;
			// 507 % 10 = 50 * (7 / 10) = 7, which is the second digit in 5070.
			number /= 10;
			// 507 / 10 = 50, which becomes the new number that helps get the next digit, and so on.

			int digit3 = number % 10;
			number /= 10;

			int digit4 = number % 10;
			number /= 10;

			int digit5 = number % 10;
			number /= 10;
			// For the 5070 example, the 5th digit is zero because it's in the for of 05070.

			//Now, to find the number of digits.
			int numDigits;

			if (digit1 >= 0)
			{
				numDigits = 1;
			}
			if (digit2 > 0)
			{
				numDigits = 2;
			}
			if (digit3 > 0)
			{
				numDigits = 3;
			}
			if (digit4 > 0)
			{
				numDigits = 4;
			}
			if (digit5 > 0)
			{
				numDigits = 5;
			}

			// Now, to find the sum of digits.
			int sumDigits = digit1 + digit2 + digit3 + digit4 + digit5;

			// To find the avergae of the digits.
			int aveDigits = sumDigits / numDigits;

			//To find the product of the digits.
			int prodDigits;
			if (numDigits == 1)
			{
				prodDigits = digit1;
			}
			if (numDigits == 2)
			{
				prodDigits = digit1 * digit2;
			}
			if (numDigits == 3)
			{
				prodDigits = digit1 * digit2 * digit3;
			}
			if (numDigits == 4)
			{
				prodDigits = digit1 * digit2 * digit3 * digit4;
			}
			if (numDigits == 5)
			{
				prodDigits = digit1 * digit2 * digit3 * digit4 * digit5;
			}


			// Finally! Output the number, sum, average, and product of the digits.
			cout << "Number of digits: " << numDigits << endl;
			cout << "Sum of digits: " << sumDigits << endl;
			cout << "Average of digits: " << aveDigits << endl;
			cout << "Product of digits: " << prodDigits << endl;

		}
	}

	if (number < 0 || number > 10000)
		cout << "The number entered is not within the range required. Please try again." << endl;

			return 0;
}