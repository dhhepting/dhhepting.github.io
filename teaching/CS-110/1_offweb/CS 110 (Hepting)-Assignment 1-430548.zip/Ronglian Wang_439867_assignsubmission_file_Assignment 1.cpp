//******************************************************************
//
//Student name: Ronglian Wang
//
//Student number: 200269662
//
//Assignment number: 1
//
//Program name: Reading an integer  
//
//Date written: 2015-01-31
//
//Problem statement:  Calculateing and displaying the digits
//
//Input: 0-10000
//
//Output: �Number of digits: 4,  �Sum of digits : 12,  �Average of digits : 3,  �Product of digits : 0
//
//Algorithm: +,-,*,/,%
//
//Major variables: Number
//
//Assumptions: 
//
//Program limitations: Only takes numbers between 0-10000
//
//*********************************************************************



#include <iostream>
using namespace std;

int main()
{

	cout << "Enter a number between 0-10000 " << endl <<endl;

	int number;

	cin >> number;

	int digit1 = 0;

	int digit2 = 0;

	int digit3 = 0;

	int digit4 = 0;

	int digit5 = 0;

	int numberOfDigit = 0;

	int sum = 0;

	int average = 0;

	int product = 0;





	if (number < 0 || number > 10000)
	{

		cout << "not valid " << endl << endl;
	}

	else

	{
		if (number >= 0 && number <= 10000)

		{
			digit1 = number % 10;

			number /= 10;

			digit2 = number % 10;

			number /= 10;

			digit3 = number % 10;

			number /= 10;

			digit4 = number % 10;

			number /= 10;

			digit5 = number % 10;

			number /= 10;

			if (digit5 >0)

			{

				numberOfDigit = 5;

				sum = digit1 + digit2 + digit3 + digit4 + digit5;

				average = sum / numberOfDigit;

				product = digit1*digit2*digit3*digit4*digit5;

			}

			if (digit4 >= 0 && digit5 == 0)

			{

				numberOfDigit = 4;

				sum = digit1 + digit2 + digit3 + digit4;

				average = sum / numberOfDigit;

				product = digit1*digit2*digit3*digit4;

			}
			if (digit3 >= 0 && digit4 == 0 && digit5 == 0)

			{

				numberOfDigit = 3;

				sum = digit1 + digit2 + digit3;

				average = sum / numberOfDigit;

				product = digit1*digit2*digit3;

			}

			if (digit2 >= 0 && digit3 == 0 && digit4 == 0 && digit5 == 0)

			{

				numberOfDigit = 2;

				sum = digit1 + digit2;

				average = sum / numberOfDigit;

				product = digit1*digit2;

			}

			if (digit1 >= 0 && digit2 == 0 && digit3 == 0 && digit4 == 0 && digit5 == 0)

			{

				numberOfDigit = 1;

				sum = digit1;

				average = digit1;

				product = digit1;

			}
		}
		cout << "Number of digits: " << numberOfDigit << endl << endl;

		cout << "Sum of digits: " << sum << endl << endl;

		cout << "Average of digits: " << average << endl<< endl;

		cout << "Product of digits: " << product << endl << endl;
	}

	
	return 0;
}
