//**************************************************************************
//
// Student name: Joseph Warren
//
// Student number: 200241391
//
// Assignment number: 1
//
// Program name: Digit Operations
//
// Date written: January 28, 2014
//
// Problem statement:  Write a program that reads an integer between 0 and 10000 and then calculates and displays
// (from the integer that has been read):
// -the number of digits
// -the sum of all the digits
// -the average of all the digits
// -the product of all of the digits
//
// Input: 4 digit number between 0 and 10000
//
// Output:
// -number of digits
// -sum of the digits
// -average of digits
// -product of digits
//
// Algorithm:
// 1. Prompt user to enter a 4 digit number between 1 and 10000
// 2. Inform user if number is too small
// 3. Inform user if number is too large
// 4. Calculate the number of digits in the number the user entered
// 5. Display the number of digits to the user
// 6. Calculate the sum of the digits in the number the user entered
// 7. Display the sum to the user
// 8. Calculate the average of the digits in the number the user entered
// 9. Display the average to the user
// 10. Calculate the product of the digits in the number the user entered
// 11. Display the product to the user
//
// Major variables: int number, int digit1, int digit2, int digit3, int digit4, int digit5, int numberofdigits, int sum, float average, int product  
//
// Assumptions:
//
// Program limitations:
// -Number entered by the user must be between 0 and 10000
// -Outputs with decimals will be within the constraints of the float variable type
//
//**************************************************************************

#include <iostream>
#include <iso646.h>
using namespace std;

int main()
{
	// Read in a number
	cout << "Please enter a number between 0 and 10000." << endl;
	int number;
	cin >> number;

	//Inform user if number is too small
	if (0 > number || number > 10000)
	{
		if (number < 0)
		{
			cout << "That number is too small." << endl;
		}

		//Inform user if number is too large

		if (number > 10000)
		{
			cout << "That number is too large." << endl;
		}



	}

	else
	{
		float numberofdigits;
		int digit1;
		digit1 = (number % 10);
		if (digit1 > 0)
		{
			numberofdigits = 1;
		}

		int digit2;
		digit2 = (number / 10) % 10;
		if (digit2 > 0)
		{
			numberofdigits = 2;
		}

		int digit3;
		digit3 = (number / 100) % 10;
		if (digit3 > 0)
		{
			numberofdigits = 3;
		}

		int digit4;
		digit4 = (number / 1000) % 10;
		if (digit4 > 0)
		{
			numberofdigits = 4;
		}

		int digit5;
		digit5 = (number / 10000) % 10;
		if (digit5 > 0)
		{
			numberofdigits = 5;
		}


		// Display the number of digits
		cout << "The number of digits is " << numberofdigits << endl;

		//Calculate sum of digits
		int sum;
		sum = (digit1 + digit2 + digit3 + digit4 + digit5);

		//Display sum of digits
		cout << "The sum of the digits is " << sum << endl;

		//Calculate average of digits
		float average;
		average = sum / numberofdigits;

		//Display average of digits
		cout << "The average of the digits is " << average << endl;

		//Calculate product of digits
		int product;
		if (number == 10000)
		{
			product = 1;
		}
		else
		{
			if (10000 > number > 999)

			{
				product = (digit1 * digit2 * digit3 * digit4);
			}
			if (1000 > number > 99)
			{
				product = (digit1 * digit2 *digit3);
			}
			if (100 > number > 9)
			{
				product = (digit1 * digit2);
			}
			if (10 > number)
			{
				product = digit1;
			}

			//Display product of digits
			cout << "The product of the digits is " << product << endl;
		}
	}
	
	return 0;
}