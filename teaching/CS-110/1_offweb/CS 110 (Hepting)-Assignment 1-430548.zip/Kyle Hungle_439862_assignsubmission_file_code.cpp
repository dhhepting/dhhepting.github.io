/*

Name: Kyle HUngle
Student #: 200354270
Assignment #1
Program Name: Assignment#1
Jan 31/15
Problem Question
Write a program that reads an integer between 0 and 10000 and then calculates and displays (from the integer that has been read): 
�the number of digits
�the sum of all the digits
�the average of all the digits
�the product of all of the digits



*/

#include <iostream>
using namespace std;
int main()
{
	int num; //Variable for integer that is being inputted


		// Asks user for integer and assigns it to variable num
		cout << "Enter an integer between 0 and 100000" << endl;
		cin >> num;

		int n1 = num;
		int numdigits=0;
		
			//While statement to find the number of digits
			// adds 1 to variable numdigits each time the while statement initiates
			while(n1>0)
			{
				numdigits=numdigits+1;
				n1=n1/10 ;
			}
		//displays the number of digits
		cout << "Number of digits: " << numdigits << endl;

		int n2 = num;
		int sum=0;
		int digit;
			
			//While statement to find the sum of digits
			// adds the digit that is calculated to variable sum each time the while statement initiates
			while(n2>0)
			{
				digit=n2 %10;
				n2=n2/10 ;
				sum=sum+digit;
			}
		//displays the sum
		cout << "Sum of digits: " << sum << endl;

		//Takes the sum and divides it by the number of digits
		int average;
			average = sum/numdigits;
		cout << "Average of digits: " << average << endl; 

		int n3 =num;
		int product = 1;
		int digit2;
		

			//While statement to find the products of digits
			// multiplies the digit that is calculated to variable product which initially equals 1 each time the while statement initiates
			while(n3>0)
			{
				digit = n3%10;
				n3=n3/10;
				product=product*digit;

			}
		//displays the product
		cout << "Product of digits: " << product << endl;


 return 0;

}



