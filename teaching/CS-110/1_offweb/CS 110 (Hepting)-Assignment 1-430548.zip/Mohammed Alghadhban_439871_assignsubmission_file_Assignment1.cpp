//										
//
// Mohammed Hassan Al-Ghadbhan
// 200318904
// CS110: Programming & Problem Solving
// Assignment 1
//
//
#include <iostream>
using namespace std;

int main()
{
	// Variable declerations
	unsigned	inputInteger;
	unsigned	nDigits = 0;
	unsigned	sumDigits = 0;
	double		averageDigits = 0;
	unsigned	productDigits = 1;

	// Prompt the user to enter an integer between 0 and 10000
	cout << "Enter an integer between 0 and 10000: ";
	cin >> inputInteger;

	// Error checking
	if (inputInteger < 0 || inputInteger > 10000)
	{
		cout << inputInteger  << " is out of the valid rangle" << endl;
		while (1);
	}

	// Run through all the digits of inputInteger as powers of 10
	while (inputInteger > 0)
	{
		// The remainder after division by ten is the least significant digit
		unsigned remainder = inputInteger - inputInteger / 10 * 10;

		// Add the current digit to the sum of all the last digits
		sumDigits = sumDigits + remainder;

		// Multiply the current digit with the product of all the last digits
		productDigits = productDigits * remainder;

		// Drop the current digit for next iteration
		inputInteger = inputInteger / 10;

		// Increment digit counter
		nDigits = nDigits + 1;
	}

	// Find average of all the digits
	averageDigits = double(sumDigits) / double(nDigits);

	// Display all the computed numbers
	std::cout << "Number of digits: " << nDigits << std::endl;
	std::cout << "Sum of digits: " << sumDigits << std::endl;
	std::cout << "Average of digits: " << averageDigits << std::endl;
	std::cout << "Product of digits: " << productDigits << std::endl;

	// A forever while loops so program doesn't terminate
	while (1);

	return 0;
}