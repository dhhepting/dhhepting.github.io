//**************************************************************************
//
// Student name: Congning Yang
//
// Student number: 200350457
//
// Assignment number: Assignment #1
//
// Program name: CS 110
//
// Date written: Feb 1st, 2015
//
// Problem statement: Write a program that reads an integer between 0 and 10000 and then calculates and displays (from the integer that has been read):the number of digits, the sum of all the digits, the average of all the digits and the product of all of the digits.
//
// Input: A numebr between 0 and 10000
//
// Output:the number of digits, the sum of all the digits, the average of all the digits and the product of all of the digits
//
// Algorithm: sum=dig1+dig2+dig3+dig4+dig5, avg=sum/5, prod=dig1*dig2*dig3*dig4*dig5
//
// Major variables: dig1, dig2, dig3, dig4, digt5, avg, sum and prod
//
// Assumptions: the integer number between 0 and 10000
//
// Program limitations: Any number is not in the range of 0 to 10000
//
// Comment: The code I created can run succefully 
//**************************************************************************

#include <iostream>
using namespace std;

int main()
{
	int num, sum, prod, dig1, dig2, dig3, dig4, dig5;
	double avg;
	cout << "Please input an integer from 0-10000" << endl;
	cin >> num;
	if (num >= 0, num <= 10000)
		cout << "The  integer you entered is:" << num << endl;
	else
	{
		cout << "The number you entered is incorrect" << endl;
		return 0;
	}
	dig1 = num % 10;
	dig2 = num/10 % 10;
	dig3 = num/100 % 10;
	dig4 = num/1000 % 10;
	dig5 = num/10000 % 10;
	cout << "digit 1 is : " << dig1 << endl;
	cout << "digit 2 is : " << dig2 << endl;
	cout << "digit 3 is : " << dig3 << endl;
	cout << "digit 4 is : " << dig4 << endl;
	cout << "digit 5 is : " << dig5 << endl;
	if (dig5 > 0)
		cout << "This integer has five digits " << endl;
	else
		if (dig4 > 0)
			cout << "This integer has four digits " << endl;
		else
			if (dig3 > 0)
				cout << "This integer has three digits " << endl;
			else
				if (dig2 > 0)
					cout << "This integer has two digits " << endl;
				else
					if (dig1 >0)
						cout << "This integer has one digits " << endl;
					else
						cout << "This integer is equal to zero " <<endl;


	sum= dig1 + dig2 + dig3 + dig4 +dig5;
	cout << "The sum of these digits is: " << sum << endl;
	if (dig5 > 0)
		avg = sum / 5.0;
	else
		if (dig4 > 0)
			avg = sum / 4.0;
		else
			if (dig3 > 0)
				avg = sum / 3.0;
			else 
				if (dig2 > 0)
					avg = sum / 2.0;
				else
					if (dig1 > 0)
						avg = sum /1.0;
					else
						cout << "Error: Cannot divide by 0";
	cout << "The average of these digits digits is:" << avg << endl;
	if (dig5 > 0)
		prod = dig1*dig2*dig3*dig4*dig5;
	else
		if (dig4 > 0)
			prod = dig1*dig2*dig3*dig4;
		else
			if (dig3 > 0)
				prod = dig1*dig2*dig3;
			else
				if (dig2 >0)
					prod =dig1*dig2;
				else
					if (dig1 > 0)
						prod = dig1;
					else
						prod = 0;
	cout << "The product of the digits is: " << prod << endl;
}
