/*  
	STUDENT NAME:  Joseph Ashworth
	STUDENT ID:  200354384
	ASSIGNMENT NO.:  1
	PROGRAM NAME:  Assignment_1.cpp
	DATE WRITTEN:  28-01-2015
	PROBLEM STATEMENT:  Create a program to read a number from the user, then calculate information from the digits
		of the number.
	INPUT:  An integer from 0 to 10000
	OUTPUT:  The number of digits in the number, the sum of the digits, the average of the digits and the product
		of the digits.
	ALGORITHM:  Recieve an integer from the user. Reduce the integer into its individual digits. Perform the
		required mathematical operations on the digits. Ouput the results to the console.
	MAJOR VARIABLES:  inputNumber, digit1 to digit5
	ASSUMPTIONS:  User will enter a number within the range.
	PROGRAM LIMITATIONS:  Cannot handle non-numerical inputs.
*/

#include <iostream>
using namespace std;

int main()
{
	cout << "Please enter a number from 0 to 10000." << endl;					//Ask user for a number. Check if
	int inputNumber = -1;														//number is between 0 and 10000. If
	while (inputNumber > 10000 || 0 > inputNumber)								//it is, continue. If not, ask for
	{																			//another number. Repeat until a
		cin >> inputNumber;														//valid number is given.
		if (inputNumber > 10000 || 0 > inputNumber)
		{
			cout << "Your number is not in the range. Please try another." << endl;
		}
	}

	int digit1 = 0, digit2 = 0, digit3 = 0, digit4 = 0, digit5=0; 
	
	int numberOfDigits = 1;
	digit1 = inputNumber % 10;							//Using the modulus function with the correct power of 10
														//removes all digits to the left of the desired one. The
	if (inputNumber >= 10)								//properties of interger division are then used to remove
	{													//all of the digits to the right, leaving the desired digit
		numberOfDigits = 2;								//isolated. This is repeated for up to 5 digits.
		digit2 = (inputNumber % 100) / 10;
	}

	if (inputNumber >= 100)
	{
		numberOfDigits = 3;
		digit3 = (inputNumber % 1000) / 100;
	}

	if (inputNumber >= 1000)
	{
		numberOfDigits = 4;
		digit4 = (inputNumber % 10000) / 1000;
	}
	if (inputNumber >= 10000)
	{
		numberOfDigits = 5;
		digit5 = (inputNumber) / 10000;
	}

	float sumOfDigits = digit1 + digit2 + digit3 + digit4 + digit5;		//Floats are used to allow the variable for
	float averageOfDigits = sumOfDigits / numberOfDigits;				//average to keep its decimals.
	
	int productOfDigits = 0;										//Because any digits that weren't used are 
	if (numberOfDigits == 1)										//stored as 0 (eg. 37 is stored as 00037), we
		{															//cannot multiply by these digits. "If
			productOfDigits = digit1;								//statements" are used to determine which
		}															//expression should be used to determine the
	if (numberOfDigits == 2)										//correct product.
		{
			productOfDigits = digit1 * digit2;
		}
	if (numberOfDigits == 3)
		{
			productOfDigits = digit1 * digit2 * digit3;
		}
	if (numberOfDigits == 4)
		{
			productOfDigits = digit1 * digit2 * digit3 * digit4;
		}
	if (numberOfDigits == 5)
		{
			productOfDigits = digit1 * digit2 * digit3 * digit4 * digit5;
		}

	cout << "The number of digits is: " << numberOfDigits << endl;			//Output the information to the console
	cout << "The sum of the digits is: " << sumOfDigits << endl;
	cout << "The average of the digits is: " << averageOfDigits << endl;
	cout << "The product of the digits is: " << productOfDigits << endl;

	return 0;
}