// *********************************************************
//
// Student name: Rebekah Leppington
// Studnet number: 200 343 095
// Assignment number: 1
// Program name: Assignment1.cpp
// Date written: January 31, 2015
// Problem statement: This program will find the number of digits, the sum of the digits, the average of the digits, the product of the digits.
// Input: Any number between 0 and 10,000 inclusive.
// Output: The number, sum, average and product of the digits.
// Algorithm: The computer will use basic math (+,/,*,=), and == to calculate the required results.
// Major variables: number, digits, sum, average, product, digit1, digit2, digit3, digit4, digit5.
// Assumptions: None
// Program limitations: None
//
//****************************************************************

#include <iostream>
using namespace std;
int main()
{
	int number;
	int digits;
	int sum;
	
	int digit1 = 0;
	int digit2 = 0;
	int digit3 = 0;
	int digit4 = 0;
	int digit5 = 0;

	cout << "Please enter a number between 0 and 10000." << endl;
	cin >> number;
   
	digit1 = (number / 1) % 10;
	digit2 = (number / 10) % 10;
	digit3 = (number / 100) % 10;
	digit4 = (number / 1000) % 10;
	digit5 = (number / 10000) % 10;
	
	if (number >= 0)
	{
		if (number <= 10000)
		{
			cout << "Thank you for following instructions!" << endl;

			if (digit1 >= 0) 
			{
				digits = 1;
			if (digit2 > 0) 
				
				digits = 2;
			if (digit3 > 0) 
					
				digits = 3;
			if (digit4 > 0) 
						
				digits = 4;
			if (digit5 > 0) 
							
				digits = 5;
			cout << "The number of digits is: " << digits << endl;
				
			}

		}
		else
		{
			cout << "Sorry, too big!" << endl;
		}
	}
	else
	{
		cout << "Sorry, too small!" << endl;
	}

	sum = digit1 + digit2 + digit3 + digit4 + digit5;

	cout << "The sum of the digits yields: " << sum << endl;

	int average;

	if (digits == 1)
	{
		average = digit1;
	}

	if (digits == 2)
	{
		average = (digit1 + digit2) / digits;
	}

	if (digits == 3)
	{
		average = (digit1 + digit2 + digit3) / digits;
	}

	if (digits == 4)
	{
		average = (digit1 + digit2 + digit3 + digit4) / digits;
	}

	if (digits == 5)
	{
		average = (digit1 + digit2 + digit3 + digit4 + digit5) / digits;
	}

	cout << "The average of the digits: " << average << endl;

	int product;

	if (digits == 1)
	{
		product = digit1;
	}

	if (digits == 2)
	{
		product = digit1 * digit2;
	}

	if (digits == 3)
	{
		product = digit1 * digit2 * digit3;
	}

	if (digits == 4)
	{
		product = digit1 * digit2 * digit3 * digit4;
	}

	if (digits == 5)
	{
		product = digit1 * digit2 * digit3 * digit4 * digit5;
	}

	cout << "The product of the digits yields: " << product << endl;

	return 0;
}