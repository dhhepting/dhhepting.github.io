//**************************************************************************
//
// Student name: Julie Ziemer
//
// Student number: 200342432
//
// Assignment number: Assignment 1
//
// Program name: CS110Assignment1.cpp
//
// Date written: February 2, 2015
//
// Problem statement: Develop a program that prompts user to enter a number between 0 and 10000 and then displays the number of digits, 
//					  the sum of the digits, the average of the digits, and the product of the digits of that number. 
//
// Input: User enters a number between 0 and 10000.
//
// Output: "Please enter a number between 0 and 10000.", "The number you entered is: ", "The number of digits is: ", "The sum of digits is: ",
//         "The average of digits is: ", "The product of digits is: "
//
// Algorithm: 
//
// Major variables: int number, digit1, digit2, digit3, digit4, digit5, digits, sumDigits, avDigits, prodDigits;
//
// Assumptions:  User must enter a number between 0 and 10000 for the program to go through all the steps.
//
// Program limitations: I cannot get the code for finding the average and finding the product to work properly. The code also does not work for numbers with zeroes in them.
//
//**************************************************************************
#include <iostream>
using namespace std; 
int main()
{
	int number;

	cout << "Please enter a number between 0 and 10000." << endl;
	cin >> number;

	if (number >= 0)
	{
		if (number <= 10000)
		{
			cout << "The number you entered is: " << number << endl;
			
	int digit1, digit2, digit3, digit4, digit5, digits;

			digit1 = (number / 1) % 10;
			digit2 = (number / 10) % 10;
			digit3 = (number / 100) % 10;
			digit4 = (number / 1000) % 10;
			digit5 = (number / 10000) % 10;
			

			// Calculate number of digits

			if (digit1 > 0)
			{
				digits = 1;
				if (digit2 > 0)
				{
					digits = 2;
					if (digit3 > 0)
					{
						digits = 3;
						if (digit4 > 0)
						{
							digits = 4;
							if (digit5 > 0)
							{
								digits = 5;
							}
						}
					}
				}
			}
			cout << "The number of digits is: " << digits << endl;
		
			//Calculate the sum of digits
			
			int sumDigits;
			cout << digits << endl;
			if (digits = 5)
			{
				sumDigits = digit5;
				if (digits = 2)
				{
					sumDigits = digit1 + digit2;
					if (digits = 3)
					{
						sumDigits = digit1 + digit2 + digit3;
						if (digits = 4)
						{
							sumDigits = digit1 + digit2 + digit3 + digit4;
							if (digits = 5)
							{
								sumDigits = digit1 + digit2 + digit3 + digit4 + digit5;
							}
						}
					}
				}
			}
			cout << "The sum of digits is: " << sumDigits << endl;

			// Find the average of the digits

			int avDigits;
			if (digits = 1)
			{
				cout << digit1 << endl;
				avDigits = digit1;
				if (digits = 2)
				{
					avDigits = (digit1 + digit2) / digits;
					if (digits = 3)
					{
						avDigits = (digit1 + digit2 + digit3) / digits;
						if (digits = 4)
						{
							avDigits = (digit1 + digit2 + digit3 + digit4) / digits;
							if (digits = 5)
							{
								avDigits = (digit1 + digit2 + digit3 + digit4 + digit5) / digits;
							}
						}
					}
 				}
			}
			cout << "The average of digits is: " << avDigits << endl;

			// Find the product of the digits

			int prodDigits;
			if (digits = 1)
			{
				prodDigits = digit1;
				if (digits = 2)
				{
					prodDigits = digit1 * digit2;
					if (digits = 3)
					{
						prodDigits = digit1 * digit2 * digit3;
						if (digits = 4)
						{
							prodDigits = digit1 * digit2 * digit3 * digit4;
							if (digits = 5)
							{
								prodDigits = digit1 * digit2 * digit3 * digit4 * digit5;
							}
						}
					}
				}
			}
			cout << "The product of digits is: " << prodDigits << endl;
				}
	}
	else
	{
		cout << "Please try entering a new number." << endl;

	}
			return 0;
}
