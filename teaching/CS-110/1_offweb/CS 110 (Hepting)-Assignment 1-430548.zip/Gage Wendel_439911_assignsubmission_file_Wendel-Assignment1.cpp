#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
	cout << fixed << setprecision(2);
	int answer, number, num1, num2, num3, num4, num5;

	cout << "Input an integer between 0 and 10 000" << endl;
	cin >> number;

	if (number < 0)
	{
		cout << "invalid number" << endl;
	}
	else if (number < 10)
	{
		cout << "number of digits is: 1" << endl
			<< "The sum of the digits is: " << number << endl
			<< "The average of the digits is: " << number << endl
			<< "The product of the digits is: " << number << endl;
	}
	else if (number < 100)
	{
		num1 = number / 10;
		num2 = number % 10;
		answer = num1 + num2;
		cout << "Number of digits is: 2" << endl
			<< "The sum of the digits is: " << answer << endl
			<< "The average of the digits is: " << float(answer) / 2 << endl
			<< "The product of the digits is: " << num1 * num2 << endl;
	}
	else if (number < 1000)
	{
		num1 = (number / 100) % 10;
		num2 = (number / 10) % 10;
		num3 = number % 10;
		answer = num1 + num2 + num3;
		cout << "number of digits is: 3" << endl
			<< "The sum of the digits is: " << answer << endl
			<< "The average of the digits is: " << float(answer) / 3 << endl
			<< "The product of the digits is: " << num1 * num2 * num3 << endl;
	}
	else if (number < 10000)
	{
		num1 = (number / 1000) % 10;
		num2 = (number / 100) % 10;
		num3 = (number / 10) % 10;
		num4 = number % 10;
		answer = num1 + num2 + num3 + num4;
		cout << "number of digits is: 4" << endl
			<< "The sum of the digits is: " << answer << endl
			<< "The average of the digits is: " << float(answer) / 4 << endl
			<< "The product of the digits is: " << num1 * num2 * num3 * num4 << endl;
	}
	else if (number == 10000)
	{
		cout << "number of digits is: 1" << endl
			<< "The sum of the digits is: 1 " << endl
			<< "The average of the digits is: 0.2" << endl
			<< "The product of the digits is: 0" << endl;
	}
	else
	{
		cout << "invalid number" << endl;
	}
	return 0;
}