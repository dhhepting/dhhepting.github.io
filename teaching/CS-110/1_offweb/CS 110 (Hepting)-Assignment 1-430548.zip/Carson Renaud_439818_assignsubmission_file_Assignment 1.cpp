//
//  main.cpp
//  Assignment 1 CS 110 Dr. Hepting
//
// Problem Statement: A program that reads an integer between 0 and 10000 and then calculates and displays
//                    the number of digits, the sum of all the digits, the average of all the digits, the
//                    product of all the digits.
//
// Algorithim: The program will take in a value within the acceptable range and by using a while loop that
// is controlled by a boolean operator will evaluate the input integers and seperate them and then become
// true in the event a non zero digit is encountered this loop will then execute the outputs required for
// the program and will exit the loop once all numbers have been evaluated.
//
// Input: int between 0-10000       Output: sum, number of digits, average, product.
//
// Major variables: Number (integer prompted from user), numDigits (number of digits), sum (sum of digits),
// product (digits multiplied to find the product)
//
// Assumptoions: This program only work for type integer numbers and within the acceptable range.
//
// Program Limitations: This only work for positive integers, and cannot calculate large values (>int)  
//
//  Created by Carson Renaud on 2015-01-31.
//  Student ID : 200304106
//  Copyright (c) 2015 carson renaud. All rights reserved.
//

#include <iostream>
using namespace std;


int main()
{
    int number; // Declares the integer input number from user
    cout << "Please enter a number between 0-10000 " << endl; // Prompts user for a type interger number
    cin >> number; // take in number from user
    if(number < 0 || number > 10000) // input test
    {
        cout << "Your number is not within the accepted range of value :( "<< endl;
        return 1; // If checks the conditions not acceptable for input values
    }
    
    int sum = 0, numDigits = 0, i = 0, product = 1; // Declaring varibles to be used for the while loop
    bool digitFound = false; // boolean operator intially false until a non-zero digit is encountered

    while (number > 0) // enters loop once a non-zero number has been encountered
    {
        i++; // increments the count for how man digits have been entered
        int digit = number % 10;
        // modulus operator used to seperate the furthest right digits and store them as the new number
        number /= 10;
        // in order to get rid of the remainder and move on to the next value we divide number by 10
        if ( digit > 0) // If checks if we have encountered a non zero value and changes bool to true
        {
            digitFound = true;
            numDigits = i; // this stores how many digits have been entered
            
        }
        
        if (digitFound) // if bool is true this if will then calculate the sum and the product
        {
            sum += digit; // sums the digits that have been entered
            product *= digit; // calculates the product
        }
    }
    
    cout << "The number of digits : " << numDigits<< endl;
    cout << "The sum of all the digits : " << sum << endl;
    cout << "The average of all the digits : " << float(sum) / numDigits << endl;
    cout << "The product of all the digits : " << product << endl;
    // Output of program 
    return 0;
}
