/*
Katie Todd
200223677
Assignment 1
Code to Compute Integers
Jan.29/15
*/

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
	int number;

	cout << "Please enter an integer between 0 and 10000, and press return." << endl;
	cin >> number;
	if (number < 0)
	{
		cout << "That is not a valid integer." << endl;
		return 0;
	}
	if (number >10000)
	{
		cout << "That is not a valid integer." << endl;
		return 0;
	}
	cout << "The integer you entered is: " << number << endl;

	int a, b, c, d, e;
	a = number / 10000 % 10;
	b = number / 1000 % 10;
	c = number / 100 % 10;
	d = number / 10 % 10;
	e = number % 10;
	// This will break the number down into its digits.

	int sum, prod;
	float dig, avg;
	if (a > 0)
	{
		dig = 5;
		sum = (a + b + c + d + e);
		avg = (sum / dig);
		prod = (a * b * c * d * e);
		cout << "Number of digits: " << dig << endl;
		cout << "Sum of digits: " << sum << endl;
		cout << "Average of digits: " << setprecision(2) << avg << endl;
		cout << "Product of digits: " << prod << endl;
	}
	else if (b > 0)
	{
		dig = 4;
		sum = (b + c + d + e);
		avg = (sum / dig);
		prod = (b * c * d * e);
		cout << "Number of digits: " << dig << endl;
		cout << "Sum of digits: " << sum << endl;
		cout << "Average of digits: " << setprecision(2) << avg << endl;
		cout << "Product of digits: " << prod << endl;
	}
	else if (c > 0)
	{
		dig = 3;
		sum = (c + d + e);
		avg = (sum / dig);
		prod = (c * d * e);
		cout << "Number of digits: " << dig << endl;
		cout << "Sum of digits: " << sum << endl;
		cout << "Average of digits: " << setprecision(2) << avg << endl;
		cout << "Product of digits: " << prod << endl;
	}
	else if (d > 0)
	{
		dig = 2;
		sum = (d + e);
		avg = (sum / dig);
		prod = (d * e);
		cout << "Number of digits: " << dig << endl;
		cout << "Sum of digits: " << sum << endl;
		cout << "Average of digits: " << setprecision(2) << avg << endl;
		cout << "Product of digits: " << prod << endl;
	}
	else if (e > 0)
	{
		dig = 1;
		sum = (e);
		avg = (sum / dig);
		prod = (e);
		cout << "Number of digits: " << dig << endl;
		cout << "Sum of digits: " << sum << endl;
		cout << "Average of digits: " << setprecision(2) << avg << endl;
		cout << "Product of digits: " << prod << endl;
	}

	return 0;
}