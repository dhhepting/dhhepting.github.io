// Geneva Gevers
// 200337724
// assignment 1
// feb 2/15
// input = numbers to be calculated
// output = number of digits, sum of digits, average of digits, product (multiplication) of digits
// program limitations: my skills in programming, I'm sorry :(

#include <iostream>
using namespace std;

int main()
{
	int number;
	int digitnum;

	cout << "please enter a number from 0 - 10000" << endl;
	cin >> number;

	if (number < 0)
		cout << "That number is too low." << endl;
	
	else if (number > 10000)
		cout << "That number is too high." << endl;
	
	else
		cout << "That number is within the required range." << endl;	

	int digit5 = number % 10;
	number /= 10;
	
	int digit4 = number % 10;
	number /= 10;

	int digit3 = number % 10;
	number /= 10;
	
	int digit2 = number % 10;
	number /= 10;
	
	int digit1 = number % 10;
	number /= 10;

	int sum = digit1 + digit2 + digit3 + digit4 + digit5;
	cout << "the sum of the numbers is: " << sum << endl;

		int average = sum / 1;
		if (digit1 > 0);
			cout << "the average of the numbers is:" << average << endl;

		else if (digit2 > 0);
		cout << "the average of the numbers is:" << average / 2 << endl;

		else if (digit3 > 0);
		cout << "the average of the numbers is:" << average / 3 << endl;

		else if (digit4 > 0);
		cout << "the average of the numbers is:" << average / 4 << endl;

		else (digit5 > 0);
		cout << "the average of the numbers is:" << average / 5 << endl;

	int multiplication = (digit1 * digit2 * digit3 * digit4 * digit5);
	cout << "The multiplication of the numbers is: " << multiplication << endl;

	
	
	cout << number << endl;
	

	return 0;
}
