//**************************************************************************
//
// Student name: Riley Peters
//
// Student number: 200 354 249
//
// Assignment number: #1
//
// Program name: Integer Analysis
//
// Date written: January 29th, 2015
//
// Problem statement: To have a program give the requested information on the number input by the user
//
// Input: a number between 1-10000
//
// Output: # of digits, sum of digits, average of digits, product of digits
//
// Algorithm: input number -> test number in the range.  If not in range goes to else statements at end of program -> then take that number and find the values for each digit [(number %              place value)/(place value/10)] -> now test each number for its number of digits.  Filtered through if statements until it falls in correct category -> the correct category sets value for digits and calculates product since product calculation depends on number of digits to avoid zero values one the left of the number -> output reads digits, calculates sums from values of each digit, calculates average of digits, and reads product.
//
// Major variables: input number, number of digits, each place value (tenthousands, thousands, hundreds, tens, ones)
//
// Assumptions: assuming decimals are not considered
//
// Program limitations: won't consider decimal points
//
// * I hope this is the information you were looking for *
//**************************************************************************


#include <iostream>
using namespace std;
int main()

{
// Setting the Variables
    double number;
    int digits;
    double product;
    int ones, tens, hundreds, thousands, tenthousands;
    
// Introduction and Input
    cout << "Welcome to assignment 1!" << endl;
    cout << "This program will analyze a number between 1-10000" << endl;
    cout << "Input your number: ";
    cin >> number;
    cout << endl;
   
// Testing if value is in set range of 0-10000
    if (number >= 0)
    {
    if (number <= 10000)
    {
    cout << "Your number is: " << number << endl;
    
// Assigning Values for each digit
    tenthousands = number/10000;
    thousands = (static_cast<int>(number) % 10000) / 1000;
    hundreds = (static_cast<int>(number) % 1000) / 100;
    tens = (static_cast<int>(number) % 100) / 10;
    ones = (static_cast<int>(number) % 10);
    
// Setting the number of digits and calculating the product.
    if (number==10000)
        {digits = 5;
        product = tenthousands*thousands*hundreds*tens*ones;}
    else if (number >= 1000)
        {digits = 4;
        product = thousands*hundreds*tens*ones;}
    else if (number >= 100)
        {digits = 3;
        product = hundreds*tens*ones;}
    else if (number >= 10)
        {digits = 2;
        product = tens*ones;}
    else if (number >=0)
        {digits = 1;
        product = ones;}
        
        /* product must be calculated in this step because you can only multiply values that occur in the number.  Variables for higher places than the number set to zero so that will change product to zero when the actual digits multiply to a value*/
 
// Output of information
    cout << endl;
    cout << "Number of digits: " << digits << endl;
    cout << "Sum of digits: " << tenthousands+thousands+hundreds+tens+ones << endl;
    cout << "Average of digits: " << (tenthousands+thousands+hundreds+tens+ones)/static_cast<double>(digits) << endl;
    cout << "Product of digits: " << product << endl;
    cout << endl;
    }
    
    
// Else for values input not in range of 0-10000
    else
        cout << "Sorry, that number is not in the set range" << endl;
}
    else
        cout << "Sorry, that number is not in the set range" << endl;
    return 0;
}
