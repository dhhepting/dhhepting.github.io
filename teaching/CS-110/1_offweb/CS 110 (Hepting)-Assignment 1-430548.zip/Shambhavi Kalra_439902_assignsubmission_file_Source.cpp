#include <iostream>
using namespace std;
/*********************************
Student name: Shambhavi Kalra
Student number:200336705
Assignment number: 1
Program name: Integer Number Fun
Date written: 1.27.2015

Problem statement: a program that reads an integer between 0 and 10000 and then calculates and displays
(from the integer that has been read):
-the number of digits
-the sum of all the digits
-the average of all the digits
-the product of all of the digits

Input:	-From user's keyboard: a number

Output:	
		Printed onto screen:	
							-the number of digits
							-the sum of all the digits
							-the average of all the digits
							-the product of all of the digits
Algorithm:
Program stores space for integer variables

Program prompts user to enter a number

User enters a number.

We can restrict the number to be [0,10000] That way there are 5 digits.
We can split up the digigts and store space for each naming them d1,d2,d3,d4,d5.
To obtain each digit, we can divide the number by each place value the digit belongs to, 
and then obtain the remainder when dividing by 10.
This way if each digit is greater than or equal to 0, we know there is a digit there, and 
we can find the total amount of digits.
		- There always be at least 1 digit.

We can also obtain the product of the digits, by multiplying the values of the digits with each other.
	We know if there is a digit there by using the same if statements.

The average is then calculated by dividing the sum of digits, by the number of the digits.

All this information is then printed.

Major variables: 

	number (The number the user will input from their keyboard)
	d1, d2, d3, d4, d5 (The digits in the 1s, 10s, 100s, 1000s and 10000s place of the number)
	sum (The sum of all the digis in the number)
	product (The product of a all the digits in the number)
	faverage (The average as a float number, because as an integer it will not show fractional parts)
Assumptions: -user will use integer numbers.
Program limitations:-If a user chooses a number not within the specified range they have to start over.
					-Program only works if the user enters an integer value.







*********************************/

int main()


{

	int number, sum, product, d1, d2, d3, d4, d5; //storing space for the major variables
	

	cout << " Please enter a number between 0 and 10,000" << endl; //prompt user for input

	cin >> number; //user enters number

	d1 = (number / 1) % 10; // d1 is the number divided by 1, and then take the remainder of the number. To get the digit in the 1s place
	d2 = (number / 10) % 10; // to get d2, the digits in the 10 place
	d3 = (number / 100) % 10; // to get d3 the digit in the 100s place
	d4 = (number / 1000) % 10; //to get d4 the digit in the 1000s place
	d5 = (number / 10000) % 10; //to get d5 the digit in the 10000s place

	if (number >= 0)//number must be at least 0 or greater than 0.
	{ 
		if (number <= 10000)//number must also be 10000 or less than 10000.

		{
			if (d1 >= 0) // there will always be at least 1 digit.
				number = 1; //number of digits is 1. there will always be at least one digit for [0,1000]
				product = d1; //the product is just the value of the first digit.
			if (d2 > 0) 
			{
				number = 2; //there are 2 digits
				product = d1*d2; 
			}

			if (d3 > 0)
			{
				number = 3; //there are 3 digits
				product = d1*d2*d3;
			}
			if (d4 > 0)
			{
				number = 4; //there are 4 digits
				product = d1*d2*d3*d4;
			}
			if (d5 > 0)
			{
				number = 5; //there are 5 digits
				product = d1*d2*d3*d4*d5;
			}

			cout << "Your number has " << number << " digits." << endl;

			sum = d1 + d2 + d3 + d4 + d5; //the sum of the digits in the number.
			cout << "The sum of the digits in your number is " << sum << endl;

			float faverage = static_cast<float>(sum) / number; //have to convert average to a float value

			
			cout << "The average of the digits in your number is " << faverage << endl;

			cout << "The product of the digits in your number is " << product << endl;

			return 0;
		}

		
		else //if the value is greater than 10000.
			cout << "Please enter a value less than 10000." << endl;
		return 0;
	}

	else //if the value is less than 0.
		cout << "Please enter a value greater than 0." << endl;
	return 0;


}
