#include <iostream>
using namespace std;
int main()
{
	//Introduces a variable for the number the user will be asked to input. 
	int Number;

	//Prompts user to enter number.
	cout << "Please enter a number between 0 and 10000." << endl;
	cin >> Number;

	//Introduces variables for the digits, and for the number of digits.
	int digit1 = 0;
	int digit2 = 0;
	int digit3 = 0;
	int digit4 = 0;
	int NumOfDigits;

	//Defines each digit as per the input number.
	digit1 = (Number / 1) % 10;
	digit2 = (Number / 10) % 10;
	digit3 = (Number / 100) % 10;
	digit4 = (Number / 1000) % 10;

	//Defines the number of digits (not counting leading zeros) as per the 
	//input number; rejects inappropriate numbers
	if (Number > 0)
	{
		if (Number < 10000)
		{
			if (digit1 > 0)
			{
				NumOfDigits = 1;
			}
			if (digit2 > 0)
			{
				NumOfDigits = 2;
			}
			if (digit3 > 0)
			{
				NumOfDigits = 3;
			}
			if (digit4 > 0)
			{
				NumOfDigits = 4;
			}

			cout << "The number of digits is " << NumOfDigits << "." << endl;





			//Sums all of the digits in the number.

			//Introduces a variable for the sum of digits.
			int SumDigits;

			//Defines the sum of digits as per the input number.        
			SumDigits = digit1 + digit2 + digit3 + digit4;

			cout << "The sum of the digits is " << SumDigits << "." << endl;




			//Computes the average of the digits in the number.

			//Introduces a variable for the average of the digits.
			int AverageOfDigits;

			//Defines the average of digits variable as per the input number.
			if (NumOfDigits == 1)
			{
				AverageOfDigits = digit1;
			}
			if (NumOfDigits == 2)
			{
				AverageOfDigits = (digit1 + digit2) / 2;
			}
			if (NumOfDigits == 3)
			{
				AverageOfDigits = (digit1 + digit2 + digit3) / 3;
			}
			if (NumOfDigits == 4)
			{
				AverageOfDigits = (digit1 + digit2 + digit3 + digit4) / 4;
			}

			cout << "The average of the digits is " << AverageOfDigits << "." << endl;




			//Computes the product of the digits in the number.

			//Introduces a variable for the product of the digits.
			int ProductDigits;

			//Defines the variable for the product of the digits as per the input number.
			if (NumOfDigits == 1)
			{
				ProductDigits = digit1;
			}
			if (NumOfDigits == 2)
			{
				ProductDigits = digit1*digit2;
			}
			if (NumOfDigits == 3)
			{
				ProductDigits = digit1*digit2*digit3;
			}
			if (NumOfDigits == 4)
			{
				ProductDigits = digit1*digit2*digit3*digit4;
			}

			cout << "The product of the digits is " << ProductDigits << "." << endl;

		}       //Closing the if (number >= 10000) bracket; rejecting numbers which are too high.
		else
		{
			cout << "That number is equal to or greater than 10000, and thus does not satisfy the criteria." << endl;
		}
	}           //Closing the if (number <= 0) bracket; rejecting numbers which are too low.
	else
	{
		cout << "That number is equal to or less than 0, and thus does not satisfy the criteria." << endl;
	}

	return 0;
}
