

#include <iostream>
using namespace std;
int main ()

{
    int number;
    int int1 = 0;
    int int2 = 0;
    int int3 = 0;
    int int4 = 0;
    int int5 = 0;
    int numdig;
    int product;
    int sum;
    int average;
    
    cout << "Enter a number between 1 and 10000" << endl;
    cin >> number;
    
    int1 = number%10;         // declares each integer
    number /= 10;
    
    int2 = number %10;
    number /= 10;
    
    int3 = number%10;
    number /= 10;
    
    int4 = number%10;
    number /= 10;
    
    int5 = number%10;
    number /=10;

    if (int1 > 0)             // counting integers
        numdig = 1;           // product of the integer
        product = int1;       // sum of the integers
        sum = int1;           // average of the integers
        average = int1;
    if (int2 > 0)
        numdig = 2;
        product = int1 * int2;
        sum = int1 + int2;
        average = (int1 + int2) / 2;
    if (int3 > 0)
        numdig = 3;
        product = int1 * int2 * int3;
        sum = int1 + int2 + int3;
        average = (int1 + int2 + int3) / 3;
    if (int4 > 0)
        numdig = 4;
        product = int1 * int2 * int3 * int4;
        sum = int1 + int2 + int3 + int4;
        average = (int1 + int2 + int3 + int4) / 4;
    
    if (int5 > 0)
        numdig = 5;
        product = int1 * int2 * int3 * int4 * int5;
        sum = int1 + int2 + int3 + int4 + int5;
        average = (int1 + int2 + int3 + int4 + int5) / 5;
        
    cout << "The number of digits: " << numdig << endl;
    cout << "The sum of the digits: " << sum << endl;
    cout << "The product of the digits: " << product;
    cout << "The average of the digits: " << average;
    
    return 0;
}

