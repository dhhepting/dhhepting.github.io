#include <iostream>
#include <iomanip>
using namespace std;

int main()
{ int number;
  int digit1 = 0;
  int digit2 = 0;
  int digit3 = 0;
  int digit4 = 0;
  int digit5 = 0;
  int numberdigits; 
  float sum;
  float average;
  int product; 

  cout << "Please enter a number between 0 and 10000 ";
  cin >> number;

  if (number < 0)
  {
      cout << " Too small " << endl;
  }
  if (number > 10000)
  {
	  cout << " Too Big " << endl;
  }
	  cout << " That is right " << endl;
	   
digit1 = number %10;
number /= 10;
digit2 = number %10;
number /=10;
digit3 = number %10;
number /=10;
digit4 = number %10;
number /=10;
digit5 = number %10;
number /=10;

if (digit1 > 0)
	{
	numberdigits = 1;
	}
if (digit2 > 0)
	{ 
	numberdigits = 2;
	}
if (digit3 > 0)
	{
	numberdigits = 3;
	}
if (digit4 > 0)
	{
	numberdigits = 4;
	}
if (digit5 > 0)
	{
	numberdigits = 5;
	}

	// finding the sum

sum = digit1 + digit2 + digit3 + digit4 + digit5;

	//finding the average

average = sum/numberdigits;

	// finding the product 

if (numberdigits == 1)
	{
	product = digit1;
	} 
if (numberdigits  == 2)
	{ 
	product = digit1*digit2;
	}
if (numberdigits == 3)
	{ 
	product = digit1*digit2*digit3;
	}
if (numberdigits == 4)
	{ 
	product = digit1*digit2*digit3*digit4;
	}
if (numberdigits ==5)
	{
	product = digit1*digit2*digit3*digit4*digit5;
	}
 cout << " the number of digits is " << numberdigits << endl;
 cout << " the sum is " << sum << endl; 
 cout << " the average is " << setprecision(2) << average << endl;
 cout << " the product is " << product << endl;

 return 0;
} 
 



  

