#include <iostream>
using namespace std;
//**************************************************************************
//
// Student name: Patrick Petracek
//
// Student number: 200266402
//
// Assignment number: #1
//
// Program name: Calculating digits
//
// Date written: Feb 2, 2015
//
// Problem statement: Write a program that reads an integer between 0 and 10000 and then calculates and displays (from the integer that has been read): 
// �the number of digits
// �the sum of all the digits
// �the average of all the digits
// �the product of all of the digits
//
// Input: a number between 0 and 10000
//
// Output: the number of digits, the sum of the digits the average of the digits and the product (multiplication) of the digits.
//
// Algorithm: get input from the user to get the number (making sure the number is between 0 and 10000, if they are not then error messages will appear ),
// count the actual digits of the number and the value of each digit and display them, add the sum of each digits and display the answer, the average of the digits and display it, 
// and then the product of multiplication of each digit and displaying it.
//
// Major variables: the most important variables would be int number and digit 1-5, because the calculations will depend on these variables to give a correct answer.
//
// Assumptions: Will show the digits, the number of digits, the sum of the digits, the average and the product of multiplication of the digits.
//
// Program limitations: Will not show numbers higher then 10,000 and less then 0.
//
//**************************************************************************
int main()
{
	for (;;) // loops the program
	{
		int number;
		cout << " Enter a number between 0 and 10000." << endl;
		cin >> number;
		int digit1 = 0;
		int digit2 = 0;
		int digit3 = 0;
		int digit4 = 0;
		int digit5 = 0;
		int digits;
		digit1 = (number / 1) % 10;
		digit2 = (number / 10) % 10;
		digit3 = (number / 100) % 10;
		digit4 = (number / 1000) % 10;
		digit5 = (number / 10000) % 10;
		int product;

		if (number >= 0)
		{
			if (number <= 10000)
			{


				cout << "Digits: " << digit5 << " , ";
				cout << digit4 << " , " << digit3 << " , ";
				cout << digit2 << " , " << digit1 << endl;

				if (digit1 >= 0) // displays the number of digits
				{
					digits = 1;
					if (digit2 > 0)
					{
						digits = 2;

						if (digit3 > 0)
						{
							digits = 3;

							if (digit4 > 0)
							{
								digits = 4;

								if (digit5 > 0)
								{
									digits = 5;

								}
							}
						}
					}
				}

			}
			else
			{
				cout << "Too big." << endl;
			}
		}
		else
		{
			cout << "Too small." << endl;
		}


		if (number >= 0)
		{
			if (number <= 10000)
			{

			cout << "The number of digits is: " << digits << endl;
		
		int sum = digit1 + digit2 + digit3 + digit4 + digit5; // adds all the digits together.
			cout << "The sum of the digits is: " << sum << endl;

		int average = sum / digits; // averages the sum of the digits with how many digits there are.
			cout << "The average of the digits is: " << average << endl;
		
		if (digit1 >= 0) // starts the process for the multiplication of the digits
		{
			product = digit1;
			if (digit2 > 0)
			{
				product = digit1 * digit2;
				if (digit3 > 0)
				{
					product = digit1 * digit2 * digit3;
					if (digit4 > 0)
					{
						product = digit1 * digit2 * digit3 * digit4;
						if (digit5 > 0)
						{
							product = digit1 * digit2 * digit3 * digit4 * digit5;
						}
					}
				}
			}
		}

		cout << "The Products of the digits is: " << product << endl;
		}
			else
				{
				cout << "Too big." << endl;
				}
		}
		else
			{
			cout << "Too small." << endl;
			}
		}
	return 0;
}
