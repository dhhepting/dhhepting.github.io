//******************************************************************
//
//Student name: Ronglian Wang
//
//Student number: 200269662
//
//Assignment number: 5
//
//Program name: calculating numbers 
//
//Date written: 2015-04-8
//
//Problem statement:  Checking the numbers
//
//Input: reading numbers from a file
//
//Output: the max,min,mode,mean
//
//Algorithm: array
//
//Major variables: 
//
//Assumptions: 
//
//Program limitations: 
//
//*********************************************************************




#include <iostream>
#include <fstream>

using namespace std;

int main()
{
	ifstream input("data.txt");
	int dataarray[20];
	int max, min, sum = 0, temp, count = 1, m = 0, mod;
	float ave, med;
	for (int i = 0; i < 20; i++)
	{
		input >> dataarray[i];
	}
	for (int j = 0; j < 20; j++)
	{
		for (int k = 0; k < 20; k++)
			if (dataarray[j] < dataarray[k])
			{
			}
			else
			{
				temp = dataarray[j];
				dataarray[j] = dataarray[k];
				dataarray[k] = temp;
			}
	}

	for (int i = 0; i < 20; i++)
	{
		sum += dataarray[i];
	}
	ave = sum*1.0 / 20;
	med = (dataarray[5] + dataarray[6])*1.0 / 2;
	max = dataarray[0];
	min = dataarray[19];
	for (int i = 0; i < 20; i++)
	{
		if (dataarray[i] == dataarray[i + 1])
		{
			if (count > m)
			{
				count++;
				m = count;
				mod = dataarray[i];
			}
			else
				count = 1;
		}
	}
	cout << "Minimum = " << min << endl;
	cout << "Maximum= " << max << endl;
	cout << "Mean = " << ave << endl;
	cout << "Median = " << med << endl;
	cout << "Mode = " << mod << endl;


	return 0;

	/* not able to upload the data.txt file

	1
	2
	3
	3
	5
	6
	7
	8
	9
	10
	11
	12
	13
	14
	15
	16
	17
	18
	19
	
	
	*/

}