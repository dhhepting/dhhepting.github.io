﻿/*
 Kyle Hungle
 200354270
 April 10/15
 Assignment #5
 Question
 Write a program to read up to 20 integers from a file and store the integers in an array of integer type. With the values in the array, compute and display the following:
•minimum: smallest value in the array
•maximum: largest value in the array
•mean: average of all values in the array
•median: the value in the middle of the array once all values have been sorted. If there is no single index at the middle of the array, average the values in the 2 adjacent spots. For example: if the array has 3 values (with indices 0,1,2), once the array is sorted the median will be at index 1. If the array has 4 values (with indices 0,1,2,3), once the array is sorted the median will be the average of the values at indices 2 and 3.
•mode: find the value in the array which occurs most often. A straightforward approach is possible once the array is sorted.
 Use a function for each computation/output specified above. You will also need to include a sort function: see Listing 7.11 from the text
 */
 #include <iostream>
#include <fstream>
using namespace std;

void Max(double[], int); //function to calculate the Max value

void Min( double[], int); // function to calculate the Min value

void Average (double[], int); // function to calculate the Average

void Median(double[], int); // function to calculate the Median

void Mode(double[], int); // function to calculate the Mode

int main()
 {
	ifstream indata;
	indata.open("input.txt"); //opens the desired text file
	if (!indata)  //makes sure the file opens if it doesnt tells the user it couldn't open it and ends the program
	{
		cout << "Could not open file " << endl;
		return 1;
	}

	int numentered; // variable to count how many numbers are entered
	double numbers[20]; // double array for all the numbers entered
	for (int i = 0; i < 20; i++) // loop to get the input from the text file
	{
		indata >> numbers[i];
		if (indata.eof()) //if the textfile runs out of numbers it assigns the i value plus one to the variable numentered and ends the loop
		{
			numentered = i+1;
			break;
		}
	}

	for (int i = 0; i < numentered; i++) // for loop
	{

	double currentMin = numbers[i]; // sets the current min variable to equal the value that corresponds to numbers[i]
	int currentMinIndex = i; // sets current min to equal i
	for (int j = i + 1; j < numentered; j++) // for loop
	{
		if (currentMin > numbers[j]) // if statement to check if the currentmin is greater than the current number
		{
			currentMin = numbers[j];
			currentMinIndex = j;
		}
	}
	if (currentMinIndex != i) // if statemtent to check if current in is not equal to i
	{
		numbers[currentMinIndex] = numbers[i];
		numbers[i] = currentMin;
	}
	}

	Max(numbers, numentered); //calls the Max function

	Min(numbers, numentered); //calls the Min function

	Average(numbers, numentered); //calls the Average function
	
	Median(numbers, numentered); //calls the Median function
	
	Mode(numbers, numentered); //calls the Mode function

	return 0;
 }
  
void Max (double Numberarray[], int x)
{
	double max = Numberarray[0]; //sets the max to the first value in the array
	for (int i = 0; i < x; i++) //loop to go through all the values in the array
	{
		if (Numberarray[i] > max) // if statement to see if the current number is greater than max
		{
			max = Numberarray[i]; // assigns the current value to max
		}	
	}
	cout << "The max is: " << max << endl; // displays the max
}

void Min (double Numberarray[], int x)
{
	double min = Numberarray[0]; // sets the min to be the first number in the array
	for (int i =0; i < x; i ++) // for loop to go through all values of the array
	{
		
		if (Numberarray[i] < min ) //checks the see if the current number is less than the min
		{
			min = Numberarray[i]; // sets the min to equal the current number
		}
	}

	cout << "The min is: " << min << endl; // displays the min
}

void Average (double Numberarray[], int x)
{
	double sum = 0; // double variable for the sum
	double average; // double variable for the average
	for (int i = 0; i < x; i++) // for loop to go through all the values in the array
	{
	 sum += Numberarray[i]; // adds each value in the array to sum
	}
 average = sum / x; // assigns average to the sum dived by x which is the number of numbers entered

	cout << "Mean: " << average << endl; //displays the average or "mean"
}

void Median(double Numberarray[], int x)
{
	double median; // variable for the median
	if (x % 2 == 0) // if statement to see if x which is the number of numbers enter % 2 is 0 meaning x is a even number if it is 0 goes through the rest of the statement
	{
		median = (Numberarray[x / 2] + Numberarray[(x - 1) / 2 ]) / 2; //sets median to be the average of the middle two numbers in the array
		cout << "The median is: " << median << endl; //displays the median
		
	}
	if (x % 2 == 1) // if statement to see if x which is the number of numbers enter % 2 is 1 mean x is an odd number, if it is 1 goes through the rest of the statement
	{
		median = Numberarray[x / 2]; //sets the median to be the middle number in the array
		cout << "The median is: " << median << endl; //displays the median
		
	}

}

void Mode(double Numberarray[], int x)
{	
	int count = 1; //count varibale assigned a value of 1
	double MAX = 0; //max variable assigned avalue of 0
	double mode = Numberarray[0]; // double mode variable originally assigned the value of the first number in the array
	for (int i = 0; i < x; i++) // for loop to go through all the values of the array
	{
		if (Numberarray[i] == Numberarray[i + 1]) // checks to see if the current number is equal to the next number
		{
			count++; // adds one to the counter
		if (count > MAX) // if the counter is greater than max
		{
		MAX = count; // max equals the counter
		mode = Numberarray[i]; // mode equals the current number in the array
		}
		}
		else // else statement if the if statement is not true
		{
			count = 1; // resets the counter to equal 1
		}

	}
	cout << "Mode: " << mode << endl;  // displays the mode

}