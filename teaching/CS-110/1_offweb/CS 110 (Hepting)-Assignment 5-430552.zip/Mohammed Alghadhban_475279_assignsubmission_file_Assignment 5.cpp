/**********************************************************************************************
*	Student Name:			Mohammed Alghadhban
*	Student Number:			200318904
*	Assignment Number:		5
*	Program Name:			Assignment5
*	Date Written:			April 10, 2015
*
*	Problem Statement:		The program takes reads up to 20 integers from a file, and finds
*							the following:
*								- Max value
*								- Min value
*								- Mean value
*								- Mode value
*								- Median value
*
*	Input:					File "inputvalues.txt" with integer numbers
*
*	Output:					Displays:
*								- Max value
*								- Min value
*								- Mean value
*								- Mode value
*								- Median value
*
*	Algorithm:				The pre-processing step for finding min, max, mode and median
*							values is the bubblesort sorting algorithm. Once the values are
*							in ascending order:
*								- Max value: Last value in the sorted array of integers
*								- Min value: First value in the sorted array of integers
*								- Mean value: Average value of the sorted array of integers
*								- Mode value: The most frequently occurring value in the 
*								              sorted array of integers
*								- Median value: Middle value in the sorted array of integers
*
*	Major variables:		intarray:
*								integer array to hold the values read from the file
*							count:
*								number of values read from the file
*
*	Assumptions:			none
*
*	Program limitations:	none
*
**********************************************************************************************/

#include <iostream>
#include <fstream>

using namespace std;

void bubbleSort(int [], int);
int findMin(int [], int);
int findMax(int [], int);
int findMode(int [], int);
double findMedian(int[], int);
double findMean(int [], int);

int main()
{
	// Input stream to read data from file
	ifstream inFile;
	inFile.open("inputvalues.txt");

	// Check if input file opened successfully
	if (!inFile.is_open())
	{
		cout << "Could not open the data file";
		return 0;
	}

	// Variable definitions
	int count = 0;
	int intarray[20] = { 0 };

	// Read data from the input file, max 20 values
	while (count < 20)
	{
		// Break the loop if end of file is reached
		if (inFile.eof()) break;

		// Read values into intarray and increment count
		inFile >> intarray[count];
		count++;
	}

	// Compute and display all the metrics
	cout << "Minimum Value: " << findMin(intarray, count) << endl;
	cout << "Maximum Value: " << findMax(intarray, count) << endl;
	cout << "Mean Value: " << findMean(intarray, count) << endl;
	cout << "Median Value: " << findMedian(intarray, count) << endl;
	cout << "Mode Value: " << findMode(intarray, count) << endl;

	return 0;
}

// Bubble sort algorithm
void bubbleSort(int intarray[], int len)
{
	// sorted flag
	bool swaped;

	// Start loop
	do {
		// Set sorted flag to false
		swaped = false;

		// Traverse the array of integers
		for (int i = 1; i < len; i++)
		{
			// if current value is bigger than the
			// next value, swap then and set sorted
			// flag to true
			if (intarray[i-1] > intarray[i])
			{
				int temp = intarray[i];
				intarray[i] = intarray[i-1];
				intarray[i-1] = temp;

				swaped = true;
			}
		}

	} while (swaped == true); // Read as long as values are swaped

}

int findMin(int intarray[], int len)
{
	// Sort values in ascending order
	bubbleSort(intarray, len);

	// Min value is the first value of the sorted array
	return intarray[0];
}

int findMax(int intarray[], int len)
{
	// Sort values in ascending order
	bubbleSort(intarray, len);

	// Max value is the last value of the sorted array
	return intarray[len-1];
}

int findMode(int intarray[], int len)
{
	// Sort values in ascending order
	bubbleSort(intarray, len);
	
	int mode = 0;
	int freq = 0;
	int prevfreq = 0;

	// Traverse the array of integers
	for (int i = 0; i < len - 1; i++)
	{
		// If subsequent values are the same
		if (intarray[i] == intarray[i + 1])
		{
			// Increment the frequency counter
			freq++;

			// if current number occurs more times than
			// the last most frequent number, set mode
			// to the current number
			if (freq > prevfreq)
			{
				mode = intarray[i];
				prevfreq = freq;
			}
		}

		// Reset counter if values change
		else
		{
			freq = 0;
		}
	}

	return mode;
}

double findMean(int intarray[], int len)
{
	// Declare and initialize sum variable as 0
	int sum = 0;

	// Traverse the array of integers
	for (int i = 0; i < len - 1; i++)
	{
		// Accumulate the sum
		sum += intarray[i];
	}

	// return the mean
	return static_cast<double>(sum) / len;
}

double findMedian(int intarray[], int len)
{
	// Sort values in ascending order
	bubbleSort(intarray, len);

	// Set idx to half the length of intarray
	int idx = static_cast<double>(len) / 2.00;

	// if length is even reurn the average of the middle two values
	if (len % 2 == 0)
	{
		return (intarray[idx] + intarray[idx + 1]) / static_cast<double>(2);
	}

	// If length is odd, return the middle value
	else
	{
		return intarray[idx + 1];
	}
}