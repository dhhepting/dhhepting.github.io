/*****************


Student name: Shambhavi Kalra
Student number:200336705
Assignment number: 5
Program name: Array Sorter
Date written: 4.10.2015

Problem statement: a program that calculates average, mode, median, min and max from an input file array list up to 20 numbers.


Input:	from text file list of numbers.
Output:	
		Printed onto screen:	
							-min
							-max
							-average
							-mode
Algorithm:
input from text file. up to 20 numbers
calculates Max, and uses same method but reverse inequality signs for Min by using for loops and storing in a temp variable.
calculates average by dividing the sum of numbers in array by the length of the array.
calculates median.
calculates mode. 



Major variables: 

	array list
	for loops
	temp values
	
Assumptions: -
Program limitations: -






*********************************/




#include <iostream>
#include <cstring>
#include <cstddef>
#include <fstream>
#include <string>

using namespace std;

void SwapValues(float[], int, int);
//maybe put max value function
void SelSort(float[], int);
//maybe print function
int Mode(const string [], int, string);
float min(float []);
float max(float []);
float ave(float[]);
float median(float []);



int main()
{
	ifstream indata;
	ofstream outdata;
	indata.open("numbers.txt");
	float list[20] = {};
//	int a = 0; // used for SelSort function? I'm not sure what SelSort does. I think it is to place in ascending order.
//	int one;
//	int two;
//	SwapValues(list[], one, two); //call swapvalues
	//maybe call max value function
//	SelSort(list[],a);
	float min(list[20]);
	float max(list[20]);
	float ave(list[20]);
	
	
	
}


float min(float list[20]){
	
	float temp=1;
	for (int i=1; i<19; i++){
			
		if (list[i]<=temp)
		temp=list[i];
		
	}
	return temp;
}

float max(float list[20]){
	
	float temp=0;
	for (int i=1; i<19; i++){
			
		if (list[i]>=temp)
		temp=list[i];
		
	}
	return temp;
}

float ave(float list[20]){
	
	float temp=0;
	for (int i=1; i<19;i++){
		temp= list[i]+temp;
	}
	return (temp/(list.size()));
}

float median(float list[20]){
	float temp=0;
	float temp1=0;
	if( strlen(list)%2==0){
		temp= list[(list.size)/2-1];
		temp1= list[strlen(list)/2+1];
		temp = temp/temp1;
	}
	else {
		temp = list[(strlen(list)+1)/2];
	}
	return temp;
}

int Mode(const string a[], int, string);
{
	
	
	
	int counter = 1;  // Counter value is 1
    int max = 0; // used to determine which number occurs the most, starts at 0
    int mode = a[0]; // this starts the mode at the first position in the array. My array is named a[]
    for (int i = 0; i < MAX_ARRAY - 1; i++) // use a variable i to run a loop through the length of the array
    {
        if ( a[i] == a[i+1] ) //<b>The counter will only be incremented if there is a mode in the function</b>
        {
            counter++;
            if ( counter > max ) // <strong>This is still part of the if ( a[i] == a[i+1] ), so if there is no mode, this part of the code will be skipped</strong>
            {
                max = counter; // <strong>Max will only be changed if there is a mode in the function, if there is no mode, max is still 0</strong>
                mode = a[i]; // <strong>This part of the code is irrelevant and isn't necessary because of below code</strong>
            }
        } 
	else
            counter = 1; // <b>This will reset the counter </b>
    }
cout << "The mode(s) is/are : " ; // prints out mode
    for (int i = 0; i < MAX_ARRAY; i++)
    {
        if (max < 1)// <strong>If there is no mode, max will equal zero, and this statement will be executed</strong>
        {
            cout << "NO MODE"; // will print out NO MODE if all numbers occur only once
            break; // need to break out of loop so NO MODE doesn't print MAX_ARRAY # of times
        }
    else if (a[i] == a[i+max-1]) // if the array position + the value of max (number of times mode occured) - 1 is equal to the a[i]
         cout << a[i] << " "; // prints out number because it is one of the modes
	
	
	
	
	
}
}
