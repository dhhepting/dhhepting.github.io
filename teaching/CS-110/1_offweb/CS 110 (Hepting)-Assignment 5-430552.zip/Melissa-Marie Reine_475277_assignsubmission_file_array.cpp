
#include<iostream>
#include<algorithm>

using namespace std;


void MINMAX(int[],int);
void MEAN(int[], int);
void MEDIAN(int[],int);
void MODE(int[], int);


int main()
{
	//Declare variables
	const int size = 20;
	int numval;

	//Input array size

		cout << "Please enter the number of integers you would like to input (maximum of 20)" << endl;
		cin >> numval;			

	//Validate array size
		if (numval < 0 || numval > 20)
		{
			do
			{
				cout << "Invalid input. Please enter the number of integers you would like to input (maximum of 20)" << endl;
				cin >> numval;
			} while (numval < 0 || numval > 20);
		}

	//If number of desired integers does not equal zero, input integers
		if (numval != 0)
		{
			cout << "Please enter an integer." << endl;

			int value[size];
			for (int i = 0; i < numval; i++)
				cin >> value[i];

	//Sort array
			sort(value, value + numval);

	//Call functions
			MINMAX(value, numval);
			MEAN(value, numval);
			MEDIAN(value, numval);
			MODE(value, numval);
		}
}

//Function to determine minimum and maximum values of the array
void MINMAX(int value[],int numval)
{
	cout << "The minimum value is: " << value[0] << endl;
	cout << "The maximum value is: " << value[numval - 1] << endl;
}

void MEAN(int value[], int numval)
{
	float avg;
	int sum=0;

	for (int i = 0; i < numval; i++)
		sum = sum + value[i];

	avg = float(sum) / numval;

	cout << "The mean is: " << avg << endl;
}

void MEDIAN(int value[], int numval)
{
	float med;

	if (numval % 2 == 0)
		med = (float(value[(numval - 1) / 2]) + float(value[((numval - 1) / 2) + 1]))/2;
	else
		med = value[numval / 2];

	cout << "The median value is: " << med << endl;
}

void MODE(int value[], int numval)
{
	int mode[20];
	int count = 1;
	int maxcount = 1;
	int j;

	for (int i = 0; i < numval; i++)
		if (value[i] == value[i + 1])
		{
			count++;
			if (count > maxcount)
			{
				maxcount = count;
				j = 0;
				mode[j] = value[i];
			}
			else if (count == maxcount)
			{
				mode[j] = value[i];
				j++;
			}
		
		}

	if (maxcount == 1)
	{
		cout << "There is no mode" << endl;
	}
	else if (maxcount>1 && j == 1)
	{
		cout << "The mode is: " << mode[0] << endl;
	}
	else
	{
		cout << "The modes are: ";
		for (int k = 0; k < j; k++)
			cout << mode[k];
	}
}