// Name: Renee Lavoy
// SID: 200336240
// Assignment: #5
// Program Name: The Five M's
// Date Written: April 6, 2015
// Problem Statement: calculate the minimum, maximum, mean, median, and mode of an array with up to 20 values
// Input: 20 values for the array
// Output: the minimum, maximum, mean, sorted array, median, and mode of the initially inputted array
// Algorithm: using integer and void funcitons to be called into the main function
// Major Variables: arrayA - arrayG in extra functions, array1 in main function
// Assumptions: that there are always 20 values entered in the array
// Problem Limitations: confused on how to read the values out of the array when they are not entered by the user, this program does not do that

#include <iostream>
using namespace std;

//function headers here
int MIN(int arrayA[]);
int MAX(int arrayB[]);
int MEAN(int arrayC[]);
void SORT(int arrayD[], int size);
void SORTED(int arrayE[], int arraySize);
int MEDIAN(int arrayF[]);
int MODE(int arrayG[]);

int main()
{
	int array1[20];
	//prompt user to enter 20 values for the array
	cout << "Enter 20 values into the array:" << endl;
	int i;
	for (i = 0; i < 20; i++)
	{
		cin >> array1[i];
	}

	//call functions here
	cout << "The minimum value in the array is: " << MIN(array1) << endl;
	cout << "The maximum value in the array is: " << MAX(array1) << endl;
	cout << "The mean value of the array is: " << MEAN(array1) << endl;

	//sort the array to compute median and mode
	SORT(array1, 20);
	cout << "Sorted, the array is as follows: ";
	SORTED(array1, 20);

	//call functions here
	cout << "The median value of the array is: " << MEDIAN(array1) << endl;
	cout << "The mode value of the array is: " << MODE(array1) << endl;

	//end of main function
	return 0;
}

//minimum function
int MIN(int arrayA[])
{
	int i;
	int minimum = arrayA[0];
	for (i = 1; i < 20; i++)
	{
		if (arrayA[i] < minimum)
			minimum = arrayA[i];
	}
	return minimum;
}

//maximum function
int MAX(int arrayB[])
{
	int i;
	int maximum = arrayB[0];
	for (i = 1; i < 20; i++)
	{
		if (arrayB[i] > maximum)
			maximum = arrayB[i];
	}
	return maximum;
}

//mean function
int MEAN(int arrayC[])
{
	int i;
	int counter = 0;
	int sum = arrayC[0];
	for (i = 0; i < 20; i++)
	{
		sum = arrayC[i] + sum;
		counter++;
	}

	int mean = sum / counter;
	return mean;
}

//sort function
void SORT(int arrayD[], int size)
{
	for (int i = 0; i < size; i++)
	{
		// Find the minimum in the list
		double currentMin = arrayD[i];
		int currentMinIndex = i;

		for (int j = i + 1; j < size; j++)
		{
			if (currentMin > arrayD[j])
			{
				currentMin = arrayD[j];
				currentMinIndex = j;
			}
		}

		// Swap list[i] with list[currentMinIndex] if necessary;
		if (currentMinIndex != i)
		{
			arrayD[currentMinIndex] = arrayD[i];
			arrayD[i] = currentMin;
		}
	}
}

//printing the sorted array
void SORTED(int arrayE[], int arraySize)
{
	for (int i = 0; i < arraySize - 1; i++)
	{
		cout << arrayE[i] << " ";
	}
	cout << endl;
}

//median function
int MEDIAN(int arrayF[])
{
	int median;
	median = (arrayF[9] + arrayF[10]) / 2;
	return median;
}

//mode function
int MODE(int arrayG[])
{
	int i;
	int counter = 0;
	int mode;
	int NumberOfValues = 0;
	
	for (i = 0; i < 20; i++)
	{
		if (arrayG[0] == arrayG[i + 1])
		{
			counter++;
			if (counter > NumberOfValues)
			{
				NumberOfValues = counter;
				mode = arrayG[i];
			}
		}
	}
	return mode;
}