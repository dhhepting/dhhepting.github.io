// Student name:Ruihao Zhao
//
// Student number: 200338484
//
// Assignment number: 5
//
// Program name: assignment5
//
// Due: April 10th, 2015
//
// Problem statement: input from a file up to 20 numbers into an array
//
// Input: up to twenty numbers from input file
//
// Output: minimum number, maximum number, mean number, median number and mode
//
// Algorithm 1: prototypes
// Algorithm 2: input
// Algorithm 3: sort
// Algorithm 4: avg
// Algorithm 5: med
// Algorithm 6: mode
// Major variables: x[],n,a[20],i,j,ave,sum,temp,mid,mode,time,m
//
// Assumptions: no more than 20 numbers
//
// Program limitations: Any number is not integer or any number is not from the file
//
//************************************************************************
#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

void sort(int[]);				// algorithm 1 start
void Min(int[]);
void Max(int[]);
void Mean(int[]);
void Med(int[]);
void Mode(int[]);			// algorithm 1 end

const int n = 20;

int main()
{

	int a[20];								// algorithm 2 start
	ifstream inData;
	inData.open("inputfromfile.txt");
	if (!inData)
	{
		cout << "Can't open the input file successfuly." << endl;
		return 1;
	}

	while (inData)
	{
		for (int i = 0; i < 20; i++)
		{
			inData >> a[i];
		}
	}										// algorithm 2 end

	sort(a);								// algorithm 3

	Min(a);									
	Max(a);
	Mean(a);								//algorithm 4
	Med(a);									//algorithm 5
	Mode(a);								//algorithm 6

	return 0;
}

void Min(int x[])
{
	cout << "smallest value is: " << x[0] << endl;
}

void Max(int x[])
{
	cout << "largest value is: " << x[n - 1] << endl;
}

void Mean(int x[])
{
	double ave;
	int sum = 0;

	for (int i = 0; i<n; i++)
		sum += x[i];
	ave = sum;
	ave /= n;

	cout << "average is: " << fixed << setprecision(2) << ave << endl;
}

void Med(int x[])
{
	int mid = n / 2;

	cout << "The value in the middle of the array once all values have been sorted is: ";
	if (n % 2 == 0 && x[mid] != x[mid - 1])
		cout << x[mid - 1] << " and ";
	cout << x[mid] << endl;
}

void Mode(int x[])
{
	int number = x[0];
	int mode = number;
	int count = 0;
	int countMode = 0;

	for (int i = 0; i < n; i++)
	{
		if (x[i] == number)
		{
			count++;
		}
		else
		{
			if (count > countMode)
			{
				countMode = count;
				mode = number;
			}
			count = 0;
			number = x[i];
		}
	}

	cout << "value which occurs most often is: " << mode << endl;
}

void sort(int a[])
{
	int minIndex = 0;
	for (int i = 0; i < n - 1; i++)
	{
		minIndex = i;
		for (int currentIndex = i + 1; currentIndex < n; currentIndex++)
		{
			if (a[currentIndex] < a[minIndex])
			{
				minIndex = currentIndex;
			}
		}
		if (minIndex != i)
		{
			int temp = a[i];
			a[i] = a[minIndex];
			a[minIndex] = temp;
		}
	}
}