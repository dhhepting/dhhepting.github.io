/****************************************************************

Name: Gerard Domingo

SID: 200356051

Assignment Number # 5

Program Name: Array Testing

Date Written: April 10th, 2015

Problem Statement: A program will get number from a text file, maximum of 20 integers. The program then proceeds to get maximum 
and minimum integers in the file and also it will get the average of the numbers. The other thing is that the program will check
the value that is in the middle of the program and the last thing it will do is that it will look at a number 
that is in consecutive order.

Input: The program will read the integers via a text file.

Ouput: The maximum value, minumum value, averages of the numbers, the most middle number, and the number that occurs mostly.

*****************************************************************/

#include<iostream>
#include<fstream>
using namespace std;

int main()
{
	int array[20];
	int counter = 0;
	int min;
	int max;
	float sum;
	
	// Opens the file with the numbers.
	ifstream indata;
	indata.open("numbers.txt");
	
	// If the program does not exist the program will exit it out.
	if(!indata)
	{
		return 1;
	}
	
	
	// Opens the file and check all the numbers present in it.
	while(!indata.eof())
	{
		indata >> array[counter];
		counter++;
	}
	
	//Prints out the numbers in the file.
	for(int i = 0; i < counter; i++)
	{
		cout << array[i] << endl;
	}
	
	cout << endl;
	
	// Checks the values for which one is the max and min values.
	for(int i = 0; i < counter; i++)
	{
		if(array[i] > max)
		{
			max = array[i];
		}
		
		if (array[i] < min)
		{
			min = array[i];
		}
	}
	
	// Adds the number together and with the value it can divide by the numbers of integers present.
	for(int i = 0; i < counter; i++)
	{
		sum += array[i];
	}
	
	cout << "The mean is: " << sum / counter << endl;
	cout << "Max is: " << max << endl;
	cout << "Min is: " << min << endl;
	
	return 0; 
}
