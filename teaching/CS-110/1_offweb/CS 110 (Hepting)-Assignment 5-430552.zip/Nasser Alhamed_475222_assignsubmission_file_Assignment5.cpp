/***************************************************

Assignemnt 5

Student name : Nasser Alhamed

Student ID : 200307983

Program name :

Date written :April 10, 2015

Problem statement :

Input : 

Output :

Algorithm : Take 20 numbers from a file and assign them to 20 arraies. After that, it give the max, min, mean, and mode.

Major variables :

Assumptions :

Program limitations:




***********************************************/

#include <iostream>
#include <fstream>

using namespace std;

//prototype function
void array(int[]);
int max(int[]);
int min(int[]);
double ave(int[]);
void selectionSort(int[], int);
double median(int[], int);
int mode(int[], int);
//main function
int main()
{
	int view;
	int w[20];
	int y;
	int x;
	double sum = 1;
	ifstream data;
	data.open("data.txt");
	int e = 0;
	while (!data.eof())
	{
		data >> w[e];
		e++;
	}
	e--;
	data.close();
	cout << " The numbers from the file: ";
	for (int i = 0; i < 20; i++)
	{
		cout << w[i] << " ";
	}
	cout << endl;
	//call or invoke the function
	x = max(w);
	cout << "The maximum " << x << endl;
	y = min(w);
	cout << "The minmum " << y << endl;
	double average = ave(w);
	cout << "The average " << average << endl;
	selectionSort(w, e);
	array(w);
	cout << "The median is: " << median(w, e) << endl;
	cout << " The mode is: " << mode(w, e) << endl;
	return 0;
}
// a Function to view the array
void array(int view[])
{
	cout << " The array: ";
	for (int i = 0; i < 20; i++)
	{
		cout << view[i] << " ";
	}
	cout << endl;

}
// Function to find out the maximum number
int max(int x[])
{
	int max = x[0];
	for (int i = 0; i < 20; i++)
	{
		if (x[i]>max)
		{
			max = x[i];
		}
	}
	return max;
}
// Function to find out the minimum number
int min(int y[])
{
	int min = y[0];
	for (int i = 0; i < 20; i++)
	{


		if (y[i] < min)
		{
			min = y[i];
		}
	}
	return min;

}
// Function to calculate the sum and the average
double ave(int w[])
{
	int sum = 0;
	double ave = 1;
	int i;
	for (i = 0; i < 20; i++)
	{
		sum += w[i];
	}
	ave = sum / 20;
	return ave;
}
// function to sort the array 
void selectionSort(int list[], int listSize)
{

	for (int i = 0; i < listSize; i++)
	{
		for (int j = i + 1; j<listSize; j++)
			if (list[j]<list[i])
			{
			int swap = list[i];
			list[i] = list[j];
			list[j] = swap;
			}

	}
}
// to find the median
double median(int  array[], int size)
{
	double median = 0;
	if (size % 2 != 0)
		median = array[size / 2];
	else
	{
		median = array[(size / 2)] + array[(size / 2) + 1];
		median = median / 2;
	}
	return median;
}
// function to find the mode
int mode(int array[], int size)
{

	int repetition[size];
	int mode = 0;
	int j = 0;
	int counter = 1;
	for (int i = 0; i<size; i++)
	{
		if (array[i] == array[i + 1])
			counter++;
		else
		{
			repetition[j] = counter;
			j++;
			counter = 1;
		}
	}
	int max = 0;
	for (int i = 0; i<size; i++)
		if (repetition[i]>max)
		{
		max = repetition[i];
		mode = array[i];
		}
	return mode;
}
// end program