//**************************************************************************
//
// Student name: Amanda Flaman
//
// Student number: 200340561
//
// Assignment number: 5
//
// Program name: Assignment5.cpp
//
// Date written: April 10/2015
//
// Problem statement:  a program that reads 20 integers from a file and
// stores them in an array of integer type. The program then sorts the values 
// and outputs the minimum value, the maximum value, the mean, the median, and
// the mode. 
//
// Input: input come from file "Values.txt"
//
// Output: Maximum value, Minimum value, Mean, median, mode
//
// Algorithm: The program first attempts to read a pre-made file. If it can do 
// so an array is declared and the values from the text file are stored in it.
// Then using functions, the program does the calculations for the desired 
// outputs. The first function reads each integer and compares the size of one 
// value to the next and determines and outputs the minimum value in the array.
// The next function does the same thing as the first but it outputs the 
// maximum value in the array. Then a void function is used to sort the values 
// in the area in ascending order, which will make it an easier task to find 
// the mean, median, and mode. Next another function calculates the mean/ finds
// the average. Another function locates the middle number in the array and 
// outputs the median. A final function then tests if values are equal to each
// other and counts how often each number appears. It then outputs the mode (the
// number that appears most frequently). Then the program is completed with 
// return 0.
// 
// Major variables: Minimum, Maximum, Mean, Median, Mode, list
//
// Assumptions: There will be 20 integers in the file
//
// Program limitations: It does not read greater then 20 integers in the file
//  and it doesn't perform the multiplication operator.
//
//**************************************************************************

#include <iostream>
#include <fstream>
using namespace std;

int Minimum(int []);
int Maximum(int []);
void SelectionSort(int[]);
float Mean(int []);
float Median(int[]);
int Mode(int[]);

int main()
{
	ifstream InData;		// This section sets the ifstream and retrieves the desired text file if it can
	InData.open("Values.txt"); 
	if (!InData)
	{
		cout << "Cannot read file" << endl;
		return 1;
	}
	int array1[20];		// This part decrlares the array and gets a value from the text file for each array number 
	for (int i = 0; i < 20; i++) 
	{
		InData >> array1[i];
	}
	
	cout << "The minimum value is " << Minimum(array1) << endl;		// this is where we just called every function and output their return values
	cout << "The maximum value is " << Maximum(array1) << endl;

	SelectionSort(array1);
	
	cout << "The mean is " << Mean(array1) << endl;
	cout << "The median is " << Median(array1) << endl;
	cout << "The mode is " << Mode(array1) << endl;

	return 0;
}

int Minimum(int list[])	//This function finds and returns the minimum value
{
	int minimum = list[0];
	for (int i = 0; i < 20; i++)
	{
		if (list[i] < minimum) //for loop checks if each array value is less than the minimum. if it is it changes it into the minimum
			minimum = list[i];
	}
	return minimum;	//returns minimum
}
int Maximum(int list[])	//This function finds and returns the maximum value
{
	int maximum = list[0];
	for (int i = 0; i < 20; i++)
	{
		if (list[i] > maximum)		//for loop checks if each array value is greater than the maximum. if it is it changes it into the maximum
			maximum = list[i];
	}
	return maximum;	//returns maximum
}
void SelectionSort(int list[])	//Similar to listing 7.11. sorts array.
{
	for (int i = 0; i < 20; i++)
	{
		int currentMin = list[i];
		int currentMinIndex = i;

		for (int j = i + 1; j < 20; j++)
		{
			if (currentMin > list[j])
			{
				currentMin = list[j];
				currentMinIndex = j;
			}
		}

		if (currentMinIndex != i)
		{
			list[currentMinIndex] = list[i];
			list[i] = currentMin;
		}
	}
}
float Mean(int list[]) //a]find average. adds up terns divides by 20.
{
	int total = 0;
	for (int i = 0; i < 20; i++)
	{
		total = total + list[i];
	}
	float mean = total / 20.0;

	return mean;
}
float Median(int list[])	//finds middle value
{
	float median = (list[9] + list[10]) / 2.0;	// even number of values so add two middle and divide by 2
	return median;
}
int Mode(int list[]) // calculates the number that appears the most. 
{
	int count = 1;
	int max = 0;
	int mode = list[0];
	for (int i = 0; i < 20; i++)
	{
		if (list[i] == list[i + 1])
		{
			count++;
			if (count > max)
			{
				max = count;
				mode = list[i];
			}
		}
		else
			count = 1;
	}
	return mode;
}