// Student Name : Cole Sanderson
//
// Student Number: 200355179
//
// Assignment Number: 5
//
// Program Name: Assignment 5 Cole Sanderson
//
// Date Written: April 10, 2015
//
// Problem Statement: Write a program to read up to 20 integers from a file and store the integers in an array of integer type. With the values in the array, compute and display the following:
//
// Input: I expect that the user will create a text file under the same name I have it labelled in the program and that he will enter 20 integers into that text file for the program to compile
//
// Output: I expect to output to the user: Max, Min, Mean, Median, and Mode after compilation.
//
// Major Variables: float numArray[20], Max(numArray), Min(numArray), Mean(numArray), Median(numArray), Mode(numArray)
//
// Assumptions: I assume that the user has worked with C++ before and also that the user is capable of entering in 20 numbers
//
// Program Limitations: This programs limitation is that the user must enter 20 integers into the text file  
//

#include <iostream>
#include <fstream> // Function header when using text files
using namespace std;

// Use of the function void and also introducing arrays to my program
void Max(float[]);
void Min(float[]);
void Mean(float[]);
void Median(float[]);
void Mode(float[]);

int main()
{
	ifstream indata;
	indata.open("numbers.txt"); // Indicating the text file name where the users 20 numbers are stored
	if (!indata)
	{
		cout << "Could not open file." << endl; // Displaying a statement to the user to indicate to them that they have incorrectly compiled the code
		return 1;
	}
	// This if statement is checking whether or not the user properly entered 20 numbers into the text file 
	float numArray[20]; // Declaring an array size of 20
	int numentered;

	for (int i = 0; i < 20; i++)
	{
		indata >> numArray[i];
	}

	// Caling each individual array as labeled above 
	Max(numArray);

	Min(numArray);

	Mean(numArray);

	Median(numArray);

	Mode(numArray);

	// This section below is sorting the numbers entered by the user so that it is easier to complete the objectives (median & mode)
	for (int i = 0; i < 20; i++)
	{
		float currentMin = numArray[i];
		int currentMinIndex = i;
		for (int j = i + 1; j < 20; j++)
		{
			if (currentMin > numArray[j])
			{
				currentMin = numArray[j];
				currentMinIndex = j;
			}
		}
		if (currentMinIndex != i)
		{
			numArray[currentMinIndex] = numArray[i];
			numArray[i] = currentMin;
		}
	}
	return 0;
}
// Below is where the process to calculate max takes place. Use of the void function allows us to output it directly in this function.
void Max(float numArray[])
{
	float Max = numArray[0];

	for (int i = 1; i < 20; i++) // Utilizing a for loop to find maximum
	{
		if (numArray[i]> Max)
		{
			Max = numArray[i];
		}
	}

	cout << "The maximum value is: " << Max << endl; // Displaying the maximum value
}
// Below is where the process to calculate min takes place. Use of the void function allows us to output it directly in this function.
void Min(float numArray[])
{
	float Min = numArray[0];
	for (int i = 1; i < 20; i++) // Utilizing a for loop to find minimum
	{
		if (numArray[i]< Min)
		{
			Min = numArray[i];
		}
	}

	cout << "The minimum value is: " << Min << endl; // Displaying the minimum value
}
// Below is where the process to calculate mean is. What calculating the means truly means is that we are finding the average.
void Mean(float numArray[])
{
	float sum = 0;
	float Mean;
	Mean = sum / 20;

	for (int i = 0; i < 20; i++) // Utilizing a for loop to find mean
	{
		sum = sum + numArray[i];
	}

	Mean = sum / 20; // Finding average

	cout << "The mean is: " << Mean << endl; // Displaying the mean value.
}
// Below is where the process to calculate median is. What calculating the median truly means is that we are finding the middle number.
void Median(float numArray[])
{
	float Median;

	Median = (numArray[9] + numArray[10]) / 2;


	int count = 1;
	int maxcount = 0;

	cout << "The median is: " << Median << endl; // Displaying the median value.
}
// Below is where the process to calculate mode is. What calculating the mode truly means is that we are finding the most frequent number.
void Mode(float numArray[])
{
	float Mode = numArray[0];
	int count = 1;
	int maxcount = 0; // Must set maxcout to 0 because or else you will have squed results

	for (int i = 0; i < 20; i++) // Utilizing a for loop to find mode
	{
		if (numArray[i] == numArray[i + 1])
		{
			count++;
			if (count > maxcount)
			{
				maxcount = count;
				Mode = numArray[i];
			}
		}
		else
		{
			count = 1;
		}
	}
	cout << "The mode is: " << Mode << endl; // Displaying the mode value.
}