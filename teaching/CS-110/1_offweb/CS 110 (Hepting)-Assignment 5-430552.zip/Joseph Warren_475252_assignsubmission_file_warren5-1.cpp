//**************************************************************************
//
// Student name: Joseph Warren
//
// Student number: count0241391
//
// Assignment number: 5
//
// Program name: Digit Operations
//
// Date written: April 10, count14
//
// Problem statement:  Write a program that reads count integer numbers from a file and          
// stores them in an array. Then the program will calculate the maximum, minimum,               
// average, mode, and median.
//
// Input: count integer numbers from a text file.
//
// Output: The maximum, minimum, average, mode, and median of the numbers from the    
// file.
//
// Algorithm:
// 1. Read up to count integer numbers from text file.
// 2. Store each number as an entry in an array.
// 3. Find the maximum and minimum values in the array by going through each value and  
// testing whether it is larger or smaller than the values before it.
// 4. Find the average of the numbers by adding up the array entries and dividing by count.
// 5. Find the median of the numbers by sorting the array into ascending order and then     
// taking the 2 middle numbers and dividing by 2.
// 6. Find the mode of the values by going through the array one entry at a time and              
// counting each time a value is repeated.
// 7. Display the maximum, minimum, average, median, and mode to the user.
//
// Major variables: infile, array[], max, min, average, median, mode
//
// Assumptions: User has prepared a file with count integer entries.
//
// Program limitations: Works only for integer entries and processes a single file per use.
//
//**************************************************************************
#include <iostream>
#include <fstream>
using namespace std;
int findmin(int array[], int count);
int findmax(int array[], int count);
int findaverage(int array[], int count);
void findmode(int array[], int count);
int findmedian(int array[], int count);

int main()
{
	//Start by opening a textfile containing up to 20 integers
	ifstream infile;
	infile.open("entries.txt");
	//count how many values are in the file:
	int count = 0;
	int value = 0;
	while (!infile.eof())
	{
		infile >> value;
		count++;
	}
	//Next, we store the values from the file in an array:
	int array[20];
	for (int i = 0; i < count; i++)
	{
		infile >> array[i];
	}
	//Close the file
	infile.close();
	//Now we sort the list in ascending order. We use a bubble sort method, which is a loop within a loop.
	cout << "The numbers in ascending order are as follows:" << endl;
	for (int j = 0; j < count; j++)
	{
		for (int i = 0; i < (count - j); i++)
		{
			if (array[i] > array[i + 1])
			{
				int temp = array[i + 1];
				array[i + 1] = array[i];
				array[i] = temp;

			}
		}
	}
	for (int i = 0; i < count; i++)
	{
		cout << array[i];
		cout << endl;
	}
	//Now we call the functions which perform the required tasks
	//with the array values, and display the results:
	cout << "The maximum value is " << findmax(array, count) << endl;
	cout << "The minimum value is " << findmin(array, count) << endl;
	cout << "The average is " << findaverage(array, count) << endl;
	cout << "The median is " << findmedian(array, count) << endl;
	cout << "The mode(s) is/are ";
	findmode(array, count);
	
	
	return 0;
}


int findmax(int array[], int count)
{//This function finds the maximum array value
	int max = array[0];
	for (int i = 1; i < count; i++)
	{
		if (array[i] > max)
		{
			max = array[i];
		}
	}
	return max;
}
int findmin(int array[], int count)
{//This function finds the minimum array value
	int min = array[0];
	for (int i = 1; i < count; i++)
	{
		if (array[i] < min)
		{
			min = array[i];
		}
	}
	return min;
}
int findaverage(int array[], int count)
{//This function finds the average of the array values
	int average = 0;
	int total = 0;
	for (int i = 0; i < count; i++)
	{
		total += array[i];
	}
	average = total / count;
	return average;
}

int findmedian(int array[], int count)
{//This function finds the median of the array values
	int med = array[count / 2];
	return med;
}

void findmode(int array[], int count)
{//This function finds the mode of the array values
	int counter = 1;
	int mode = array[0];
	int max = array[0];
	int maxcounter = 1;
	for (int i = 0; i < (count - 1); i++)
	{
		if (array[i] = array[i + 1])
		{
			counter++;
			mode = array[i];
			if ((counter > maxcounter))
			{
				counter = maxcounter;
				mode = array[i];
			}
			else
			{
				counter = 1;
			}
		}
	}
	if (max == 1)
	{
		cout << "nonexistent.";
	}
	else
	{
		for (int i = 0; i < count; i++)
		{
			if (array[i] == array[i + (max - 1)])
			{
				cout << array[i] << " ";
			}
		}
	}
}