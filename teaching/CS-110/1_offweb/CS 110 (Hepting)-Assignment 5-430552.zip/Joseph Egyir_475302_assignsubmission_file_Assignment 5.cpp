#include <iostream>
using namespace std;

int Max(int [], int);
int Min(int [], int);
int Avg(int [], int);
void Median(int [], int);
void Mode(int [], int, int);
int main()
{
	const int MAX_ARRAY = 20;

	int  a[MAX_ARRAY];
	int length;
	int  index;


	// Ask users to enter values for array a[]. 
	for (index = 0; index < MAX_ARRAY; index++)
	{

		cout << "Please input a number for the array element: ";
		cin >> a[index];
		cout << endl;
	}


	cout << endl;
	cout << endl;
	int max = Max(a, 20);
	int min = Min(a, 20);
	int avg = Avg(a, 20);

	
	cout << "Max is " << max << endl;
	cout << "Min is " << min << endl;
	Median(a, 20);
	Mode(a, max, 20);
	
	return 0;
}

	int Max(int a[], int length)
	{
		int max = a[0];     

		for (int i = 1; i <length; i++)
		{
			if (a[i] > max)
				max = a[i];
		}
		return max;                // return highest value in array
	}

	int Min(int ary[], int len)
	{
		int min = ary[0];

		for (int i = 1; i <len; i++)
		{
			if (ary[i] < min)
				min = ary[i];
		}
		return min;                // return highest value in array
	}

	int Avg(int ary[], int length)
	{
		int sum = 0;
		for (int i = 0; i < length; i++)
		{

			sum += ary[i];
		}
		int avg = sum / 20;
		  return avg;
	}

	void Median(int ary[], int length)
	{

		
		for (int j = 0; j < 19; j++)
		{
			for (int i = 0; i < 19 - j; i++)
			{
				if (ary[i] > ary[i + 1])
				{
					int temp = ary[i + 1];
					ary[i + 1] = ary[i];
					ary[i] = temp;
				}
				}
			}
			for (int i = 0; i < length; i++)
			{
				cout << ary[i] << " ";
			}
			cout << endl;
			
			int med = (ary[10] + ary[11]) / 2;
			
			cout << "The median of the array is " << med << endl;
			return;
	}

	void Mode(int a[], int b, int c)
	{
		int j = 1;
		b = 0; 
		int mode = a[0]; 
		for (int i = 0; i < c - 1; i++) 
		{
			if (a[i] == a[i + 1]) 
			{
				j++;
				if (j > b)
				{
					b = j; 
					mode = a[i]; 
				}
			}
			else
				j = 1; 
		}
		cout << "The mode(s) is/are: "; 
		for (int i = 0; i < c; i++)
		{
			if (b < 1)
			{
				cout << "There is no mode"; 
				break; 
			}
			else if (a[i] == a[i + b - 1]) 
				cout << a[i] << " "; 
		}
		return;
	}
