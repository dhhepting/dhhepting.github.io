/*
//
// Student name: Quinn Bast
// Student number: 200352973
//
// Assignment number: 5
// Program name: Max, Min, Mean, Median, Mode
// Date written: 4/6/15
//
// Problem statement: THe program must:
//
// - Read numbers from a file into an array
// - determine the maximum value
// - determine the minimum value
// - determine the average value
// - determine the value appearing the most often
// - determine the middle value
// - some tasks require an array to be sorted from lowest to greatest.
//
//
// Algorithm: Bubble sorting an array and for loops
//
// Major variables: 
//
//	number[] - holds the values from the file
//	numbers  - how many numbers there are in the file
//	min		- the min
//  max		- the max
//	mean	- the mean
//	mode	- the mode
//	median	- the median
//	sort[]	- the lowest-to-highest sorted array
// i		- loops!
//
// Assumptions:
//
// - People won't enter more than 20 values as the array only has a size of 20
//
// Program limitations:
//
// - must only be 20 values in the file
// - 
//
//
*/

#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>
using namespace std;

void minimum(int a[], int b)
{

int min = a[0]; // set minimum to first value in array
int i=0;
for(i=0; i<b; i++)
{
	if(a[i] < min)
		{
			min = a[i]; //determine if any other values are smaller than that through a loop
		}
}

cout << endl << endl;
cout << "The minimum value is: " << min;

return;
}
void maximum(int a[], int b)
{

int max = a[0]; //set maximum to the first value of the array
int i=0;
for(i=0; i<b; i++)
{
	if(a[i] > max)
		{
			max = a[i]; //determine if any number is larger than that through a loop
		}
}

cout << endl << endl;
cout << "The maximum value is: " << max << endl;

return;
}
void mean(int a[], int b)
{
float mean;
float sum = 0.0;
int i=0;

for(i=0; i<b; i++)
{
	sum += a[i]; //calculates a sum of all array values by adding them all to the sum
}
mean = (sum/b); //determines the average

cout << "The mean is: " << mean << endl;
}
void median(int a[], int b)
{

int middle;
int high;
int low;
float median;

//NOTE: My array has been sorted before this function occurs


if((b % 2) == 0) // if there are an even amount of numbers, there will be two numbers in the middle.
{
	high = ceil((b/2.0)); //finds the middle number rounded up (as it will be a decimal)
	low = (high -1);		// finds the number below that
	median = ((a[high] + a[low])*1.0/2.0);	// averages the two middle numbers to find the median
}
else if((b % 2 == 1)) // if there are an odd amount of numbers, one will sit perfectly in the middle
{
median = a[(b/2)]; //fetch the middle value
}

cout << "The median is: " << median << endl;
}
void mode(int a[], int b)
{
int often = 1;
int mostoften = 0;
int mode[20];
int num=0;
int i=0;

//NOTE: My array has been sorted.


for(i=0; i<b; i++) //b is the number of numbers in my array
{
				// a is my array of numbers
	if(a[i] == a[i+1]) //if there are two numbers that are the same
	{
	often +=1; // record them as being duplicates
	}

	if(often > mostoften && often != 1) //if this is the most often number so far and they aren't singlets
	{
	mostoften = often; // set this number to the most number of times a number has occurred
	mode[0] = a[i]; // set the first value of the mode array(0) to the number that has just occurred the most
	num = 0; // record that this is the largest value yet and thus the only value stored in the mode array by setting the maximum position of the array (mode[] to mode[0])
	}
	
	if(often = mostoften && often !=1) // if another number needs to be stored as a mode in the array because they occur the same amount of times (not singlets)
	{
	num +=1;				//increase the number of slots the mode array has (if we had mode[0], this would open up mode[1] for another mode to be stored
	mode[num-1] = a[i];		// set the newly opened postion in the array to this new number
	}
	if(a[i] != a[i+1])
		often = 1; // reset the number ot times a number has repeated itself if the next number is not the same
}


// this works because if only one number is stored, num=0 and I only need to cout << mode[0]
// if three numbers occur the same number of times, num=3 (mode[0], mode[1], and mode[2] will all have numbers that occured the same amount of times
// and thus a for(i=0; i<num; i++) (note num=3 because it has not been reset to zero) will cycle through ONLY the numbers that have occured. Thus even if we have 1, 1, 2, 2, 3, 3, 3
// the num will be reset to 0 because of the higher value of 3. Thus even though mode[1] = 2, it will not be printed out to the screen because the for
// loop (as you will see below) is limited to the variable num, or the number of numbers at their highest count.



if(num<= 1)
{
cout << "No Mode exists." << endl; //no mode exists if the numbers only appear once
}
if(num >1)
{
	for (i=0; i<num; i++) //the for loop only runs for i<num, and num is equal to each repeated value's position in the array. Thus only loops up to cout the maximum modes and nothing more
		{
		cout << "The number: " << mode[i] << " appears the most often, a total of: " << mostoften << " times." << endl;
		}
}
}

int main()
{

////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// Read numbers from a file
////////////////////////////////////////////////////////////////////////////////////////////////////////////

int number[20];
int i=0;

ifstream  in("input.txt");

int test;
while( in >> test)
	{
	number[i] = test; // take numbers from the file stream
	cout << number[i] << " ";
	i +=1;
	}
const int numbers = i;
cout << "There are: " << numbers << " numbers." << endl;

////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// Do everything else with functions
////////////////////////////////////////////////////////////////////////////////////////////////////////////

minimum(number, numbers);
maximum(number, numbers);
mean(number, numbers);
	sort(number, (number + numbers));
median(number, numbers);
mode(number, numbers);

return 0;
}

