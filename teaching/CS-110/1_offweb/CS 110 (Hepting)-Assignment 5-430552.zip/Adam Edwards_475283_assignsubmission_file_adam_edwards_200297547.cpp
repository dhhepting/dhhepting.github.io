#include <iostream>
#include <fstream>
using namespace std;

void printList(int list[], int size);
void selectionSort(int number, int size);
void calculateMaxMin(int index[], int size, int integerValues, int maxValue, int minValue);
void calculateMean(int index[], int size, int a);
void calculateMedian(int index[], int size);
void calculateMode(int i[], int size, int a, int integerValues);

int main()
{
	
	ifstream inData;						// declares input stream
	inData.open("inputfile.txt");			 // binds program variable inData to the input file "inputfile.txt"
	float integerValues[20];
	for (int i = 0; i < 19; i++)
	{
		float integerValues;
		integerValues[i];
	}
	
	cout << "The values read from the file are: " << endl;
	printList(integerValues, 20);					// print out read integers

	cout << "The values sorted: " << endl;
	selectionSort(integerValues, 20);				// print out sorted

	calculateMaxMin(integerValues, 20);

	cout << "The mean values: "; 
	calculateMean(integerValues, 20);
	cout << endl;
	
	cout << "The median is: "; 
	calculateMedian(integerValues, 20);
	cout << endl;

	calculateMode(integerValues, 20);
}


void printList(int list[], int size)
{
	for (int i = 0; i < size; i++)
	{
		cout << list[i] << endl;
	}
	return;
}

void selectionSort(int number, int size)
{
	for (int i = 0; i < size; i++)
		if (number[i] > number[i + 1])
		{
		int temp = number[i + 1];
		number[i + 1] = number[i];
		number[i] = temp;
		}
	for (int i = 0; i < size; i++)
	{
		cout << number[i] << " ";
	}
	cout << endl;
}

void calculateMaxMin(int index[], int size, int integerValues, int maxValue, int minValue)
{

	for (int i = 0; i < size; i++)
	{
		if (integerValues[index] > maxValue[index])
		{
			maxValue = integerValues[index];
		}

		if (integerValues < minValue[index])
		{
			minValue = integerValues[index];
		}

	}
	cout << "The maximum value is: " << maxValue << endl;
	cout << "The minimum value is: " << minValue << endl;
	return;
}

void calculateMean(int index[], int size, int a)
{
	int sum;
	int average;
	sum = 0;
	for (int i = 0; i < size; i++)
	{
		sum += a[index];
	}
	average = sum / 20;
	cout << average << endl;
	return;

}

void calculateMedian(int index[], int size)
{	// Sort values first
	selectionSort(index, size);
	int median;
	
	if (size % 2 = 0)
	{
		int index, secondIndex;
		index = size / 2;
		secondIndex = index - 1;
		median = (integerValues[index]) + number[secondIndex]) / 2.0;
	}
	else
	{
		int index;
		index = size / 2.0;
		median = (number[index] + number[secondIndex] / 2.0);
	}

return;
}

void calculateMode(int i[], int size, int a, int integerValues)
{
	int counter = 1;  // this will count how many times the number has occured
	int max = 0; // used to determine which number occurs the most
	int mode = a[0]; // this starts the mode at the first position in the array. My array is named a[]
	for (int i = 0; i < integerValues - 1; i++) // use a variable i to run a loop through the length of the array
	{
		if (a[i] == a[i + 1]) //if the previous number = the number next to it in the array, the counter is incremented
		{
			counter++;
			if (counter > max) // if the counter is greater than the previous max value for mode, it replaces it
			{
				max = counter; // max will replace previous counter value
				mode = a[i]; // mode is now equal to whatever a[i] is, i value will be based on what iteration of the loop is occuring
			}
		}
		else
			counter = 1; // if number occurs more than once, but doesn't occur more than the current mode it resets the counter for the loop
	}
	cout << "The mode is : "; // prints out mode
	for (int i = 0; i < integerValues; i++)
	{
		if (max < 1)// if all numbers occur only once, then no mode
		{
			cout << "NO MODE"; // will print out NO MODE if all numbers occur only once
			break; // need to break out of loop so NO MODE doesn't print MAX_ARRAY # of times
		}
		else if (a[i] == a[i + max - 1]) // if the array position + the value of max (number of times mode occured) - 1 is equal to the a[i]
			cout << a[i] << " "; // prints out number because it is one of the modes

		return;
		// Note this was modified from Piazza topic 'Assignment 5 mode'.
}