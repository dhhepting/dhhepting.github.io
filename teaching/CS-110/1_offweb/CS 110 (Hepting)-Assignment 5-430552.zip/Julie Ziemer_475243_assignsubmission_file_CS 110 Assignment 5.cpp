// PROGRAM IS INCOMPLETE!! SORRY, THERE ARE ERRORS AND IT DOES NOT WORK PROPERLY AS A RESULT.

//**************************************************************************
//
// Student name: Julie Ziemer
//
// Student number: 200342432
//
// Assignment number: Assignment 5
//
// Program name: CS 110 Assignment 5.cpp
//
// Date written: April 10, 2015
//
// Problem statement:   Write a program to read up to 20 integers from a file and store the integers in an array of integer type. With the values in the array, compute and display the following:
//						minimum, maximum, mean, median, and mode.  Use a function for each computation / output specified above.  You will also need to include a sort function : see Listing 7.11 from the text.
//
// Output: "Error, file cannot be opened.", "The smallest value is: ", "The largest value is: ", "The mean is: ";
//
// Algorithm: Open the file and store up to 20 integers into an integer array, continuing to transfer until the end of the file is reached. Before sorting the array, find the minimum and maximum
//			  values using for loops and if statements. Checking each value in the array, test if it is larger or smaller than the first value of the array.  If it is, reset the values for the
//			  maximum and minimum value.  Output the max and min from the array.  For the mean, calculate the average of the array by adding up all of the integer values and dividing them by the total.
//			  Before finding the mode and the median, sort the array using Listing 7.11 from the textbook.
//
// Major variables: int i, j, arrayValue[], minValue, maxValue, currentMin, currentMinValue, currentMinIndex; ifstream infile;
//
// Assumptions:  The file will be able to open to extract the number values to put in the array.
//
// Program limitations: If the file doesn't open, the rest of the program will not run.  This program is unfinished.
//
//**************************************************************************
#include <iostream>
#include <fstream>
using namespace std;

int main()
{
	int arrayValue[20];
	ifstream infile;
	infile.open("Assignment 5 Array Storage.txt");
	
	//check infile
	if (!infile)
	{
		cout << "Error, file cannot be opened." << endl;
		return -1;
	}
	
	
	while (!infile.eof())
	{
		// transfer infile values to the array
		for (int i = 0; i < 20; i++)
		{
			infile >> arrayValue[i];
			cout << arrayValue[i] << ", " << endl;
		}
	}

		// find the maximum and the minimum values
		int minValue = arrayValue[0];
		int maxValue = arrayValue[0];

		for (int i = 0; i < 20; i++)
		{
			// storing minimum value
			if (arrayValue[i] < minValue)
			{
				minValue = arrayValue[i];
			}
			// storing maximum value
			if (arrayValue[i] > maxValue)
			{
				maxValue = arrayValue[i];
			}
		}
		cout << "The smallest value is: " << minValue << endl;
		cout << "The largest value is: " << maxValue << endl;
		
		// find the mean value
		int arrayAverage;
		int sum = 0;
		for (int i = 0; i < 20; i++)
		{
			sum += arrayValue[i];
		}
		arrayAverage = sum / 20.0;
		cout << "The mean is: " << arrayAverage << endl;
	
	//sorting the array: using listing 7.11 Selection Sort
	for (int i = 0; i < 20 - 1; i++)
	{
		// find the minimum
		int currentMin = arrayValue[i];
		int currentMinIndex = i;
		for (int j = i + 1; j < 20; j++)
		{
			if (currentMin > arrayValue[j])
			{
				currentMin = arrayValue[j];
				currentMinIndex = j;
			}
		}
		// swap if necessary
		if (currentMinIndex != i)
		{
			arrayValue[currentMinIndex] = arrayValue[i];
			arrayValue[i] = currentMin;
		}
		// find the median
		// find the mode
	}

	return 0;
}