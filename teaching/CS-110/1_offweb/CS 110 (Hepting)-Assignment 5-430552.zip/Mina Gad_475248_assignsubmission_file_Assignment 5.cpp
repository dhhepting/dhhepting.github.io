#include <iostream>
#include <fstream>
using namespace std;

int main()
{
	int numbers[20];
	int min;
	int max;
	int sum=0;
	float avg;
	float median=0;
	int counter = 1;
	int mode = numbers[0];
	int occurence=0;
	ifstream inData;
    ofstream outData;
    inData.open("input.txt");
    if(!inData)
    {
    	cout<< "filne not found"<<endl;
    }
    else
    {
    	for(int i=0;i<20;i++)
    	{
    		inData>> numbers[i];
    	}
    }
    
     for (int i=0;i<20;i++)
    {
    	if(numbers[i]>max)
    	{
    		max=numbers[i];
    	}
    	if(numbers[i]<min)
    	{
    		min=numbers[i];
    	}
    	sum = sum+numbers[i];
    	avg = sum/20;
    	
    	if ( numbers[i] == numbers[i+1] ) 
        {
            counter++;
            if ( counter > occurence ) 
            {
                occurence = counter; 
                mode = numbers[i]; 
            }
        } else
            counter = 1;
    	if (occurence == 1)
			{
					cout << "No modes found" << endl;
			}
		else
			{
				cout << "The mode(s) is/are : " ;
				int i = 0;
				while (i < 20)
				{
					if (numbers[i] == numbers[i+occurence-1]) 
					{
						cout << numbers[i] << " ";
						i += occurence;
					}
					else
					{
						i++;
					}
				}
			}
			median=(numebsr[9]+numbers[10])/2;
			
			outData.open("output.txt");
		    outData << "The maximum value in the array is: " << max<<endl; 
			outData << "The minimum value in the array is: " << min<<endl; 
			outData << "The average value in the array is: " << avg<<endl; 
			outData << "The median value in the array is: " << median<<endl;
			outData << "The most appearence value in the array is: " << occurence <<endl; 
    
    
}
