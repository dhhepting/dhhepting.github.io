// Brandon Watson
// 200269911

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

// Function Prototype
void Sort(int num[], int size);

int main()
{
	int num[20];
	Sort(num, 20);
	int a = 0;
	int sum = 0;
	int mean = 0;
	ifstream inData;
	// Open txt file to obtain values for array
	inData.open("input.txt");
	cout << "Numbers before sorting: ";
	while (! inData.eof())
	{
		inData >> num[a];
		cout << " " << num[a];
		sum += num[a];
	}
	// Get the mean of the array
	mean = sum / 20;
	cout << endl;
	cout << "mean is: " << mean << endl;
	// Call Function
	void Sort(int num[], int size);
	cout << endl;
	cout << "Numbers after sorting: " << num[20];
	cout << endl;
	
	return 0;
}

void Sort(int num[], int size)
{
	for (int x = 0; x < size - 1; x++)
	{
		int minValue = num[x];
		int minIndex = x;

		for (int y = x + 1; y < size; j++)
		{
			if (minValue > num[y])
			{
				minValue = num[y];
				minIndex = y;
			}
		}

		if (minIndex != x)
		{
			num[minIndex] = num[x];
			num[x] = minValue;
		}

	}
}