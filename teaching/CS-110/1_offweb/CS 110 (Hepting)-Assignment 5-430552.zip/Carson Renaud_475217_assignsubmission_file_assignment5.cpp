//**************************************************************************
//
// Student name: Carson Renaud
//
// Student number: 200304106
//
// Assignment number: 5
//
// Program name: Assignment5.cpp
//
// Date written: 04/09/15
//
// Problem statement: Create a program that computes & displays the smallest an largest values,
//                    mean,meadian, and mode.
//
// Input:   Input is from a text file that will have integers within they are then stored into a array.
//
// Output: The smallest an largest value in the array also mean, meadian, and mode.
//
// Algorithm: Takes in data from the text file until eof or 20 values have been taken, next stores them
//            in a array, at this point functions will be called from main, a selection sort function will
//            sort the data with the use of a swap value function and the maxindex fuction, after this the
//            minIndex, and along with findMean, findMeadian, and findMode functions will process the data
//            for output.
//
// Major variables: void swapvalues, int findMaxIndex, int findMinIndex, void selectionSort, int findMode,
//                  float findMean, float findMedian, void printArray.
//
// Assumptions: The file will have integers contained with in and vales not greater than int.
//
// Program limitations: Only works on integers and from files that are attached
//
//**************************************************************************

#include <iostream>
#include <fstream>

using namespace std;
void swapvalues(int number[], int value1, int value2);
int findMaxIndex(const int number[], int size);
int findMinIndex(const int number[], int size);
void selectionSort(int number[], int size);        //function prototypes
int findMode(int number[], int size);
float findMean(const int number[], int size);
float findMedian(int number[], int size);
void printArray(const int number[], int size);

int main()
{
    int number[20]; //= {23, 34, 45, 56, 23, 34 ,56 ,76, 32, 21};// ints to test array, declare array
     ifstream integerfile;
     integerfile.open("integers.txt"); // open input file
    
     if(!integerfile)
     {
         cout << "Couldn't open the file! " << endl; // reads in intergers from the file
         return 1;
     }
    
    int i=0;
    while(!integerfile.eof() && i <20)
    {
        integerfile >> number[i];
        i++;// take integers and stores them into array of type int
    }
    
    int size = i;
    
    int maxindex = findMaxIndex(number, size);   // function calls for max, min, mean, median, mode.
    cout << "The maximum number is: " << number[maxindex] << endl;
    int minindex = findMinIndex(number, size);
    cout << "The mininmum number is: " << number[minindex] << endl;
    float mean = findMean(number, size);
    cout << "The mean is: " << mean << endl;
    float median = findMedian(number, size);
    cout << "the median: " << median << endl;
    int mode = findMode(number, size);
    cout << "the mode is: " << mode << endl;
    
    printArray(number, size); // prints out array was used to check selection sort.
    
    return 0;
    
}

//functions
void swapvalues(int number[], int value1, int value2) //swaps the last element and the highest value element
{

        int temp = number[value1];
        number[value1]= number[value2];
        number[value2]= temp;
    
}


int findMaxIndex(const int number[], int size) // finds the position of the largest value
{
    int maxindex = 0;
    int maxvalue = number[0];
    for( int i= 0; i < size; i++)
    {
        if(number[i]>maxvalue)
        {
            maxvalue=number[i];
            maxindex = i;
        }
    }
    return maxindex;
}


int findMinIndex(const int number[], int size) // finds the position of the lowest value
{
    int minindex = 0;
    int minvalue = number[0];
    for(int i = 0; i < size; i++)
    {
        if(number[i] < minvalue)
        {
            minvalue = number[i];
            minindex = i;
        }
    }
    return minindex;
}


void selectionSort(int number[], int size) // sorts the input into a list lowest to highest
{
    for(int n = size; n >= 2; n--)
    {
    int maxindex = findMaxIndex(number, n);
    swapvalues(number,maxindex,n-1);
    }
}


int findMode(int number[], int size) //finds mode by comparing each number with the next value n incrementin
{
    selectionSort(number, size); //sorts values
    int count = 1;
    int max = 0;
    int mode = number[0];
    for(int i = 0; i < size-1; i++)
    {
        if(number[i] == number[i+1])
        {
            count++;
            if( count > max)
            {
            max = count;
            mode = number[i];
            }
        }
        else
        count = 1;
    }
    return mode;
}


float findMean(const int number[], int size)//finds mean, sums input data and divides by the # of elements
{
    int sum = 0;
    for(int i = 0; i < size; i++)
    {
        sum+= number[i];
    }
   return (float(sum)/float(size));
}


float findMedian(int number[], int size) //finds median will return either float or whole int number
{
    // sort values first
    selectionSort(number, size);
    float median;
    
    if ((size%2) == 0)
    {
        int index, secondIndex;
        index= size/2;
        secondIndex= index -1;
        median = (number[index] + number[secondIndex])/ 2.0;
    }
    
    else
    {
        int index;
        index = size/2;
        median = number[index];
    }
    return median;
}

void printArray(const int number[], int size)  //prints elements in the array
{
    cout << "the elements of the array are: " << endl;
    for(int i= 0; i < size; i++)
    {
        cout << number[i] << " ";
    }
}






