//**************************************************************************
//
// Student name: Olivia Philippon
//
// Student number: 200294151
//
// Assignment number: 5
//
// Program name: Assignment5
//
// Date written: Apr. 10, 2015
//
// Problem statement: The problem we are trying to solve with this code is to have the file enter up to 20 integers and to store those 
// integers in an array. Once they are stored, the program must be able to find the largest value, minimum value, mean, median, and mode. 
// Each of these calculations must be done in a separate function. 
//
// Input: The program will except up to 20 integers from the a file as input. 
//
// Output: As output, I expect the functions that are called upon to provide the answers to the calculations, ultimately providing the
// max, min, mean, median, and mode. These values will appear in the output screen. 
//
// Algorithm: In order to solve the instructed problem, the main function will take up to 20 numbers from a file. These numbers will be stored in an array and will 
//  be sent to subsequent functions. There are separate functions that will return the maximum, minumum, mean, median, and mode of the array to the main function. 
//  From here, the values that the functions have calculated will be outputted.  
//
// Major variables: The major variables include the array integer. This array allows the storage allocation of the integers from the user. 
//    Other major variables in the function names that will be called upon. These are important because they allow the output to be revealed
//    from the calculations. For example, if a function returns an integer, this is important because now the result of the calculation is 
//    able to be provided to the main function and outputted. 
//
// Assumptions: The program assumes that the user would like to enter up to 20 integers and no more. 
//
// Program limitations: Other limitations of the program include that the integers taken from the file are treated as integers. A user cannot enter 
//  decimal values and have the correct corresponding output. Also, if there is a mode, the program does not say how many times that number 
//  occurred. It just displays the number that has occurred most frequently. 
//
//**************************************************************************
#include <iostream>
#include <fstream>

using namespace std;

///Here each function prototype is declared.
int getlowest(int[], int);
int gethighest(int[], int);
double getaverage(int[], int);
int GetMedian(int[], int);
int GetMode(int[], int);

int main()
{	
	//Declare the variables
	int highest, lowest;
	double avg;
	int median = 0;
	int mode = 0;

	//Declare the current size of the array
	const int SIZE = 20;
	int numbers[SIZE];

	ifstream inData;
	//This opens the file 
	inData.open("inputfile.txt");
	
	cout << "The values in the array are: " << endl;
	int count = 0;
	//This loop will print the number of values in the file and increment the new value of integers in the array. 
	while (!inData.eof())
	{
			inData >> numbers[count];
			count++;
	}

	for (int i = 0; i < count - 1; i++)
	{
		cout << numbers[i] << endl;
	}

	//The call the functions to allow the calculations to occur based on the array and the number of values that are in the array
	highest = gethighest(numbers, count - 1);
	lowest = getlowest(numbers, count - 1 );
	avg = getaverage(numbers, count - 1);
	median = GetMedian(numbers, count - 1);

	cout << "The maximum number in the array is: " << highest << endl;
	cout << "The minumum number in the array is: " << lowest << endl;
	cout << "The average of the numbers is " << avg << endl;
	cout << "The median of the array is: " << median << endl;
	cout << "The mode of the array is " << mode << endl;

	return 0;

}
//This function finds the lowest value in the array
int getlowest(int theArray[], int size)
{
	//We declare the initial lowest value of the array to be at the index of zero. 
	int lowest = theArray[0];

	for (int index = 0; index < size; index++)
	{
		//Here we compare the array values to the lowest value. For example, if the new array value is smaller than the array value at index 0, 
		// the new array value replaces the previously declared lowest value. 
		if (theArray[index] < lowest)
		{
			lowest = theArray[index];
		}
	}

	return lowest;

}

//The function finds the maximum value in an array 
int gethighest (int theArray[], int size)
{
	//We declare the initial highest value of the array to be at the index of 12. 
	int highest = theArray[12];
	for (int index = 1; index <= size; index++)
	{
		//Here we compare the array values to the highest value. Much like the function that found the lowest number, if the new array 
		//value is larger than the array value at index 12, the new array value replaces the previously declared highest value.
		if (theArray[index] > highest)
			highest = theArray[index];
	}

	return highest;
}

//The function funds the average/mean of the values in the array. 
//This function returns a double value so that the average can be in decimal form to be more precise. 
double getaverage(int theArray[], int size)
{
	double total = theArray[0];
	double average;
	//First we find the sum of the array
	for (int index = 1; index < size; index++)
	{
		total += theArray[index];		
	}
	//We divide the sum by the size of the array to find the arrange
	average = total / size;
	//This permits a decimal value to be allowed for the average. 
	average = average / 1.0;

	return average;

}

int GetMedian(int theArray[], int size) 
{
	// This sorts the array first. Sorting is necessary to find the median. 
	//This sorting algorithm is from the example on Piazza.
	for (int i = 0; i < size; i++)
	{
		if (theArray[i] > theArray[i + 1])
		{
			int temp = theArray[i + 1];
			theArray[i + 1] = theArray[i];
			theArray[i] = temp;
		}
	}

	int median = 0;
	//This condition checks if the array has an even or odd number of integers
	if ((size % 2) == 0) 
	{
		median = (theArray[size / 2] + theArray[(size / 2) - 1]) / 2.0;
	}
	else 
	{
		median = theArray[size / 2];
	}

	return median;
}

int GetMode(int theArray[], int size) 
{
	//This code to find the array has been retrieved and slightly modified from a piazza discussion.

	//This is the maximimum number of modes that we could have if the user enters all 20 intergers. 
	int maxPossibleMode = theArray[10];
	int mode = 1;
	int maxMode = 0;
 
	for (int i = 0; i < size - 1; i++) 
	{
		//This checks if there is an array value that is equal to the following array value
		if (theArray[i] == theArray[i + 1])
		{
			mode += 1;
			if (mode > maxMode && mode != 1)
			{
				maxMode = mode;
				maxPossibleMode = theArray[i];
			}
			else if (mode == maxMode && mode != 1)
			{
				maxPossibleMode += 1;
				maxPossibleMode = theArray[i];
			}
		}
		else
		{
			mode = 1;
		}
	}

	//If there is no mode, this if statement will execute and return a mode value of 0. 
	for (int i = 0; i < size; i++)
	{
		if (maxMode < 1)
		{
			maxPossibleMode = 0;
		}

	}

	return maxPossibleMode;
}