// Shyla Christie
// 200337036
// April 10th,2015
// Assignment 5

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
using namespace std;
// Declare function prototypes
void max(int num[20], int arrSize);
void average(int num[20], int arrayNum);
void min(int num[20], int arrSize);
void sortAndMedian(int num[20], int size);
void mode(int array[20], int size);
const int arraySize = 20;
int arrayNumber;
double avg;
double total = 0;

int main()
{
	// Declare variables for main function
	string name;
	int num[arraySize];
	int j = 0;
	int k = 0;
	int used = 0;
	int a = 0;
	//Open the input file
	ifstream input("Project.txt");
	// Case of input file failure
	if (input.fail())
	{
		cout << "File open failed!";
		exit(1);
	}
	for (int i = 0; i < 20; i++)
	{
		input >> num[i];
	}

	//Call to functions
	max(num, 20);
	min(num, 20);
	average(num, 20);
	sortAndMedian(num, 20);
	mode(num, 20);
}
// Function to find the maximum value in the file
void max(int num[20], int arrSize)
{
	int index;
	int temp = 0;

	for (index = 0; index < arrSize; index++)
	{
		if (num[index] > temp)
		{
			temp = num[index];
		}
	}

	cout << "The largest number is: " << temp << endl;
}
// Function to find the minnimum value in the file
void min(int num[20], int arrSize)
{
	int index;
	int temp;

	temp = num[0];

	for (index = 0; index < arrSize; index++)
	{
		if (num[index] < temp)
		{
			temp = num[index];
		}
	}

	cout << "The smallest number is: " << temp << endl;
}
// Function to find the average value of the numbers in the file
void average(int num[20], int arrayNum)
{
	for (int i = 0; i < arrayNum; i++)
	{
		total += num[i];
	}

	avg = total / arrayNum;

	cout << "The average of this array is: " << avg << endl;
}
// Function to sort the vaules in the file and then to find the median
void sortAndMedian(int num[20], int size)
{
	int temp;

	for (int i = 0; i < size; i++)
	{
		for (int j = 0; j < size - 1; j++)
		{
			if (num[j] > num[j + 1])
			{
				//we need to swap
				temp = num[j];
				num[j] = num[j + 1];
				num[j + 1] = temp;
			}
		}
	}

	cout << "The median is: " << num[9] << endl;
}
// Function to find the mode of the numbers  
void mode(int array[], int size)
{
	int counter = 1;
	int max = 0;
	int mode = array[0];

	for (int pass = 0; pass < size - 1; pass++)
	{
		if (array[pass] == array[pass + 1])
		{
			counter++;
			if (counter > max)
			{
				max = counter;
				mode = array[pass];
			}
		}
		else
			counter = 1;
	}
	cout << "The mode is: " << mode << endl;
}