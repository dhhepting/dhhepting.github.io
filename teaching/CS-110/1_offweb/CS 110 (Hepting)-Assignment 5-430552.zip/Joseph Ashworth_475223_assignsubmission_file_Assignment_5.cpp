/*  
	STUDENT NAME:  Joseph Ashworth
	STUDENT ID:  200354384
	ASSIGNMENT NO.:  5
	PROGRAM NAME:  Assignment_5.cpp
	DATE WRITTEN:  20-03-2015
	PROBLEM STATEMENT:  Create a program to read up to 20 integers from a file, then calculate information from the 
		integers using functions.
	INPUT:  Up to 20 integers from an input file.
	OUTPUT:  The maximum, minimum, mean, median and mode of the integers.
	ALGORITHM:  Read up to 20 numbers from a file, and store them in an array. Order the array in ascending order. Find 
		the maximum and minimum values and then use functions to find the mean, median and mode of the group of numbers.
	MAJOR VARIABLES:  anArray[], maximum, minimum, mean, median, mode
	ASSUMPTIONS:  
	PROGRAM LIMITATIONS:  Mode will only registar as the first (lowest) of numbers with the same amount of appearances.
*/

#include <iostream>
#include <fstream>
using namespace std;

void sortAscending(int [], int);		//Function Declarations
double findMean(int [], int);
double findMedian(int [], int);
int findMode(int [], int);

int main()
{
	ifstream inData;					//Declare and bind input stream
	inData.open("InputFile.txt");

	int anArray[20];					//Decalre a 1D array with 20 elements, since 20 is the maximum amount of inputs.
	int count = 0;

	while (count < 20)					//On each cycle, read an interger from the input stream and store it into the 
	{									//array. Repeat 20 times, or until the input stream fails to read a value. Count
		inData >> anArray[count];		//number of successful inputs to the array.
		if (!inData)
			break;
		else
			count++;
	}

	sortAscending(anArray, count);		//Sort the array into ascending order using a function.

	int minimum = anArray[0];				//The minimum and maximum values should be the first and last values 
	int maximum = anArray[count - 1];		//respectively in the sorted array.

	double mean = findMean(anArray, count);			//Find the mean, median and mode using functions with parameter of 
	double median = findMedian(anArray, count);		//the array (passed by reference) and the number of inputs.
	int mode = findMode(anArray, count);

	cout << "The maximum value was\t" << maximum << endl;		//Output the information to the console.
	cout << "The minimum value was\t" << minimum << endl;
	cout << "The mean value was\t" << mean << endl;
	cout << "The median value was\t" << median << endl;
	cout << "The mode value was\t" << mode << endl;

	return 0;
}

void sortAscending(int array[], int size)				//sortAscending uses a bubble sort to arrange the elements of
{														//passed array (up to the number of entries) into ascending 
	for (int iii = 0; iii < size; iii++)				//order.
	{
		for (int jjj = iii + 1; jjj < size; jjj++)
		{
			if (array[jjj] < array[iii])
				swap (array[jjj], array[iii]);
		}
	}
}

double findMean(int array[], int num)			//findMean calculates the sum of the values in the array, then divides 
{												//that amount by the number of elements summed, and returns that value.
	double sum = 0;
	for (int iii = 0; iii < num; iii++)
		sum += array[iii];

	return (sum / num);
}

double findMedian (int array[], int num)		//findMedian returns the median value based on whether there is an odd
{												//or even number of elements in the array.
	double median;
	if (num % 2 == 0)
		median = (array[num/2 - 1] + array[num/2])/2.0;
	else
		median = array[num/2];

	return median;
}

int findMode (int array[], int num)				//findMode loops through the array, comparing every value to the one
{												//before it. If they are the same, then currentCount is incremented. If 
	int mode = array[0];						//currentCount exceeds modeCount, then the current value occurs in the 
	int modeCount = 1;							//array more often than the current mode. At this point, the current
	int currentCount = 1;						//value (array[iii]) becomes the new mode and currentCount becomes the 
												//modeCount. Once the loop is finished, return the mode. Since only one 
	for (int iii = 1; iii < num; iii++)			//value can be returned, if multiple elements occur the same number of 
	{											//times, only the first (lowest) is returned.
		if (array[iii] == array [iii - 1])
			currentCount++;
		else
			currentCount = 1;

		if (currentCount > modeCount)
		{
			mode = array[iii];
			modeCount = currentCount;
		}
	}
	return mode;
}