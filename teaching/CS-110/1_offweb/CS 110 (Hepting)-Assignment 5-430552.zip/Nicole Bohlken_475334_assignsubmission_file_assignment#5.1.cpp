/*
Student name: Nicole Bohlken
Student number: 200273089
Assignment number: 5
Program name: Computations with Arrays
Date: written for April 10, 2015
Problem Statement: Write a program to read up to 20 integers from a file and store the integers in an array of integer type. 
With the values in the array, compute and display the following:
minimum: smallest value in the array
maximum: largest value in the array
mean: average of all values in the array
median: the value in the middle of the array once all values have been sorted. 
mode: find the value in the array which occurs most often. A straightforward approach is possible once the array is sorted.
Input: A file with perferably 20 integers.
Output: The minimun, maximun, mean, median, and mode of the 20 integers.
Algorithm: The computer will read numbers from a text file, and store them into arrays of interger types. 
The numbers will then be tested in void fuctions in order to find the min, max,and mean,
and then the numbers in the array will be sorted and if/else functions will be used to dtermine the median and mode.
Major variables: Min(int[], int), Max(int[], int), Mean(int[], int), Median(int[], int), Sort(int[], int), Mode(int[], int).
Assumptions: The program will compile and run correctly, no syntax or logic or runtime errors are present in the code.
Program Limitations: Only 20 numbers are used within the array
*/


#include <iostream>
#include <fstream>
using namespace std;

void Min(int[], int);	// function parameters
void Max(int[], int);
void Mean(int[], int);
void Median(int[], int);
void Sort(int[], int);
void Mode(int[], int);

int main()
{

ifstream inData;	// declaring a variable for the inData.open("input.txt");

cout << "Hello, I'm about to give you some really cool " << endl;
cout << "information about the numbers in the file \"input.txt\"." << endl;

int array[20];
int num = 0;

	while (num < 20)
{
	while (!inData.eof())
{
	if (inData.eof())
num = 21;
inData >> array[num];
num++;
}
}
Min(array, num);
Max(array, num);
Mean(array, num);
Sort(array, num);
Median(array, num);
Mode(array, num);
	return 0;
}

void Min(int a[], int numEl)
{
int min = a[0];
	for (int index = 0; index < numEl; index++)
{
	if (a[index] < min)
min = a[index];
}
cout << "The minimum value is: " << min << endl;
}

void Max(int a[], int numEl)
{
int max = a[0];
	for (int index = 0; index < numEl; index++)
{
	if (a[index] > max)
max = a[index];
}
cout << "The maximum value is: " << max << endl;
}

void Mean(int a[], int numEl)
{
int sum = 0;
	for (int index = 0; index < numEl; index++)
{
sum += a[index];
}
	double average = static_cast<double>(sum)/numEl;
cout << "The mean value is: " << average << endl;
}

void Sort(int a[], int numEl)
{
	for (int i = 0; i < numEl; i++)
{
	for (int j = 0; j < numEl; j++)
{
	if (a[i] < a[j])
{
int temp = a[j];
a[j] = a[i];
a[i] = temp;
}
}
}
	for (int i = 0; i < 20; i++)
cout << a[i] << ", ";
}

void Median(int a[], int numEl)
{
	double middle;
	if (numEl % 2 == 1)
{
	int element = (numEl - 1) / 2;
	middle = a[element];
}
	else
{
	int low = numEl / 2;
	int high = (numEl / 2) + 1;
middle = (a[low] + a[high]/ 2.0);
}
cout << "The median value is: " << middle << endl;
}

void Mode(int a[], int numEl)
{
	int count = 1;
	int max = 0;
	int mode = a[0];
	for (int index = 0; index < numEl - 1; index++)
{
	if (a[index] == a[index + 1])
{
count++;
	if (count > max)
{
max = count;
mode = a[index];
}
}
	else
count = 1;
}
cout << "The mode value is: " << mode << endl;
}