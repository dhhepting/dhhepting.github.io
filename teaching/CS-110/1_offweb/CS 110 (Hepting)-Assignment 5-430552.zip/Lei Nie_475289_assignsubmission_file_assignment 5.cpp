#include<iostream>
#include<algorithm>
#include<fstream>
using namespace std;

int minimum(int array[], int Max);
int maxinum(int array[], int Max);
double mean(int array[], int Max);
void median(int array[], int Max);
void mode(int array[], int Max);

int minimum(int array[], int Max)
{
	int min = array[0];
	for (int i = 0; i < Max; i++)
	{
		
		if (min>array[i])
		{
			min = array[i];
		}
	}
	return min;
}

int maxinum(int array[], int Max)
{
	int max = array[0];
	for (int i = 0; i < Max; i++)
	{
		if (max < array[i])
		{
			max = array[i];
		}
	}
	return max;
}

double mean(int array[], int Max)
{
	double sum = 0;
	for (int i = 0; i < Max; i++)
	{
		sum = sum + (double)array[i];
	}
	double avg = sum / (double)Max;

	return avg;
}

void median(int array[], int Max)
{
	for (int i = 0; i < Max; i++)
	{
		double currentMin = array[i];
		int currentMinIndex = i;

		for (int j = i + 1; j < Max; j++)
		{
			if (currentMin > array[j])
			{
				currentMin = array[j];
				currentMinIndex = j;
			}
		}
		if (currentMinIndex != i)
		{
			array[currentMinIndex] = array[i];
			array[i] = currentMin;
		}
	}

	if (Max % 2 == 1)
	{
		int med;
		med = array[Max / 2];
		cout << "median is " << med << endl;

	}
	else if (Max % 2 == 0)
	{
		int med1, med2;
		med1 = array[Max / 2];
		med2 = array[Max / 2 - 1];
		cout << "median is " << med1 << " and " << med2 << endl;
	}
}

void mode(int array[], int Max)
{
	int count = 1;
	int Maxcount = 1;
	int Maxarray = array[0];
	for (int i = 0; i < Max; i++)
	{
		if (array[i] == array[i + 1])
		{
			count++;
		}
		else
			count = 1;
		if (count > Maxcount)
		{
			Maxcount = count;
			Maxarray = array[i];
		}
	}
	
	cout << "the occurs most often is " << Maxarray << " and " << Maxcount << " times" << endl;
	
}

int main()
{
	int Maxcount;
	int i = 0;
	int array[20];
	int Min;
	int Max;
	double Mean;

	ifstream input;
	input.open("input.txt");

	while (input)
	{
		input >> array[i];
		i++;
	}
	Maxcount = i - 1;
	cout << "the array is ";
	for (int j = 0; j < Maxcount; j++)
	{
		cout<<array[j] << " ";
	}
	cout << endl;
	Min = minimum(array, Maxcount);
	Max = maxinum(array, Maxcount);
	Mean = mean(array, Maxcount);

	cout << "the minimum number is " << Min << endl;
	cout << "the maxinum number is " << Max << endl;
	cout << "the average is " << mean << endl;

	median(array, Maxcount);
	mode(array, Maxcount);
	return 0;

	
}