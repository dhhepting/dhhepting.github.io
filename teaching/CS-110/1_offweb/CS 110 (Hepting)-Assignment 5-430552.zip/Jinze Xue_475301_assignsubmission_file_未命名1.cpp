//********************************************************************
//Name: Jinze Xue
//Student number: 200353480
//Assignment number: 5
//Program name: math
//Date written: April 10th, 2015
//Problem statement: Write a program that prompts the user to enter number and calculate 
//Output: maximum,minimum,mean
//Major variables: number
//Assumptions:  
//Program limitations:20 numbers
//**********************************************************************

#include <iostream>

#include<fstream>

using namespace std;

void sort(int x[], int i);

void DisplayMin(int x[], int i);

void DisplayMax(int x[], int i);

void DisplayMean(int x[], int i);

void DisplayMed(int x[], int i);

void DisplayMode(int x[], int i);

int main()

{

int i = 0;

int a[20];

ifstream indata;

indata.open("input.txt");

cout << "Get numbers from file: " << endl;

while (indata)

{

indata >> a[i];

i++;

}

sort(a, i);

DisplayMin(a, i);

DisplayMax(a, i);

DisplayMean(a, i);

DisplayMed(a, i);

DisplayMode(a, i);

return 0;

}

void sort(int x[], int i)

{

int temp;

for (int q = 0; q<i-1; q++)

for (int z = q + 1; z<i-1; z++)

if (x[q]>x[z])

{

temp = x[q];

x[q] = x[z];

x[z] = temp;

}

for (int q = 0; q <i-1; q++)

{

cout << x[q]<<endl;

}

}

��

void DisplayMin(int x[], int i)

{

cout << "The smallest value in the array is: " << x[0] << endl;

}

void DisplayMax(int x[], int i)

{

int s = i - 1;

cout << "The largest value in the array is: " << x[s] << endl;

}

void DisplayMean(int x[], int i)

{

double ave;

int sum = 0;

for (int q = 0; q<i-1; q++)

sum += x[q];

ave = sum;

ave /= i;
cout << "The average of all values in the array is: " << ave << endl;

}

void DisplayMed(int x[], int i)

{

int mid = i / 2;

cout << "The value in the middle of the array once all values have been sorted is: ";

if (i % 2 == 0 && x[mid] != x[mid - 1])

cout << x[mid - 1] << " and ";

cout << x[mid] << endl;

}

void DisplayMode(int x[], int i)

{

int mode, time = 0;

int m = x[0], t = 1;

x[i] = x[0];

for (int q = 1; q <= i; q++)

{

if (x[q] == m) t++;

else

{

if (t>time)

{

time = t;

mode = m;

}

t = 1;

m = x[q];

}

}

cout << "The value in the array which occurs most often is: " << mode<<endl;

��

��

m = x[0];

t = 1;

for (int q = 1; q <= i; q++)

{

if (x[q] == m) t++;

else

{

if (t == time && m != mode) cout << " " << m;

t = 1;

m = x[q];

}

}

}

��

