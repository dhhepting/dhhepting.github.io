// Nandha Kishore Bijumon
// Sid 200 355 253
// Assignment 5
// April 10, 2015

#include <iostream>
#include <fstream>
#include <string>

using namespace std;

void minmax (int, int, int);

int main()
{

	int a[20];
	int sum = 0;

	int lines = 0;
	string line;

	ifstream inData;

	inData.open("input.txt");

	if (!inData)
	{
		cout << "error loading file" << endl;
	}

	for (int i = 0; i < 19; i++)
	{

		inData >> a[i];

	}


	while (inData)
		++lines;


	cout << "Number of lines in text file: " << lines;

	minmax(a[20], sum, lines);

	return 0;
}



void minmax (a[], sum, lines)

{

	int avg;
	int j;
	int k;
	int median;
	int max;
	int min;
	max = a[0];
	min = a[0];

	for (j = 0; j < 20; j++)
	{
		if (a[j] > max)
		{
			max = a[j];
		}

		else if (a[j] < min)
		{
			min = a[j];
		}
		sum = sum + a[j];

	}

	if (lines % 2 = 0)
	{
		k = (lines / 2)
			median = (a[k] + a[k + 1]) / 2
	}
	else
	{
		k = (lines / 2) - 1;
		median = a[k];
	}

	avg = sum / 20;

	cout << "The maximum value is " << max << endl;

	cout << "The minimum value is " << min << endl;

	cout << "The average of all the values is" << avg << endl;

	cout << "The median value is" << median << endl;


}



