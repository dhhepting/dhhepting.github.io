//**************************************************************************
//
// Student name:Bright Nwanoruo
//
// Student number: 200337192
//
// Assignment number: #5
//
// Program name: BrightAssig5.cpp
//
// Date written: 10/4/2015
//
// Problem statement:
// Write a program to read up to 20 integers from a file and store the integers in an array of integer type. 
//With the values in the array, compute and display the following:
//
// minimum: smallest value in the array
//
// maximum : largest value in the array
//
// mean : average of all values in the array
//
// median : 
// the value in the middle of the array once all values have been sorted.
// If there is no single index at the middle of the array, average the values in the 2 adjacent spots.
// For example : if the array has 3 values(with indices 0, 1, 2), once the array is sorted the median will be at index 1.
// If the array has 4 values(with indices 0, 1, 2, 3), once the array is sorted the median will be the average of the
// values at indices 2 and 3.
//
// mode : find the value in the array which occurs most often.A straightforward approach is possible once the array is sorted.
//
//Use a function for each computation / output specified above.You will also need to include a sort function : see Listing 7.11 from the text.
//
//
// Input: accept numbers fro your computation from the file
//
// Output: 
//minimum value
//maximum value
//mean value
//median value
//mode value


// Algorithm:
// open an input file
// accpet the input file in your int main function
//  sort the values in the input file from lowest highest
//  invoke the min function to calculate the minimum value
//invoke the max function to calculate the maximum value
//invoke the mean function to calculate the mean value
//invoke the median function to calculate the median value
//invoke the mode function to calculate the mode value

// Major variables: 
// inData
// Calc_Min_Value
// Calc_Max_Value
// Calc_Median
// Calc_Mean
// Calc_Mode

// Assumptions: The user will input his/her values in the text file "Inputfile.txt"
// The user must enter values up to 20 values, if not the empty slots will have value 0
//
// Program limitations: 
// This program accepts input from the input file called "Inputfile.txt" but does not display output in an output file.
//
//
//**************************************************************************
#include<iostream>
#include<fstream>
#include<cmath>
using namespace std;

void Calc_Min_Value(int [],int);//function Prototype for Cal_Min_Values
void Calc_Max_Value(int[], int);//function Prototype for Cal_Max_Values
void Calc_Median(int[], int);//function Prototype for Cal_Median
void Calc_Mean(int[], int);//function Prototype for Cal_Mean
void Calc_Mode(int[], int);//function Prototype for Cal_Mode

int main()
{
	ifstream inData;//file input stream
	

	inData.open("Inputfile.txt");//open input text file

	int Values[20];//Array declaration and initialization


	for (int i = 0; i < 20; i++)//for loop to accept input from file and store in th array
	{
		inData >> Values[i];
	
	}

	// we need a nested loop to do the bubble sort:
	// the inner loop ensures that the largest value amongst
	// those to be sorted goes to the highest available spot
	// the outer loop determines how many times this needs to
	// be done.  Note that it is 1 less than the number of elements
	// in the array because once array[1] has the proper value, so
	// does array[0]
	for (int j = 0; j < 19; j++)
	{
		// go over the array.  Note, because we want to test
		// indices i and i+1, need to test if "i < 19", so that
		// i+1 will be a valid index
		for (int i = 0; i < 19 - j; i++)
		{
			if (Values[i] > Values[i + 1])
			{
				int temp = Values[i + 1];
				Values[i + 1] = Values[i];
				Values[i] = temp;
			}
		}
		// the result of this loop puts the proper value into
		// the array at index 9-j

		
	}



	Calc_Min_Value(Values, 20);//invoke function to cal. min. Value
   Calc_Max_Value(Values, 20);//invoke function to cal. max. Value
   Calc_Median(Values, 20);//invoke function to cal. median value
   Calc_Mean(Values, 20);//invoke function to cal. mean value
   Calc_Mode(Values, 20);//invoke function to cal. mode value
	
   cout << endl;
   cout << endl;

	return 0;
}

void Calc_Min_Value(int Values[],int Array_Const)//funtion for Cal. min. Value
{
	int minValue = Values[0];
	for (int i = 0; i < 20; i++)//loop to compare values in the loop by arrays indexes
	{
		if (Values[i] < minValue)
		{
			minValue = Values[i];

		}
	}
	cout << "Minimum Value is : " << minValue << endl;//display min Value
	cout << endl;
}
void Calc_Max_Value(int Values[], int Array_Const)//function to calc. Max Value
{
	int maxValue = Values[0];
	for (int i = 0; i < 20; i++)//loop to compare values by arrays indexes
	{
		if (Values[i] > maxValue)
		{
			maxValue = Values[i];

		}
	}
	cout << "Maximum Value is : " << maxValue << endl;//display max Values
	cout << endl;
}

void Calc_Median(int Values[], int Array_Const)//function to cal. Median
{
	
	int median;
	double PositionOfMedian;//declare position of median


	PositionOfMedian = 0.5 * (20 + 1);//cal. the position of median


	int Round_Down_Position_Median = floor(PositionOfMedian);//round down the position of median

	int Round_Up_Position_Median = ceil(PositionOfMedian);//round up the position of median
	median = (Values[Round_Down_Position_Median - 1] + Values[Round_Up_Position_Median - 1]) / 2;//divide the values
	//in the position of the arrays by 2 to get the median value 


	cout << "The median of the Values is : " << median << endl;//display the median value
	cout << endl;
}

void Calc_Mean(int Values[], int Array_Const)//function Prototype for Cal_Mean
{
	int sum = 0;
	for (int i = 0; i < 20; i++)//for loop for getting the sum of values  
	{
		sum += Values[i];
	}
	cout << "Sum of Values is: " << sum << endl;//display the sum of Values
	cout << endl;

	float mean = sum / 20.0;
		cout << "Mean value is :" << mean << endl;
		cout << endl;
}

//code implementation from the discusion with Prof. Daryl Hepting in piaza
void Calc_Mode(int Values[],int Array_Const)//funtion to cal. the mode
{
	

	// array a has been sorted before being passed here 
	// pass the max array size as 2nd parameter
	int counter = 1;  // counter for current number
	int max = 0; // counter value for mode

	int mode = Values[0]; // assign the 1st array element to be the mode to start
	for (int i = 0; i < 19 - 1; i++) // stop 1 short, allowed i+1
	{
		// increment counter if consecutive elements are the same
		if (Values[i] == Values[i + 1])
		{
			counter++;
			if (counter > max) // is current element now mode?
			{
				// max is set to new counter value
				max = counter;
				// mode is set to a[i+1]
				mode = Values[i + 1];
			}
		}
		else
		{
			// if number changes, reset counter
			counter = 1;
		}
	}
	cout << "The mode is: "; // prints out the mode 

	for (int i = 0; i < 20; i++)
	{
		if (max < 1)// <strong>If there is no mode, max will equal zero, and this statement will be executed</strong>
		{
			cout << "NO MODE BECAUSE ALL VALUES OCCUR ONLY ONCE!!"; // will print out NO MODE if all numbers occur only once
			break; // need to break out of loop so NO MODE doesn't print MAX_ARRAY # of times
		}
		else if (Values[i] == Values[i + max - 1]) // if the array position + the value of max (number of times mode occured) - 1 is equal to the a[i]
			cout << Values[i] << " "; // prints out number because it is one of the modes

	}


}