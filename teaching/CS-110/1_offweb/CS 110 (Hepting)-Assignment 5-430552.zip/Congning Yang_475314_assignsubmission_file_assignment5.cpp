//**************************************************************************
//
// Student name: Congning Yang
//
// Student number: 200350457
//
// Assignment number: Assignment 5
//
// Program name: CS 110
//
// Date written: April 10th, 2015
//
// Problem statement: Write a program to read up to 20 integers from a file and store the integers in an array of integer type. With the values in the array, compute and display the following: 
//                  minimum: smallest value in the array
//                  maximum: largest value in the array
//                  mean: aver age of all values in the array
//		            median: the value in the middle of the array once all values have been sorted.If there is no single index at the middle of the array, average the values in the 2 adjacent spots.For example : if the array has 3 values(with indices 0, 1, 2), once the array is sorted the median will be at index 1. If the array has 4 values(with indices 0, 1, 2, 3), once the array is sorted the median will be the average of the values at indices 2 and 3.
//				    mode: find the value in the array which occurs most often.A straightforward approach is possible once the array is sorted
//
// Input:twenty numbers from input file
//
// Output: minimum number, maximum number, mean number, median number and mode
//
// Algorithm 1: Set up a function prototype: void cal (int x[],int n)
// Algorithm 2: Open the input file and read the twenty numbers from this file
// Algorithm 3: Use sort function to rank the number(from smallest to largest)
// Algorithm 4: Use FOR LOOP to find the average of these 20 numbers
// Algorithm 5: When find median number, there are two situation: if the number of median is odd or even. Thus, I use moduulus operator(%2) to identify these two conditions.
// Algorithm 6: Use For loop to find mode.
// Major variables: x[],n,a[20],i,j,ave,sum,temp,mid,mode,time,m,minIndex,currentIndex
//
// Assumptions: the integer 20 number from the file
//
// Program limitations: Any number is not integer or any number is not from the file
//
// Comment: The code I created can run succefully 
//************************************************************************
#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

void sorting(int[]);
void DisplayMin(int[]);
void DisplayMax(int[]);
void DisplayMean(int[]);
void DisplayMed(int[]);
void DisplayMode(int[]);

const int n = 20;

int main()
{

	int a[20];

	ifstream inData;
	inData.open("input.txt");
	cout << "Read the 20 numbers from the file:" << endl;

	if (!inData)
	{
		cout << "Can't open the input file successfuly." << endl;
		return 1;
	}

	while (inData)
	{
		for (int i = 0; i < 20; i++)
		{
			inData >> a[i];
		}
	}

	sorting(a);

	DisplayMin(a);
	DisplayMax(a);
	DisplayMean(a);
	DisplayMed(a);
	DisplayMode(a);

	return 0;
}

void DisplayMin(int x[])
{
	cout << "The smallest value in the array is: " << x[0] << endl;
}

void DisplayMax(int x[])
{
	cout << "The largest value in the array is: " << x[n-1] << endl;
}

void DisplayMean(int x[])
{
	double ave;
	int sum = 0;

	for (int i = 0; i<n; i++)
		sum += x[i];
	ave = sum;
	ave /= n;

	cout << "The average of all values in the array is: " << fixed<< setprecision(2)<<ave << endl;
}

void DisplayMed(int x[])
{
	int mid = n / 2;

	cout << "The value in the middle of the array once all values have been sorted is: ";
	if (n % 2 == 0 && x[mid] != x[mid - 1])
		cout << x[mid - 1] << " and ";
	cout << x[mid] << endl;
}

void DisplayMode(int x[])
{
	int number = x[0];
	int mode = number;
	int count = 0;
	int countMode = 0;

	for (int i = 0; i < n; i++)
	{
		if (x[i] == number)
		{ 
			count++;
		}
		else
		{ 
			if (count > countMode)
			{
				countMode = count;
				mode = number;
			}
			count = 0; 
			number = x[i];
		}
	}

	cout << "The value in the array which occurs most often is: " << mode << endl;
}

void sorting(int a[])
{
	int minIndex = 0;
	for (int i = 0; i < n - 1; i++)
	{
		minIndex = i;
		for (int currentIndex = i + 1; currentIndex < n; currentIndex++)
		{
			if (a[currentIndex] < a[minIndex])
			{
				minIndex = currentIndex;
			}
		}
		if (minIndex != i)
		{
			int temp = a[i];
			a[i] = a[minIndex];
			a[minIndex] = temp;
		}
	}
}