/*
 Name: Michael Thatcher
 
 Student Number: 200 353 864
 
 Assignment 5: CS 110
 
 Program Name: Informational Integer Calculator WITH FUNCTIONS PART 2
 
 Date: April 10, 2015
 
 Problem statement:
Write a program to read up to 20 integers from a file and store the integers in an array of integer type. With the values in the array, compute and display the following:
    Minimum
    Maximum
    Mean
    Median
    Mode
 
 USE FUNCTIONS TO COMPLETE ABOVE
 
 Input: 20 integer values from "integers.txt" file
 
 Output: Minimum, Maximum, Mean, Median, and Mode
 
 Algorithm: receive input for 20 integers. Use functions to calculate min, max, mean, median, and mode seperately
 
 USE FUNCTIONS TO MAKE CODE IN int main() EASIER TO READ
 
 Major variables: | MAX_ARRAY | a[] | index | max | min | sum | median | mean | mode
 ALL variables stored as integers except when calculating mean where the mean is stored as double
 
 Assumptions: Input file will only contain integer numbers
 
 Program limitations: Limited functionality for numbers that are not integers. Doesn't ensure text file is properly formatted, only that it properly opens.
 
 */



#include <iostream>
#include <fstream> // used for input file


using namespace std;

void min(int a[], int MAX_ARRAY, int index); // function to determine the minimum
void max(int a[], int MAX_ARRAY, int index); // function to determine the maximum
void mean(int a[], int MAX_ARRAY, int index);// function to determine the mean
void median (int a[], int MAX_ARRAY, int index);// function to determine the median
void mode (int a[], int MAX_ARRAY); // function to determine the mode
int main() // start of the main function
{
    
    ifstream myfile ("integers.txt"); // prepares to open the input file
    
  
    
   
    const int MAX_ARRAY = 20; // sets the Array size, change this if you want more/fewer numbers to be read from the file
    
    int a[MAX_ARRAY]; // array used to store integer numbers from integers.txt
    int index; // index value used for loops
   
    
    // commented out below code, code was used for user input instead of input from a file
    /*
    for (index = 0; index < MAX_ARRAY; index++)
    {
        cout << "Please input 20 integer numbers for the array element: " << endl;
        cin >> a[index];
    }
    
    */
    
    if(myfile.is_open()) // ensures file can be opened, won't proceed unless it can
    {
       
      
        
        for(index = 0; index < MAX_ARRAY; ++index) // loop to read integers into array
        {
            myfile >> a[index]; // reads integers into array
        }
    }
    
   
  
    // Below 5 are all function calls for their respective function
    
    min(a, MAX_ARRAY, index);
    max(a, MAX_ARRAY, index);
    mean(a, MAX_ARRAY, index);
    median (a, MAX_ARRAY, index);
    mode (a, MAX_ARRAY);
    
    

    
    
    return 0;
}


void min(int a[], int MAX_ARRAY, int index) // Minimum function
{
    int min = a[0]; // set minimum value to first number in array
    
    
    
    for (index = 0; index < MAX_ARRAY; index++) // loop to find lowest value
        if (a[index] < min) // if a[index] is less than current min value, change min value to a[index]
        {
            min = a[index];
        }
    cout << "The minimum value is " << min; // prints out minimum value
    cout << endl; // sets new line
   
}




void max (int a[], int MAX_ARRAY, int index) // Maximum function
{
int max = a[0]; // set maximum to first number in array

for (index = 0; index < MAX_ARRAY; index++) // loop to find greatest number
if (a[index] > max) // if the position of the index in the array is greater than the max
{
    max = a[index]; // new max at index position
}

cout << "The maximum value is " << max << endl; // print out max to console
    
}





void mean(int a[], int MAX_ARRAY, int index) // Mean function
{
    double sum = 0; // sum of double point for decimal precision
    for (index = 0; index < MAX_ARRAY; index++) // loop to sum all numbers in array
    {
        sum = sum + a[index]; // creates sum of array
    }
    
    double mean = sum / MAX_ARRAY; // determines mean by dividings sum by MAX_ARRAY
    
    
    cout << "The mean is " << mean << endl; // prints out mean to console
}





void median(int a[], int MAX_ARRAY, int index) // median function
{
    
    sort(a, a + MAX_ARRAY); // use standard sort function
    
    // used below code to test print out of input numbers, and to properly format median/mode
    
    /*
    
    for (int i = 0; i < MAX_ARRAY; ++i)
        cout << a[i] << ' ';
    
    cout << endl;
     
     */
    
    if (MAX_ARRAY % 2 == 0) // if there are an even amount of numbers
    {
    
        int median_position_low = MAX_ARRAY / 2 - 1; // finds the low number in median
        int median_position_high = MAX_ARRAY / 2; // finds high number in median
    
        double median = (a[median_position_high] + a[median_position_low]) / 2; // takes the average of the high & low median values
        
        cout << "The median is: " << median << endl; // prints out median to console
    
    }
    
    else // if there are an odd amount of numbers
    {
        int median_position = MAX_ARRAY / 2 + 1; // find the middle position by dividing by 2 (integer division) and adding one)
        cout << "The median is " << a[median_position]; // prints out the median for odd number of inputs
    }
    
    

}



// THE ARRAY HAS ALREADY BEEN SORTED IN ORDER FROM MEDIAN FUNCTION
// SAMPLE NUMBERS : 3 12 12 23 23 24 53 56 56 74 74 85 123 123 211 464 542 546 2343 4755


void mode(int a[], int MAX_ARRAY) // int a[] is the name of the array, MAX_ARRAY is a constant for the number of values in the array (in this case, 20),
{
    
    int counter = 1;  // this will count how many times the number has occured
    int max = 0; // used to determine which number occurs the most
    int mode = a[0]; // this starts the mode at the first position in the array. My array is named a[]
    for (int i = 0; i < MAX_ARRAY - 1; i++) // use a variable i to run a loop through the length of the array
    {
        if ( a[i] == a[i+1] ) //if the previous number = the number next to it in the array, the counter is incremented
        {
            counter++;
            if ( counter > max ) // if the counter is greater than the previous max value for mode, it replaces it
            {
                max = counter; // max will replace previous counter value
                mode = a[i]; // mode is now equal to whatever a[i] is, i value will be based on what iteration of the loop is occuring
            }
        } else
            counter = 1; // if number occurs more than once, but doesn't occur more than the current mode it resets the counter for the loop
    }
    
    // Need to create something that prints out all numbers that occur max times
    // use another variable, j, to determine the counter value
    
    cout << "The mode(s) is/are : " ; // prints out mode
    for (int i = 0; i < MAX_ARRAY; i++)
    {
        if (max < 1)// if all numbers occur only once, then no mode
        {
            cout << "NO MODE"; // will print out NO MODE if all numbers occur only once
            break;
        }
    else if (a[i] == a[i+max-1]) // if the array positin + the value of max (number of times mode occured) - 1 is equal to the a[i]
         cout << a[i] << " "; // prints out number because it is one of the modes
     
    }

    cout << endl; // prints a line break
    
    
    
}




// END OF PROGRAM