//**************************************************************************
//
// Student name: Juan Echavarria
//
// Student number: 200360759
//
// Assignment number: 5
//
// Program name: 2015-04-07_CS110_Ass5.cpp
//
// Date written: 09-04-2015
//
// Problem statement:  Write a program to read up to 20 integers from a file and store the integers in an array of integer type. With the values in the array, compute and display the following:
//minimum: smallest value in the array
//maximum : largest value in the array
//mean : average of all values in the array
//median : the value in the middle of the array once all values have been sorted.If there is no single index at the middle of the array, average the values in the 2 adjacent spots.For example : if the array has 3 values(with indices 0, 1, 2), once the array is sorted the median will be at index 1. If the array has 4 values(with indices 0, 1, 2, 3), once the array is sorted the median will be the average of the values at indices 2 and 3.
//mode : find the value in the array which occurs most often.A straightforward approach is possible once the array is sorted.
//Use a function for each computation / output specified above.You will also need to include a sort function : see Listing 7.11 from the text.
//
//
// Input: array of 20 elements, because it is not specified the imput of the user.
//
// Output: minimum, maximum, mean, median, mode.
//
// Major variables: i, min, max, x, mod,ms, a, j, temp, arr[21],arr1[900000];
// Assumptions:The array is fiexed to be always 20 becasue there is no speficiaction of the user input to know how many numbers are in the file.
//
//
//**************************************************************************

#include "iostream"
#include "fstream"
#include "iomanip"
using namespace std;

void fileopen();
void read();
void bubbleSort();
void outarr();
int minimum(int);
int maximum(int);
float mean(float);
float median(float);
void mode();
int i, min, max, x, mod,ms, a, j, temp, arr[21],arr1[900000];
float avg, med, mef;
ifstream inData;

int main(){
	
	fileopen();
	read();
	bubbleSort();
	outarr();

	cout << "The minimum value is:" << minimum(min) << '\n'
		<< "The maximum value is:" << maximum(max) << '\n'
		<< "The mean value is:" << mean(avg) << '\n'
		<< "The median value is:" << median(med) << '\n'
		<< "The mode value(s) is/are:";  mode();
	cout << endl;
}

void fileopen(){
	inData.open("inputfile.txt");
	if (!inData)
		cout << "error opening the file" << endl;
}

void read(){

	for (i = 0; i <= 19; i++){
		inData >> x;
		arr[i] = x;
	}
}

void bubbleSort(){
	for (i = 0; i <=18; i++){
		for (j = i + 1; j <=19; j++){
			if (arr[i] > arr[j]){
				temp = arr[i];
				arr[i] = arr[j];
				arr[j] = temp;
			}
		}
	}
}

void outarr(){
	for (i = 0; i < 20; i++){
		cout << '\n' << arr[i] << '\n';
	}
}

int maximum(int max1){
	for (i = 0; i < 20; i++){
		if (arr[i]>max)
			max = arr[i];
	}
	return max;
}

int minimum(int min1){
	min = maximum(max);
	for (i = 0; i < 20; i++){
		if (arr[i] < min)
			min = arr[i];
	}
	return min;
}

float mean(float avg1){
	for (i = 0; i < 20; i++){
		avg += arr[i];
	}
	avg = ((float)avg)/i;
	return avg;
}

float median(float med1){
	med = ((float) arr[9] + (float) arr[10]) / 2;
	return med;
}

void mode(){
	for (i = 0; i < 20; i++)
		arr1[arr[i]]++;
	for (i = 0; i < max; i++)
		if (arr1[i] > ms)
			ms = arr1[i];
	for (i = 0; i < max; i++)
		if (ms == arr1[i])
			cout << "Number " << i << " times "<< arr1[i] << endl;
}