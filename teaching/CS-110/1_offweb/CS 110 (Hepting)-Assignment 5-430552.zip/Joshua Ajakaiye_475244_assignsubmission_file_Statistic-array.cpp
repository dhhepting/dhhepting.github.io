////////////////////////////////////////////////////////////////////////////////////////////////
//Student Name: Joshua AJakaiye
//Student number: 200348270
//Assignment number: 5
//Program name: Statistic-array
//Date Written: 4/10/2015
//Problem statement: to to find the smallest value in an array, largest value in an array,
//                   average of all the values in the array, the median of the array, the 
//                   most occurring number in the array.
//Input: 20 numbers into an input file
//Output: Min, Max, Mean, Median, Mode
//Main Algorithm: fill in values of an array with a for loop.
//                use a for loop to find the smallest number in the array.
//                use a for loop to find the largest number in the array.
//                set a declared vareiable to the first character of the array
//                add all the numbers in the array and divide them by the size of the array
//                to find mean.
//                sort the numbers in the array from ascending to descending order with a 
//                nested for loop and a swap system (temp).
//                find the median of the sorted numbers if its odd its the number at the
//                center if its even add the two numbers by the center and divide by two.
//                check for the most occuring number starting from the first.
//Major Variables: Array, arraysize, max_value, min_value, max, min, Mean, Median, Mode
//Assumptions: none, cant think of one
//Limitations: can only process for 20 numbers in array size
////////////////////////////////////////////////////////////////////////////////////////////////
#include<iostream>
#include<fstream>
using namespace std;

// function prototype
void Min(double [], int arraysize);

// function prototype
void Max(double [], int arraysize);

// function prototype
void Mean(double [], int arraysize);

// function prototype
void Sort(double [], int arraysize);

// function prototype
void Median(double [], int arraysize);

// function prototype
void Mode(double[], int arraysize);

int main()
{
	// declare a const double for array size 
	const int arraysize = 20;
	double Array[arraysize];

	// declare an input file stream and open a file
	ifstream inData;
	inData.open("input.txt");

	if (!inData)
	{
		cout << "wrong input file, request to open input.txt failed. Exiting.." << endl;
		return 1;
	}

	//fill in the value of array
	for (int i = 0; i < arraysize; i++)
	{
		inData >> Array[i];
	}


	// function call
	Min(Array, arraysize);

	// function call
	Max(Array, arraysize);

	// function call
	Mean(Array, arraysize);

	// function call
	Sort(Array, arraysize);

	// function call
	Median(Array, arraysize);

	// function call
	Mode(Array, arraysize);

	return 0;

}
void Min(double Array[], int arraysize)
{
	// set min to be the first value of the array
	int min_value = Array[0];

	// test array element to find the min
	for (int index = 0; index < arraysize; index++)
	{
		// is the current element smaller than min_value
		if (Array[index] < min_value)
		{
			min_value = Array[index];
		}
	}
	cout << "The minimum value in the array is: " << min_value << endl;
}
void Max(double Array[], int arraysize)
{
	// set max to be the first value of the array
	int max_value = Array[0];

	// test array element to find the max
	for (int index = 0; index < arraysize; index++)
	{
		// is the current element larger tghan the max_value
		if (Array[index] > max_value)
		{
			max_value = Array[index];
		}
	}
	cout << "The maximum value in the array is: " << max_value << endl;
}
void Mean(double Array[], int arraysize)
{
	double sum = Array[0];
	for (int index = 0; index < arraysize; index++)
	{
		sum += Array[index];    // adds all the numbers in the array
	}
	double Mean = sum / arraysize;    // calculation to determine the mean from the numbers in the array
	cout << "The Mean of the array values is: " << Mean << endl;
}
void Sort(double Array[], int arraysize)
{
	// nested for loop to sort the numbers in the array in ascending form.
	for (int i = arraysize - 1; i > 0; i--)
	{
		for (int index = 0; index < 19; index++)
		{
			if (Array[index] > Array[index + 1])
			{
				int temp = Array[index + 1];
				Array[index + 1] = Array[index];
				Array[index] = temp;
			}
		}
	}
		// display content of array
	cout << "the numbers in the array in ascending form is: ";
		for (int i = 0; i < arraysize; i++)
		{
			cout << Array[i] << " ";
		}
		cout << endl;
		
}
void Median(double Array[], int arraysize)
{
	// calculation of the median (middle number)
	if (arraysize % 2 != 0)
	{
		// is the number of elements odd
		int temp = ((arraysize + 1) / 2) - 1;
		cout << "The median is " << Array[temp] << endl;
		cout << endl;
	}
	else
	{
		// then it's even
		cout << "The median is " << (Array[(arraysize / 2) - 1] + Array[arraysize / 2])/2 << endl;
		cout << endl;
	}
}
void Mode(double Array[], int arraysize)
{
	int counter = 1;   // to keep count of the number of feedbacks
	int max = 0;       // declaration and initialization
	double Mode = Array[0];      // to make sure mode detection starts from the first position in the array

	for (int i = 0; i < arraysize; i++)
	{
		if (Array[i] == Array[i + 1])
		{
			counter++;
			if (counter > max)
			{
				max = counter;             // max replaces the prev counter value if counter is bigger
				Mode = Array[i];
			}
		}
		else
			counter = 1;         // initializes the counter back to one
	}
	cout << "The mode of the given set of numbers is: ";

	if (max == 1)
	{
		cout << "No Modes found" << endl;
	}
	else
	{
		int j = 0;
		while (j < arraysize)
		{
			if (Array[j] == Array[j + max - 1])    // condition works if Array is a mode
			{
				cout << Array[j] << " ";        // prints out the mode
				j += max;
				cout << endl;
			}
			else
			{
				j++;
			}
		}

	}
}

	

