// Student Name: Jessica Shepherd
// Student Number: 200341982
// Assignment Number: 5
// Program Name: The Deadly 5 M's
// Date Written: April 9 & 10, 2015
// Problem Statement: Have user input 20 numbers and calculates max, min, mean, median and mode
// Input: 20 numbers
// Output: Min, Max, Median, Mode and Mean
// Algorithm: Have the program take numbers from the array and calculate the deadly 5 m's
// Major variables: Mean, min, max, median and mode, and MAX_ARRAY (i dont know if this is a variable)
// Assumptions: Hopefully works with all numbers, ****PREWARNING**** I could not get median to work so I gave up
// Program limitations: Median does not work Sorry :(
//***************************************************************************************************************

#include <iostream>

using namespace std;

int main ()
{
    const int MAX_ARRAY = 20;
    
    int  a[MAX_ARRAY];
    
    
    int  index;
    
    // Ask users to enter values for array a[].
    for (index = 0; index < MAX_ARRAY; index++)
    {
        
        cout << "Please input 20 numbers for the array element: ";
        cin >> a[index];
    }
    
    
    
    int max = a[0];
    
    for (index = 1; index < 20; index++)
        
        if (max < a[index])
        {
            max = a[index];
        }
    

    for (index = 0; index < 1; index++)
    {
        cout << "The maximum number of the array is " << max << endl;
       
    }
    
    // fix minimum
    
    int min = a[0];
    
    for (index = 1; index <20; index++)
        
    if (min > a[index])
    {
        min = a[index];
    }
    
    
    
    for (index = 0; index < 1; index++)
    {
        cout << "The minimum number of the array is " << min << endl;
        
    }

    
    
    //
    
    int mean;
    mean = a[0];
    
    for (index = 1; index < 20; index++)
    {
        mean += (a[index]);
        mean = mean % 20;
    }
    
    for (index = 0; index < 1; index++)
    {
        cout << "The mean of the array is " << mean << endl;
    }
    
    
    //
    
    int median;
    median = a[0];
    
    for (index = 1; index < 20; index++)
    {
        median = 0;
    }
    
    for (index = 0; index < 1; index++)
    {
        cout << "The median of the array is " << median << endl;
    }
    
    // Sorry, I could not figure out how to get the median of the numbers :(
    
    
    
    int mode;
    mode = a[0];
    
    if (max == 1)
    {
        cout << "No modes found" << endl;
    }
    else
    {
                int i = 0;
        while (i < MAX_ARRAY - max + 1)
        {
            if (a[i] == a[i+max-1])
            {
                cout << a[i] << " ";
                i += max;
            }
            else
            {
                i++;
            }
        }
    
    for (index = 0; index < 1; index++)
    {
        cout << "The mode of the array is " << mode << endl;
    }
    
    
    
    return 0;
    
}
}
    
    
