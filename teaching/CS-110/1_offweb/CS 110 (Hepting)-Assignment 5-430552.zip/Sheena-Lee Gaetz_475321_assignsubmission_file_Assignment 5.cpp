// 
//**************************************************************************
//
// Student name: Sheena-Lee Gaetz
//
// Student number: 200317727
//
// Assignment Number: 5
//
// Program Name: Calculations using Arrays
//
// Date written: April 1, 2015
//
// Problem statement: Read 20 integers and calculate the maximum value, minimun value
// the mean, median, and mode.
//
// Input: 1 to 20 integers
//
// Output: Max value, Min value, mean, median, mode.
//
// Algorithm: Use separate functions to calculate everything. Use a variety of if statements and while loops.
// A sort function is used before calculating the mode and median to make it easier.
//
// Major variables: number[20], min, max, mean,  mode, median
//
// Assumptions: The user will enter 20 integers
//
// Program limitations: Only works with 20 integers.
//
//**************************************************************************
# include <iostream>
using namespace std;

int ComputeMin(int number[]); //function protoytpes
int ComputeMax(int number[]);
double ComputeMean(int number[]);
void SortArray(int number[], int listsize);
void PrintSorted(int number[]);
int ComputeMode(int number[]);
double ComputeMedian(int number[]);


int main()
{
	cout << "Please enter 20 integer: " << endl; 
	int number[20]; //array initialization

	for (int i = 0; i < 20; i++) //for loop to get all 20 integers
	{
		cin >> number[i];
	}
	
	cout << "The minimun value is: " << ComputeMin(number) << endl; //funcion calls
	cout << "The maximum value is: " << ComputeMax(number) << endl;
	cout << "The mean value is: " << ComputeMean(number) << endl;
	SortArray(number, 20);
	cout << "The array sorted is: " << endl;
	PrintSorted(number);
	cout << "The mode value is: " << ComputeMode(number) << endl;
	cout << "The median is: " << ComputeMedian(number) << endl;

	return 0;

}


int ComputeMin(int number[]) //function for computing min value
{

	int min_array = number[0];
		
	
		for(int i = 0; i < 20; i++)
		{
			
			if (number[i] < min_array)
			{
				min_array = number[i];
			}
			
			
		}
		
		return min_array;
	}


int ComputeMax(int number[]) //Computing max value
{
	int max_array = number[0];


	for (int j = 0; j < 20; j++)
	{
		if (number[j]>max_array)
		{
			max_array = number[j];
		}
	}

	return max_array;
}


double ComputeMean(int number[]) //computing mean
{
	double sum = 0;
	double mean;
	for (int k = 0; k < 20; k++)
	{
		 sum = sum + number[k];
	}
	mean = sum / 20.00;

	return mean;
}


void SortArray(int number[], int listsize) //Sorting the function
{
	for (int m = 0; m < listsize - 1; m++) //find the min value in number[]
	{
		int currentMin = number[m];
		int currentMinIndex = m;

		for (int n = m + 1; n < listsize; n++)
		{
			if (currentMin > number[n])
			{
				currentMin = number[n];
				currentMinIndex = n;
			}
		}
		if (currentMinIndex != m) //swap current number[m] withnumber[currentMinindex] if necessary
		{
			number[currentMinIndex] = number[m];
			number[m] = currentMin;
		}
	}

}


void PrintSorted(int number[]) //print the newly sorted array
{
	for (int i = 0; i < 20; i++)
	{
		cout << number[i] << " ";
	}
	cout << endl;
}


int ComputeMode(int number[]) //compute the mode
{
	int count = 1;
	int max = 0;
	int mode = number[0];

	for (int i = 0; i < 20; i++)
	{
		if (number[i] == number[i + 1])
		{
			count++;
			if (count > max)
			{
				max = count;
				mode = number[i];
			}

		}
		else
			count = 1;
	}

	return mode;
}


double ComputeMedian(int number[]) //compute the median
{
	double median = (number[9] + number[10]) / 2.00;
	return median;

}
