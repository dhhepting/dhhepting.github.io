// *********************************************************
//
// Student name: Rebekah Leppington
// Studnet number: 200 343 095
// Assignment number: 5
// Program name: Assignment5.cpp
// Date written: April 10, 2015
// Problem statement: This program will read upto 20 integers from a file, store those integers in an array
//                    sort the integers using Listing 7.11, then find the minimum, maximum, mean, median and mode.
// Input: None (integers from file are pre-made)
// Output: Sorted integers in the array, minimum, maximum, mean, median, and mode.
// Algorithm: The computer will use several functions to sort the integers in the array, then it will use other functions to find
//            the min, max, mean, median and mode.
// Major variables: arraySize, list[], selectionSort, printArray, inputfile, i, j, min_value, max_value, mean, median, mode, sum, rightSide, leftSide...
// Assumptions: None
// Program limitations: I was not able to correctly input the file values intime for the due date so I left it out to let it compile.
//                      The mode also repeats the set of modes the first mode value is...
//
//****************************************************************

#include <iostream>  // to use cin and cout and other basics
#include <fstream>   // for the file stuff

using namespace std;

void selectionSort(double[], int);             // Start of Listing 7.11
void printArray(double list[], int arraySize); // function prototype

ifstream inputfile;                            // declare an input file stream and open a file


int main()
{
	inputfile.open("testinput.txt");
	const int arraySize = 20;
	double list[arraySize] = { 9, 1, 2, 5, 4, 8, 6, 2, 8, 7, 7, 3, 6, 4, 9, 5, 3, 3, 7, 4 }; // integers from the file.
	
	cout << "Welcome to my last program of the year!" << endl;
	cout << "Lets find the min, max, mean, median and mode of an array." << endl;
	cout << endl;
	cout << endl;

	cout << "Original array: ";
	
	for (int i = 0; i < arraySize; i++)
	{
		cout << list[i] << " ";
	}
	cout << endl;


	selectionSort(list, 20);

	printArray(list, 20);

	// initialize an array of 20 integers
	int integer_array[20] = { 9, 1, 2, 5, 4, 8, 6, 2, 8, 7, 7, 3, 6, 4, 9, 5, 3, 3, 7, 4 };

	// set min_value and max_value to be the first of the values
	int min_value = integer_array[0];
	int max_value = integer_array[0];

	// find the maximum and minimum value in the array by 
	// testing each array element
	for (int index = 0; index < arraySize; index++)
	{
		// is the current element smaller than min_value?
		if (integer_array[index] < min_value)
		{
			min_value = integer_array[index];
		}
		// is the current element larger than max_value?
		if (integer_array[index] > max_value)
		{
			max_value = integer_array[index];
		}
	}
	cout << endl;
	cout << "The minimum value in the array is: " << min_value << endl;
	cout << "The maximum value in the array is: " << max_value << endl;
	cout << endl;

	// Finding the mean (average of all values in the array)

	double sum = 0;
	double mean = 0;
	
	for (int i = 0; i < arraySize - 1; list[i + 1]) // loop to add all array entries
	{
		sum += list[i];
		mean = sum / arraySize;
		i++;
	}
	cout << "The mean: " << mean << endl;

	// Finding the median (the value in the middle of the array once all values have been sorted)

	double median = 0;
	

	int i = arraySize / 2;

	if ((i == 0)
		|| (i == 2)
		|| (i == 4)
		|| (i == 6)
		|| (i == 8)
		|| (i == 10))
		{
			median = list[i];
		}
		if ((i == 1)
		|| (i == 3)
		|| (i == 5)
		|| (i == 7)
		|| (i == 9))
		{
			double rightSide = list[i - 1];
			double leftSide = list[i + 1];
			median = (rightSide + leftSide) / 2.0;
		}

	cout << "The median: " << median << endl;

	// Finding the mode

	int counter = 1;       // counts the number of repeats
	int max = 0;           // initialization
	double mode = list[0];    // mode starts at the first position in the array

	for (int i = 0; i < arraySize - 1; i++) // loop goes thru the array
	{
		if (list[i] == list[i + 1])         //if the first number equals the number next to it then the counter goes up 1
		{
			counter++;
			if (counter > max)              // compares counter and max value
			{
				max = counter;              // max will replace previous counter value if counter is bigger
				mode = list[i];
			}
		}
		else
			counter = 1; // if number occurs more than once, but doesn't occur more than the current mode it resets the counter for the loop
	}
	cout << "The mode: "; // outputs mode

	for (int i = 0; i < arraySize; i++)
	{
		if (max == 1)
		{
			cout << "No modes found" << endl;
		}
		else
		{
			if (mode == list[i])    // the if statement limits the mode output to 3 repeats rather than 20.
			{
				break;
			}
			int i = 0;
			while (i < arraySize)
			{
				if (list[i] == list[i + max - 1]) // true if list[i] is a mode
				{
					cout << list[i] << " "; // prints out number because it is one of the modes
					i += max;
				}
				else
				{
					i++;
				}
			}
		}
	}

	cout << endl;
	cout << endl;
	cout << "Goodbye CS110 <3 " << endl;

	return 0;
}

void selectionSort(double list[], int arraySize)
{
	for (int i = 0; i < arraySize; i++)
	{
		// Find the minimum in the list[i..listSize-1]
		double currentMin = list[i];
		int currentMinIndex = i;

		for (int j = i + 1; j < arraySize; j++)
		{
			if (currentMin > list[j])
			{
				currentMin = list[j];
				currentMinIndex = j;
			}
		}

		// Swap list[i] with list[currentMinIndex] if necessary;
		if (currentMinIndex != i)
		{
			list[currentMinIndex] = list[i];
			list[i] = currentMin;
		}
	}
}

void printArray(double list[], int arraySize)
{
	cout << "Sorted array: ";
	for (int i = 0; i < arraySize - 1; i++)
	{
		cout << list[i] << " ";
	}
}
