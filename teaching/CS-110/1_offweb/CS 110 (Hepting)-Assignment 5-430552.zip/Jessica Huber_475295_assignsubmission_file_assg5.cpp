
#include <iostream>
using namespace std; 

int MaxValue ( int[]);
int MinValue (int[]);
int array[20]={};
int index;
int MAX_ARRAY;
float find_average(array [20]); 
int find

int main()
{
	cout << "Enter 20 integers " << array << endl;
	cout << " The max value is:" << endl;
	int Max = MaxValue(array);
	cout << Max<< endl; 

	cout << "The min value is:" << endl ;
	int Min = MinValue(array);
	cout << Min << endl; 

//back(array);
return 0; 
}

int MaxValue( int x [])
{
	int Max= x[0];
	for( int i=0; i < MaxValue(array); i++)
	{
		if (Max < x[i])
		{
			Max= x[i];
		}
	}
	return Max;
} 

int MinValue( int x [])
{
	int Min = x[0];
	for ( int i=0; i > MinValue(array); i--)
	{
		if ( Min > x[i])
		{
			Min = x[i];
		}
	}
	return Min; 
}

 // here 
	int counter=1;
    int max = 0; 
    int mode = array [20];
    for (int i = 0; i < MAX_ARRAY - 1; i++) 
    {
        if ( x[i] == x[i+1] ) 
        {
            counter++;
            if ( counter > max ) 
            {
                max = cou.ter; 
                mode = a[i];            }
        } else
            counter = 1; 
    }
cout << "The modes are : " ; 
    for (int i = 0; i < MAX_ARRAY; i++)
    {
        if (max < 1)
        {
            cout << "NO MODE";        
			break; 
        }
    else if (a[i] == a[i+max-1])
		cout << a[i] << " "; 
		return 1; 
	}
}
