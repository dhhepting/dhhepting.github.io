/*Austin Schlosser
Student ID: 200352214
Assignment 5
Array information
April 6, 2015
Problem: Read an array up to 20 integers and calculate min, max, mean, median and mode
Input: 20 integers
Output: Min, max, mean, median and mode of integers
Algorithm: functions, addition, subtraction, for-loops
Varibles:minimum, maximum, occur, average, middle, mode, min, max, mode, avg, mini, maxi,
	sort, list, numbers, SIZE, size, count, median
Assumptions: Thu user only inputs integers, not letters
Limitations: Can only read up to 20 integers, no more
*/

#include <iostream>
using namespace std;

void sort(int list[], int size)		//Sorting the array in ascending order
{
for (int i=0; i<size-1;i++)
{
int minval=list[i];
int minindex=i;

for (int j=i+1; j<size; j++)
{
if (minval > list[i])
{
minval=list[j];
minindex=j;
}
}

if (minval != i)
{
list[minindex]=list[i];
list[i]=minval;
}
}
}
 

int min(int list [], int size)	//Finding minimum value
{
int mini=list[0];
for (int i=1; i<size; i++)
{
if (list[i] < mini)
{
mini=list[i];
}
}
return mini;		//Returning minimum value to main function
}


int maximum(int list[]. int size)	//Finding maximum value
{
int max=list[0];
for (int i=1; i<size; i++)
{
if (list [i] > max)
{
max=list[i];
}
}
return max;		//Returning maximum value to main funtion
}


int mean(int list[], int size)		//Calculating mean
{
double sum;
for (int i=0; i<size; i++)
{
sum +=list[i];		//Finding sum
}
avg=sum/size;
return avg;		//Returning mean to main function
}


int median(int list[],int size)		//Calculating median
{
int middle;
int i;
if (size%2==1)
{
i=size/2;		//Finding middle
middle=list[i];
}
if (size%2==0)
{
i=size/2;		//Finding average of the two middle terms
middle=(list[i]+list[i+1]);
}
return middle;		//Returning median to main function
}

int mode(int list[], int size)
{
int count=1;
int most=list[0];
for (int i=0; i<size; i++)
{
if (list[i]==list[i+1])
{
count ++;
}
else
{
coutn=1;
}
}
return count;
}




int main ()
{
int SIZE;	//Requesting size of array
cout <<"Please input size of deisred array to a maximum of 20." << endl;
cin >> SIZE;

int numbers[SIZE];	//Requesting integer input from user
cout << "Please input " << SIZE << " integers." << endl;
for (int i=0;i<SIZE;i++)
{
cin >> numbers[i];
}
int minimum;
int maximum;
double average;
int middle;
int occur;

minimum=min(numbers[SIZE], SIZE);	//Calling back functions
maximum=max(numbers[SIZE], SIZE);
average=mean(numbers[SIZE], SIZE);
middle=median(numbers[SIZE], SIZE);
occur=mode(numbers[SIZE], SIZE);

cout <<"The mimimum value is " << minimum << endl;	//Displaying values
cout <<"The maximum value is " << maximum << endl;
cout <<"The average is " << average << endl;
cout <<"The middle value is " << middle << endl;
cout <<"The most a value occurs is " << occur << " times." << endl;

return 0;
}
//end of program