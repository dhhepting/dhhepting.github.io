//**************************************************************************
//
// Student name: Brayden Tang
//
// Student number: 200350623
//
// Assignment number: 5
//
// Program name: Assignment 5- Writing a Program That Finds The Maximum Value, Minimum Value, The Mean, the Mode, and Median from up to Twenty Integers In a File
//
// Date written: April 9th, 2015
//
// Problem statement: Write a program to read up to 20 integers from a file and store the integers in an array of integer type. With the values in the array, compute and display the following:
//
//minimum: smallest value in the array
//maximum : largest value in the array
//mean : average of all values in the array
//median : the value in the middle of the array once all values have been sorted.If there is no single index at the middle of the array, average the values in the 2 adjacent spots.For example : if the array has 3 values(with indices 0, 1, 2), once the array is sorted the median will be at index 1. If the array has 4 values(with indices 0, 1, 2, 3), once the array is sorted the median will be the average of the values at indices 2 and 3.
//mode : find the value in the array which occurs most often.A straightforward approach is possible once the array is sorted.
//					 Use a function for each computation / output specified above.You will also need to include a sort function : see Listing 7.11 from the text.
// Input: A file called "numbers.txt" that will contain integers. Up to twenty integers from this file will be read.
//
// Output: The maximum value, minimum value, mean, median, and mode of the first twenty integers read.
//
// Algorithm: Depending on what we are finding, the algorithm varies. For the median and mode, the program takes advantage of the fact that the middle values will always be half of the total values or half of the total values + 1 (if the array size is even), or in the case of odd integers, the total array size divided by two and then rounded up. This is after assumption of the array being sorted first. For the mode calculation, the program takes advantage of the sort function again, and simply finds repeated numbers in the array that are next to each other. Then, the modes are outputted by knowing that the position of a mode will always be the position of a variable i in a loop that's being incremented + the maximum number of values in the mode, subtracted by one (for offset error).
// Major variables: 
//int minimum;
//int maximum;
//double mean;
//double median;
//ifstream input;
//int array1[20];
//int listsize = 0;
//
// Assumptions: That in the file, the values are integers in the file, and that the values are correctly formatted (ie. a single whitespace character seperating values). Also, that the file even exists (named properly, for instance).
// Program limitations: -Program can't read values other than integers, program can't read incorrectly formatted text files, and can't check if the file even exists (though this can be easily added).
//
//
//**************************************************************************



#include <iostream>  
#include <fstream> //for file streaming
#include <cmath> //for ceil function
using namespace std;

void minimumvalue(int array1[], int& minimum, int listsize)  //find the minimum
{
	minimum = array1[0];  //initialize minimum at position zero, ie. the first value in the array is the minimum
	for (int i = 0; i < listsize; i++)  //search the array
	{
		if (array1[i] < minimum)   //if the next position is less than the minimum
		{
			minimum = array1[i];  //then, the new miniumum is the checked array position at i
		}
	}
}
void maximumvalue(int array1[], int& maximum, int listsize)
{
	maximum = array1[0];   //initialize maximum at position zero, ie. the first value in the array is the maximum
	for (int f = 0; f < listsize; f++)  //search the array
	{
		if (array1[f] > maximum)  //if the next position is greater than the maximum
		{
			maximum = array1[f];  //then the new maximum is the checked array position at i
		}
	}
}
void meanofarray(int array1[], double& mean, int listsize)
{
	int sum = 0;
	mean = 0;
	for (int g = 0; g < listsize; g++)
	{

		sum = sum + array1[g];  //find the sum of the array by adding the corresponding array elements together
	}
	mean = sum / listsize;  //find the mean by dividing the sum of the array by the listsize of the array.
}
void sort(int array1[], int listsize)  //the sort function so that the median and mode functions can be used properly
{

	for (int i = 0; i < listsize - 1; i++)  
	{
		int currentmin = array1[i];  //initialize the current minimum to be position i
		int currentMinIndex = i;

		for (int j = i + 1; j < listsize; j++)  //check the next position
		{
			if (currentmin > array1[j])  //if the current minimum initialized at position i is greater than the next position
			{
				currentmin = array1[j];  //then the current min should be the value of the next position in the array
				currentMinIndex = j;
			}
		}
		if (currentMinIndex != i)  //if the index of the current min is not what it was originally, ie. the above if statement was run meaning that the array is out of order
		{

			array1[currentMinIndex] = array1[i];  //then, switch positions
			array1[i] = currentmin;
		}
	}

}
void FindMedian(int array1[], int listsize, double& median)
{
	int arrayposition = 0;
	int sum = 0;
	if (listsize % 2 == 0)  //even amount of numbers in the file
	{
		for (int f = 0; f < listsize; f++)
		{
			if (arrayposition == (listsize - 1) / 2 || arrayposition == ((listsize - 1) / 2) + 1)  //as explained in the Algorithm header, the middle values will always be the array size / 2 or the (array size / 2) + 1. By finding these values, we can then add them and divide by two to get the median. Note the -1 is for offset error since the list size is always 1 larger than the positions themselves.
			{
				sum = sum + array1[f];
			}
			arrayposition++;  
		}
		median = sum / 2.0;
	}
	else if (listsize % 2 != 0) //odd amount of numbers in the file
	{

		for (int g = 0; g < listsize; g++)
		{
			if (arrayposition == ceil(listsize - 1) / 2.0)  //in this case, we simply need to divide the list size by two and then round it up to get the middle position
			{
				median = array1[arrayposition];
			}
			arrayposition++;
		}

	}
}
void FindMode(int array1[], int listsize)  //find the mode
{

	int count_mode = 1;
	int max_numberofmode = 0;

	for (int j = 0; j < listsize - 1; j++)
	{
		if (array1[j] == array1[j + 1])  //if the next value in the array equals the previous value when sorted
		{
			count_mode++;  //increase the counter of corresponding values
			if (count_mode > max_numberofmode)  //if the counter for corresponding values is greater than the stored maximum number of values of a different mode, we have a new mode. 
			{
				max_numberofmode = count_mode;   
			}
		}
	else  //count mode will be reset to one once a new value is encountered
	{
				count_mode = 1;
	}
	

	}
	if (max_numberofmode < 1)  //if max_numberofmode stays at zero, the value it was initialized at, ie. if array1[x] never equals array1[x+1] than we know we have no mode (one of every digit)
	{
		cout << "No modes found." << endl;
	}
	else
	{
		cout << "The mode(s) are: "; 
		int i = 0;
		while (i < listsize)
		{
			if (array1[i] == array1[i + (max_numberofmode - 1)]) //if the number is a mode, it will be displayed if the position of array at i equals i + the maximum mode found, subtracted by one (found through pattern regonition)
			{
				cout << array1[i] << " "; 
				i += max_numberofmode;  //increment i by the max number of mode plus the position to skip over the other repetitions of the mode
			}
			else  //if no mode is found, increment i and keep searching
			{
				i++;
			}
		}
	}
}
int main()

{
	int minimum;
	int maximum;
	double mean;
	double median;
	ifstream input;  //declare file input stream called input
	input.open("numbers.txt");  //input file is called numbers.txt

	int array1[20];  //declare array of size twenty
	int listsize = 0;
	for (int i = 0; i < 20; i++)  //get up to the first twenty intergers from the file called numbers.txt
	{
		if (input >> array1[i])
		{
			listsize++;  //obtain the number of values in the file
		}
		else
		{
			break;  //if we can't get anymore values from the file, break out of the loop at that is the end of the file
		}
	}

	minimumvalue(array1, minimum, listsize);  //call to get miniumum from the array
	cout << "The minimum value is " << minimum << "." << endl;
	maximumvalue(array1, maximum, listsize);  //call to get maximum
	cout << "The maximum value is " << maximum << "." << endl;
	meanofarray(array1, mean, listsize);  //call to get mean
	cout << "The mean of the array is " << mean << "." << endl;
	sort(array1, listsize);  //call to sort array
	FindMedian(array1, listsize, median);  //call to find median
	cout << "The median of the array is " << median << "." << endl;
	FindMode(array1, listsize); //call to get mode(s)

	return 0;
}

//end of program