/*
Student name: Brooke Ham
Student number: 200353759
Assignment number: 5
Program name: I Don't Have Enough Ingenuity to Devise a Neat Programming Name
Date: written for Apr. 10, 2015
Problem Statement: Write a program to read up to 20 integers from a file and store the integers in an 
	array of integer type. With the values in the array, compute and display the following:
		1. minimum: smallest value in the array
		2. maximum: largest value in the array
		3. mean: average of all values in the array
		4. median: the value in the middle of the array once all values have been sorted. If there is no 
			single index at the middle of the array, average the values in the 2 adjacent spots. For 
			example: if the array has 3 values (with indices 0,1,2), once the array is sorted the median 
			will be at index 1. If the array has 4 values (with indices 0,1,2,3), once the array is 
			sorted the median will be the average of the values at indices 2 and 3.
		5. mode: find the value in the array which occurs most often. A straightforward approach is possible 
			once the array is sorted.
Input: A series of up to 20 integers from a file
Output: The minimum value, maximum value, mean, median, and mode
Algorithm: The program will read up to 20 integers from a file and compute and print specific values in 
	functions (making use of for loops)
Major variables: inData, num, index, i, j, array, min, max, median, mode, middle, numEl, average, temp, 
	element, low, high, count, max
Assumptions: The program will compile and run correctly, no syntax or logic or runtime errors are present 
	in the code, integers are in the file and are formatted correctly, there are 20+ integers in tthe file
Program Limitations: Integers are contained in the file and are formatted correctly
*/

#include <iostream>
#include <fstream>																			// Header is used for file input and output

using namespace std;

void Min(int[], int);																		// Function parameters
void Max(int[], int);
void Mean(int[], int);
void Median(int[], int);
void Sort(int[], int);
void Mode(int[], int);

int main()
{
	cout << "Hallo, I'm about to give you some really cool " << endl;						// Output to user
	cout << "information about the numbers in the file \"input.txt\"." << endl;
	cout << endl;
	
	ifstream inData;																		// Declaring a variable for the input file
	inData.open("input.txt");																// Opens the file
	
	int array[20];																			// An array with 20 integer spaces is declared
	int num = 0;																			// num is assigned the value zero

 	while (num < 20)																		// Maximum of 20 integers are to be inputted
	{
		while (!inData.eof())																// No inputs will be taken in if there are no more integers to be inputted
		{
			inData >> array[num];
			
			if (array[num] % 1 == isdigit(array[num]))
			{
				cout << "There was a non-integer value in the file \"input\"." << endl;
				cout << "The program will now quit." << endl;
				
				return 0;
			}

			num++;
		}
	}
	
	for (int index = 0; index < num; index++)				// REMOVE LATER
	{
		cout << array[index] << ", ";
	}
	
	Min(array, num);																	// Function calls
	Max(array, num);
	Mean(array, num);
	Sort(array, num);
	Median(array, num);
	Mode(array, num);
	
	return 0;
}

void Min(int a[], int numEl)															// Function definition for minimum
{
	int min = a[0];																		// The first integer in the array is assigned to the variable min
	for (int index = 0; index < numEl; index++)											// Each integer in the array is tested, and if it is smaller in value than the
	{																					// variable min is assigned the smaller value
		if (a[index] < min)
			min = a[index];
	}
	cout << "The minimum value is: " << min << endl;									// The minimum value is printed
}

void Max(int a[], int numEl)															// The maximum is found using a similar method to find the minimum
{
	int max = a[0];
	for (int index = 0; index < numEl; index++)
	{
		if (a[index] > max)
			max = a[index];
	}
	cout << "The maximum value is: " << max << endl;
}

void Mean(int a[], int numEl)															// Function definition for mean
{																						// The sum is found by adding all the values of the integers in the array
	int sum = 0;																		// The average is equivalent to the sum divided by the number of elements in the arrat
																						// The average is a double to avoid excluding the integer from the average
	for (int index = 0; index < numEl; index++)
	{
		sum += a[index];
	}

	double average = static_cast<double>(sum) / numEl;
	cout << "The mean value is: " << average << endl;
}

void Sort(int a[], int numEl)															// Function defintion for sort
{																						// Each integer is tested with the integer stored after it, and if the previous integer is
	for (int i = 0; i < numEl; i++)														// larger, then the placement of the integers is switched
	{
		for (int j = 0; j < numEl; j++)
		{
			if (a[i] < a[j])
			{
				int temp = a[j];
				a[j] = a[i];
				a[i] = temp;
			}
		}
	}
	for (int i = 0; i < 20; i++)					// REMOVE LATER
		cout << a[i] << ", ";
}

void Median(int a[], int numEl)															// Function definition for median
{																						// If the number of elements is odd, then the highest element value is even, 
	double middle;																		// and the middle element is the 0.5 times the element value
	if (numEl % 2 == 1)
	{
		int element = (numEl - 1) / 2;
		middle = a[element];
	}

	else																				// If the number of elements is even, then the highest element value is odd, and
	{																					// the middle is an average of the two elements that are closest to the middle of the array
		int low = numEl / 2;
		int high = (numEl / 2) + 1;
		middle = (a[low] + a[high]/ 2.0);
	}
	cout << "The median value is: " << middle << endl;
}

void Mode(int a[], int numEl)															// Function definition for mode
{					
	int count = 1;																		// Every number in the array is included at least once
	int max = 0;
	int mode = a[0];																	// The mode is initally set to the first integer

	for (int index = 0; index < numEl - 1; index++)										// Each integer in the array is tested
	{																					// If the element in the sorted array is equal to the element beside it, then
		if (a[index] == a[index + 1])													// the number occurs more than once and the count is incremented
		{
			count++;

			if (count > max)															// For a series of similar numbers to be a mode, they have to occur more times than 
			{																			// other numbers
				max = count;
				mode = a[index];
			}
		}

		else
			count = 1; 																	// The count is reset if the number didn't occur more times than the current mode
	}

	if (max != 1)	
		cout << "The mode value is: " << mode << endl;

	else															// If no numbers were repeated in the array, then no mode was present
		cout << "There was no mode." << endl;
}