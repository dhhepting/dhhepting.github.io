// Kian Blanchette
// 200354600
// Assignment 5
// The Wackness
// 9 April 2015
// Problem Statement: Write a program that reads up to 20 values from a file into an integer array. Using these values find the min, max, mean, median and mode.
// Input: Integer values from a file.
// Output: The minimum value, the maximum value, the mean value, the median value and the mode of the values read from the file.
// Algorithm: Read values from a file into an integer array and count how many values were read. Call the function Min to find the minimum value in the array. Call
//			  the function Max to find the maximum value in the array. Call the function Mean to calculate the mean of all the values in the array. Call the function
//			  Sort to sort the values in the array in ascending order. Call the function Median to find the median value of the array. Call the function Mode to find
//			  the mode, if it has one (or more).
// Major Variables: maxArray - This is the highest number of values that will be read into the array. It is set at 20.
//					num[] - The array I am using.
//					numCount - The number of values read from the file into the array.
// Assumptions: I assume that the file contains only integer values.
// Program Limitations: As it is the program only uses 20 values, but that can be easily changed. Also, it doesn't work properly for non-integer numbers.
#include <iostream>
#include <fstream> 
using namespace std;
// Function prototypes! They all use my array num[] and the array size numCount.
void Sort(int[], int);
void Min(int [], int);
void Max(int [], int);
void Mean(int [], int);
void Median(int [], int);
void Mode(int [], int);
int main()
{
	
	ifstream input;
	input.open("TooManyCooks.txt");

	const int maxArray = 20; // Initialize the array, the highest possible array size, and the actual array size.
	int num[maxArray];
	int numCount = 0;

	for (int i = 0; i < maxArray; i++) // Read the file into the array and count how many values there are.
	{
		if (input >> num[i])
		{
			numCount++;
		}
		else break;
	}
	// Function calls!
	Sort(num, numCount);
	Min(num, numCount);
	Max(num, numCount);
	Mean(num, numCount);
	Median(num, numCount);
	Mode(num, numCount);
		
	return 0;
}
void Sort(int num[], int nc) // I sort my array first to simplify the subsequent functions.
{
	for (int i = 0; i < nc - 1; i++)
	{
		int currentMin = num[i]; // Initialize the currentMin to the number in the i position and the currentMinIndex to i.
		int currentMinIndex = i;

		for (int j = i + 1; j < nc; j++)
		{
			if (currentMin > num[j]) // Check the positions after i for numbers smaller than currentMin. If there are any, set currentMin to their values and
			{						 // currentMinIndex to the position where the smaller value appeared.
				currentMin = num[j];
				currentMinIndex = j;
			}
		}
		if (currentMinIndex != i) // If the indices of the initial min and the currentMin aren't equal, swap their positions.
		{
			num[currentMinIndex] = num[i];
			num[i] = currentMin;
		}
	}
}
void Min(int num[], int nc) // Since the array is sorted in ascending order, the minimum is the first value in the array.
{
	int min = num[0];
	cout << "Min: " << min << endl;
}
void Max(int num[], int nc) // Since the array is sorted in ascending order, the maximum is the last value in the array.
{
	int max = num[nc - 1];
	cout << "Max: " << max << endl;
}
void Mean(int num[], int nc) // This sums all the values in the array and then divides by how many there are to determine the mean.
{
	int sum = 0;
	for (int i = 0; i < nc; i++)
		sum += num[i];
	float mean = float(sum) / nc;
	cout << "Mean: " << mean << endl;
}

void Median(int num[], int nc) // This gets the median by picking the value in the middle index if there are an odd number of values, or by taking the average of 
{							   // the two middle values if there are an even number of values.
	double median;
	if (nc % 2 == 1)
	{
		median = num[nc / 2];
	}
	else median = double(num[nc / 2 - 1] + num[nc / 2]) / 2;
	cout << "Median: " << median << endl;
}
void Mode(int num[], int nc) // This gets the mode or modes if they exist by checking if two consecutive values are the same and increasing the counter if they are.
{							 // If a new number becomes the mode, the variable max is set to count and the loop continues until all the values have been checked.
	int count = 1;			 // If all the values appear once, there is no mode, and if multiple values appear the highest amount of times, there are multiple modes.
	int max = 0;
	for (int i = 0; i < nc - 1; i++) 
	{
		if (num[i] == num[i + 1]) // Check if the values are the same as the next one in the array.
		{
			count++; // If they are increment the count.
			if (count > max) // If the count excedes the previous max, the number in position i is the new mode.
			{
				max = count;
			}
		}
		else count = 1; // If a new number is encountered, this sets the value of count back to 1.
	}
	cout << "Mode(s):";
	for (int i = 0; i < nc; i++)
	{
		if (max == 0) // If max = 0 it is because no number appeared in the array more than once, so it has no mode.
		{
			cout << "There is no mode." << endl;
			break;
		}
		else if (num[i] == num[i + max - 1]) // This takes care of the possibility of multiple modes by checking if any other number appears the same number of times
			cout << " " << num[i];			 // consecutively.
	}
	cout << endl;
}