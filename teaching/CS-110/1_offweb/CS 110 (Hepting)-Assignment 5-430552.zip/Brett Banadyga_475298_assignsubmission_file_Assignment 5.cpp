/*
Name: Brett Banadyga
Student #: 200318551
Assignment #5
Program Name: Computing List of Numbers
Date Written: April 8, 2015
Problem Statement: Write a program to read up to 20 integers from a file and store the integers in an array of integer type. With the values in the array, compute and display the following: 
�minimum: smallest value in the array
�maximum: largest value in the array
�mean: average of all values in the array
�median: the value in the middle of the array once all values have been sorted. If there is no single index at the middle of the array, average the values in the 2 adjacent spots. For example: if the array has 3 values (with indices 0,1,2), once the array is sorted the median will be at index 1. If the array has 4 values (with indices 0,1,2,3), once the array is sorted the median will be the average of the values at indices 2 and 3.
�mode: find the value in the array which occurs most often. A straightforward approach is possible once the array is sorted.

*/


#include <iostream>
#include <fstream>
using namespace std;

float computeMax(float[]); //defines functions
float computeMin(float[]);
float computeMean(float[]);
float computeMedian(float[]);
float computeMode(float[]);

int main()
{
	ifstream indata;
	indata.open("numbers.txt");
	if (!indata)
	{
		cout << "Could not open file." << endl; // Makes sure that indata is defined
		return 1;
	}

	float numArray[20]; // makes array of size 20
	
	for (int i = 0; i < 20; i++)
	{
		indata >> numArray[i];
		
		if (indata.eof())
		{
			cout << "Ran out of Data." << endl;
			return 2;
		}
	}


	for (int i = 0; i < 20; i++) //Sorts array into ascending order
	{
		float currentMin = numArray[i];
		int currentMinIndex = i;

		for (int j = i + 1; j < 20; j++)
		{
			if (currentMin > numArray[j])
			{
				currentMin = numArray[j];
				currentMinIndex = j;
			}
		}

		if (currentMinIndex != i)
		{
			numArray[currentMinIndex] = numArray[i];
			numArray[i] = currentMin;
		}
	}

	float min;
	float max;
	float mean;
	float median;
	float mode;

	max = computeMax(numArray);//Function calls
	min = computeMin(numArray);
	mean = computeMean(numArray);
	median = computeMedian(numArray);
	mode = computeMode(numArray);


	cout << "The maximum value is: " << max << endl;
	cout << "The minimum value is: " << min << endl;
	cout << "The mean is: " << mean << endl;
	cout << "The median is: " << median << endl;
	cout << "The mode is: " << mode << endl;

	return 0;
}

float computeMax(float numArray[])
{
	float max = numArray[0];
	for (int i = 1; i < 20; i++)
	{
		if (numArray[i]> max)
		{
			max = numArray[i];
		}
	}
	return max;
}

float computeMin(float numArray[])
{
	float min = numArray[0];
	for (int i = 1; i < 20; i++)
	{
		if (numArray[i]< min)
		{
			min = numArray[i];
		}
	}
	return min;
}
float computeMean(float numArray[])
{
	float sum = 0;
	for (int i = 0; i < 20; i++)
	{
		sum = sum + numArray[i];
	}
	float mean;
	mean = sum / 20;
	return mean;
}

float computeMedian(float numArray[])
{
	float median;
	median = (numArray[9] + numArray[10]) / 2;
	return median;
}

float computeMode(float numArray[])
{
	int count = 1;
	int maxcount = 0;
	float mode = numArray[0];

	for (int i = 0; i < 20; i++)
	{
		if (numArray[i] == numArray[i + 1])
		{
			count++;
			if (count > maxcount)
			{
				maxcount = count;
				mode = numArray[i];
			}
		}
		else
		{
			count = 1;
		}
	}
	return mode;
}