/*
Name: Mfonisoabasi James
Student number: 200344498
Assignment 5
Program name: Assignment five.cpp
Date written: 3/11/2015
Problem statement: This program computes maximum, minimum and average values in an array
Input: inData
Output: cout
Algorithm: 1. create a text file for to put in values
2. create an array to collect values from the file
3. create functions to compute the maximum, minimum and average values
4. display values to the console
Major variables: 1. const int arrays
2. a[arrays]
3. i
4. inData
Assumptions: The assumption made is that the user would follow the instructions given
Program limitations: The algorthm only handles maximum, minimum and average values computations
*/

#include <iostream>
#include <fstream>
using namespace std;
void maximum(float x[], int, int); //declaring functions
void minimum(float y[], int, int);
void average(float z[], int, int);
int main()
{
	

	const int arrays = 12;
	float a[arrays];
	int i;
	ifstream inData;

	inData.open("inputfile.txt"); // binding inData to the input file "input.txt"
	

	
	for (i = 0; i < arrays; i++)
	{
		inData >> a[i];
		

	}


	for (i = 0; i < arrays; i++)
	{
		cout << a[i] << endl;
	}

	//calling fumctions
	maximum(a, i, arrays);
	minimum(a, i, arrays);
	average(a, i, arrays);

	return 0;
}
// computing maximum value
void maximum(float x[], int, int max)
{


	int maxvalue = x[0];
	for (int index = 0; index < max; index++)
	{
		if (maxvalue < x[index])
		{
			maxvalue = x[index];
		}

	}
	cout <<"The maximum value in the array is:" << maxvalue << endl;

	return;
}
//computing minimum values
void minimum(float y[], int, int min)
{


	int minvalue = y[0];
	for (int index = 0; index < min; index++)
	{
		if (minvalue > y[index])
		{
			minvalue = y[index];
		}

	}
	cout << "The least value in the array is:" << minvalue << endl;

	return;
}
// computing avareage
void average(float z[], int, int max)
{
	float sum = 0;
	float avg;

	for (int i = 0; i < max; i++)
	{
		sum += z[i];
		
		avg = sum / max;
		
	}
	cout << "The average value of arrays:" << avg << endl;

	return;
}