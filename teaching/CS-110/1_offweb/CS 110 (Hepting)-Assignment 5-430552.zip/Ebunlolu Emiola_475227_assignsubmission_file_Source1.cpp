#include <iostream>
#include <iomanip>
#include <fstream>

using namespace std;

void selectionSort(float[], const int);

void getMin(float[], float &, const int);

void max(float[], float &, const int);

void avg(float[], float &, const int);

void median(float[], float &, const int);

void mode(float[], float &, const int);

const int SIZE = 20;

int main()
{

	float a[SIZE];
	float med;
	float average;
	float maximum;
	float minimum;
	float mod;
	ifstream inData;
	inData.open("Text1.txt");
	while (!inData)
	{
		cout << "Could not read input file. Exiting. . ." << endl;
		return 1;
	}
	while (inData)
	{
		for (int i = 0; i < SIZE; i++)
		{
			inData >> a[i];
		}
	}
	selectionSort(a, SIZE);
	cout << "After sorting .... :" << endl;
	for (int i = 0; i < SIZE; i++)
	{
		cout << a[i] << " ";
	}
	cout << endl;
	getMin(a, minimum, SIZE);

	max(a, maximum, SIZE);

	avg(a, average, SIZE);

	median(a, med, SIZE);

	mode(a, mod, SIZE);

	cout << mod << minimum << maximum << average << med;


	return 0;
}

void selectionSort(float a[], const int SIZE)
{
	float t;
	float p;
	int i = 0;
	while (i<SIZE)
	{
		if (a[i + 1] < a[i])
		{
			t = a[i];
			p = a[i + 1];
			a[i + 1] = t;
			a[i] = p;
		}
		i + 2;
	}
}

void getMin(float a[], float &b, const int)
{
	b = a[0];
}

void max(float a[], float &b, const int)
{
	b = a[19];
}

void avg(float a[], float &b, const int)
{
	float sum = 0.0;
	for (int i = 0; i < SIZE; i++)
		sum += a[i];
	b = sum / SIZE;
}

void median(float a[], float &b, const int)
{
	if (SIZE % 2 == 0)
		b = (a[SIZE / 2] + a[SIZE / 2 + 1]) / 2;
	
}

void mode(float a[], float &b, const int)
{
	float number = a[0];
	float mode = number;
	int count = 1;
	int countMode = 1;

	for (int i = 1; i<SIZE; i++)
	{
		if (a[i] == number)
		{ // count occurrences of the current number
			countMode++;
		}
		else
		{ // now this is a different number
			if (count > countMode)
			{
				countMode = count; // mode is the biggest ocurrences
				mode = number;
			}
			count = 1; // reset count for the new number
			number = a[i];
		}
		b = mode;
	}
}

