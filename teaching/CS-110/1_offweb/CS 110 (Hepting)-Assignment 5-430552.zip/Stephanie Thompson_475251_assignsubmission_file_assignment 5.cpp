//*****************************************************************
//
// Student name: Stephanie Thompson
//
// Student number: 200355041
//
// Assignment number: Assignmnet 5
//
// Program name: Array Calculator
//
// Date written: April 10, 2015
//
// Problem statement: The user needs to know the maximum, minimum, mean, median, and mode in an array.
//
// Input: An input file called "inputvalues.txt" will provide the array with a maximum of twenty values.
//
// Output: The program will output the maximum, minimum, mean, median, and mode of the array.
//
// Algorithm: The program opens a '.txt' file to get input for an array of maximum size twenty.  The program will then call a series of functions to provide information to
//				the user.  The first function will sort the values (to make other calculations simpler) from least to greatest of the values from the file.  The next function
//				will find the maximum value in the array and display it to the user.  The third function will find the minimum value in the array and display it to the user.
//				The fourth function will find the mean value in the array and display it to the user.  The fifth function will find the median value in the array and display 
//				it to the user.  The sixth function will find the mode value in the array and the number of times it occurs in the array and display it to the user.
//				
// Major variables: The major variables in the program include a[], i, and MAX_ARRAY.
//
// Assumptions: The file will contain only integer values.
//
// Program limitations: The program calculates for a maximum of 20 integer values from the file.
//
//*******************************************************************************
#include <iostream>
#include <fstream>
using namespace std;

// Function prototypes
void sort(int[], int);
void maximum(int[], int);
void minimum(int[]);
void mean(int[], int);
void median(int[], int);
void mode(int[], int);

int main()
{
	// Initializing and declaration of variables
	const int MAX_ARRAY = 20;
	int i = 0;
	int a[MAX_ARRAY];
	// Opening an input file to get values for the array
	ifstream input;
	input.open("inputvalues.txt");

	// Starts a loop that tests when the file contains no more values
	while (!input.eof())
	{
		if (i == MAX_ARRAY) // If the number of values read is the same as the maximum value the array can hold the program will exit the loop (no more input values will be read)
		{
			break;
		}
		input >> a[i];
		i++;
	}

	// Calling functions to sort the array and find the: maximum, minimum, mean, median, and mode
	sort(a, i);
	maximum(a, i);
	minimum(a);
	mean(a, i);
	median(a, i);
	mode(a, i);

	return 0;
}

// Definition of functions
void sort(int a[], int total) // From lisitng in the textbook, sorts the array in order of least to greatest
{
	int i = 0;
	for (i = 0; i < total - 1; i++)
	{
		double currentmin = a[i];
		int currentminindex = i;
		for (int j = i + 1; j < total; j++)
		{
			if (currentmin > a[j])
			{
				currentmin = a[j];
				currentminindex = j;
			}
		}
		if (currentminindex != i)
		{
			a[currentminindex] = a[i];
			a[i] = currentmin;
		}
	}
	cout << "The values in the array are: " << endl;
	for (i = 0; i < total; i++)
	{
		if (i == total - 1)
		{
			cout << "and " << a[i] << endl;
			break;
		}
		cout << a[i] << ", ";
	}
}

void maximum(int a[], int maxvalue) // Function finds the maximum value in the array
{
	int i = 0;
	int maximum = a[i];
	for (i = 0; i < maxvalue; i++) // Starts a loop to find the maximum by comparing values until the largest is found
	{
		if (a[i] > maximum)
		{
			maximum = a[i];
		}
	}
	cout << "The maximum value in the array is: " << maximum << endl; // Displays the maximum to the user
}

void minimum(int a[]) // Function finds the minimum value in the array
{
	int minimum = a[0]; // After the function is sorted the minimum is the first value in the array
	cout << "The minimum value in the array is: " << minimum << endl; // Displays the minimum to the user
}

void mean(int a[], int total) // Function finds the mean value in the array
{
	double mean = 0;
	double sum = 0;
	int i;
	// Starts a loop to find the sum of all the values in the array
	for (i = 0; i < total; i++)
	{
		sum += a[i];
	}
	// Calculates the mean from the sum and number of values in the array
	mean = sum / total;
	cout << "The mean value in the array is: " << mean << endl; // Displays the mean to the user
}

void median(int a[], int total) // Function to find the median value in the array
{
	double median;
	median = a[(total - 1) / 2]; // Calculates the median by finding the value of the halfway point in the array
	cout << "The median in the array is: " << median << endl; // Displays the median to the user
}

void mode(int a[], int total) // Function finds the mode value in the array
{
	int mode = a[0];
	int modecount = 1;
	// Displays the mode and the number of occurences to the user
	cout << "The mode in the array is: " << mode << endl;
	cout << "The mode in the array occurs " << modecount << " number of times." << endl;
}