
//Name: Rana Mujahid Tariq
//Student #: 200-321-914
//Assignment #: 5

//Program name: FIND MAX, MIN, Medium, MODE, MEAN from input file.
// Date: April 06, 2015
// Problem Statement: Make an array that reads upto 20 integers from a input file and stores them in an array. Then calculates the 
//						min, max, medium, mode, and mean.
//input: Takes input form a input file;
//output; displays the result on screen.
//major variables: min, total, count, sum, mean, mode, max, medium
// assumptions: program reads exactly 20 integers from file.
// program limitations: program can only read up to 20 integers and inputs can't be taken form keyboard;
// Algorithm: <fstream>, <iostream>


#include <iostream>
#include <fstream>
using namespace std;

//TRIED TO FIGURE OUT HOW TO SOLVE FOR MEDIUM BY SORTHING ARRAYS FROM SECTION 7.11 but could not do it.

// void selectionSort(int total[], int listSize)
//{
//for (count = 0; count < total; count++) 
//{
	//if (int min = total[count];
	//int current minindex = count;
	//for (int j =count + 1; j < listsize; j++) 
	//{
		//if (current minindex > total[j])
		//{
			//min = total[j];
			//current minindex =j;
		//}
	//}
	//if (current minindex != count)
	//{
		//list[current minindex] = total[count];
		//list[count] = min;
	//}
//}
//}

int main()
{
	ifstream inData;
	ofstream outData;
	inData.open ("INPUTS.txt");
	outData.open ("OUTPUTS.txt");

	if (!inData)
	{
		cout << "cant open input file" << endl;
		return 1;
	}
	
	const int total = 20;
	int n[total];
	int count;
	for (count = 0; count < total; count++) // gets input for all the arrays
	{
		inData >> n[count];
	}
	
	for (count = 0; count < total; count++) // outputs all the arrays
	{
	outData << n[count] << endl;
	cout << n[count] << endl;
	}

	int max; // this parts calculates the largest value
	max = n[0];
	for  (count = 0; count < total; count++)
	{
		if (n[count] > max)
		{ 
			max = n[count];
		}
	}
	cout << "The maximum number is: " << max << endl;

	int min; // this part calculates the smallest value
	min = n[0];
	for (count = 0; count < total; count++)
	{
		if (n[count] < min)
		{ 
			min = n[count];
		}
	}
	cout << "The smallest number is: " << min << endl;

	int sum = 0;
for (count = 0; count < total; count++) // sum of all the values
	{
		sum += n[count];
	}

int mean = sum/total;  // average of all the values
	cout << "The average is: " << mean << endl;




	return 0;
}

