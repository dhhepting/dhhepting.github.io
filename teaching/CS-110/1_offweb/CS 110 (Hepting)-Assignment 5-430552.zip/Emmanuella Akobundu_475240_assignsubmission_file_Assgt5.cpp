//Name: Emmanuella Akobundu
//
//Class: CS 110
//
//Assignment: 5
//
//Student number: 200359057
//
// Program name: Program determining the maximum, minimum, mean, median, and mode of the values in the array
//				 contained in an input file
//
// Date written: 10 April, 2015
//
// Problem statement: This code read up to 20 integers from a file and store the integers in an array
//
// Input: Integers are gotten from input file
//
// Output: The outputs are the maximum, minimum, mean, median, and mode of the values in the array
//
// Algorithm: In order to solve the assigned problem, the computer is first instructed to sort the array
//			  then the minimum, maximum, mean, median, and mode of the values in the array are calculated
//			  using functions.
//
// Major variables: The size of the array, MAX_ARRAY, and the array, intarray[].
//					Major varibles also include: selectionSort(int[], int), printArray(int[], int), minVal(int[], int), 
//					maxVal(int[], int), meanVal(int[], int), medVal(int[], int), modeVal(int[], int).
//
// Limitations: none


#include <iostream>
#include <fstream>

//Function prototype
using namespace std;

void selectionSort(int[], int);
void printArray(int[], int);
int minVal(int[], int);
int maxVal(int[], int);
double meanVal(int[], int);
void medVal(int[], int);
void modeVal(int[], int);

int main()
{
	// declare a const int for array size and use this in code
	const int MAX_ARRAY = 20;
	int intarray[MAX_ARRAY];

	// declare an input file stream and open a file
	ifstream inputfile;
	inputfile.open("readinput.txt");

	// declare and initialize a counter for number of integers read
	int uniqueints = 0;
	bool isUnique = true;

	// try to read at most MAX_ARRAY integers from the input file
	for (int i = 0; i < MAX_ARRAY; i++)
	{
		int inputval;
		if (inputfile >> inputval)
		{
			// if an integer has been read, 
			// test if it is unique before storing 
			// it in the array
			// break out of loop as soon as value is
			// identified as NOT unique
			for (int j = 0; j < uniqueints; j++)
			{
				if (inputval == intarray[j])
				{
					isUnique = false;
					break;
				}
			}
			// if it is unique, store it and increment the
			// counter of unique integers in the array
			if (isUnique)
			{
				intarray[uniqueints] = inputval;
				uniqueints++;
			}

		}
		else
		{
			break; // if value not read, break out of loop
		}
	}
	// display the array here:
	// value of uniqueints after the loop is the number of integers 
	// in the array: maximum value of uniqueints (when loop ends 
	// normally) is MAX_ARRAY
	cout << "Array from file: ";
	for (int i = 0; i < uniqueints; i++)
	{
		 cout << intarray[i] << " ";
	}
	cout << endl;

	selectionSort(intarray, MAX_ARRAY);
	printArray(intarray, MAX_ARRAY);
	cout << endl;
	cout << "The minimum value in the array is: " << minVal(intarray, MAX_ARRAY) << endl;
	cout << endl;
	cout << "The maximum value in the array is: " << maxVal(intarray, MAX_ARRAY) << endl;
	cout << endl;
	cout << "The mean value in the array is: " << meanVal(intarray, MAX_ARRAY) << endl;
	cout << endl;
	medVal(intarray, MAX_ARRAY);
	cout << endl;
	modeVal(intarray, MAX_ARRAY);
	cout << endl;

	return 0;
}



void selectionSort(int list[], int listSize)
{
	for (int i = 0; i < listSize; i++)
	{
		// Find the minimum in the list[i..listSize-1]
		int currentMin = list[i];
		int currentMinIndex = i;

		for (int j = i + 1; j < listSize; j++)
		{
			if (currentMin > list[j])
			{
				currentMin = list[j];
				currentMinIndex = j;
			}
		}

		// Swap list[i] with list[currentMinIndex] if necessary;
		if (currentMinIndex != i)
		{
			list[currentMinIndex] = list[i];
			list[i] = currentMin;
		}
	}
}

void printArray(int list[], int arraySize)
{
	cout << "Sorted loop: ";
	for (int i = 0; i < arraySize - 1; i++)
	{
		cout << list[i] << " ";
	}
}


//Now that loop is sorted, the minimum value will be the first value in the array
//and the maximum value will be the last in the array.

int minVal(int list[], int size)
{
	int minimum = list[0];
	int i;
	for (i = 0; i < size; i++)
	{
		if (list[i] < minimum)
			minimum = list[i];
	}
	return minimum;
}


int maxVal(int list[], int size)
{
	int maximum = list[0];
	int i;
	for (i = 0; i < size; i++)
	{
		if (list[i] > maximum)
			maximum = list[i];
	}
	return maximum;
}

double meanVal(int list[], int size)
{
	int i;
	int sum = 0;
	for (i = 0; i < size; i++)
	{
		sum += list[i];
	}
	double mean = static_cast<double>(sum / size);
	return mean;
}


void medVal(int list[], int size)
{
	int medpos1 = size / 2;
	int medpos2 = (size / 2) - 1;
	
	if (size % 2 == 0)
	{
		double median = static_cast<double>((list[medpos1] + list[medpos2]) / 2);
		cout << "The median is: " << median << endl;
	}
	else
	{
		cout << "The median is " << list[medpos1] << endl;
	}
}

void modeVal(int list[], int size)
{
	int counter = 1;  // this will count how many times the number has occured
	int max = 0; // used to determine which number in the array occurs the most, iitialized to 0
	int mode = list[0]; // this starts the mode at the first position in the array
	for (int i = 0; i < size - 1; i++) // use a variable i to run a loop through the length of the array
	{
		if (list[i] == list[i + 1]) //if the previous number = the number next to it in the array, the counter is incremented
			//but only if there is a mode in the function
		{
			counter++;
			if (counter > max) // if the counter is greater than the previous max value for mode, it replaces it
				//if there is no mode, this part will be skipped
			{
				max = counter; // max will replace previous counter value. If there is no mode, max remains at initialized value
				mode = list[i]; // mode is now equal to whatever a[i] is, i value will be based on what iteration of the loop is occuring
			}
		}
		else
			counter = 1; // if number occurs more than once, but doesn't occur more than the current mode it resets the counter for the loop
	}

	if (max < 1)// if all numbers occur only once, then no mode and max will equal zero
	{
		cout << "No modes found" << endl;// will print out NO MODE if all numbers occur only once
	}
	else
	{
		cout << "The mode(s) is/are : "; // prints out mode
		int i = 0;
		while (i < size - max + 1)
		{
			if (list[i] == list[i + max - 1]) // true if a[i] is a mode
			{
				cout << list[i] << " "; // prints out number because it is one of the modes
				i += max;
			}
			else
				i++;
		}
	}
}