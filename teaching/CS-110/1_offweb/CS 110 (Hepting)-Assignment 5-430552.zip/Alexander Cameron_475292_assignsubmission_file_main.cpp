/***********************************************************************************************************
 Student Name: Alexander Cameron
 
 Student Number: 200 246 288
 
 Assignment Number: 5
 
 Program Name: Diget Processor With Functions
 
 Date Written: 10 April, 2015
 
 Problem Statement: This program is created to accept an array, sort it in ascending order, find the smallest and largest values, as well as the mean, median, mode

 Input: up to 20 numbers into a text file
 
 Output: smallest and largest value, the mean, median, and mode, as well the ascenfing order of the values
 
 Algorithm: The file will be opened and the numbers stored into an array using the get array function. Next the selection sort function will be called to sort the values of the file into ascending order. Next, the minArray and maxArray functions will be called to find the smallest and largest values respectively. Next the printArray function will be called to print the array in ascending order. Finally, meanArray will be called to output the average, medianArray will be called to output the middle most value, and the modeArray function will be called to output the most common number.
 
 Major Variables: int, arrays.
 
 Assumptions: assumes the user is putting in integers, no more than 20 values input
 Program Limitations: digits that have been spaced out, can read just a long mess of numbers
 
 
 ********************************************************************************************************/

#include <iostream>
#include <fstream>

using namespace std;


void getArray (int a[],int& max, int toomany);
void sortArray(int a[], int max);
void minArray(int a[], int max);
void maxArray(int a[], int max);
void printArray(int a[], int max);
void meanArray(int a[], int max);
void medianArray(int a[], int max);
void modeArray(int a[],int max);

int main()
{
    
    int p=20;
    int num[p];
    
    
    

  
    
    getArray (num,p,p);   //call to function getArray
    sortArray(num, p);  //call to function selectionsort
    printArray(num,p);  //call to function printArray, this will list the array out
    minArray(num,p);    //call to function minArray to output the smallest number
    maxArray(num,p);    //call to function maxArray to output the largest number
    meanArray(num,p);   //call to function meanArray to ouput the average
    medianArray(num, p);//call to function medianArray to output then
    modeArray(num,p);   //call to function modeArray to ouput the most common number
    
    return 0;
    
}



//getArray is a function that will open a textfile, and add each of the numbers into an array

void getArray (int a[],int& max,int toomany)
{
   
    ifstream inputfile; //initialize the input stream from the file
    inputfile.open("testinput.txt"); //open the file
    int k=0;  //set a counter to 0 to keep track of the number of items read
    while(!inputfile.eof()&&k<=toomany)//keep reading numbers while the file is not finished and the file is less than or = 20
    {
        inputfile >> a[k]; //take an integer from the file and add to an array
        k ++;              //increment the counter
    }
    inputfile.close(); //when file is done, close the file.
    max=k-1;           //set max to one less than the count because on the last trial it will increment up and then break loop, so really
                       //we have one more number than
}



void sortArray(int a[], int max)
{
    for (int i = 0; i <= max+1; i++)
    {
        // Find the minimum in the list[i..listSize-1]
        double currentMin = a[i];
        int currentMinIndex = i;
        
        for (int j = i + 1; j < max+1; j++)
        {
            if (currentMin > a[j])
            {
                currentMin = a[j];
                currentMinIndex = j;
            }
        }
        
        // Swap list[i] with list[currentMinIndex] if necessary;
        if (currentMinIndex != i)
        {
            a[currentMinIndex] =a[i];
            a[i] = currentMin;
        }
    }
}

//function to print the array

void printArray(int a[], int max)
{
    cout<<"The array in ascending order is: ";
    for (int j=0;j<=max; j++) //while the array still has numbers, cout the numbers at each step, increment by one
    {
        cout<<a[j]<<" ";
    }
    cout<<endl;
    
}
//reads the array, finds the smallest number

void minArray(int a[], int max)
{
    int min=a[0]; //initialize it to the first number
    for (int i=1;i<max;i++) //read through the array
    {
        if (min>a[i])//if the tried value is smaller than the current min, replace it with the smaller number
            min=a[i];
    }
    cout<<"The smallest value is "<<min<<endl;
    
    
}
//reads the array, looks for largest number

void maxArray(int a[], int max)
{
    int large=a[0]; //set largest number to the first integer
    for (int i=1;i<max+1;i++)
    {
        if (large<a[i]) //if the next number is larger than the first, replace it
            large=a[i];
    }
    cout<<"The largest value is "<<large<<endl;
    
    
}
//read array, find the average value

void meanArray(int a[], int max)
{
    int sum=0; //initialize sum to zero
    for (int j=0;j<max; j++)
    {
        sum+=a[j]; //add together all of the array values
    }
    float avg=(sum/static_cast <float>( max)); //take the average, set max to float to get decimal values
    cout<<"The Mean is: "<<avg<<endl;
}

//read array, find the middle value

void medianArray(int a[], int max)
{
    int median=0;
    float med=0;//set median to float, for if we are taking average of two middle points
    float x=0;
    float z=0;
    max++;
    if (max%2==0)  //if it is an even number of values
    {
        x=a[max/2-1]; //find the middle diget to the left of center
        z=a[(max/2)]; //find the middle diget to the right of center
        med=(x+z)/2.0; //add the values together and divide by 2 to find the averag
        cout<<"The Median is "<<med<<endl;
    }
    else
    {
        median=a[(max/2)]; //otherwise, take the middle value
        cout<<"The Median is "<<median<<endl;
    }
    
}


void modeArray(int a[],int max)
{
    
    int counter = 1;  // this will count number of occurances
    int most = 0; // determines the most occurring number
    int mode = a[0]; // this starts the mode at the first position in the array
    for (int i = 0; i <=max-1; i++) // use a variable i to run a loop through the length of the     array
    {
        if ( a[i] == a[i+1] ) //if the previous number = the number next to it in the array, the counter is incremented
        {
            counter++;
            if ( counter > most ) // if the counter is greater than the previous most common value for mode,replace it
            {
                most = counter; // most will replace previous counter value
                mode = a[i]; // mode is now equal to a[i] 
            }
        }
        
        else
            counter = 1; // if number occurs more than once, but doesn't occur more than the current mode it resets the counter for the loop
    }
    cout << "The mode(s) is/are : " ; // prints out mode
    for (int i = 0; i < max; i++)
    {
        if (most < 1)// if all numbers occur only once, then no mode
        {
            cout << "NO MODE"; // will print out NO MODE if all numbers occur only once
            break; // need to break out of loop so NO MODE doesn't print MAX_ARRAY # of times
        }
        else if (a[i] == a[i+most-1]) // if the array position + the value of max (number of times mode occured) - 1 is equal to the a[i]
            cout << a[i] << " "; // prints out number because it is one of the modes
    }
}

