/*Name: Zackary Hubelit
Student ID: 200351286
Assignment 5
Arrays
April 10, 2015
Problem: Read an array up to 20 integers and calculate min, max, mean, median and mode
Input: 20 integers
Output: Min, max, mean, median and mode of integers
Algorithm: functions, addition, subtraction, for-loops
Varibles: SIZE, minimum, maximum, average, middle, occur
Assumptions: Thu user only inputs integers, not letters
Limitations: Can only read up to 20 integers, no more
*/

#include <iostream>
using namespace std;

void sort(int[], int);
int min(int[], int);
int max(int[], int);
double mean(int[], int);
int median(int[], int);
int mode(int[], int);




int main ()
{
	const int SIZE = 20;	//Requesting size of array

	int numbers[SIZE];	//Requesting integer input from user
	cout << "Please input " << SIZE << " integers." << endl;

	for (int i = 0; i < SIZE; i++)
	{
		cin >> numbers[i];
	}

	int minimum;
	int maximum;
	double average;
	int middle;
	int occur;

	minimum=min(numbers, SIZE);	//Calling back functions
	maximum=max(numbers, SIZE);
	average=mean(numbers, SIZE);
	middle=median(numbers, SIZE);
	occur=mode(numbers, SIZE);

	cout <<"The mimimum value is " << minimum << endl;	//Displaying values
	cout <<"The maximum value is " << maximum << endl;
	cout <<"The average is " << average << endl;
	cout <<"The middle value is " << middle << endl;
	cout <<"The most a value occurs is " << occur << " times." << endl;

	return 0;
}

void sort(int list[], int size)		//Sorting the array in ascending order
{
	for (int i = 0; i<size - 1 ;i++)
	{
		int minval = list[i];
		int minindex = i;

		for (int j = i +1 ; j < size; j++)
		{
			if (minval > list[i])
			{
				minval = list[j];
				minindex = j;
			}
		}

		if (minval != i)
		{
			list[minindex] = list[i];
			list[i] = minval;
		}
	}
}


int min(int list [], int size)	//Finding minimum value
{
	int min = list[0];
	for (int i = 1; i < size; i++)
	{
		if (list[i] < min)
		{
			min = list[i];
		}
	}
	return min;		//Returning minimum value to main function
}


int max(int list[], int size)	//Finding maximum value
{
	int max = list[0];
	for (int i = 1; i < size; i++)
	{
		if (list[i] > max)
		{
			max = list[i];
		}
	}
	return max;		//Returning maximum value to main funtion
}


double mean(int list[], int size)		//Calculating mean
{
	double sum = 0;
	for (int i = 0; i < size; i++)
	{
		sum += list[i];		//Finding sum
	}
	double avg = sum/size;
	return avg;		//Returning mean to main function
}


int median(int list[],int size)		//Calculating median
{
	int middle;
	int i;
	i = size/2;		//Finding middle
	middle = list[i];
	return middle;		//Returning median to main function
}

int mode(int list[], int size)
{
	int count = 1;
	int most = list[0];
	for (int i = 0; i < size; i++)
	{
		if (list[i] == list[i+1])
		{
			count ++;
		}
		else
		{
			count = 1;
		}
	}
	return count;
}


//end of program