/*
Name: Naizhao Tan
Student number: 200353140
Assignment number: 5
Program Name: Assignment5
Program Due: Apr 04 2015
Date: Apr 10 2015
problem statement:
Write a program to read up to 20 integers from a file and store the integers in an array of integer type. With the values in the array, compute and display the following:

minimum: smallest value in the array
maximum: largest value in the array
mean: average of all values in the array
median: the value in the middle of the array once all values have been sorted. If there is no single index at the middle of the array, average the values in the 2 adjacent spots. For example: if the array has 3 values (with indices 0,1,2), once the array is sorted the median will be at index 1. If the array has 4 values (with indices 0,1,2,3), once the array is sorted the median will be the average of the values at indices 2 and 3.
mode: find the value in the array which occurs most often. A straightforward approach is possible once the array is sorted.
Use a function for each computation/output specified above. You will also need to include a sort function: see Listing 7.11 from the text.

input:  77 1 6 55 4 8 92 595 51 64 649 597 521 26 59 56 9 13 -24 -5
output:
Minimum value in this array: -24
Maximum value in this array:  649
Average value in this array:  142.7
Median in this array:         55.5
No mode because no number occers twice time

algorithm:
Step 1. Read in the array from the file 'input.txt'
Step 2. Calculate required values in each function
Step 3. Call the function and show the result

major variables:
array1[]: The array used to save numbers from the file
min: Minimum number in the array
max: Maximum number in the array
mode: The number which occers most often in the array
median: The median number in the array
mean: The average in the array
size: The length of the array

program limitations:
It will return only one number in the mode function, so it will not work properly if there are more than one mode

*/




#include <iostream>
#include <fstream>
using namespace std;

// The function prototype
double getMin(double[], int);
double getMax(double[], int);
double getMean(double[], int);
void sorting(double[], int);
double getMedian(double[], int);
double getMode(double[], int);

int main(){
	// Defining variables and open the file
	ifstream inData;
	double array1[20];
	double min, max, mode;
	const int size = 20;
	double mean, median;
	inData.open("input.txt");

	// Put numbers in the file into the array
	for (int i = 0; i < size; i++){
		inData >> array1[i];
	}
	// Function call
	sorting(array1, size);
	min = getMin(array1, size);
	max = getMax(array1, size);
	mean = getMean(array1, size);
	median = getMedian(array1, size);
	mode = getMode(array1, size);

	// Show the result
	cout << "Minimum value in this array: " << min << endl;
	cout << "Maximum value in this array: " << max << endl;
	cout << "Average value in this array: " << mean << endl;
	cout << "Median in this array: " << median << endl;
	if (mode == 0){
		cout << "No mode because no number occers twice time" << endl;
	}
	else{
		cout << "Mode in this array: " << mode << endl;
	}



}
// Function definition

double getMin(double array1[], int size){
	double min = array1[0];
	// Use for loop to get the minimum number
	for (int i = 0; i < size; i++){
		if (min >= array1[i]){
			min = array1[i];
		}
	}
	return min;
}

double getMax(double array1[], int size){
	double max = array1[0];
	// Use for loop to get the maximum number
	for (int i = 0; i < size; i++){
		if (max <= array1[i]){
			max = array1[i];
		}
	}
	return max;
}

double getMean(double array1[], int size){
	double sum = 0;
	double mean;
	// Get sum of the array
	for (int i = 0; i < size; i++){
		sum += array1[i];
	}
	// Calculate the average
	mean = static_cast<double>(sum) / 20;
	return mean;
}

void sorting(double array1[], int size){

	// Sorting the array by using two for loops
	for (int i = 0; i < size - 1; i++){
		double currentMin = array1[i];
		int currentMinIndex = i;
		for (int j = i + 1; j < size; j++){
			// Swap the position
			if (currentMin > array1[j]){
				currentMin = array1[j];
				currentMinIndex = j;
			}
		}
		// Swap the position
		if (currentMinIndex != i){
			array1[currentMinIndex] = array1[i];
			array1[i] = currentMin;
		}
	}


}

double getMedian(double array1[], int size){
	// Calculate the median
	double median;
	int i, j;
	i = size / 2 + 1;
	j = size / 2;
	median = (array1[i] + array1[j]) / 2;
	return median;
}


double getMode(double array1[], int size){
	double mode = 0;
	int counter1 = 1, counter2 = 1;
	for (int i = 0; i < size - 1;){
		while (array1[i] == array1[i + 1]){
			// Count how many times a number occers
			counter1++;
			i++;
		}
		// Find the number which occers most often
		if (counter1 > counter2){
			mode = array1[i];
		}
		counter2 = counter1;
		counter1 = 1;
		i++;
	}
	return mode;
}