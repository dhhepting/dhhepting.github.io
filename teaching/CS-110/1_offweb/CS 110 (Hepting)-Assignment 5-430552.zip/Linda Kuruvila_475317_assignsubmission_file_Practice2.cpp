// Student name : Linda Kuruvila
// Student ID number : 200354184
// Assignment number : 5
// Program name : Finding minimum, maximum, mean, median, and mode of the given integers
// Date Written : April 03, 2015
// Problem Statement : Write a program to read up to 20 integers from a file 
//                     and store the integers in an array of integer type. With the values in the array, compute and display
//                     the minimum, maximim, mean. median and mode of the integers.
// Input : Upto 20 integers
// Output : Outputs the functions like minimum and maximum of the integers, 
//          Will find the mean and median of the integers and finally will find the mode of the integers.
// Algorithm : We use the ARRAY function for this program. PrintArray will initialize the number of integers. For and if-else 
//             statements will be used to find the mean, median and mode. Void will find the mininmum and maximum of the function.
// Major VAriables : integer_values, min_value, max_value, index, counter, mode, int i, and int j
// Assumptions : None
// Limitations : Upto 20 integers only

#include <iostream>
#include <cmath>
#include <fstream>
using namespace std;

// Function prototypes

int getMinimum(int[], int);
int getMaximum(int[], int);
double calculateMean(int[], int);
double calculateMedian(int[], int);
int calculateMode(int[], int);
void bubbleSort(int[], int);

int  main()
{
	const int ARRAY_SIZE = 20;   //array size
	int number[ARRAY_SIZE];
	int maximum, minimum, mean, median, mode;  //values
	double average;      //mean value
	int count = 0;

	ifstream inputFile;     //open stored file
	inputFile.open("Textfile.txt");
	if (!inputFile)
	{
		cout << "Error opening File.\n";
	}
	else
	{
		for (count = 0; count < ARRAY_SIZE; count++)
		{
			inputFile >> number[count];

			maximum = getMaximum(number, ARRAY_SIZE);  //get highest number


			minimum = getMinimum(number, ARRAY_SIZE);   //get lowest number


			mean = calculateMean(number, ARRAY_SIZE);    //get sum


			median = calculateMedian(number, ARRAY_SIZE);   //get mean

			mode = calculateMode(number, ARRAY_SIZE);           // get mode

		}//end while
		inputFile.close();
		cout << "The maximum value is " << maximum << endl;
		cout << "The minimum value is " << minimum << endl;
		cout << "The mean of the numbers is " << mena << endl;
		cout << "The median of the numbers is " << median << endl;
		cout << "The mode of the numbers is " << mode << endl;
	}
	system("pause");
	return 0;
}

//Functions
int getMinimum(int number[], int ARRAY_SIZE)  //get Lowest Function
{
	int minimum, count;
	minimum = number[0];
	for (count = 1; count < ARRAY_SIZE; count++)
	{
		if (number[count] < minimum)
			minimum = number[count];
	}
	return minimum;
}
int getmaximum(int number[], int ARRAY_SIZE) //get Highest Function
{
	int maximum, count;
	maximum = number[12];
	for (count = 1; count < ARRAY_SIZE; count++)
	{
		if (number[count] > maximum)
			maximum = number[count];
	}
	return maximum;
}
double calculateMean(int number[], int ARRAY_SIZE)  //get average Function
{
	double total = 0; // Initialize Accumulator
	double mean; // To hold the average

	for (int count = 0; count < ARRAY_SIZE; count++)
	{
		total += number[count];
		mean = total / ARRAY_SIZE;
	}
	return mean;
}
double calculateMedian(int number[], int ARRAY_SIZE)
{
	int temp;
	int total;
	int nums;
	int i, j;
	for (i = 0; i<total; i++)
		for (j = i + 1; j<total; j++) {
		if (nums[i]>nums[j]) {
			temp = nums[j];
			nums[j] = nums[i];
			nums[i] = temp;
		}
		}
	if (total % 2 == 0) {
		int x;
		int y;
		x = nums[total / 2];
		y = nums[(total / 2) - 1];

		return ((x + y) / 2);
	}
	else {
		return nums[total / 2];
	}
}
int calculateMode(int number[], int ARRAY_SIZE)
{
	    int total;
		int nums;
    	int i, j, maxCount, modeValue;
		int tally[total];
		for (i = 0; i < total; i++) {
			tally[nums[i]]++;
		}
		maxCount = 0;
		modeValue = 0;
		for (j = 0; j < total; j++) {
			if (tally[j] > maxCount) {
				maxCount = tally[j];
				modeValue = j;
			}
		}
		return modeValue;
}

