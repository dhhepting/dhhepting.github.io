/*
Riley Herman
200352833
Assignment 5
I mean to max the min in the mode of medians
April 10/2015
Write a program to read up to 20 integers from a file and store the integers in an array of integer type. With the values 
in the array, compute and display the following:
minimum: smallest value in the array
maximum: largest value in the array
mean: average of all values in the array
median: the value in the middle of the array once all values have been sorted. If there is no single index at the middle of
the array, average the values in the 2 adjacent spots. For example: if the array has 3 values (with indices 0,1,2), once the
array is sorted the median will be at index 1. If the array has 4 values (with indices 0,1,2,3), once the array is sorted the 
median will be the average of the values at indices 2 and 3.
mode: find the value in the array which occurs most often. A straightforward approach is possible once the array is sorted.
Input: a file full of numbers
Output: max, min, mean, median, mode of the inputted numbers
Algorithm: Input 20 of the numbers from an opened file. Then in functions use loops and selections and math to find the max, 
min, mean, median, and mode. Display those.
Major variables: input, awry (also the letters a-f in the functions), functions named MIN, MAX, MEAN, MODE, MEDIAN, and ORDERARRY. 
The functions have their own variables bu they are minor and temporary.
Assumptions: the file is properly formatted and has the right amount of integers (they have to be integers) in it.
Program limitations: the number of array elements is 20, the numbers in the file are integers, the format of the integers is correct,
and the program actually works.
*/
#include <iostream>			// include the input/output stream and the file stream (for files)
#include <fstream>

using namespace std;		//using a standard way of doing things

int MIN(int []);		// function prototypes for the MIN, MAX, MEAN, MODE, MEDIAN, and ORDERARRAY functions. They all take arguments
int MAX(int []);		//		for the array
float MEAN(int []);
float MODE(int []);
int MEDIAN(int []);
void ORDERARRAY(int[]);

int main()
{
	ifstream input;		// input file stream input variable declaration
	input.open("input.txt");		// open the file with numbers

	int awry[20];		// declare the integer array for the numbers to be stored in (20 numbers)

	cout << "Hey y'all, looky at dem numbers in dem dar faile!" << endl;		// user prompt

	int i = 0;		// this variable counts how many times the following loop runs (max 20 items)
	while (!input.eof() || i < 20)		//while loop that gos until the end of the file or until i = 20
	{
		input >> awry[i];		// input the number from the file into the ith place
		i++;					// increment i
	}

	if (i < 20)
	{
		for (i; i < 20; i++)
			awry[i] = 0;
	}

	cout << "The minimum value is " << MIN(awry) << endl;		// these cout statements display the values calculated in the functions below.
	cout << "The maximum value is " << MAX(awry) << endl;		//		they also contatin the function calls that return the value they've calculated
	cout << "The mean value is " << MEAN(awry) << endl;
	cout << "The median value is " << MODE(awry) << endl;
	cout << "The mode value is " << MEDIAN(awry) << endl;

	return 0;
}


int MIN(int a[])		// function definition that has the parameter of the integer array from above
{
	int mini = a[0];		// the original minimum is the first value in the file, which is then tested 
	for (int f = 0; f < 20; f++)		//		against all of the other values in the file, and if it isn't the actual min then it 
	{									//		is replaced by the actual minimum
		if (a[f] < mini)
			mini = a[f];
	}
	return mini;		// return the minimum calculated above
}


int MAX(int b[])		// function definition that has the parameter of the integer array from above 
{
	int maxi = b[0];		// same as the previous function except with the maximum
	for (int g = 0; g < 20; g++)
	{
		if (b[g] > maxi)
			maxi = b[g];
	}
	return maxi;		// return the maximum
}


float MEAN(int c[])		// function definition that has the parameter of the integer array from above
{
	int sum = 0;		// this function adds all of the numbers in the array together and then divides 
	int num = 20;		//		them by the number of elements in the array
	for (int h = 0; h < 20; h++)
		sum += c[h];
	float ave = static_cast<float>(sum) / num;
	return ave;	 	// return the calculated average
}

float MODE(int d[])			// function definition that has the parameter of the integer array from above
{
	ORDERARRAY(d);		// call the order array function which orders the array from lowest to highest

	int mode = 0;		// declaring the variables for the mode, the number of times a number appears, 
	int count = 1;		//		and the maximum number of times a number appears
	int max = 1;
	for (int i = 0; i < 20; i++)		// the for loop that looks through the array and fins the mode by 
	{									//		comparing the number of times each number occurs
		if (d[i] == d[i + 1])
		{
			count++;
			if (count > max)
			{
				mode = d[i];
				max = count;
			}
		}
		else
		{
			count = 1;		// if the numbers beside each other don't match, then the count resets
		}
	}

	if (max = 1)
		return 0;
	else
		return mode;		// return the mode
}

int MEDIAN(int e[])			// function definition that has the parameter of the integer array from above
{
	ORDERARRAY(e);		// call the function that orders the array

	int med;			// the variable that stores the median
	if (!20 % 2)		// if the number of elements is odd
	{
		med = e[20 / 2];		// the median is the number in the middle of the array
	}
	else
	{
		med = (e[20 / 2 + 1] + e[20 / 2]) / 2;		// if the number of elements is even, then it is the average of the two elements in the middle
	}
	return med;		// return the median
}

void ORDERARRAY(int f[])		// function definition that has the parameter of the integer array from above
{
	for (int k = 0; k < 20; k++)		// this is a generic bubble sort
	{
		for (int l = 0; l < 20; l++)
		{
			if (f[k] < f[l])
			{
				int temp = f[l];
				f[l] = f[k];
				f[k] = temp;
			}
		}
	}
	for (int m = 0; m < 20; m++)
		cout << f[m] << endl;
}