//**************************************************************************
//
// Student name: Riley Peters
//
// Student number: 200 354 249
//
// Assignment number: #5
//
// Program name: Integer File Analysis
//
// Date written: April 9th, 2015
//
// Problem statement: Find the max, min, mean, median, and mode for a file.
//
// Input: a file with integers
//
// Output: max, min, mean, median, and mode values
//
// Algorithm: declare max size of array -> call function to read in integers. Counts the number of input integers to a max of 20 -> call a function to organize the array into increasing order -> calculate max and min and output it.  Last and first integers in the array -> call a function to calculate mean my taking average of the integers -> call a function to find median by taking the average of the middle terms in the array -> use a function to find mode by finding the numbers that occurs the most
//
// Major variables: array, integers in the array
//
//
// Assumptions: user has the proper text file,
//
//
// Program limitations: will cut off decimal points, only works with up to 20 integers
//
//**************************************************************************

#include <iostream>
#include <fstream>
using namespace std;

// FUNCTION PROTOTYPES
void readdata (int [], int&);

void organize_array (int [], int);

int max (int [], int);

int min (int []);

double mean (int [], int);

double median (int [], int);

void mode (int [], int);

int main()

{
    cout << "This program will analyze a file with integers." << endl;
    
    const int MAX_ARRAY = 20; /* Setting max array size */
    
    int ARRAY_SIZE = 0;       /* Declaring array size to be counted from zero */
    
    int array[MAX_ARRAY];     /* Declaring array */
    
    // Reading in data
    readdata(array, ARRAY_SIZE);
    
    // Sorting the array into ascending order
    organize_array(array, ARRAY_SIZE);
    
    //Outputting the important values
    cout << "The maximum value is: " << max(array, ARRAY_SIZE) << endl;
    cout << "The minimum value is: " << min(array) << endl;
    
    cout << "The mean value is: " << mean(array, ARRAY_SIZE) << endl;

    cout << "The median value is: " << median(array, ARRAY_SIZE) << endl;
    
    cout << "The mode value(s) is/are: ";
    
    mode(array, ARRAY_SIZE);
    
    cout << endl;
    
    return 0;
}

void readdata (int a[], int& SIZE)
{
    
    ifstream indata;
    indata.open("integers.txt");            /* Opening file */
    
    if (!indata)                            /* Testing if file is found */
        cout << "File not found" << endl;

    int i = 0;
    while (!indata.eof())                    /* Reading in values from file */
    {
        indata >> a[i];
        i++;
        SIZE++;                             /* Counting integers read from file */
    }
    
    SIZE--;
    
}

void organize_array(int a[], int SIZE)
{
    for (int i = 0; i < SIZE-1; i++)
    {
        int temp_min = a[i];                /* Find the minimum value and its index */
        int min_index = i;
        
        for (int j = i + 1; j < SIZE; j++)
        {
            if (temp_min > a[j])
            {
                temp_min = a[j];
                min_index = j;
            }
        }
        
        if (min_index != i)
        {
            a[min_index] = a[i];            /* Set the first value in the array to minimum */
            a[i] = temp_min;
        }
    }
}

int max (int a[], int SIZE)
{
    return a[SIZE-1];                           /* Return the last value in the ascending array */
}

int min (int a[])
{
    return a[0];                            /* Return the first value in the ascending array */
}

double mean(int a[], int SIZE)
{
    long sum = 0;                           /* Calculate and return the average */
    for (int i = 0; i < SIZE; i++)
        sum += a[i];
    double average = sum / static_cast<double>(SIZE);
    return average;
}

double median(int a [], int SIZE)
{
    double median = 0;
    if (SIZE % 2 == 0)                  /* Average of two middle numbers if an even num of integers */
        median = (a[SIZE/2 - 1] + a[SIZE/2])/2.0;
    else                                /* Middle term if odd num of integers */
        median = a[(SIZE-1)/2];
    
    return median;
}

void mode (int a[], int SIZE)
{
    int modemax = 0;
    int modetotal[20];                    /* Check for occurances of each value */
    int countmode = 1;
    for (int i = 0; i < SIZE; i++)
    {
        if (a[i] == a[i+1])
            countmode++;
        else
        {
            if (countmode >= modemax)
                modemax = countmode;
        
            modetotal[i] = countmode;       /* Stores occurances in the array */
        
            countmode = 1;
        }
    }
    
    for (int i = 0; i < SIZE; i++)
    {
        if (modetotal[i] == modemax && modetotal[i] > 1)
            cout << a[i] << " ";            /* All values that equal the max occurances are output */
    }
    
    cout << endl;

}