//student Name: Caleigh Ritson
//ID: 200253359
//Program Create Date: April 10, 2015
//Program Name: Attempt with arrays and functions


#include <iostream>
#include <fstream>
using namespace std;

int MAX(int [], int);
int MIN(int[], int);
int AVG(int[], int);
int MED(int[], int);
int MODE(int[], int);
void Sort(int[], int);

int main()
{
	//Reading file
	ifstream inData;
	ofstream outData; 
	inData.open("input.txt");
	if (!inData)
	{
		cout << "File cannot be read" << endl;
		return 1;
	}
	outData.open("output.txt");
	if (!outData)
	{
		cout << "File cannot be read" << endl;
		return 2;
	}

	int integers; //the integers on the file

	while (inData >> integers) //continues until no more integers left
	{
		const int Mxval = 20;
		int array[Mxval];
		int i;
		int min;
		int max, med, mod, mean;
		//finding the max and min values
		min = MIN(array, Mxval);
		max = MAX(array, Mxval); 

		cout << "The minimum value is: " << min << endl;
		cout << "The maximum value is: " << max << endl;

		//finding the mean
		mean= AVG(array, Mxval);

		Sort(array, integers);

		cout << "The mean is: " << mean << endl;

		//finding the median
		med = MED(array, Mxval);

		cout << "The median is: " << med << endl;
		
		//finding the mode
		mod = MODE(array, Mxval);

		cout << "The mode is: " << mod << endl;

	}
	inData.close();

}

int MAX(int a[], int mxval )
{
	int max=a[0];
	for (int i = 0; i < mxval; i++)
	{
		if (a[i] > max)
			max = a[i];
		else
			max = a[i + 1];

	}
	return max;
}

int MIN(int b[], int val)
{
	int min=a[0];
	for (int i = 0; i < val; i++)
	{
		if (b[i] < min)
			min = b[i];
		else
			min = b[i + 1];
	}
	return min;
}

int MED(int x[], int ml) 
{
	for (int i = 0; i < ml; i++)
	{
		int t = x[i] % 2;
		int even = 0;
		int odd = 1;
		int final;
		if (t = even)
		{
			final = (x[t]+x[t+1] / ml;
		}
		else
		{
			final = x[t] / ml;
		}
		return final;
	}

}

int AVG(int c[], int vl)
{
	int count;
	int avg, mean;
	for (int i = 0; i < vl; i++)
	{
		
		int avg = c[i];
		count++;
	}
	mean = avg / count;
	return mean;

}

int MODE(int d[], int mx)
{
	for (int i = 0; i < mx; i++)
	{
		int max = 0;
		int mode = d[0];
		int count = 1;
		if (d[i] == d[i + 1])
		{
			count++;
			if (count > max)
			{
				max = count;
				mode = d[i];
			}

		}
		else
		{
			count = 1;
		}
		return count;
}

void Sort(int x[], int y)
{
	for (int i = 0; i < y; i++)
	{
		int currentMin = x[i];
		int current_Min = i; //current min index

		for (int j = i + 1; j < y; j++)
		{
			if (currentMin > x[j])
			{
				currentMin = x[j];
				current_Min = j;
			}
		}
		//swap x[i] with list[current_Min] if necessary
		if (current_Min != i)
		{
			x[current_Min] = x[i];
			x[i] = currentMin;
		}
		}
	}
}