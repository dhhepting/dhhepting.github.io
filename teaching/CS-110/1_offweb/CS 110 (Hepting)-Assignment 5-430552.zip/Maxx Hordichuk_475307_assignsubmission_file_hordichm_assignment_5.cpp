// Name: Maxx Hordichuk
// Student #: 200353849
// Assignment: 5
// Program Name: Array Calculator
// Date Written: 04/9/15
/* Problem:  Write a program to read up to 20 integers from a file and store the integers in an array of integer type. 
             With the values in the array, compute and display the following:

    minimum: smallest value in the array
    maximum: largest value in the array
    mean: average of all values in the array
    median: the value in the middle of the array once all values have been sorted.
    mode: find the value in the array which occurs most often. A straightforward approach is possible once the array is 
sorted.

Use a function for each computation/output specified above. */

// Input: 20 integers from "integers.txt" file
// Output: Minimum, Maximum, Mean, Median, Mode
// Algorithm: Read 20 integers from input file, then use sequenced functions to calculate the minimum, maximum, mean, median, and mode separately.
// Major variables: MAX_ARRAY, a[], mode, max, sum, min, max, median, mean, index.
// Assumptions: Input file will contain integers.
// Limitations: Can only calculate integers and an unproperly formatted input file will sometimes not compute.


#include <iostream>
#include <fstream> // to use input file
#include <algorithm> // to use sort function

using namespace std;

void min(int a[], int MAX_ARRAY, int index); // function to determine the minimum
void max(int a[], int MAX_ARRAY, int index); // function to determine the maximum
void mean(int a[], int MAX_ARRAY, int index);// function to determine the mean
void median (int a[], int MAX_ARRAY, int index);// function to determine the median
void mode (int a[], int MAX_ARRAY); // function to determine the mode

int main() // start of the main function
{
    
    ifstream myfile ("integers.txt"); // defines input file
    
    const int MAX_ARRAY = 20; // sets the Array size
    int a[MAX_ARRAY]; // array used to store integer numbers from integers.txt
    int index; // index value used for loops
    
    if(myfile.is_open()) // ensures input file can be opened.
    {
       
        for(index = 0; index < MAX_ARRAY; ++index) // loop to read integers into array
        {
            myfile >> a[index];
        }
        
    }
    
   // All five function calls are below
    
    min(a, MAX_ARRAY, index);
    max(a, MAX_ARRAY, index);
    mean(a, MAX_ARRAY, index);
    median (a, MAX_ARRAY, index);
    mode (a, MAX_ARRAY);
    
    return 0;
}

void min(int a[], int MAX_ARRAY, int index) // Minimum function
{
    int min = a[0]; // Sets minimum value to first number in array
    
    for (index = 0; index < MAX_ARRAY; index++) // Loop to find lowest value
        if (a[index] < min)
        {
            min = a[index];
        }
    cout << "The minimum value is " << min << endl;

}

void max (int a[], int MAX_ARRAY, int index) // Maximum function
{
    int max = a[0]; // Sets maximum to first number in array

    for (index = 0; index < MAX_ARRAY; index++) // loop to find greatest number
        if (a[index] > max)
        {
            max = a[index];
        }

cout << "The maximum value is " << max << endl;
    
}

void mean(int a[], int MAX_ARRAY, int index) // Mean function
{
    double sum = 0;
    for (index = 0; index < MAX_ARRAY; index++) // Loop to sum all numbers in array
    {
        sum = sum + a[index];
    }
    
    double mean = sum / MAX_ARRAY;
    
    cout << "The mean is " << mean << endl;
}

void median(int a[], int MAX_ARRAY, int index) // Median function
{
    
    sort(a, a + MAX_ARRAY); // Sort function

    if (MAX_ARRAY % 2 == 0) // if there are an even amount of integers
    {
    
        int median_position_low = MAX_ARRAY / 2 - 1;
        int median_position_high = MAX_ARRAY / 2;
    
        double median = (a[median_position_high] + a[median_position_low]) / 2;
        
        cout << "The median is: " << median << endl; // prints out median to console
    
    }
    
    else // if there are an odd amount of integers
    {
        int median_position = MAX_ARRAY / 2 + 1;
        cout << "The median is " << a[median_position];
    }
    
}

void mode(int a[], int MAX_ARRAY)
{
    
    int counter = 1;
    int max = 0;
    int mode = a[0];
    
    for (int i = 0; i < MAX_ARRAY - 1; i++)
    {
        if ( a[i] == a[i+1] ) //if the previous number = the number next to it in the array, the counter is incremented
        {
            counter++;
            if ( counter > max ) // if the counter is greater than the previous max value for mode, it replaces it
            {
                max = counter;
                mode = a[i];
            }
        } else
            counter = 1;
    }
    
    cout << "The mode(s) is/are: " ;
    
    for (int i = 0; i < MAX_ARRAY; i++)
    {
        if (max < 1)
        {
            cout << "NO MODE";
            break;
        }
    else if (a[i] == a[i+max-1])
	         cout << a[i] << " ";     
    }

    cout << endl;
    
}
