#include <iostream>
#include <fstream>

using namespace std;


//Prototype all of the neccessary functions
int getData(int[20]);
int largest(int[20], int);
int smallest(int[20], int);
int sort(int[20], int);
double calcMean(int[20], int);
double calcMedian(int[20], int);
int calcMode(int[20], int, bool&);
void printData(int, int, double, double, int, bool);

int main()
{
	//Instantiate an array to hold the set of numbers as well as varialbes to hold data
	int dataSet[20];
	int index;
	int max, min, mode;
	bool modeFound = false;
	double median, mean;
	
	//Grab the numbers as well as the number of entries from the file using the getData function
	index = getData(dataSet) - 1;
	//Calculate the largest number in the set
	max = largest(dataSet, index);
	//Calculate the smallest number in the set
	min = smallest(dataSet, index);
	
	//Arrange the list so that it is in decending order
	sort(dataSet, index);
	
	//Calculate the mean, median and mode using their respective functions
	mean = calcMean(dataSet, index);
	median = calcMedian(dataSet, index);
	mode = calcMode(dataSet, index , modeFound);
	
	//Output the calculated data
	printData(max, min, mean, median, mode, modeFound);
	
	//Terminate the program with return value 0
	return 0;
}


int getData(int array[20])
{
	//Declare a variable to hold the number of entries
	int counter = 0;
	
	//Create an ifstream object to grab input from the file input.txt
	ifstream inData;
	inData.open("input.txt");
	
	//Grab entered data from the file
	while(!inData.eof() && counter < 20)
	{
		inData >> array[counter];
		//Increment the counter to keep track of the number of entries
		counter++;
	}
	
	//Return the number of entries
	return counter;
}

int largest(int array[20], int index)
{
	//Set a baseline maximum
	int max = array[0];
	
	//Search for a higher maxiumum
	for(int i = 0; i < index; i++)
	{
		if(array[i] > max)
		{
			max = array[i];
		}
	}
	
	
	return max;
}

int smallest(int array[20], int index)
{
	//Set a baseline for the minimum
	int min = array[0];
	
	//Search for a lower minimum
	for(int i = 0; i < index; i++)
	{
		if(array[i] < min)
		{
			min = array[i];
		}
	}
	
	return min;
}

int sort(int array[20], int index)
{
	
	int temp;
	
	for(int i = 0; i < index - 1; i++)
	{
		//If the current number is less than the next number in the set, swap them and start from the top of the list again
		if (array[i] < array[i+1])
		{
			temp = array[i];
			array[i] = array[i+1];
			array[i+1] = temp;
			i = 0;
		}
	}
	//The sorted array is passed back to the main function via reference
	
}

double calcMean(int array[20],int index)
{
	// Instantiate two variables to store the average as well as the sum of the numbers
	int total = 0;
	double mean;
	
	
	// Sum the numbers
	for(int i = 0; i < index; i++)
	{
		total += array[i];
	}
	
	//Calculate and return the average
	mean = (double)total / (double)index;
	return mean;
}

double calcMedian(int array[20],int index)
{
	// Declare a variable to store the median 
	double median;
	
	if(index + 1 % 2 != 0)
	{
		//Condition where there are two values within the median. Take the average of them
		median  = (array[(index + 1) / 2] + array[(index / 2) + 1]) / 2.0;
	}
	else
	{
		//Case where there is only one candidate for median
		median = array[(index + 1) / 2];
	}
	
	//Return the median
	return median;
}

int calcMode(int array[20], int index, bool & modeFound)
{
	//Declare two variables to hold candidates for the mode as well as the number of times they appear
	int tempCounts = 1;
	int counts = 2;
	int mode = array[0];
	
	for(int i = 0; i <= index; i++)
	{
		for(int j = 1; j < index; j++)
		{
			//Search for instances wher the same number appears more than once
			if(array[i] == array[j])
			{
				// Increment the counts for instances of the current number
				tempCounts++;
			}
		}
		
		//Determine if a new mode was found
		if(tempCounts > counts)
		{
			mode = array[i];
			modeFound = true;
		}
		
		//Reset the counter
		tempCounts = 1;
		
	}
	
	//Return the calculated mode
	return mode;
	
	
}

void printData(int max, int min, double mean, double med, int mode, bool modeFound)
{
	//Output the calculated data
	cout << "The maximum number in the set is: " << max << endl;
	cout << "The minimum number in the set is: " << min << endl;
	cout << "The mean of the set is: " << mean << endl;
	cout << "The median of the set is: " << med << endl;
	
	//Whether or not a mode exists, print a respective message
	if(!modeFound)
	{
		cout << "There is no mode in this set. " << endl;
	}
	else
	{
		cout << "The mode of the set is: " << mode << endl;
	}
}
