﻿//********************************************************************
//Name: Shu Wang
//Student number: 200335170
//Assignment number: 5
//Program name: Calculate integers by using functions
//Date written: Apr 10, 2015
//Problem statement: Write a program to read up to 20 integers from a file and store the integers in an array of integer type. 
//					 With the values in the array, compute and display the following: Maximum, Minimum, Mean, Median, and Mode.
//Input: Up to 20 integers
//Output: Maximum, Minimum, Mean, Median, and Mode among those integers
//Algorithm: 
//(1) call function: define the name of each functions for  Maximum, Minimum, Mean, Median, and Mode
//(2) ifstream: input integers from file
//(3) several for loop： check integers from the first one to the end
//(4) several if function: check the condition
//Major variables: mim, max, mean, sum, median, median1, median2, currentMinIndex, currentMin， count， mode
//Assumptions: The inputs are less than 20 integers.  The program required to be done by using function.
//Program limitations: It cannot do more than 20 integers since the constant array size is 20.
//**********************************************************************

#include <iostream>
#include <fstream>

using namespace std;
using std::cout;
const int size = 20;
int minimum(int list[], int size);
int maximum(int list[], int size);
int mean(int list[], int size);
void median(int list[], int size);
void selectionSort(int list[], int size);
int mode(int list[], int size);


int main()
{
	cout << "The program read up to 20 integers from file and display: Maximum, Minimum, Mean, Median, and Mode.\n ";
	ifstream inData;
	inData.open("inputfile.txt");
	int list[size];
	for (int i = 0; i < size; i++)
	{
		inData >> list[i];
		int index = i;
	}

	minimum(list, size);
	maximum(list, size);
	mean(list, size);
	selectionSort(list, size);
	median(list, size);
	mode(list, size);

	return 0;
}

//Function: find the minimum number in the file, and print it out
int minimum(int list[], int size)
{
	int min = list[0];
	for (int i = 0; i < size; i++)
	{
		if (list[i + 1]<min)
		{
			list[i] = min;
		}

	}
	cout << "The minimum number in the file is:" << min << endl;
	return min;
}

//Function: find the maximum number in the file, and print it out
int maximum(int list[], int size)
{
	int max = 0;
	for (int i = 0; i < size; i++)
	{
		if (list[i] >max)
		{
			max = list[i];
		}
	}
	cout << "The maximum number in the file is:" << max << endl;
	return max;
}

//Function: find the mean of all integers in the file, and print it out. 
int mean(int list[], int size)
{
	//find the sum first and then divide by the numbers of integer
	int sum = 0;
	int index;
	int mean;
	for (int i = 0; i < size; i++)
	{
		sum += list[i];
		index = i;
		
	}
	mean = sum / (index + 1);
	cout << "The mean of all integers is:" << mean << endl;
	return mean;
}


// use for loop to sort the integers in ascending order
void selectionSort(int list[], int size)
{
	for (int i = 0; i < size - 1; i++)
	{
		int currentMin = list[i];
		int currentMinIndex = i;
		//compare the value of index i and j, if smaller value in list[j] is found, change current min and the index
		for (int j = i + 1; j < size; j++)
		{
			if (currentMin>list[j])
			{
				currentMin = list[j];
				currentMinIndex = j;
			}
		}
		//when program find a value smaller than currentMin, swap list[i] and list[currentMinIndex]
		if (currentMinIndex != i)
		{
			list[currentMinIndex] = list[i];
			list[i] = currentMin;
		}
	}

}

//Function: find the median of all integers in the file, and print it out. 
//Note: (1) odd number entry  (2) even number entry
void median(int list[], int index)
{



	//after soring, we try to find median
	if ((index + 1) % 2 == 1)
	{
		int median;
		median = list[index / 2 + 1];
		cout << "The file includes ODD numbers of integer. The median is:" << median << endl;
	}
	if ((index + 1) % 2 == 0)
	{
		int median1, median2;
		median1 = list[index / 2 + 1];
		median2 = list[index / 2 + 2];
		cout << "The file includes EVEN numbers of integer. The medians are:" << median1 << "and" << median2 << endl;
	}

}


int mode(int list[], int size)
{
	int count = 1;
	int max = 0;
	int mode = list[0];
	for (int i = 0; i < size; i++)
	{
		if (list[i] = list[i + 1])
		{

			if (count>max)
			{
				max = count;
				mode = list[i];
				count++;
			}
			else
			{
				count = 1;
			}
		}
	}

	cout << "The mode is:" << mode << ". It appears" << count << "times." << endl;
	return mode;
}