// Student name: Callum Jacobson
//
// Student number: 200234874
//
// Assignment number: 5
//
// Program name: The Array Analyzer 5000
//
// Date written: 10 April 2015
//
// Problem statement: 
//		The problems that need to be solved by this program are:
//		1) Input an array of 20 integers from a .txt file.
//		2) Output the min value, max value, mean, median and mode of the array numbers.
//
// Input:
//		A 20 integer array from a .txt file
//
// Output:
//		After computation, the program will output the following:
//		1) The min value, max value, mean, median and mode of the array numbers.
//
// Algorithm: 
//		1) Program inputs data from "input.txt"
//		2) Program outputs the array.
//		3) Using function 'array1sort,' the program sorts the array in ascending order.
//		4) Using function 'getMin,' the program outputs the array's minimum value.
//		5) Using function 'getMax,' the program outputs the array's maximum value.
//		6) Using function 'getMean,' the program outputs the array's mean value.
//		7) Using function 'getMedian,' the program outputs the array's median value.
//		8) Using function 'getMode,' the program outputs the array's mode value.
//
// Major variables: 
//		1) The 20 integers contained in the array
//		2) The length of the array (the const int 20)
//
// Assumptions:
//		1) Assumes that the array will contain exactly 20 integers.
//		2) Assumes that the data in the .txt file will be numerical and properly formatted (i.e. with breaks between integers).
//
// Program limitations:
//		1) Array cannot contain less than or greater than 20 integers.
//
//**************************************************************************

#include <iostream>
#include <fstream>
using namespace std;

void array1Sort(int[], int);
int getMin(int[], int);
int getMax(int[], int);
float getMean(int[], int);
float getMedian(int[], int);
void getMode(int[], int);


// function that sorts array
void array1Sort(int x[], int n)
{
	for (int i = 0; i < n - 1; i++)
	{
		int currentMin = x[i];
		int currentMinIndex = i;

		for (int j = i + 1; j < n; j++)
		{
			if (currentMin > x[j])
			{
				currentMin = x[j];
				currentMinIndex = j;
			}
		}
		if (currentMinIndex != i)
		{
			x[currentMinIndex] = x[i];
			x[i] = currentMin;
		}

	}
}
// function that returns min:
int getMin(int x[], int n)
	{
	array1Sort(x, n);
	return x[0];
	}

// function that returns max:
int getMax(int x[], int n)
	{
	array1Sort(x, n);
	return x[n - 1];
	}

// function that returns mean:
float getMean(int x[], int n)
		{
			float mean = 0.00;
			int sum = 0;
			for (int i = 0; i < n; i++)
			{
				sum = sum + x[i];
			}
			mean = (sum / n);
			return mean;
		}

// function that returns median:
float getMedian(int x[], int n)
	{
		array1Sort(x, n);	
		float median = 0.00;
		for (int i = 0; i < n; i++)
		if ((i % 2) == 0)
		{
			median = ((x[i / 2]) + (x[i / 2] - 1)) / 2.0;
		}
		return median;
	}

// function that returns mode;
void getMode(int x[], int n)
{
	array1Sort(x, n);

	int count = 1;
	int mode = x[0];
	int modecount = 1;

	for (int i = 0; i < n; i++)
	{
		if (x[i] == x[n - 1])
			count++;
		else
		{
			if (count > modecount)
			{
				modecount = count;
				mode = x[n - 1];
			}
			x[n - 1] = x[i];
			count = 1;
		}
	}
	if (count == 1)
		cout << "no mode" << endl;
	else if (count > 1)
	{
		cout << mode;
	}
}

int main()
{

	int const number = 20;
	int array1[number];

	ifstream inData;
	inData.open("input.txt"); 

	for (int i = 0; i < number; i++)
	{
		inData >> array1[i];
	}
	inData.close();
		
	cout << "The array: " << endl;
	
	for (int i = 0; i < number; i++)
	{
		cout << array1[i] << endl;
	}
	
// find and display minimum:
	cout << "The minimum value in the array is " << getMin(array1, number) << endl;

// find and display maximum:
	cout << "The maximum value in the array is " << getMax(array1, number) << endl;

// find and display mean:
	cout << "The mean value of the array is " << getMean(array1, number) << endl;

// find and display median:
	cout << "The median value of the array is " << getMedian(array1, number) << endl;

// find and display mode:
	cout << "The mode value of the array is "; 
	getMode(array1, number); 
	cout << endl;

	return 0;
}

