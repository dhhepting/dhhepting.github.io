//Ashlyn Heintz
//200287036
#include <iostream> 
#include <cmath>
#include <fstream>
#include <string>
using namespace std;

int main()
{
	ifstream inputfile;
	inputfile.open("inputfile.txt");
	int count = 0;
	int value;
	int const MAX_ARRAY = 20;
	int myArray[20];
	bool iscount = true; 

		// try to read at most MAX_ARRAY integers from the input file
		for (int i = 0; i < MAX_ARRAY; i++)
		{
			int inputvalues;
			if (inputfile >> inputvalues)
			{
				// if an integer has been read, 
				// test if it is unique before storing 
				// it in the array
				// break out of loop as soon as value is
				// identified as NOT unique
				for (int j = 0; j < count; j++)
				{
					if (inputvalues == myArray[j])
					{
						iscount = false;
						break;
					}
				}
				// if it is unique, store it and increment the
				// counter of unique integers in the array
				if (iscount)
				{
					myArray[count] = inputvalues;
					count++;
				}

			}
			else
			{
				break; // if value not read, break out of loop
			}
			cout << "The array is: " << inputvalues << " " << endl;

			float sum = 0;
			for (int k = 0; k < MAX_ARRAY; k++)
			{
				sum = sum + myArray[k];
				cout << "The average of the numbers in the array is: " << sum << endl;
			}
			

			double max = myArray[0];
			for (int l = 0; l < MAX_ARRAY; l++)
			{
				if (myArray[l] > max)
					max = myArray[l];
				cout << "The max number of the array is: " << max << endl;
			}
	
		}


	return 0;
}