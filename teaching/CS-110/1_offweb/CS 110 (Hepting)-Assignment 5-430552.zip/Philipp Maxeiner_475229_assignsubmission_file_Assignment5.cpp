//**************************************************************************
//
// Student name: Philipp Maxeiner
//
// Student number: 200343181
//
// Assignment number: 5
//
// Program name: Assignment 5
//
// Date written: April 2015
//
// Problem statement: Find the minimum, maximum, average, median and mode
// of an array of numbers
//
// Input: Array of numbers from a file
//
// Output: minimum, maximum, average, median and mode
//
// Algorithm: 
//
// Major variables: MAX_ELEMENTS, count, maxVal, minVal, currentMin,
// array[], currentMinIndex. average, mode, median
//
// Assumptions: 
//
// Program limitations: limit in the size of the array. possible limits with 
// negative numbers?
//**************************************************************************

#include <iostream>
#include <fstream>
using namespace std;

// Function protocol
void selectionSort(double list[], int listSize);

int main()
{

ifstream input("numbers.txt");

    const int MAX_ELEMENTS = 20;
    double array[MAX_ELEMENTS];
    int count = 0;
    while (!input.eof())
    {
        for (int i = 0; i < MAX_ELEMENTS; i++)
        {
            input >> array[i];
	    count++;
        }
    }

 
 //Determine the maximum value
  int maxVal = array[0];
  for (int i = 0; i < count; i++)
  {
      if (maxVal < array[i])
      {
          maxVal = array[i];
      }
}
cout << "Maximum value is " << maxVal << endl;


// Determine the minimum value
int minVal = array[0];
for (int j = 0; j < count; j++)
{
    if (minVal > array[j])
    {
        minVal = array[j];
    }
}
cout << "Minimum value is " << minVal << endl;


// Determine the average of the array
int sum = 0;
for (int k = 0; k < count; k++)
{
    sum += array[k];
}
int average = sum / max_size;
cout << "The average of the array is " << average << endl;

// Sort the array using the sort function
selectionSort(array[], count);

// Determine the median of the array (value in the middle)


return 0;
}


void selectionSort(double list[], int listSize)
{
for (int i = 0; i < listSize - 1; i++)
	{
		// Find the minimum in the list[i..listSize-1]
		double currentMin = list[i];
		int currentMinIndex = i;

		for (int j = i + 1; j < listSize; j++)
			{
				if (currentMin > list[j])
					{
						currentMin = list[j];
						currentMinIndex = j;
					}
			}

		// Swap list[i] with list[currentMinIndex] if necessary;
		if (currentMinIndex != i)
			{
				list[currentMinIndex] = list[i];
				list[i] = currentMin;
			}
	}
}