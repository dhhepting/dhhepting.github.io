//Student name : Yue Wang
// Studnet number: 200350793
// Assignment number: 5
// Program name: sourceccc.cpp
// Date written: April 10th, 2015
// Problem statement: to calculatemin/max, mean, mode of a array
// Input: a file with input
// Output: min/max, mean, mode of a array
// Algorithm: array
// Major variables: max, min, tries
// Assumptions: None
// Program limitations: intergers only
#include <iostream>  // basic comand
#include <fstream>   // for the input file

using namespace std;

void selectionSort(double[], int);             // Start of Listing 7.11
void printArray(double list[], int ); // function prototype

int main()
{
	const int Size = 20;
	double list[Size];
	selectionSort(list, 20);
    printArray(list, 20);


	ifstream infile;
	infile.open("test.txt");


	while (!infile.eof())
	{
		infile >> list[20];
		

	}
	

	// set min_value and max_value to be the first of the values
	int min_value = list[0];
	int max_value = list[0];

	// find the maximum and minimum value 

	for (int i = 0; i < 20; i++)
	{
		// if a numbmer is smaller than [0] it is the new min_value?
		if (list[i] < min_value)
		{
			min_value = list[i];
		}
		// if a numbmer is smaller than [0] it is the new max_value?
		if (list[i] > max_value)
		{
			max_value = list[i];
		}
	}
	cout << endl;
	cout << "The minimum value in the array is: " << min_value << endl;
	cout << "The maximum value in the array is: " << max_value << endl;

	



	// to find the mode

	int counter = 1;       // counts thow many times it repeats
	int maxium = 0;           // initiate  the max
	double mode = list[0];    //to make it start at the first number list[0]
	for (int i = 0; i <Size - 1; i++) 
	{
		if (list[i] == list[i + 1])         //if there is a identical number as the first then the counter goes up by 1
		{
			counter++;
			if (counter > maxium)              
			{
				maxium = counter;          
				mode = list[i];
			}
		}
		else
			counter = 1; // resets the counter for the loop
	}
	cout << "The modes are listed: "; // outputs mode

	for (int i = 0; i <Size; i++)
	{

		while (i < Size)
		{

			cout << list[i] << " "; // prints out modes
			i += maxium;


			i++;

		}
		cout << endl;
	}
	//to find the median 
	double value, median;
	int count = 1;
	if ((count % 2) == 0){
		count = count / 2;

		median = ((list[count + 1] + list[count]) / 2);
	}
	else {
		count = ((count - 1) / 2) + 1;

		median = list[count];
	}

	cout << "The median is " << median << "." << endl;
//to find the mean
	int sum = 0;
	int avg = 0;
	//initialization

	for (int i = 0; i < 20; i++)
	{
		sum += list[i];
	}
	avg = sum / 20;

	cout << "The mean is " << avg << "." << endl;
	return 0;
}

void selectionSort(double list[], int listSize)//sort array
{
	for (int i = 0; i < listSize; i++)
	{
		// Find the minimum in the list
		double currentMin = list[i];
		int currentMinIndex = i;

		for (int j = i + 1; j < listSize; j++)
		{
			if (currentMin > list[j])
			{
				currentMin = list[j];
				currentMinIndex = j;
			}
		}

		
		if (currentMinIndex != i)
		{
			list[currentMinIndex] = list[i];
			list[i] = currentMin;
		}
	}
}

void printArray(double list[], int array_size)//print array
{
	for (int i = 0; i < array_size; i++)
	{
		cout << list[i] << " ";
	}
}
