//**************************************************************************
//
// Student name: Mark Onza
//
// Student number: 200356407
//
// Assignment number: Assignment Number 5
//
// Program name: Array Values
//
// Date written: April 10, 2015
//
// Problem statement: Print out arrays for min,max,mean,average,median and mode.
//
// Input: 20 interger values.
//
// Output: min,max,mean,average,median and mode.
//
// Algorithm: pass values to voids to compute the code
//
// Major variables: v and MAX_ARRAY
//
// Assumptions: the user will input 20 integer values to then compute for the output.
//
//**************************************************************************

#include<iostream>
using namespace std;

void getval(int[], int);
int getmax(int[], int);
int getmin(int[], int);
float avg(int[], int);
int getmed(int[], int);
void getmode(int[], int);


int main()
{
	const int MAX_ARRAY = 20;
	int v[MAX_ARRAY];


	getval(v, MAX_ARRAY);
	int a = getmin(v, MAX_ARRAY);
	int x = getmax(v, MAX_ARRAY);
	float z = avg(v, MAX_ARRAY);
	int y = getmed(v, MAX_ARRAY);
	getmode(v, MAX_ARRAY);

	

	cout << "The maximum value in the array is " << x << endl;
	cout << "The minimum value in the array is " << a << endl; 
	cout << "The average of the array is " << z << endl;
	cout << "The median of the array is " << y << endl;


	return 0;
}

void getval(int val[], int MAX_ARRAY)
{
	int j = MAX_ARRAY;
	for (int i = 0; i < MAX_ARRAY; i++)
	{
		cout << "Enter " << j << " more value(s)." << endl;
		cin >> val[i];
		j--;
	}
}

int getmax(int val[], int MAX_ARRAY)
{
	int max = val[0];
	for (int i = 0; i < MAX_ARRAY; i++)
	{
		if (val[i] > max)
			max = val[i];
	}
	return max;
}

int getmin(int val[], int MAX_ARRAY)
{
	int min = val[0];
	for (int i = 0; i < MAX_ARRAY; i++)
	{
		if (val[i] < min)
			min = val[i];
	}
	return min;
}

float avg(int val[], int MA)
{
	int sum = 0;
	for (int i = 0; i < MA; i++)
		sum += val[i];
	float avg = sum / MA;

	return avg;
}

int getmed(int val[], int MA)
{
	if (MA % 2 == 0)
	{
		int x = (val[MA / 2]) + (val[(MA / 2 - 1)]);
		int y = x / 2;
		return y;
	}
	else 
	{
		int x = (val[MA / 2]);
		return x;
	}
	
}

void getmode(int a[], int MA)
{
	int counter = 1;  // this will count how many times the number has occured
	int max = 0; // used to determine which number occurs the most
	int mode = a[0]; // this starts the mode at the first position in the array. My array is named a[]
	for (int i = 0; i < MA - 1; i++) // use a variable i to run a loop through the length of the array
	{
		if (a[i] == a[i + 1]) //if the previous number = the number next to it in the array, the counter is incremented
		{
			counter++;
			if (counter > max) // if the counter is greater than the previous max value for mode, it replaces it
			{
				max = counter; // max will replace previous counter value
				mode = a[i]; // mode is now equal to whatever a[i] is, i value will be based on what iteration of the loop is occuring
			}
		}
		else
			counter = 1; // if number occurs more than once, but doesn't occur more than the current mode it resets the counter for the loop
	}
	cout << "The mode(s) is/are : "; // prints out mode
	for (int i = 0; i < MA; i++)
	{
		if (max < 1)// if all numbers occur only once, then no mode
		{
			cout << "NO MODE" << endl; // will print out NO MODE if all numbers occur only once
			break; // need to break out of loop so NO MODE doesn't print MAX_ARRAY # of times
		}
		else if (a[i] == a[i + max - 1]) // if the array position + the value of max (number of times mode occured) - 1 is equal to the a[i]
			cout << a[i] << " "; // prints out number because it is one of the modes
	}
}