/*
NAME: SHUROUK ALHELOU
SID: 200336944
ASSIGNMENT 5
*/
/*
Write a program to read up to 20 integers from a file and store the integers in an array of integer type. With the values in the array, compute and display the following:

minimum: smallest value in the array
maximum: largest value in the array
mean: average of all values in the array
median: the value in the middle of the array once all values have been sorted. If there is no single index at the middle of the array, average the values in the 2 adjacent spots. For example: if the array has 3 values (with indices 0,1,2), once the array is sorted the median will be at index 1. If the array has 4 values (with indices 0,1,2,3), once the array is sorted the median will be the average of the values at indices 2 and 3.
mode: find the value in the array which occurs most often. A straightforward approach is possible once the array is sorted.
*/

#include<iostream>
#include<fstream>
#include<ctime>
using namespace std;

int GetMax(int[], int, int&);
int GetMin(int[], int, int&);
float GetAvg(float&, int);
//int GetMedian(int[]);
//int GetMode(int[]);

int main()
{
	const int size = 20;
	int array[size];
	int max, min, index;
	//int median, mode;
	float avg, sum = 0;
		
		ifstream inputfile;
		inputfile.open("input.txt");
		
		//srand(time(0));
		for (index = 0; index < size; index++)
		{
			array[index]= rand() % size;
		}
		
			for (index = 0; index < size; index++)
			{
				inputfile >> array[index];
				sum += array[index];
			}
			
			max = GetMax(array, size, index);;
			min = GetMin(array, size, index);
			avg = GetAvg(sum, size);
			//median;
			//mode;
			
			for (int i = 0; i < size; i++)
			{
				cout << array[i] << endl;
			
			}

			
			while (array[size] > array[20])
			{
				cout << "Error! Values are More than 20" << endl;
				return -1;
			}
			cout << endl;
			cout << "The Total Sum of the Values in the array is: " << sum << endl;
			cout << "The Maximum value in the array is: " << max << endl;
			cout << "The Minimum value in the array is: " << min << endl;
			cout << "The Average of the values in the array is: " << avg << endl;
			//cout << "The Median value in the array is: " << median << endl;
			//cout << "The Mode value in the array is: " << mode << endl;
	
	return 0;
}



int GetMax(int Array[], int Size, int& index)
{
	int Max = Array[0];
	for (int i = 0; i < Size; i++)
	{
		if (Array[i]>Max)
		{
			Max = Array[i];
			index = i;
		}
	}
	return Max;
}




int GetMin(int Array[], int Size, int& index)
{
	int Min = Array[0];

	for (int j = 0; j < Size; j++)
	{
		if (Array[j] < Min)
		{
			Min = Array[j];
			index = j;
		}
	}
	return Min;
}



float GetAvg(float& Sum, int Total)
{
	float Avg;
	Avg = Sum / Total;

	return Avg;
}

//int GetMedian(int[])
//int GetMode(int[])

