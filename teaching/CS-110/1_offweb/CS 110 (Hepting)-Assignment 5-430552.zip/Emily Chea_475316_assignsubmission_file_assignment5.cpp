// STUDENT NAME: Emily Chea

// STUDENT NUMBER: 200352055

// ASSIGNMENT NUMBER: 5

// PROGRAM NAME: C++ Visual Studio 2013

// DATE WRITTEN: March 30, 2015

// PROBLEM STATEMENT: write a array that can hold up to 20 integers and display the minimum, maximum mean, median and mode of the array

// INPUT: 20 integers

// OUTPUT: minimum, maximum, median, mode

// ALGORITHM: get 20 values from a external text file; calculate minimum; calculate maximum; calculate mean; calculate median; calculate mode; display minimum, maximum, mean and mode

// MAJOR VARIABLES: int minimum, int maximum, float mean, float median, int mode

// ASSUMPTIONS: 

// PROGRAM LIMITATIONS: 

//***************************************************************************************************************
#include <iostream>
#include <fstream>
using namespace std;

//function protype
int Minimum(int[], int);
int Maximum(int[], int);
float Mean(int[], int, int);
float Median(int[], int, int, int);
int Mode(int[], int, int);

int main()
{
	const int maxarray = 20;
	int number[maxarray];
	int index;

	ifstream inputfile;
	inputfile.open("input.txt");
	
	int numread = 0;
	bool read = true;
	int value;
	//read integers from file
	for (index = 0; index < maxarray; index++)
	{
		if (inputfile >> value)
		{
			for (int j = 0; j < numread; j++)
			{
				if (value == number[maxarray])
				{
					read = false;
					break;
				}
			}
			if (read)
			{
				number[numread] = value;
				numread++;
			}
		}
		else
		{
			break;
		}
	}
	for (int index = 0; index < numread; index++)
	{
		cout << number[index] << " ";
	}
	cout << endl;
	//determine minimum
	int minimum = Minimum(number, index);
	cout << "The minimum of the array is " << minimum << endl;
	//determine maximum
	int maximum = Maximum(number, index);
	cout << "The maximum of the array is " << maximum << endl;
	//determine mean
	float mean = Mean(number, index, value);
	cout << "The mean of the array is " << mean << endl;
	//determine median
	float median = Median(number, index, minimum, value);
	cout << "The median of the array is " << median << endl;
	// detemine mode
	int mode = Mode(number, index, minimum);
	cout << "The mode of the array is " << mode << endl;
	

	return 0;
}
int Minimum(int number[], int index)
{
	int minimum = number[0];
	for (index = 0; index < 20; index++)
	{
		if (minimum > number[index])
		{
			minimum = number[index];	
		}
	}
	return minimum;
}
int Maximum(int number[], int index)
{
	int maximum = number [19];
	for (index = 19; index >= 0; index--)
	{
		if (maximum < number[index])
		{
			maximum = number[index];
		}
	}
	return maximum;
}
float Mean(int number[], int index, int value)
{
	float mean;
	float sum = 0;
	for (index = 0; index < 20; index++)
	{
		sum = sum + number[index];
	}
	mean = sum / value;
	return mean;
}
float Median(int number[], int index, int minimum, int value)
{
	for (int i = 0; i < index - 1; i++)
	{
		int minindex = i;
		for (int j = i + 1; j < index; j++)
		{
			if (minimum > number[j])
			{
				minimum = number[j];
				minindex = j;
			}
		}
		// swap number [i] with number [ minindex] if needed
		if (minindex != i)
		{
			number[minindex] = number[i];
			number[i] = minimum;
		}
	}
	float median;
	if (value % 2 == 0)
	{
		median = (number[value / 2] + number[(value / 2) - 1]) / 2;
	}
	else
	{
		median = number[(value + 1) / 2];
	}
	return median;
}
int Mode(int number[], int index, int minimum)
{
	for (int i = 0; i < index - 1; i++)
	{
		int minindex = i;
		for (int j = i + 1; j < index; j++)
		{
			if (minimum > number[j])
			{
				minimum = number[j];
				minindex = j;
			}
		}
		// swap number [i] with number [ minindex] if needed
		if (minindex != i)
		{
			number[minindex] = number[i];
			number[i] = minimum;
		}
	}
	int count = 1;
	int max = 0;
	int mode = number[0];
	for (index = 0; index < 20; index++)
	{
		if (max == 1)
		{
			cout << "No mode found" << endl;
		}
		else
		{
			cout << "The mode(s) is/are " << endl;
			int maxarray;
			while (index < maxarray - max + 1)
			{
				if (number[index] == number[index + max - 1])
				{
					cout << number[index] << " ";
					index += max;
				}
				else
				{
					index++;
				}
			}
		}
	}
	return mode;
}