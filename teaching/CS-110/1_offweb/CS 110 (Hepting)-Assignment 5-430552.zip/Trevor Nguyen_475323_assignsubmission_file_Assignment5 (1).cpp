// Name: Trevor Nguyen
// Student ID: 200275037
// Class: CS 110
// Instructor: Daryl Hepting
// Assignment 5

/*Write a program to read up to 20 integers from a file and store the integers in an array of integer type. With the values in the array, compute and display the following:

minimum: smallest value in the array
maximum: largest value in the array
mean: average of all values in the array
median: the value in the middle of the array once all values have been sorted.
    If there is no single index at the middle of the array,
    average the values in the 2 adjacent spots.
mode: find the value in the array which occurs most often.
    A straightforward approach is possible once the array is sorted.

*/

#include <iostream>

using namespace std;

void PrintMin(int s, int list[]);
void PrintMax(int s, int list[]);
void PrintAverage(int s, int list[]);
void PrintMedian(int s, int list[]);
void PrintMode(int s, int list[]);

int main()
{    
// declare an array for size
    int s;
    int list[s];

    cout << "please enter a array size (between 1 and 20): ";
    cin >> s;

    
// all variables
    double sum = 0;
    int max = list[0];
    int IndexOfMax = 0;
    int min = 20;
    int IndexOfMin = 0;
    double median;



//Ask user to enter numbers for the array
    for (int i = 0; i < s ; i++)
        {
            cout << "enter number " << i + 1 << " for the array: ";
            cin >> list[i];
    
        }
        
//minimum: smallest value in the array
    PrintMin(s, list);


//maximum: largest value in the array
    PrintMax(s, list);

//mean: average of all values in the array
    PrintAverage(s, list);
    
//median: the value in the middle of the array once all values have been sorted.
    PrintMedian(s, list);
    
//mode: find the value in the array which occurs most often. 
    PrintMode(s, list);

return 0;
}

void PrintMin(int s, int list[])
{
    int min = 20;
    cout << "The smallest value in the array is ";
        for (int i = 0; i < s; i++)
        {
            if (list[i] < min)
            {
                min = list[i];
            }
        }
    cout << min << endl;
}    

void PrintMax (int s, int list[])
{
    int max = list[0];
    cout << "The largest value in the array is ";
    for (int i = 0; i < s; i++)
    {
        if (list[i] > max)
        {
            max = list[i];
        }
    }
    cout << max << endl;
}


void PrintAverage (int s, int list[])
{
    double sum = 0;
    cout << "the mean of the numbers are: ";
    for (int i= 0; i < s; i++)
        {
            sum += list[i];
        }
    cout << sum / s << endl;
}

void PrintMedian (int s, int list[])
{
    cout << "The median is: ";
    for (int i= 0; i < s - 1; i++)
    {
        double currentMin = list[i];
        int currentMinIndex=i;
        for (int j = i +1; j < s; j++)
        {
            if (currentMin > list[j])
            {
                currentMin= list[j];
                currentMinIndex=j;
            }
        }
        if (currentMinIndex != i)
        {
            list[currentMinIndex] = list[i];
            list[i] = currentMin;
        }
    }
        
    cout << list[ s / 2 ] << endl;
}

void PrintMode (int s, int list[])
{   
    int counter = 1; 
    int mode = list[0];
    int modemax = 0;
    for (int i = 0; i < s - 1; i++)
    {
        if ( list[i] == list[i+1] )
        {
            counter++;
            if (counter > modemax)
            {
                modemax = counter;
                mode = list[i];
            }
        }   
        else
        {
            counter = 1;
            mode = 0;
        }
    }

    if (mode != 0)
        cout <<"The mode is: " << mode << endl;
    else
        cout << "There is no mode" << endl;
}
