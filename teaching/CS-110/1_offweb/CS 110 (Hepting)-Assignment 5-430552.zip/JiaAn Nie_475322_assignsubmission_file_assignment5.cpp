#include <iostream>
#include <iomanip>
using namespace std;
const int max = 20;
void sort(int[]);
int maximum(int[], int);
int minimum(int[], int);
double average(int[]);
double median(int[]);
int mode(int[]);
int main()
{
	int input[max];
	double mean;
	int Mode;
	cout << "enter 20 numbers" << endl;
	for (int i = 0; i < max; i++)
	{
		cin >> input[i];
	}	
	sort(input);
	int largest = input[0], smallest = input[0];
	double Med;
	cout << endl << endl;
	largest = maximum(input, largest);
	smallest = minimum(input, smallest);
	mean = average(input);
	Med = median(input);
	Mode = mode(input);
	cout << "the largest number is " << largest << endl;
	cout << "the smallest number is " << smallest << endl;
	cout << "the mean of all numbers is " << fixed  << setprecision (2) << mean << endl;
	cout << "the median of all the number is " << fixed << setprecision (2) << Med << endl;
	if (Mode == 0)
	{
		cout << "there is no mode in the list of numbers that you entered" << endl;
	}
	else
	{
		cout << "the mode of all the numbers is " << Mode << endl;
	}
	return 0;
}
void sort(int input[])
{
	
	int temp;
	int Min;
	for (int i = 0; i < max; i++)
	{
		Min = i;
		for (int j = (i + 1); j < max; j++)
		{
			if (input[j] < input[Min])
			{
				Min = j;
			}
			
		}
		temp = input[i];
		input[i] = input  [Min];
		input [Min] = temp;
	}
}
int maximum(int input[], int largest)
{
	for (int i = 0; i < max; i++)
	{
		if (input[i] >= largest)
		{
			largest = input[i];
		}
	}
	return largest;
	return 0;
}
int minimum(int input[], int smallest)
{
	for (int i = 0; i < max; i++)
	{
		if (input[i] <= smallest)
		{
			smallest = input[i];
		}
	}
	return smallest;
}
double average(int input[])
{
	double mean;
	double sum = 0;
	for (int i = 0; i < max; i++)
	{
		sum += input[i];
	}
	mean = sum / max;
	return mean;
}
double median(int input[])
{
	double Med;
	if ((max % 2) == 0)
	{
		Med = (input[(max / 2)] + input[max / 2 + 1]) / 2.00;
	}
	else
	{
		Med = input[max / 2];
	}
	return Med;
}
int mode(int input[])
{
	int Mod = 0;
	int count = 1;
	int temp = 1;
	for (int i = 0; i < max; i++)
	{

			if (input[i] == input[i + 1])
			{
				count++;
			}
			else
			{
				if (count > temp)
				{
					Mod = input[i];
				}

				temp = count;
				count = 1;

			}
		
	}
	return Mod;
}