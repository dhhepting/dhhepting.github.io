vertex-and-fragment -- source files

Unzip, then serve this folder with any static web server, for example:

    python3 -m http.server 8000

and open  http://localhost:8000/experimental/modular/vertex-and-fragment/app.html

(Opening the html file straight from disk will not work: the page loads ES modules
and shader files, which browsers only allow over http.)
