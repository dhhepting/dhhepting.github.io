// chaosgame.mjs -- DOM-free renderer for a two-map chaos game, drawn by INSTANCING.
// Each map is described by its centre and an SVD of its linear part:
// { centre: [x, y], u, v, s: [s0, s1] }  (see svdMap in ifs.mjs).
//
// The chaos game runs once on the CPU and its points go to the GPU once.
// The vertex shader then draws them 2^levels times, instance i using the
// composite matrix whose binary digits (0 -> Transformation0, 1 -> Transformation1)
// spell i. levels = 4 gives the 16 instances 0000 ... 1111.
//
// The dependency points one way: main.mjs (controller) -> ChaosGame.
// Nothing here touches `document`; the API speaks in geometry (centres,
// scales, angles, point counts), not in UI vocabulary.

import {
  svdMap,
  chaosGame,
  makeChoices,
  colourBytes,
  viewMatrix,
  worldAt,
} from './ifs.mjs';

export const MAX_POINTS = 400000;
export const MAX_LEVELS = 6;      // 2^6 = 64 instances; the shader loops over at most 8 digits

// One colour per transformation (RGB, 0..1). Exported so the controller
// can colour its labels to match the picture.
export const MAP_COLOURS = [
  [0.10, 0.35, 0.85],
  [0.88, 0.30, 0.10],
];

const OUTLINE_COLOUR = [0.13, 0.13, 0.13];

export class ChaosGame {
  #gl;
  #program;
  #uniforms;

  #pointVao;
  #positionBuffer;
  #mapBuffer;

  #centreVao;
  #centrePositionBuffer;
  #centreMapBuffer;

  #positions = new Float32Array(MAX_POINTS * 2);
  #choices;
  #colours = new Uint8Array(MAX_POINTS);
  #colourDepth = 1;
  #colourDirty = true;
  #seed = 1;

  #transforms = [];
  #mats = [];

  #count = 30000;
  #levels = 4;
  #byInstance = false;
  #pointSize = 1.5;
  #showCentres = true;
  #view = { cx: 0.5, cy: 0.15, half: 1.25 };

  #width = 1;
  #height = 1;
  #dpr = 1;

  #bounds = { x0: -1, x1: 1, y0: -1, y1: 1 };
  #pointsDirty = true;
  #choicesDirty = true;
  #frameDirty = true;
  #lastGenerateMs = 0;

  // `program` comes from initShaders(gl, vertSource, fragSource).
  constructor(gl, program) {
    this.#gl = gl;
    this.#uniforms = {
      view: gl.getUniformLocation(program, 'uView'),
      pointSize: gl.getUniformLocation(program, 'uPointSize'),
      color0: gl.getUniformLocation(program, 'uColor0'),
      color1: gl.getUniformLocation(program, 'uColor1'),
      round: gl.getUniformLocation(program, 'uRound'),
      map: gl.getUniformLocation(program, 'uMap'),
      levels: gl.getUniformLocation(program, 'uLevels'),
      instanced: gl.getUniformLocation(program, 'uInstanced'),
      byInstance: gl.getUniformLocation(program, 'uByInstance'),
    };
    this.#program = program;

    // --- the chaos-game points: position (vec2) + map index (0 or 1)
    this.#pointVao = gl.createVertexArray();
    gl.bindVertexArray(this.#pointVao);

    this.#positionBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.#positionBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, this.#positions.byteLength, gl.DYNAMIC_DRAW);
    gl.enableVertexAttribArray(0);
    gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);

    this.#mapBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.#mapBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, MAX_POINTS, gl.DYNAMIC_DRAW);
    gl.enableVertexAttribArray(1);
    // bytes 0..255 arrive in the shader as t = 0.0..1.0 (the colour address)
    gl.vertexAttribPointer(1, 1, gl.UNSIGNED_BYTE, true, 0, 0);

    // --- the two centre handles
    this.#centreVao = gl.createVertexArray();
    gl.bindVertexArray(this.#centreVao);

    this.#centrePositionBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.#centrePositionBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, 4 * 4, gl.DYNAMIC_DRAW);
    gl.enableVertexAttribArray(0);
    gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);

    this.#centreMapBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.#centreMapBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Uint8Array([0, 255]), gl.STATIC_DRAW);
    gl.enableVertexAttribArray(1);
    gl.vertexAttribPointer(1, 1, gl.UNSIGNED_BYTE, true, 0, 0);

    gl.bindVertexArray(null);
    gl.clearColor(1, 1, 1, 1);
  }

  // ------------------------------------------------------------ the maps

  // Exactly two { centre: [x, y], u, v, s: [s0, s1] } records (angles in radians).
  setTransforms(list) {
    if (list.length !== 2) {
      throw new Error('ChaosGame draws exactly two transformations');
    }
    this.#transforms = list.map((t) => ({
      centre: [t.centre[0], t.centre[1]],
      u: t.u,
      v: t.v,
      s: [t.s[0], t.s[1]],
    }));
    this.#rebuildMatrices();
  }

  getTransforms() {
    return this.#transforms.map((t) => ({
      centre: [t.centre[0], t.centre[1]],
      u: t.u,
      v: t.v,
      s: [t.s[0], t.s[1]],
    }));
  }

  // Move one centre; scale and angle are untouched.
  setCentre(i, x, y) {
    this.#transforms[i].centre = [x, y];
    this.#rebuildMatrices();
  }

  // The current 3x3 matrix of map i (a copy)
  getMatrix(i) {
    return Float64Array.from(this.#mats[i]);
  }

  #rebuildMatrices() {
    this.#mats = this.#transforms.map(svdMap);
    this.#pointsDirty = true;
    this.#frameDirty = true;
  }

  // ------------------------------------------------------------ settings

  setCount(n) {
    this.#count = Math.max(1, Math.min(MAX_POINTS, Math.floor(n)));
    this.#pointsDirty = true;
    this.#frameDirty = true;
  }

  // New random sequence of map choices. Same seed -> same picture.
  reroll(seed) {
    this.#seed = seed >>> 0;
    this.#choicesDirty = true;
    this.#colourDirty = true;
    this.#pointsDirty = true;   // the orbit itself follows the choices
    this.#frameDirty = true;
  }

  // Colour each point by its last n map choices (1..8): 2^n colours.
  setColourDepth(n) {
    this.#colourDepth = Math.max(1, Math.min(8, Math.floor(n)));
    this.#colourDirty = true;
    this.#frameDirty = true;
  }

  // Number of binary digits in each instance address: 2^n instances (n = 0..MAX_LEVELS).
  setLevels(n) {
    this.#levels = Math.max(0, Math.min(MAX_LEVELS, Math.floor(n)));
    this.#frameDirty = true;
  }

  get instanceCount() {
    return 1 << this.#levels;
  }

  setColourByInstance(on) {
    this.#byInstance = on;
    this.#frameDirty = true;
  }

  setPointSize(px) {
    this.#pointSize = px;
    this.#frameDirty = true;
  }

  setShowCentres(on) {
    this.#showCentres = on;
    this.#frameDirty = true;
  }

  get lastGenerateMs() {
    return this.#lastGenerateMs;
  }

  // ---------------------------------------------------------------- view

  get bounds() {
    return this.#bounds;
  }

  getView() {
    return { ...this.#view };
  }

  setView(v) {
    this.#view = { cx: v.cx, cy: v.cy, half: v.half };
    this.#frameDirty = true;
  }

  // width/height in device pixels; dpr = device pixels per CSS pixel
  resize(width, height, dpr) {
    this.#width = Math.max(1, width);
    this.#height = Math.max(1, height);
    this.#dpr = dpr;
    this.#gl.canvas.width = this.#width;
    this.#gl.canvas.height = this.#height;
    this.#frameDirty = true;
  }

  // u, v in [0, 1] across the canvas, v pointing up -> world [x, y]
  worldAt(u, v) {
    return worldAt(this.#view, this.#width / this.#height, u, v);
  }

  // ------------------------------------------------------------- drawing

  // The positions depend on the maps; the colours depend only on the choice
  // sequence and the depth, so they are rebuilt far less often.
  #updateChoicesAndColours() {
    const gl = this.#gl;
    if (this.#choicesDirty) {
      this.#choices = makeChoices(MAX_POINTS, this.#transforms.length, this.#seed);
      this.#choicesDirty = false;
      this.#colourDirty = true;
    }
    if (this.#colourDirty) {
      colourBytes(this.#choices, MAX_POINTS, this.#colourDepth, this.#colours);
      gl.bindBuffer(gl.ARRAY_BUFFER, this.#mapBuffer);
      gl.bufferSubData(gl.ARRAY_BUFFER, 0, this.#colours);
      this.#colourDirty = false;
    }
  }

  #regenerate() {
    const gl = this.#gl;
    const t0 = performance.now();
    // Centre 0 is the fixed point of map 0, hence a point of the attractor
    chaosGame(
      this.#mats,
      this.#choices,
      this.#count,
      this.#transforms[0].centre,
      this.#positions,
    );
    this.#lastGenerateMs = performance.now() - t0;
    // bounding box of the attractor (the instances are all subsets of it)
    let x0 = Infinity, x1 = -Infinity, y0 = Infinity, y1 = -Infinity;
    const P = this.#positions;
    for (let i = 0; i < this.#count; i++) {
      const x = P[2 * i], y = P[2 * i + 1];
      if (x < x0) x0 = x;
      if (x > x1) x1 = x;
      if (y < y0) y0 = y;
      if (y > y1) y1 = y;
    }
    this.#bounds = { x0, x1, y0, y1 };

    gl.bindBuffer(gl.ARRAY_BUFFER, this.#positionBuffer);
    gl.bufferSubData(
      gl.ARRAY_BUFFER,
      0,
      this.#positions.subarray(0, this.#count * 2),
    );
    this.#pointsDirty = false;
  }

  // Returns true if it drew a frame, false if nothing had changed.
  render() {
    const gl = this.#gl;
    this.#updateChoicesAndColours();
    if (this.#pointsDirty) {
      this.#regenerate();
    }
    if (!this.#frameDirty) {
      return false;
    }

    gl.viewport(0, 0, this.#width, this.#height);
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.useProgram(this.#program);

    gl.uniformMatrix3fv(
      this.#uniforms.view,
      false,
      viewMatrix(this.#view, this.#width / this.#height),
    );

    // 1. the attractor: ONE set of points, drawn once per instance
    gl.uniformMatrix3fv(
      this.#uniforms.map,
      false,
      Float32Array.from([...this.#mats[0], ...this.#mats[1]]),
    );
    gl.uniform1i(this.#uniforms.levels, this.#levels);
    gl.uniform1i(this.#uniforms.instanced, 1);
    gl.uniform1i(this.#uniforms.byInstance, this.#byInstance ? 1 : 0);
    gl.uniform1i(this.#uniforms.round, 0);
    gl.uniform3fv(this.#uniforms.color0, MAP_COLOURS[0]);
    gl.uniform3fv(this.#uniforms.color1, MAP_COLOURS[1]);
    gl.uniform1f(this.#uniforms.pointSize, this.#pointSize * this.#dpr);
    gl.bindVertexArray(this.#pointVao);
    gl.drawArraysInstanced(gl.POINTS, 0, this.#count, this.instanceCount);

    // 2. the centres: a dark disc, then a coloured disc on top of it
    if (this.#showCentres) {
      const c0 = this.#transforms[0].centre;
      const c1 = this.#transforms[1].centre;
      gl.bindBuffer(gl.ARRAY_BUFFER, this.#centrePositionBuffer);
      gl.bufferSubData(
        gl.ARRAY_BUFFER,
        0,
        new Float32Array([c0[0], c0[1], c1[0], c1[1]]),
      );
      gl.bindVertexArray(this.#centreVao);
      gl.uniform1i(this.#uniforms.round, 1);
      gl.uniform1i(this.#uniforms.instanced, 0);

      gl.uniform3fv(this.#uniforms.color0, OUTLINE_COLOUR);
      gl.uniform3fv(this.#uniforms.color1, OUTLINE_COLOUR);
      gl.uniform1f(this.#uniforms.pointSize, 17 * this.#dpr);
      gl.drawArrays(gl.POINTS, 0, 2);

      gl.uniform3fv(this.#uniforms.color0, MAP_COLOURS[0]);
      gl.uniform3fv(this.#uniforms.color1, MAP_COLOURS[1]);
      gl.uniform1f(this.#uniforms.pointSize, 11 * this.#dpr);
      gl.drawArrays(gl.POINTS, 0, 2);
    }

    gl.bindVertexArray(null);
    this.#frameDirty = false;
    return true;
  }
}
