import { defineConfig } from "vite";

// base "./" keeps every URL relative, so the build can be dropped into
// code/experimental/built/figure/ (or anywhere else) and just work.
export default defineConfig({
  base: "./",
  build: {
    outDir: "dist",
    emptyOutDir: true,
    // Shaders are tiny: never inline them as data: URLs, we want real files
    // that students can open and read in the browser's network tab.
    assetsInlineLimit: 0,
  },
});
