#version 300 es
// Per-FRAGMENT lighting, vertex half: only the three vectors the fragment
// shader needs (N, L, E) are produced here, in eye space, and interpolated.
layout(location = 0) in vec3 aPosition;
layout(location = 1) in vec3 aNormal;

uniform mat4 uModelViewMatrix;
uniform mat4 uProjectionMatrix;
uniform mat3 uNormalMatrix;
uniform vec4 uLightEye;

out vec3 vN;
out vec3 vL;
out vec3 vE;

void main() {
    vec4 eyePos = uModelViewMatrix * vec4(aPosition, 1.0);
    vec3 pos = eyePos.xyz;

    vL = normalize(uLightEye.xyz - uLightEye.w * pos);
    vE = normalize(-pos);
    vN = normalize(uNormalMatrix * aNormal);

    gl_Position = uProjectionMatrix * eyePos;
}
