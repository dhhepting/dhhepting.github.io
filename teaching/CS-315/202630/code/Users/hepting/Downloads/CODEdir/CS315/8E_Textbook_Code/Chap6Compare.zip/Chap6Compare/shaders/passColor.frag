#version 300 es
// Fragment shader for per-VERTEX lighting: the colour was already computed in
// the vertex shader and interpolated by the rasteriser, so this does no maths.
precision highp float;

in vec4 vColor;
out vec4 fragColor;

void main() {
    fragColor = vColor;
}
