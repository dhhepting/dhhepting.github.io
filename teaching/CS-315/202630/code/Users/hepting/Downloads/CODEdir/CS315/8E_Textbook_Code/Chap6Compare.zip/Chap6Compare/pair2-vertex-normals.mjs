// shadedSphere3 (per-vertex) vs shadedSphere4 (per-fragment), both using
// vertex normals (each vertex carries the sphere's own normal there).
import { CompareApp } from './lib/CompareApp.mjs';

new CompareApp(document.getElementById('app'), {
    title: 'Per-vertex vs per-fragment shading with vertex normals',
    summary:
        '<strong>shadedSphere3</strong> (left) lights each vertex and interpolates colour. <strong>shadedSphere4</strong> (right) interpolates the normal ' +
        '(plus light and eye vectors) and lights every pixel. Each vertex carries the sphere’s true surface normal, so the surface looks smooth rather than faceted.',
    shaders: ['perVertex.vert', 'passColor.frag', 'perFragment.vert', 'blinnPhong.frag'],
    mesh: { kinds: ['sphere'], normalMode: 'vertex' },
    defaults: { subdiv: 3 },
    panes: [
        {
            title: 'shadedSphere3',
            subtitle: 'vertex normals, per-vertex shading',
            sources: () => ({ vert: 'perVertex.vert', frag: 'passColor.frag' }),
        },
        {
            title: 'shadedSphere4',
            subtitle: 'vertex normals, per-fragment shading',
            sources: () => ({ vert: 'perFragment.vert', frag: 'blinnPhong.frag' }),
        },
    ],
    notes: [
        {
            heading: 'What to look for',
            html: `
<p>This is the pair where the gap is easiest to see, because the normal now changes smoothly across each triangle.</p>
<ul>
<li><strong>Per-vertex (left)</strong> computes N·L and N·H only at the corners. Between corners it can only blend colours, so the specular highlight is smeared across triangles and its edges follow the triangle layout. It can vanish entirely if no corner lies inside it.</li>
<li><strong>Per-fragment (right)</strong> interpolates the normal, renormalises it, and evaluates the equation per pixel, giving a round highlight at any subdivision level.</li>
<li><strong>Try:</strong> subdivision 1–2 with shininess 100 or more, then rotate slowly (or tick <em>Auto-orbit</em> with the light fixed to the world). Compare how the highlight moves on each side.</li>
<li>Raise the subdivision level: the left side converges toward the right, because smaller triangles mean the corners sample the surface more densely. That convergence costs vertices instead of pixels.</li>
</ul>`,
        },
    ],
}).start();
