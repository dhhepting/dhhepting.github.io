// shadedSphere1 (per-vertex) vs shadedSphere2 (per-fragment), both using
// true (face) normals.
import { CompareApp } from './lib/CompareApp.mjs';

new CompareApp(document.getElementById('app'), {
    title: 'Per-vertex vs per-fragment shading with true normals',
    summary:
        '<strong>shadedSphere1</strong> (left) evaluates the lighting equation once per vertex and interpolates the resulting colour. ' +
        '<strong>shadedSphere2</strong> (right) interpolates the vectors and evaluates the equation at every pixel. ' +
        'Both use each triangle’s true face normal, so every triangle is flat.',
    shaders: ['perVertex.vert', 'passColor.frag', 'perFragment.vert', 'blinnPhong.frag'],
    mesh: { kinds: ['sphere'], normalMode: 'true' },
    defaults: { subdiv: 3 },
    panes: [
        {
            title: 'shadedSphere1',
            subtitle: 'true normals, per-vertex shading',
            sources: () => ({ vert: 'perVertex.vert', frag: 'passColor.frag' }),
        },
        {
            title: 'shadedSphere2',
            subtitle: 'true normals, per-fragment shading',
            sources: () => ({ vert: 'perFragment.vert', frag: 'blinnPhong.frag' }),
        },
    ],
    notes: [
        {
            heading: 'What to look for',
            html: `
<p>With true normals the surface is faceted on both sides, because the normal is constant across each triangle. What differs is
<em>where the lighting equation is evaluated</em>.</p>
<ul>
<li><strong>Diffuse term.</strong> With a directional light and a constant face normal, N·L is the same at all three corners, so both sides agree on diffuse.</li>
<li><strong>Specular term.</strong> The halfway vector depends on the direction to the viewer, which changes from pixel to pixel. Per-fragment shading follows that change across the triangle; per-vertex shading can only blend the three corner values, so a highlight that falls between corners is blunted or missed.</li>
<li><strong>Try:</strong> switch the light to <em>Point</em>, raise shininess to 150 or more, and lower the subdivision level to 1 or 2. Then watch the difference image as you drag the view.</li>
</ul>
<p>The cost table shows the trade: per-vertex shading does its work per vertex, per-fragment shading does it per pixel. Raise the subdivision level and watch the balance move.</p>`,
        },
    ],
}).start();
