# Chapter 6 shading comparisons (WebGL2)

Four two-canvas pages, one set of viewing controls each, plus a difference
image and an informal cost comparison.

| Page | Left | Right |
|---|---|---|
| `pair1-true-normals.html` | shadedSphere1: true normals, per-vertex | shadedSphere2: true normals, per-fragment |
| `pair2-vertex-normals.html` | shadedSphere3: vertex normals, per-vertex | shadedSphere4: vertex normals, per-fragment |
| `pair3-eye-vs-object-space.html` | shadedSphereEyeSpace | shadedSphereObjectSpace |
| `pair4-phong-vs-blinn-phong.html` | Phong, (R·E)^n | modified Blinn-Phong, (N·H)^n′ |

Open `index.html` for the list.

## Where it goes

Put the `Chap6Compare/` folder next to your `Common/` folder:

    <course root>/
      Common/            MV.mjs, initShadersJS.mjs
      Chap6Compare/      this project

The only file that names `Common/` is `lib/common.mjs`. If your layout differs,
change the two paths there. It assumes Angel's MV API (`vec3`, `lookAt`, `ortho`,
`perspective`, `rotate` in degrees, `mult`, `inverse`, `normalMatrix(m, true)`,
`flatten`) and `initShaders(gl, vertexSource, fragmentSource)` returning a
linked program (named or default export).

Run it from a dev server (ES modules and `fetch` do not work from `file://`),
with the Vite root at `<course root>` so `Common/` is inside it.

## Layout

    lib/CompareApp.mjs     two-canvas harness: shared controls, difference image, cost panel, stress test
    lib/LitMeshPane.mjs    one canvas + WebGL2 context + program (uniforms found by reflection)
    lib/frameMath.mjs      camera, light and eye in eye/object space (no DOM/GL)
    lib/meshes.mjs         subdivided-tetrahedron sphere (true or vertex normals), cube (no DOM/GL)
    lib/costModel.mjs      counts operations in shader source, weights them
    lib/shaderLibrary.mjs  literal new URL(...) entries for every shader (Vite-friendly) + loader
    shaders/*.vert|*.frag  GLSL ES 3.00 shaders, one idea per file
    pairN-*.mjs/.html      thin page configs

## The cost panel

*Cost per vertex / per pixel* is read from the shader text itself (see
`costModel.mjs` for the weights). *Pixels shaded* is measured by reading the
canvas back. *Estimated work* = vertices × vertex cost + pixels × pixel cost.
The stress test redraws each side many times with the depth test off and waits
for the GPU, so it measures wall-clock time per pass. Both are informal.

## Notes on fidelity to the textbook samples

* The 7E sample repo labels shadedSphere1/2 "true normals" but its code feeds
  them vertex normals, and the reverse for 3/4. These pages follow the README
  names: pair 1 uses face normals, pair 2 uses vertex normals.
* The object-space sample's viewer vector is `normalize(eyePosition)` (viewer at
  infinity). Pair 3 uses `normalize(eyePosition - position)` so that the two
  sides match exactly.
* "Modified Blinn-Phong" here means the halfway-vector specular term with the
  exponent multiplied (default 4) so highlights match Phong's size.
