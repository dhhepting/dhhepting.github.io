#version 300 es
// Blinn-Phong with L and H supplied as constants (directional light + viewer
// at infinity). Per-fragment work shrinks to one normalize, two dots and a pow.
precision highp float;

in vec3 vN;

uniform vec3 uLightDirEye;
uniform vec3 uHalfwayEye;
uniform vec4 uAmbientProduct;
uniform vec4 uDiffuseProduct;
uniform vec4 uSpecularProduct;
uniform float uShininess;

out vec4 fragColor;

void main() {
    vec3 N = normalize(vN);

    float NdotL = dot(uLightDirEye, N);
    float Kd = max(NdotL, 0.0);
    float Ks = pow(max(dot(N, uHalfwayEye), 0.0), uShininess);
    if (NdotL < 0.0) {
        Ks = 0.0;
    }

    vec3 rgb = uAmbientProduct.rgb + Kd * uDiffuseProduct.rgb + Ks * uSpecularProduct.rgb;
    fragColor = vec4(rgb, 1.0);
}
