#version 300 es
// Per-vertex ("Gouraud") lighting, evaluated in EYE space.
// Light position arrives already in eye coordinates (uLightEye).
// w = 0 -> directional light, w = 1 -> point light.
layout(location = 0) in vec3 aPosition;
layout(location = 1) in vec3 aNormal;

uniform mat4 uModelViewMatrix;
uniform mat4 uProjectionMatrix;
uniform mat3 uNormalMatrix;
uniform vec4 uLightEye;
uniform vec4 uAmbientProduct;
uniform vec4 uDiffuseProduct;
uniform vec4 uSpecularProduct;
uniform float uShininess;

out vec4 vColor;

void main() {
    vec4 eyePos = uModelViewMatrix * vec4(aPosition, 1.0);
    vec3 pos = eyePos.xyz;

    vec3 L = normalize(uLightEye.xyz - uLightEye.w * pos);
    vec3 E = normalize(-pos);
    vec3 H = normalize(L + E);
    vec3 N = normalize(uNormalMatrix * aNormal);

    float Kd = max(dot(L, N), 0.0);
    float Ks = pow(max(dot(N, H), 0.0), uShininess);
    if (dot(L, N) < 0.0) {
        Ks = 0.0;
    }

    vec3 rgb = uAmbientProduct.rgb + Kd * uDiffuseProduct.rgb + Ks * uSpecularProduct.rgb;
    vColor = vec4(rgb, 1.0);
    gl_Position = uProjectionMatrix * eyePos;
}
