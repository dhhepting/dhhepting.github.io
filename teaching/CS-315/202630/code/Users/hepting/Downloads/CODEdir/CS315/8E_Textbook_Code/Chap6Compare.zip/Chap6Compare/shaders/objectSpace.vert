#version 300 es
// Per-vertex lighting carried out in OBJECT space (shadedSphereObjectSpace).
// The CPU supplies the light and the eye position already expressed in object
// coordinates, so the shader never transforms the light, normal or position
// for lighting; the model-view matrix is needed only for gl_Position.
layout(location = 0) in vec3 aPosition;
layout(location = 1) in vec3 aNormal;

uniform mat4 uModelViewMatrix;
uniform mat4 uProjectionMatrix;
uniform vec4 uLightObj;
uniform vec3 uEyeObj;
uniform vec4 uAmbientProduct;
uniform vec4 uDiffuseProduct;
uniform vec4 uSpecularProduct;
uniform float uShininess;

out vec4 vColor;

void main() {
    vec3 L = normalize(uLightObj.xyz - uLightObj.w * aPosition);
    vec3 E = normalize(uEyeObj - aPosition);
    vec3 H = normalize(L + E);
    vec3 N = normalize(aNormal);

    float Kd = max(dot(L, N), 0.0);
    float Ks = pow(max(dot(N, H), 0.0), uShininess);
    if (dot(L, N) < 0.0) {
        Ks = 0.0;
    }

    vec3 rgb = uAmbientProduct.rgb + Kd * uDiffuseProduct.rgb + Ks * uSpecularProduct.rgb;
    vColor = vec4(rgb, 1.0);
    gl_Position = uProjectionMatrix * (uModelViewMatrix * vec4(aPosition, 1.0));
}
