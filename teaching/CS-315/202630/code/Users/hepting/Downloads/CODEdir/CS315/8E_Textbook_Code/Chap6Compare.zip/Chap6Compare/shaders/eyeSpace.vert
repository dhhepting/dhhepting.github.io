#version 300 es
// Per-vertex lighting carried out in EYE space (shadedSphereEyeSpace).
// Light position is given in OBJECT coordinates, so the light, the normal and
// the vertex all have to be pushed through the model-view matrix.
layout(location = 0) in vec3 aPosition;
layout(location = 1) in vec3 aNormal;

uniform mat4 uModelViewMatrix;
uniform mat4 uProjectionMatrix;
uniform vec4 uLightObj;
uniform vec4 uAmbientProduct;
uniform vec4 uDiffuseProduct;
uniform vec4 uSpecularProduct;
uniform float uShininess;

out vec4 vColor;

void main() {
    vec4 eyePos = uModelViewMatrix * vec4(aPosition, 1.0);
    vec3 pos = eyePos.xyz;

    vec3 lightEye = (uModelViewMatrix * uLightObj).xyz;
    vec3 L = normalize(lightEye - uLightObj.w * pos);
    vec3 E = normalize(-pos);
    vec3 H = normalize(L + E);
    // No non-uniform scaling here, so the model-view matrix can transform normals.
    vec3 N = normalize((uModelViewMatrix * vec4(aNormal, 0.0)).xyz);

    float Kd = max(dot(L, N), 0.0);
    float Ks = pow(max(dot(N, H), 0.0), uShininess);
    if (dot(L, N) < 0.0) {
        Ks = 0.0;
    }

    vec3 rgb = uAmbientProduct.rgb + Kd * uDiffuseProduct.rgb + Ks * uSpecularProduct.rgb;
    vColor = vec4(rgb, 1.0);
    gl_Position = uProjectionMatrix * eyePos;
}
