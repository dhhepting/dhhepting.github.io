#version 300 es
// Per-fragment lighting with the true Phong specular term:
// specular = (R . E)^shininess, R = L reflected about N.
precision highp float;

in vec3 vN;
in vec3 vL;
in vec3 vE;

uniform vec4 uAmbientProduct;
uniform vec4 uDiffuseProduct;
uniform vec4 uSpecularProduct;
uniform float uShininess;

out vec4 fragColor;

void main() {
    vec3 N = normalize(vN);
    vec3 L = normalize(vL);
    vec3 E = normalize(vE);
    vec3 R = reflect(-L, N);

    float Kd = max(dot(L, N), 0.0);
    float Ks = pow(max(dot(R, E), 0.0), uShininess);
    if (dot(L, N) < 0.0) {
        Ks = 0.0;
    }

    vec3 rgb = uAmbientProduct.rgb + Kd * uDiffuseProduct.rgb + Ks * uSpecularProduct.rgb;
    fragColor = vec4(rgb, 1.0);
}
