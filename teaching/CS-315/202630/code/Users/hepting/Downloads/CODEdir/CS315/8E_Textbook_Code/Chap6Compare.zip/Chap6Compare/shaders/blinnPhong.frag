#version 300 es
// Per-fragment lighting with the halfway vector: specular = (N . H)^shininess.
// This is the model used by shadedSphere2/4 and shadedCube in the textbook
// (it is what the book calls the "modified Phong" model).
precision highp float;

in vec3 vN;
in vec3 vL;
in vec3 vE;

uniform vec4 uAmbientProduct;
uniform vec4 uDiffuseProduct;
uniform vec4 uSpecularProduct;
uniform float uShininess;

out vec4 fragColor;

void main() {
    // Interpolation shortens vectors, so renormalise.
    vec3 N = normalize(vN);
    vec3 L = normalize(vL);
    vec3 E = normalize(vE);
    vec3 H = normalize(L + E);

    float Kd = max(dot(L, N), 0.0);
    float Ks = pow(max(dot(N, H), 0.0), uShininess);
    if (dot(L, N) < 0.0) {
        Ks = 0.0;
    }

    vec3 rgb = uAmbientProduct.rgb + Kd * uDiffuseProduct.rgb + Ks * uSpecularProduct.rgb;
    fragColor = vec4(rgb, 1.0);
}
