#version 300 es
// Vertex half for the "hoisted" Blinn-Phong variant. L and H are constant for
// a directional light and an infinitely distant viewer, so they are uniforms
// computed once on the CPU; only the normal still varies.
layout(location = 0) in vec3 aPosition;
layout(location = 1) in vec3 aNormal;

uniform mat4 uModelViewMatrix;
uniform mat4 uProjectionMatrix;
uniform mat3 uNormalMatrix;

out vec3 vN;

void main() {
    vN = normalize(uNormalMatrix * aNormal);
    gl_Position = uProjectionMatrix * (uModelViewMatrix * vec4(aPosition, 1.0));
}
