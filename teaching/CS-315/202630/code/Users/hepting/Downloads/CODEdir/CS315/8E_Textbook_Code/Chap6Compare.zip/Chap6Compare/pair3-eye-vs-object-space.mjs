// shadedSphereEyeSpace vs shadedSphereObjectSpace: the same per-vertex
// lighting, computed in two different coordinate systems.
import { CompareApp } from './lib/CompareApp.mjs';

new CompareApp(document.getElementById('app'), {
    title: 'Lighting in eye space vs object space',
    summary:
        'Both canvases use per-vertex lighting with vertex normals and should produce the same picture. <strong>shadedSphereEyeSpace</strong> (left) transforms the ' +
        'vertex, the normal and the light into eye coordinates for every vertex. <strong>shadedSphereObjectSpace</strong> (right) instead has the CPU express the ' +
        'light and the eye position in object coordinates once per frame, so the vertex shader does the lighting on the raw vertex data.',
    shaders: ['eyeSpace.vert', 'objectSpace.vert', 'passColor.frag'],
    mesh: { kinds: ['sphere'], normalMode: 'vertex' },
    defaults: { subdiv: 4, lightFrame: 'world', lightType: 'point', lightX: 2, lightY: 2, lightZ: 2, spin: false, orbit: true },
    panes: [
        {
            title: 'shadedSphereEyeSpace',
            subtitle: 'lighting computed in eye space',
            sources: () => ({ vert: 'eyeSpace.vert', frag: 'passColor.frag' }),
        },
        {
            title: 'shadedSphereObjectSpace',
            subtitle: 'lighting computed in object space',
            sources: () => ({ vert: 'objectSpace.vert', frag: 'passColor.frag' }),
        },
    ],
    notes: [
        {
            heading: 'What to look for',
            html: `
<p>The difference image should stay essentially black (differences of 1/255 or so are rounding). Lighting is geometry: it does not matter which coordinate system you
do the dot products in, as long as every vector is expressed in the same one. What changes is <em>how much work</em> the GPU does to get there.</p>
<ul>
<li><strong>Eye space</strong> needs the light, the normal and the position all multiplied by the model-view matrix inside the vertex shader, for every vertex. The eye is conveniently at the origin, so <code>E = −normalize(pos)</code>.</li>
<li><strong>Object space</strong> needs no per-vertex transforms for lighting. The price is a little CPU work per frame: invert the model-view matrix, then use it to carry the light and the eye position back into object coordinates. The model-view matrix is still needed for <code>gl_Position</code>.</li>
<li><strong>Try:</strong> turn on <em>Spin the object</em>. The CPU recomputes the object-space light each frame, and the two sides still agree, so the object-space light direction is genuinely changing relative to the mesh.</li>
<li>Switch <em>Light is fixed to</em> between the camera and the world to see the lighting stay with the viewer or with the scene. Both sides follow either rule identically.</li>
</ul>
<p>The textbook’s object-space sample uses <code>normalize(eyePosition)</code> as the viewer direction, which assumes a viewer at infinity. This version uses <code>normalize(eyePosition − position)</code>, matching the eye-space version exactly so the two can be compared pixel for pixel.</p>`,
        },
    ],
}).start();
