// shadedCubeHalfway, extended: true Phong (R . E) vs modified Blinn-Phong (N . H).
import { CompareApp } from './lib/CompareApp.mjs';

new CompareApp(document.getElementById('app'), {
    title: 'Phong vs modified Blinn-Phong shading',
    summary:
        'Both canvases shade per fragment with the same diffuse term; only the specular term differs. ' +
        '<strong>Phong</strong> (left) reflects the light about the normal and compares that with the eye direction, (R·E)<sup>n</sup>. ' +
        '<strong>Modified Blinn-Phong</strong> (right) uses the halfway vector H = normalize(L + E), (N·H)<sup>n′</sup>, with the exponent scaled so highlights come out a similar size.',
    shaders: [
        'perFragment.vert', 'phong.frag', 'blinnPhong.frag',
        'perFragmentNormalOnly.vert', 'blinnPhongHoisted.frag',
    ],
    mesh: { kinds: ['cube', 'sphere'], normalMode: 'vertex' },
    defaults: {
        mesh: 'cube', shininess: 100, lightType: 'point', lightFrame: 'camera',
        lightX: 1, lightY: 1, lightZ: 1, projection: 'persp',
    },
    extraControls: [
        {
            id: 'blinnScale', type: 'range', label: 'Blinn-Phong exponent multiplier', min: 1, max: 8, step: 0.5, value: 4,
            hint: 'The angle between N and H is about half the angle between R and E, so n′ ≈ 4n gives a comparable highlight. Set to 1 to use the same exponent on both.',
        },
        {
            id: 'hoist', type: 'checkbox', value: false,
            label: 'Hoist L and H out of the fragment shader',
            hint: 'Valid only for a directional light and an orthographic view, so those controls lock while this is on. The right-hand shader then receives L and H as constants.',
        },
    ],
    constrain(state) {
        if (!state.hoist) return [];
        state.lightType = 'directional';
        state.projection = 'ortho';
        return ['lightType', 'projection'];
    },
    panes: [
        {
            title: 'Phong',
            subtitle: 'specular = (R · E)^n',
            sources: () => ({ vert: 'perFragment.vert', frag: 'phong.frag' }),
        },
        {
            title: 'Modified Blinn-Phong',
            subtitle: 'specular = (N · H)^n′',
            sources: (state) => (state.hoist
                ? { vert: 'perFragmentNormalOnly.vert', frag: 'blinnPhongHoisted.frag' }
                : { vert: 'perFragment.vert', frag: 'blinnPhong.frag' }),
            uniforms: (state) => ({ uShininess: state.shininess * state.blinnScale }),
        },
    ],
    notes: [
        {
            heading: 'What to look for',
            html: `
<ul>
<li><strong>Highlight shape.</strong> At glancing angles the Blinn-Phong highlight stretches into an ellipse while the Phong highlight stays rounder. Use a point light, the cube, and rotate until a face is seen at a grazing angle.</li>
<li><strong>Exponent.</strong> At multiplier 1 the Blinn-Phong highlight is much larger than the Phong one. At 4 they are close near the centre and drift apart toward the edges. The difference image shows where.</li>
<li><strong>Sphere.</strong> Switch the object to the sphere to see both models on a curved surface.</li>
</ul>`,
        },
        {
            heading: 'What it costs',
            html: `
<p>Read the table above. Counted in per-fragment operations, the two models are almost the same size: Phong needs <code>reflect</code>, while Blinn-Phong needs one more <code>normalize</code> to build H. Blinn-Phong’s reputation for being cheaper comes from a special case.</p>
<p>When the light is directional and the viewer is at infinity, L, E and therefore H are the same for every pixel, so H can be computed once on the CPU. Tick <em>Hoist L and H</em> and the right-hand shader loses its L and E varyings and three of its four per-pixel normalizes. Phong cannot do this, because R = reflect(−L, N) depends on N and so must be recomputed for each pixel.</p>
<p>Switching the hoist on also changes the viewer model on the right to a true infinite viewer (E = +z), while the left keeps its eye-at-the-origin vector. The difference image therefore shows both effects together, which is what a real renderer that adopted this optimisation would see.</p>`,
        },
    ],
}).start();
